# TNAP-30865 - apply the complete alert migration to a portal-ui checkout.
# Usage (PowerShell, from the folder that contains this script):
#   .\apply.ps1 -RepoRoot C:\path\to\portal-ui
param([Parameter(Mandatory = $true)][string]$RepoRoot)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not (Test-Path (Join-Path $RepoRoot 'package.json'))) { throw "No package.json in $RepoRoot" }

# 1. Copy every migrated file over the checkout (overwrite, don't merge).
$src = Join-Path $here 'files'
Get-ChildItem $src -Recurse -File | ForEach-Object {
  $rel = $_.FullName.Substring($src.Length + 1)
  $dest = Join-Path $RepoRoot $rel
  New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
  Copy-Item $_.FullName $dest -Force
}
Write-Host "Copied migrated files."

# 2. Delete the legacy alert module and pipe.
Get-Content (Join-Path $here 'DELETED_FILES.txt') | Where-Object { $_ } | ForEach-Object {
  $p = Join-Path $RepoRoot $_
  if (Test-Path $p) { Remove-Item $p -Force; Write-Host "Deleted $_" }
}
$dir = Join-Path $RepoRoot 'src\app\modules\alerting'
if ((Test-Path $dir) -and -not (Get-ChildItem $dir -Recurse -File)) { Remove-Item $dir -Recurse -Force }

# 3. Report anything still on the old API.
$left = Get-ChildItem (Join-Path $RepoRoot 'src') -Recurse -Include *.ts |
  Select-String -Pattern "modules/alerting|createSuccessAlert|createErrorAlert|createWarningAlert|\bAlertService\b|'AlertService'"
if ($left) { Write-Warning "Still on the old alert API:"; $left | ForEach-Object { Write-Host "  $($_.Path):$($_.LineNumber)" } }
else { Write-Host "No old alert references left." }
