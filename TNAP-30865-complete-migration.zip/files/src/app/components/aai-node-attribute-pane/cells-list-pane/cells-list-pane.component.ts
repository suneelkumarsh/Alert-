/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */
import {
  Component,
  computed,
  DestroyRef,
  EventEmitter,
  inject,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { exhaustMap, filter, map, switchMap, take } from 'rxjs/operators';
import {
  CellRuListResponse,
  CellRuResponse,
  PnfsService,
  ServiceInstancesService,
} from 'openapi/output';
import { BehaviorSubject, EMPTY, Observable } from 'rxjs';
import { AuthService, HasPermissionPipe } from '@portal-mfe/auth';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { HistoryService } from '../../../services/history.service';
import { ActionType, EntityType } from '../../../model/user-last-action.model';
import { ConfirmationModalComponent } from 'src/app/components/shared/confirmation-modal/confirmation-modal.component';
import { CellsListColumnName } from 'src/app/model/cell.model';
import { Router } from '@angular/router';
import { QueryParamService } from '../../../services/query-param.service';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { ColumnDefinition } from '@portal-mfe/tnap-ui-kit/components/data-table';
import { Sort, SortDirection } from '@portal-mfe/tnap-ui-kit/components/sort';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';
@Component({
  selector: 'app-cells-list-pane',
  templateUrl: './cells-list-pane.component.html',
  providers: [HasPermissionPipe],
  standalone: false,
})
export class CellListPaneComponent implements OnInit {
  ColumnName = CellsListColumnName;
  columnNames: string[] = Object.entries(this.ColumnName).map(
    entry => entry[1]
  );

  readonly permissions = inject(PERMISSIONS_TOKEN);

  readonly baseColumns = computed<ColumnDefinition<CellRuResponse>[]>(() => {
    this.lang();
    return [
      {
        key: CellsListColumnName.SITE,
        label: this.translateService.instant('topology.labels.cell.siteId'),
        classes: 'qa_cell_siteId_header',
        value: row => row.siteId ?? '',
        sorting: { enabled: true },
      },
      {
        key: CellsListColumnName.NAME,
        label: this.translateService.instant('topology.labels.cell.cellName'),
        classes: 'qa_cell_cellName_header',
        value: row => row.cellName ?? '',
        sorting: { enabled: true },
      },
      {
        key: CellsListColumnName.AZIMUTH,
        label: this.translateService.instant('topology.labels.cell.azimuth'),
        classes: 'qa_cell_azimuth_header',
        value: row => row.azimuth ?? '',
        sorting: { enabled: true },
      },
      {
        key: CellsListColumnName.LOCAL_ID,
        label: this.translateService.instant(
          'topology.labels.cell.cellLocalId'
        ),
        classes: 'qa_cell_cellLocalId_header',
        value: row => row.cellLocalId ?? '',
        sorting: { enabled: true },
      },
      {
        key: CellsListColumnName.FREQUENCY,
        label: this.translateService.instant(
          'topology.labels.cell.frequencyBand'
        ),
        classes: 'qa_cell_frequencyBand_header',
        value: row => row.frequencyBand ?? '',
        sorting: { enabled: true },
      },
      {
        key: CellsListColumnName.STATUS,
        label: this.translateService.instant(
          'activeAvailableInventory.map.cellStatus'
        ),
        classes: 'qa_cell_cellStatus_header',
        value: row => row.ru ?? '',
        sorting: { enabled: true },
      },
      {
        key: CellsListColumnName.RU,
        label: this.translateService.instant('treeview.imgText.ru'),
        classes: 'qa_cell_ru_header',
        value: row => row.ru ?? '',
        sorting: { enabled: true },
      },
      {
        key: CellsListColumnName.ID,
        label: this.translateService.instant('topology.labels.cell.cellId'),
        classes: 'qa_cell_cellId_header',
        value: row => row.cellId ?? '',
        sorting: { enabled: true },
      },
      {
        key: 'actions',
        label: this.translateService.instant('topology.labels.cell.redirect'),
        classes: 'qa_cell_redirect_header',
        value: () => '',
      },
    ];
  });

  SortDirection = SortDirection;
  @Input() nodeId: string | undefined;
  @Output() selectedCell = new EventEmitter<CellRuResponse | undefined>();

  private readonly pnfsService = inject(PnfsService);
  private readonly authService = inject(AuthService);
  private readonly serviceInstancesService = inject(ServiceInstancesService);
  private readonly alertService = inject(TnapAlertService);
  private readonly historyService = inject(HistoryService);
  private readonly translateService = inject(TranslateService);
  private readonly modalService = inject(NgbModal);
  private readonly router = inject(Router);
  private readonly queryParamService = inject(QueryParamService);
  private readonly destroyRef$ = inject(DestroyRef);
  private readonly hasPermissionPipe = inject(HasPermissionPipe);
  private readonly lang = toSignal(this.translateService.onLangChange);
  private readonly showRuColumn = toSignal(
    this.hasPermissionPipe.transform(this.permissions.HIDE_RU_COLUMN),
    { initialValue: false }
  );

  private readonly showOperatorColumn = toSignal(
    this.hasPermissionPipe.transform(this.permissions.VIEW_CELL_OPERATOR),
    { initialValue: false }
  );

  private readonly showSiteColumn = toSignal(
    this.hasPermissionPipe.transform(this.permissions.VIEW_CELL_SITE_COLUMN),
    { initialValue: false }
  );

  private readonly showAzimuthColumn = toSignal(
    this.hasPermissionPipe.transform(this.permissions.VIEW_CELL_AZIMUTH_COLUMN),
    { initialValue: false }
  );

  private readonly showMapColumn = toSignal(
    this.hasPermissionPipe.transform(this.permissions.VIEW_CELL_MAP_COLUMN),
    { initialValue: false }
  );

  readonly CELLS_LIST_COLUMNS = computed(() => {
    const columns = this.baseColumns().filter(column => {
      if (column.key === CellsListColumnName.RU && !this.showRuColumn()) {
        return false;
      }
      if (column.key === CellsListColumnName.SITE && !this.showSiteColumn()) {
        return false;
      }
      if (
        column.key === CellsListColumnName.AZIMUTH &&
        !this.showAzimuthColumn()
      ) {
        return false;
      }
      if (column.key === 'actions' && !this.showMapColumn()) {
        return false;
      }
      return true;
    });

    if (this.showOperatorColumn()) {
      const operatorColumn: ColumnDefinition<CellRuResponse> = {
        key: CellsListColumnName.OWNER,
        label: this.translateService.instant('topology.labels.cell.operator'),
        classes: 'qa_cell_operator_header',
        value: row => row.cellOwner ?? '',
        sorting: { enabled: true },
      };

      const cellIdIndex = columns.findIndex(
        column => column.key === CellsListColumnName.ID
      );

      columns.splice(cellIdIndex + 1, 0, operatorColumn);
    }

    return columns;
  });

  public cells$: Observable<CellRuListResponse> =
    new Observable<CellRuListResponse>();
  public selectedCell$: BehaviorSubject<CellRuResponse | undefined> =
    new BehaviorSubject<CellRuResponse | undefined>(undefined);
  public loggedUserId$ = this.authService.getLoggedUserId();

  readonly sort$ = this.queryParamService.getValueOf('sort').pipe(
    map(sort => {
      if (!sort) {
        return {
          parameter: '',
          direction: SortDirection.NONE,
        };
      }

      const [parameter, direction] = sort.split(',');

      return {
        parameter,
        direction: direction as SortDirection,
      };
    })
  );
  public sortedCellsData$ = new Observable<CellRuResponse[] | undefined>();

  ngOnInit(): void {
    if (!this.nodeId) {
      return;
    }

    this.selectedCell$
      .pipe(takeUntilDestroyed(this.destroyRef$))
      .subscribe(cell => {
        this.selectedCell.emit(cell);
      });

    this.cells$ = this.serviceInstancesService.listCellsByServiceInstance(
      this.nodeId
    );

    this.sortedCellsData$ = this.sort$.pipe(
      switchMap(sortValue =>
        this.cells$.pipe(
          map(cells =>
            cells ? this.sortCells([...cells.items], sortValue) : undefined
          )
        )
      )
    );
  }

  public openModalRebootCell(cell: CellRuResponse): void {
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalRef.componentInstance.okText = this.translateService.instant(
      'topology.labels.cell.reboot'
    );
    modalRef.componentInstance.title = this.translateService.instant(
      'topology.labels.cell.modal.reboot.title'
    );
    modalRef.componentInstance.text = this.translateService.instant(
      'topology.labels.cell.modal.reboot.text',
      {
        cellName: cell.ru,
      }
    );

    modalRef.closed
      .pipe(
        takeUntilDestroyed(this.destroyRef$),
        switchMap((confirm: boolean) => {
          if (confirm) {
            this.loggedUserId$
              .pipe(
                take(1),
                filter((userName): userName is string => !!userName),
                exhaustMap(userName => {
                  return this.pnfsService
                    .rebootPnf(cell.cellName, {
                      jobName: `reboot_${Date.now()}`,
                      userName,
                    })
                    .pipe(
                      switchMap(() =>
                        this.historyService.createRuRebootHistoryAction({
                          type: ActionType.REBOOT,
                          entity: EntityType.PNF,
                          entityParams: { pnfName: cell.ru, userName },
                        })
                      )
                    );
                }),
                take(1)
              )
              .subscribe(
                () =>
                  this.alertService.success(
                    this.translateService.instant(
                      'topology.labels.cell.modal.reboot.messages.success',
                      {
                        cellName: cell.ru,
                      }
                    ),
                    { keepAfterRouteChange: true }
                  ),
                () => {
                  this.alertService.error(
                    this.translateService.instant(
                      'topology.labels.cell.modal.reboot.messages.error',
                      {
                        cellName: cell.ru,
                      }
                    ),
                    { keepAfterRouteChange: true }
                  );
                }
              );
          }
          return EMPTY;
        })
      )
      .subscribe();
  }

  public changeSelectedCell(
    cell: CellRuResponse,
    selectedCell: CellRuResponse | null | undefined
  ) {
    if (cell === selectedCell) {
      this.selectedCell$.next(undefined);
      return;
    }
    this.selectedCell$.next(cell);
  }

  public onSortChange(sort: Sort): void {
    this.router.navigate([], {
      queryParams: {
        sort:
          sort.direction === SortDirection.NONE
            ? null
            : `${sort.parameter},${sort.direction}`,
      },
      queryParamsHandling: 'merge',
    });
  }
  readonly currentSort = toSignal(this.sort$, {
    initialValue: {
      parameter: '',
      direction: SortDirection.NONE,
    },
  });

  private sortCells(
    cells: CellRuResponse[],
    sortValue: Sort
  ): CellRuResponse[] {
    if (sortValue.direction === SortDirection.NONE || !sortValue.parameter) {
      return [...cells];
    }
    return cells.sort((cell1, cell2) => {
      const parameter = sortValue.parameter as keyof CellRuResponse;
      const direction = sortValue.direction;
      const value1 = cell1[parameter];
      const value2 = cell2[parameter];

      if (typeof value1 === 'number' && typeof value2 === 'number') {
        if (direction === SortDirection.ASC) {
          return value1 - value2;
        } else if (direction === SortDirection.DESC) {
          return value2 - value1;
        }
      }

      if (typeof value1 === 'string' && typeof value2 === 'string') {
        if (direction === SortDirection.ASC) {
          return value1.localeCompare(value2);
        } else if (direction === SortDirection.DESC) {
          return value2.localeCompare(value1);
        }
      }

      return 0;
    });
  }
}
