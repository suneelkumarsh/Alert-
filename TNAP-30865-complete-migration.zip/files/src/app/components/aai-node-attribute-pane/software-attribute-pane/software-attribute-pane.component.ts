/*
 * Copyright (c) 2022. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, inject, Input } from '@angular/core';
import {
  SoftwareManagementService,
  SoftwarePackageResponse,
} from 'openapi/output';
import { environment } from 'src/environments/environment';
import { exhaustMap, filter, switchMap, take } from 'rxjs/operators';
import { AuthService } from '@portal-mfe/auth';
import { of } from 'rxjs';
import { TreeviewFinalModel } from 'src/app/model/treeview.model';
import { ActionType, EntityType } from 'src/app/model/user-last-action.model';
import { HistoryService } from 'src/app/services/history.service';
import { TranslateService } from '@ngx-translate/core';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';
@Component({
  selector: 'app-software-attribute-pane',
  templateUrl: './software-attribute-pane.component.html',
  styleUrls: ['./software-attribute-pane.component.css'],
  standalone: false,
})
export class SoftwareAttributePaneComponent {
  private nodeForUpdate!: TreeviewFinalModel;

  get node(): TreeviewFinalModel {
    return this.nodeForUpdate;
  }
  @Input() set node(value: TreeviewFinalModel) {
    this.nodeForUpdate = value;
  }
  public selectedSoftware: SoftwarePackageResponse | undefined;
  public readonly dateTimeFormat = environment.dateTimeFormat;
  public software$ = this.swManagementService.listSwPackages();
  public loggedUserId$ = this.authService.getLoggedUserId();
  readonly permissions = inject(PERMISSIONS_TOKEN);

  constructor(
    private readonly swManagementService: SoftwareManagementService,
    private readonly authService: AuthService,
    private readonly historyService: HistoryService,
    private readonly alertService: TnapAlertService,
    private readonly translateService: TranslateService
  ) {}

  public changeSelectedSoftware(software: SoftwarePackageResponse) {
    if (software === this.selectedSoftware) {
      this.selectedSoftware = undefined;
    } else {
      this.selectedSoftware = software;
    }
  }

  public changeSw(): void {
    this.loggedUserId$
      .pipe(
        filter((userName): userName is string => !!userName),
        exhaustMap(userName => {
          const nodeName = String(this.node.model?.pnfName);
          if (this.selectedSoftware && nodeName) {
            return this.swManagementService
              .executeSwJob({
                jobName: `${this.selectedSoftware.packageName}_${Date.now()}`,
                userName,
                nodeList: [nodeName],
                workflowList: [
                  {
                    sw_upgrade: {
                      sftp_upgrade_package_path:
                        this.selectedSoftware.pathDetails,
                    },
                  },
                ],
              })
              .pipe(
                switchMap(() =>
                  this.historyService.createSwManagementHistoryAction({
                    type: ActionType.UPGRADE,
                    entity: EntityType.SWMANAGEMENT,
                    entityParams: {
                      userId: userName,
                      packageName: this.selectedSoftware?.packageName || '',
                      nodeName,
                    },
                  })
                )
              );
          }
          return of(null);
        }),
        take(1)
      )
      .subscribe(() =>
        this.alertService.success(
          this.translateService.instant(
            'swManagement.messages.success.upgrade'
          ),
          { keepAfterRouteChange: true }
        )
      );
  }
}
