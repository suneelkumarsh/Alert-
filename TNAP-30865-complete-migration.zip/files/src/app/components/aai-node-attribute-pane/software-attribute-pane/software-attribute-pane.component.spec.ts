/*
 * Copyright (c) 2023. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SoftwareAttributePaneComponent } from './software-attribute-pane.component';
import { of } from 'rxjs';
import { ActionType, EntityType } from '../../../model/user-last-action.model';
import {
  ActionsResponse,
  SoftwareManagementService,
  SoftwarePackageResponse,
} from '../../../../../openapi/output';
import {
  AuthService,
  KEYCLOAK_HOSTNAME,
  KEYCLOAK_REALM,
  RBAC_BACKENDS,
} from '@portal-mfe/auth';
import { HistoryService } from '../../../services/history.service';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import {
  HttpResponse,
  provideHttpClient,
  withInterceptorsFromDi,
} from '@angular/common/http';
import {
  AuthConfig,
  OAuthLogger,
  OAuthModule,
  OAuthService,
  OAuthStorage,
} from 'angular-oauth2-oidc';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthConfigService } from '../../../services/authconfig.service';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('SoftwareAttributePaneComponent', () => {
  let component: SoftwareAttributePaneComponent;
  let fixture: ComponentFixture<SoftwareAttributePaneComponent>;
  let swManagementService: SoftwareManagementService;
  let historyService: HistoryService;
  let alertService: TnapAlertService;
  let translateService: TranslateService;
  let oauthService: OAuthService;
  const userName = 'user';
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SoftwareAttributePaneComponent],
      imports: [
        OAuthModule.forRoot(),
        RouterTestingModule,
        TranslateModule.forRoot(),
      ],
      providers: [
        SoftwareManagementService,
        AuthService,
        OAuthService,
        HistoryService,
        AuthConfigService,
        {
          provide: TnapAlertService,
          useValue: jasmine.createSpyObj('TnapAlertService', [
            'success',
            'error',
          ]),
        },
        TranslateService,
        provideHttpClient(withInterceptorsFromDi()),
        { provide: PERMISSIONS_TOKEN, useValue: [] },
        { provide: OAuthStorage, useValue: localStorage },
        { provide: AuthConfig, useValue: {} },
        { provide: KEYCLOAK_REALM, useValue: '' },
        { provide: KEYCLOAK_HOSTNAME, useValue: '' },
        { provide: RBAC_BACKENDS, useValue: ['portal-bff'] },
        OAuthLogger,
      ],
    });

    fixture = TestBed.createComponent(SoftwareAttributePaneComponent);
    component = fixture.componentInstance;
    swManagementService = TestBed.inject(SoftwareManagementService);
    historyService = TestBed.inject(HistoryService);
    alertService = TestBed.inject(TnapAlertService);
    translateService = TestBed.inject(TranslateService);
    oauthService = TestBed.inject(OAuthService);
    spyOn(component['authService'], 'loadCachedUserProfile').and.returnValue(
      of({ sub: '' })
    );
    spyOn(oauthService, 'getIdentityClaims').and.returnValue({ sub: userName });
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should change selected software', () => {
    const software: SoftwarePackageResponse = {
      packageName: 'Package1',
      vendorCode: 'VendorCode1',
      vendorName: 'VendorName1',
      nodeType: 'NodeType1',
      pathType: 'PathType1',
      pathDetails: 'PathDetails1',
      modifyTime: 'ModifyTime1',
      modifyUser: 'ModifyUser1',
    };
    component.selectedSoftware = undefined as
      | SoftwarePackageResponse
      | undefined;

    component.changeSelectedSoftware(software);

    expect(component.selectedSoftware).toBe(software);
  });
  it('should remove software selection', () => {
    const software: SoftwarePackageResponse = {
      packageName: 'Package1',
      vendorCode: 'VendorCode1',
      vendorName: 'VendorName1',
      nodeType: 'NodeType1',
      pathType: 'PathType1',
      pathDetails: 'PathDetails1',
      modifyTime: 'ModifyTime1',
      modifyUser: 'ModifyUser1',
    };
    component.selectedSoftware = software as
      | SoftwarePackageResponse
      | undefined;

    component.changeSelectedSoftware(software);

    expect(component.selectedSoftware).toBe(undefined);
  });

  it('should change software successfully', () => {
    const PNF_NAME = 'test_pnf';
    const software: SoftwarePackageResponse = {
      packageName: 'Package1',
      vendorCode: 'VendorCode1',
      vendorName: 'VendorName1',
      nodeType: 'NodeType1',
      pathType: 'PathType1',
      pathDetails: 'PathDetails1',
      modifyTime: 'ModifyTime1',
      modifyUser: 'ModifyUser1',
    };

    component.selectedSoftware = software;
    spyOn(swManagementService, 'executeSwJob').and.returnValue(
      of(new HttpResponse())
    );
    const rsp: ActionsResponse = {
      action: {
        type: ActionType.UPGRADE,
        entity: EntityType.SWMANAGEMENT,
        entityParams: {
          userId: userName,
          packageName: software.packageName,
          nodeName: jasmine.any(String),
        },
      },
      actionCreatedAt: new Date().toISOString(),
      saveInterval: 1,
    };
    spyOn(historyService, 'createSwManagementHistoryAction').and.returnValue(
      of(rsp)
    );
    spyOn(translateService, 'instant').and.returnValue('Success Message');
    component.loggedUserId$ = of(userName);
    component.node = {
      model: { pnfName: 'test_pnf' },
      id: 'test_pnf',
      name: '',
    };
    component.changeSw();

    expect(swManagementService.executeSwJob).toHaveBeenCalledWith(
      jasmine.objectContaining({
        //jobName: `${software.packageName}_${jasmine.any(Number)}`,
        userName,
        nodeList: [PNF_NAME],
        workflowList: [
          {
            sw_upgrade: {
              sftp_upgrade_package_path: software.pathDetails,
            },
          },
        ],
      })
    );
    expect(historyService.createSwManagementHistoryAction).toHaveBeenCalledWith(
      {
        type: ActionType.UPGRADE,
        entity: EntityType.SWMANAGEMENT,
        entityParams: {
          userId: userName,
          packageName: software.packageName,
          nodeName: PNF_NAME,
        },
      }
    );
    expect(alertService.success).toHaveBeenCalledWith('Success Message', {
      keepAfterRouteChange: true,
    });
  });

  it('should not change software when selected software is undefined', () => {
    component.selectedSoftware = undefined;
    spyOn(swManagementService, 'executeSwJob');
    component.changeSw();

    expect(swManagementService.executeSwJob).not.toHaveBeenCalled();
  });
});
