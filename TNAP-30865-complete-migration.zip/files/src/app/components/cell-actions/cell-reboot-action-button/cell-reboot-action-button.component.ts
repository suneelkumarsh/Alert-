/*
 * Copyright (c) 2022. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, Input } from '@angular/core';
import { PnfsService } from '../../../../../openapi/output';
import { ConfirmationModalComponent } from '../../shared/confirmation-modal/confirmation-modal.component';
import { exhaustMap, filter, switchMap, take, takeUntil } from 'rxjs/operators';
import { ActionType, EntityType } from '../../../model/user-last-action.model';
import { EMPTY } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { UnsubscribeService } from '../../../services/unsubscribe/unsubscribe.service';
import { HistoryService } from '../../../services/history.service';
import { AuthService } from '@portal-mfe/auth';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-cell-reboot-action-button',
  templateUrl: './cell-reboot-action-button.component.html',
  styleUrls: ['./cell-reboot-action-button.component.css'],
  standalone: false,
})
export class CellRebootActionButtonComponent {
  @Input() cellName!: string;
  public loggedUserId$ = this.authService.getLoggedUserId();

  constructor(
    private readonly modalService: NgbModal,
    private readonly translateService: TranslateService,
    private readonly unsubscribeService: UnsubscribeService,
    private readonly pnfsService: PnfsService,
    private readonly historyService: HistoryService,
    private readonly authService: AuthService,
    private readonly alertService: TnapAlertService
  ) {}

  public openModalRebootCell(): void {
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalRef.componentInstance.okText = this.translateService.instant(
      'topology.labels.cell.reboot'
    );
    modalRef.componentInstance.title = this.translateService.instant(
      'topology.labels.cell.modal.reboot.title'
    );
    modalRef.componentInstance.text = this.translateService.instant(
      'topology.labels.cell.modal.reboot.text',
      {
        cellName: this.cellName,
      }
    );
    modalRef.closed
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap((confirm: boolean) => {
          if (confirm) {
            this.loggedUserId$
              .pipe(
                filter((userName): userName is string => !!userName),
                exhaustMap(userName => {
                  return this.pnfsService
                    .rebootPnf(this.cellName, {
                      jobName: `reboot_${Date.now()}`,
                      userName,
                    })
                    .pipe(
                      switchMap(() =>
                        this.historyService.createRuRebootHistoryAction({
                          type: ActionType.REBOOT,
                          entity: EntityType.PNF,
                          entityParams: { pnfName: this.cellName, userName },
                        })
                      )
                    );
                }),
                take(1)
              )
              .subscribe(
                () =>
                  this.alertService.success(
                    this.translateService.instant(
                      'topology.labels.cell.modal.reboot.messages.success',
                      {
                        cellName: this.cellName,
                      }
                    ),
                    { keepAfterRouteChange: true }
                  ),
                () => {
                  this.alertService.error(
                    this.translateService.instant(
                      'topology.labels.cell.modal.reboot.messages.error',
                      {
                        cellName: this.cellName,
                      }
                    ),
                    { keepAfterRouteChange: true }
                  );
                }
              );
          }
          return EMPTY;
        })
      )
      .subscribe();
  }
}
