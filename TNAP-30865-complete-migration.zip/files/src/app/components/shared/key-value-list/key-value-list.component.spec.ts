/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
} from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { Component } from '@angular/core';
import { StringifyPipe } from '../../../pipes/stringify.pipe';
import { SharedModule } from '../../../shared.module';
import { KeyValueListComponent } from './key-value-list.component';
import { of } from 'rxjs';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';
// Test-only host that projects a custom cell template
@Component({
  standalone: true,
  template: `
    <app-key-value-list [data]="data" [columns]="cols" view="horizontal">
      <ng-template
        appKvCell="a"
        let-row="row"
        let-key="key"
        let-header="header"
        let-value="value">
        <span class="custom-a"
          >{{ header }}: {{ key }}={{ value }} ({{ row?.a }})</span
        >
      </ng-template>
    </app-key-value-list>
  `,
  imports: [KeyValueListComponent, TranslateModule, SharedModule],
})
class HostProjectionComponent {
  data = { a: 42, extra: 'x' };
  cols = [{ key: 'a', custom: true, header: 'A-Header' }];
}

// Test-only host that demonstrates array rendering in the child template
@Component({
  standalone: true,
  template: `
    <app-key-value-list [data]="data" [columns]="cols" view="horizontal">
      <ng-template appKvCell="a" let-value="value">
        @if (Array.isArray(value)) {
          <span class="custom-array">{{ value.join(' – ') }}</span>
        } @else {
          <span class="custom-array">{{ value }}</span>
        }
      </ng-template>
    </app-key-value-list>
  `,
  imports: [KeyValueListComponent, TranslateModule, SharedModule],
})
class HostArrayJoinComponent {
  data = { a: [1, 2, 3] };
  cols = [{ key: 'a', custom: true }];
  protected readonly Array = Array;
}

describe('KeyValueListComponent', () => {
  let component: KeyValueListComponent;
  let fixture: ComponentFixture<KeyValueListComponent>;
  let fix: ComponentFixture<HostProjectionComponent>;
  let fixArray: ComponentFixture<HostArrayJoinComponent>;
  let alertServiceSpy: jasmine.SpyObj<TnapAlertService>;

  beforeEach(async () => {
    alertServiceSpy = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
    ]);

    await TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), KeyValueListComponent],
      providers: [{ provide: TnapAlertService, useValue: alertServiceSpy }],
    }).compileComponents();

    // host (for projected template test)
    fix = TestBed.createComponent(HostProjectionComponent);
    fix.detectChanges();

    fixArray = TestBed.createComponent(HostArrayJoinComponent);
    fixArray.detectChanges();

    // raw component (for VM / behavior tests)
    fixture = TestBed.createComponent(KeyValueListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    // Spy on private signal setter
    spyOn<any>(component['_raw'], 'set').and.callThrough();
    spyOn<any>(component, 'ensureObject').and.callThrough();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('normalizes columns and filters by presence; custom columns always included', () => {
    component.data = { a: 1, b: [2, 3] };
    component.columns = [
      'a',
      { key: 'b', header: 'Bee' },
      { key: 'c', header: 'See' },
      { key: 'customOnly', custom: true },
    ];
    fixture.detectChanges();

    const rows = component.displayed();
    expect(rows.map(r => r.header)).toEqual(['a', 'Bee', 'customOnly']);

    const rowA = rows.find(r => r.keys[0] === 'a')!;
    expect(rowA.isArray).toBe(false);
    expect(rowA.value).toBe(1);

    const rowB = rows.find(r => r.keys[0] === 'b')!;
    expect(rowB.isArray).toBe(true);
    expect(rowB.arr).toEqual([2, 3]);
  });

  it('renders horizontal list with <dt>/<dd> and stringified values', () => {
    component.view = 'horizontal';
    component.data = { a: 1, b: { x: 2 } };
    component.columns = ['a', 'b'];
    fixture.detectChanges();
    const host = fixture.nativeElement as HTMLElement;
    const dt = host.querySelector('dl.kv-list-horizontal dt.key');
    expect(dt).toBeTruthy();
    expect(dt!.textContent!.trim()).toBe('a');
    const valueSpan = host.querySelector(
      'dl.kv-list-horizontal .kv-row:nth-child(2) dd.value .value-text'
    ) as HTMLElement;
    expect(valueSpan).toBeTruthy();
    const text = valueSpan.textContent!.trim();
    const parsed = JSON.parse(text);
    expect(parsed).toEqual({ x: 2 });
  });

  it('shows <tnap-empty> when no displayed rows', () => {
    component.data = {};
    component.columns = ['missing'];
    fixture.detectChanges();

    const host = fixture.nativeElement as HTMLElement;
    expect(host.querySelector('tnap-empty')).toBeTruthy();
    expect(host.querySelector('dl.kv-list')).toBeFalsy();
  });

  it('renders vertical list with headers and values', () => {
    component.view = 'vertical';
    component.data = { a: 1, b: 2 };
    component.columns = ['a', 'b'];
    fixture.detectChanges();

    const host = fixture.nativeElement as HTMLElement;

    const dts = Array.from(
      host.querySelectorAll('dl.kv-list-vertical dt.key')
    ).map(el => el.textContent!.trim());

    expect(dts).toEqual(['a', 'b']);

    const dds = Array.from(
      host.querySelectorAll('dl.kv-list-vertical dd.value .value-text')
    ).map(el => el.textContent!.trim());

    expect(dds).toEqual(['1', '2']);
  });

  it('renders array values as joined text by default', () => {
    component.view = 'horizontal';
    component.data = { a: [1, 2, 3] };
    component.columns = ['a'];
    fixture.detectChanges();

    const host = fixture.nativeElement as HTMLElement;

    const span = host.querySelector(
      'dl.kv-list-horizontal dd.value .value-text'
    ) as HTMLElement;

    expect(span).toBeTruthy();

    const text = span.textContent!.trim();
    expect(text).toBe('1, 2, 3');
  });

  it('applies classes to dd.value and tooltip to dt.key (aria-label)', () => {
    component.data = { a: 1 };
    component.columns = [{ key: 'a', classes: 'highlight', tooltip: 'tip' }];
    fixture.detectChanges();

    const host = fixture.nativeElement as HTMLElement;
    const dd = host.querySelector('dd.value')!;
    const dt = host.querySelector('dt.key')!;

    expect(dd.classList.contains('highlight')).toBeTrue();
    expect(dt.getAttribute('aria-label')).toBe('a');
  });

  it('respects wordSliceUpperCount when truncating headers', () => {
    component.wordSliceUpperCount = 5;
    component.data = { a: 1 };
    component.columns = [{ key: 'a', header: 'abcdef' }];
    fixture.detectChanges();

    const host = fixture.nativeElement as HTMLElement;
    const span = host.querySelector('dt.key span') as HTMLElement;

    expect(span.textContent!.trim()).toMatch(/^abcde\s+\.\.\.$/);
  });

  it('supports columns with multiple keys (value array)', () => {
    component.data = { a: 1, b: 2 };
    component.columns = [{ key: ['a', 'b'] }];
    fixture.detectChanges();

    const rows = component.displayed();
    expect(rows.length).toBe(1);
    expect(rows[0].header).toBe('a');
    expect(rows[0].isArray).toBeTrue();
    expect(rows[0].arr).toEqual([1, 2]);
  });

  it('handles undefined columns gracefully (no rows)', () => {
    component.data = { a: 1 };
    component.columns = undefined as any;
    fixture.detectChanges();

    expect(component.displayed().length).toBe(0);
  });

  describe('showCopyIcon', () => {
    it('should default to false for a plain string column', () => {
      component.data = { a: 1 };
      component.columns = ['a'];
      fixture.detectChanges();

      expect(component.displayed()[0].showCopyIcon).toBe(false);
    });

    it('should carry through when explicitly set on an object column', () => {
      component.data = { a: 1 };
      component.columns = [{ key: 'a', showCopyIcon: true }];
      fixture.detectChanges();

      expect(component.displayed()[0].showCopyIcon).toBe(true);
    });

    it('should carry through in array-mode via the matching column config', () => {
      component.data = [['a', 1]];
      component.columns = [{ key: 'a', showCopyIcon: true }];
      fixture.detectChanges();

      expect(component.displayed()[0].showCopyIcon).toBe(true);
    });
  });

  describe('copyToClipboard', () => {
    beforeEach(() => {
      spyOn(navigator.clipboard, 'writeText').and.resolveTo();
    });

    it('should write the value to the clipboard', () => {
      component.copyToClipboard('48.36581');
      expect(navigator.clipboard.writeText).toHaveBeenCalledWith('48.36581');
    });

    it('should do nothing for null/undefined/empty values', () => {
      component.copyToClipboard(null);
      component.copyToClipboard(undefined);
      component.copyToClipboard('');
      expect(navigator.clipboard.writeText).not.toHaveBeenCalled();
    });

    it('should show a success alert after a successful copy', fakeAsync(() => {
      component.copyToClipboard('some-id');
      tick();

      expect(alertServiceSpy.success).toHaveBeenCalled();
      expect(alertServiceSpy.error).not.toHaveBeenCalled();
    }));

    it('should show an error alert after a failed copy', fakeAsync(() => {
      (navigator.clipboard.writeText as jasmine.Spy).and.rejectWith(
        new Error('denied')
      );

      component.copyToClipboard('some-id');
      tick();

      expect(alertServiceSpy.error).toHaveBeenCalled();
      expect(alertServiceSpy.success).not.toHaveBeenCalled();
    }));
  });

  //   // PIPE-LEVEL TESTS
  describe('FormatValuePipe', () => {
    const pipe = new StringifyPipe();

    it('stringifies primitives (matches pipe current behavior)', () => {
      expect(pipe.transform(null)).toBe('');
      expect(pipe.transform(true)).toBe(true);
      expect(pipe.transform(123)).toBe(123);
      expect(pipe.transform('abc')).toBe('abc');
    });

    it('stringifies objects as JSON (still valid JSON)', () => {
      const out = pipe.transform({ a: 1, b: [2, 3] });
      expect(typeof out).toBe('string');
      expect(JSON.parse(out as string)).toEqual({ a: 1, b: [2, 3] });
    });

    it('prints Date as quoted ISO (JSON string)', () => {
      const d = new Date('2020-01-02T03:04:05.000Z');
      const out = pipe.transform(d) as string;
      expect(out).toBe('"2020-01-02T03:04:05.000Z"');
    });

    it('prints Error via JSON.stringify (no enumerable props)', () => {
      const err = new Error('boom');
      expect(pipe.transform(err)).toBe('{}');
    });
  });

  // ✅ ARRAY INPUT
  it('should map array entries correctly without column config', () => {
    const raw = [
      ['name', 'John'],
      ['age', 30],
    ];

    component.data = raw;

    const result = component.displayed();

    expect(result.length).toBe(2);

    expect(result[0]).toEqual({
      id: 'name_0',
      keys: ['name'],
      header: 'name', // fallback
      value: 'John',
      isArray: false,
      arr: [],
      custom: false,
      showCopyIcon: false,
      classes: undefined,
      tooltip: undefined,
      rowObj: raw,
    });

    expect(result[1]).toEqual({
      id: 'age_1',
      keys: ['age'],
      header: 'age',
      value: 30,
      isArray: false,
      arr: [],
      custom: false,
      showCopyIcon: false,
      classes: undefined,
      tooltip: undefined,
      rowObj: raw,
    });
  });

  // ✅ STRING → JSON ARRAY
  it('should parse JSON string array and set it', () => {
    const input = JSON.stringify([['a', 1]]);

    component.data = input;

    expect(component['_raw'].set).toHaveBeenCalledWith([['a', 1]]);
  });

  // ✅ STRING → JSON OBJECT
  it('should parse JSON string object and call ensureObject', () => {
    const obj = { a: 1 };
    const input = JSON.stringify(obj);

    component.data = input;

    expect(component['ensureObject']).toHaveBeenCalledWith(obj);
    expect(component['_raw'].set).toHaveBeenCalledWith(obj);
  });

  // ✅ STRING → INVALID JSON
  it('should fallback to {} for invalid JSON string', () => {
    component.data = '{invalid-json';

    expect(component['_raw'].set).toHaveBeenCalledWith({});
  });

  // ✅ OBJECT INPUT
  it('should pass object through ensureObject', () => {
    const obj = { a: 10 };

    component.data = obj;

    expect(component['ensureObject']).toHaveBeenCalledWith(obj);
    expect(component['_raw'].set).toHaveBeenCalledWith(obj);
  });

  // ✅ NULL INPUT
  it('should handle null via ensureObject', () => {
    component.data = null;

    expect(component['ensureObject']).toHaveBeenCalledWith(null);
    expect(component['_raw'].set).toHaveBeenCalledWith({ value: null });
  });

  // ✅ PRIMITIVE INPUT
  it('should wrap primitive using ensureObject', () => {
    component.data = 123;

    expect(component['ensureObject']).toHaveBeenCalledWith(123);
    expect(component['_raw'].set).toHaveBeenCalledWith({ value: 123 });
  });

  // ✅ STRING JSON → PRIMITIVE
  it('should handle JSON string resolving to primitive', () => {
    component.data = '123';

    expect(component['ensureObject']).toHaveBeenCalledWith(123);
    expect(component['_raw'].set).toHaveBeenCalledWith({ value: 123 });
  });
  describe('unwrap()', () => {
    it('should return observable as-is', () => {
      const obs$ = of(123);

      const result = component.unwrap(obs$);

      expect(result).toBe(obs$);
    });

    it('should wrap non-observable into observable', done => {
      const result$ = component.unwrap(123);

      result$.subscribe(val => {
        expect(val).toBe(123);
        done();
      });
    });
  });
  describe('columns setter', () => {
    it('should normalize string column', () => {
      component.columns = ['name'];

      const cols = (component as any)._columns();

      expect(cols[0]).toEqual({
        keys: ['name'],
        header: 'name',
        custom: false,
        tooltip: undefined,
        showCopyIcon: false,
      });
    });

    it('should normalize object column', () => {
      component.columns = [{ key: ['a', 'b'], header: 'Test', custom: true }];

      const cols = (component as any)._columns();

      expect(cols[0]).toEqual({
        keys: ['a', 'b'],
        header: 'Test',
        custom: true,
        classes: undefined,
        tooltip: undefined,
        showCopyIcon: false,
      });
    });
  });
});
