/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Component,
  ContentChildren,
  Input,
  QueryList,
  TemplateRef,
  computed,
  signal,
  AfterContentInit,
  DestroyRef,
  inject,
} from '@angular/core';
import { CommonModule, NgTemplateOutlet } from '@angular/common';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { KeyValueCellDirective } from '../../../directives/key-value-cell.directive';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { JoinPipe } from '../../../pipes/join.pipe';
import { EmptyComponent } from '@portal-mfe/tnap-ui-kit/components/empty';
import { NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { StringifyPipe } from 'src/app/pipes/stringify.pipe';
import { isObservable, of } from 'rxjs';
import { copyToClipboardWithAlert } from 'src/app/helpers/clipboard.helper';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

type AnyObject = Record<string, unknown>;

export type ColumnDef =
  | string
  | {
      key: string | string[];
      header?: string;
      custom?: boolean;
      classes?: string;
      tooltip?: string;
      showCopyIcon?: boolean;
    };

export type KvCellContext = {
  $implicit: AnyObject;
  key: string;
  header: string;
  row: AnyObject;
  value: unknown;
};

@Component({
  selector: 'app-key-value-list',
  standalone: true,
  imports: [
    NgTemplateOutlet,
    TranslatePipe,
    JoinPipe,
    EmptyComponent,
    NgbTooltipModule,
    CommonModule,
    StringifyPipe,
  ],
  templateUrl: './key-value-list.component.html',
  styleUrls: ['./key-value-list.component.css'],
})
export class KeyValueListComponent implements AfterContentInit {
  private readonly _raw = signal<AnyObject | any[]>([]);
  orientation = signal<'horizontal' | 'vertical'>('horizontal');

  private readonly translateService = inject(TranslateService);
  private readonly alertService = inject(TnapAlertService);

  @ContentChildren(KeyValueCellDirective)
  private readonly cellDirs!: QueryList<KeyValueCellDirective>;
  private destroyRef = inject(DestroyRef);
  tplByKey: Record<string, TemplateRef<KvCellContext> | null> = {};
  readonly _wordSliceUpperCount = signal<number | undefined>(undefined);

  @Input() set data(value: unknown) {
    // If ARRAY
    if (Array.isArray(value)) {
      this._raw.set(value);
      return;
    }

    // If STRING → parse JSON
    if (typeof value === 'string') {
      try {
        const parsed = JSON.parse(value);

        if (Array.isArray(parsed)) {
          this._raw.set(parsed);
        } else {
          this._raw.set(this.ensureObject(parsed));
        }
      } catch {
        this._raw.set({});
      }
      return;
    }

    this._raw.set(this.ensureObject(value));
  }

  private readonly _columns = signal<
    {
      keys: string[];
      header: string;
      custom: boolean;
      classes?: string;
      tooltip?: string;
      showCopyIcon: boolean;
    }[]
  >([]);

  @Input() set columns(cols: ColumnDef[] | undefined) {
    const norm = (cols ?? []).map(c => {
      if (typeof c === 'string') {
        return {
          keys: [c] as string[],
          header: c,
          custom: false,
          tooltip: undefined,
          showCopyIcon: false,
        };
      }
      const keys = Array.isArray(c.key) ? [...c.key] : [c.key];
      return {
        keys,
        header: c.header ?? keys[0],
        custom: !!c.custom,
        classes: c.classes,
        tooltip: c.tooltip || undefined,
        showCopyIcon: !!c.showCopyIcon,
      };
    });
    this._columns.set(norm);
  }

  @Input() set view(v: 'horizontal' | 'vertical' | undefined) {
    if (v) this.orientation.set(v);
  }

  @Input() set wordSliceUpperCount(count: number | undefined) {
    if (count !== undefined && count >= 0) {
      this._wordSliceUpperCount.set(count);
    }
  }

  ngAfterContentInit() {
    this.rebuildTplMap();
    this.cellDirs.changes
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => this.rebuildTplMap());
  }

  private getValue(obj: any, path: string): any {
    return path.split('.').reduce((acc, key) => {
      return acc ? acc[key] : undefined;
    }, obj);
  }

  private rebuildTplMap() {
    const map: Record<string, TemplateRef<KvCellContext> | null> = {};
    this.cellDirs?.forEach(d => (map[d.key] = d.tpl));
    // replacing reference so CD sees the change
    this.tplByKey = map;
  }
  displayed = computed(() => {
    const raw = this._raw();

    // ARRAY
    if (Array.isArray(raw)) {
      return raw.map(([key, value], index) => {
        const col = this._columns().find(c => c.keys.includes(key));

        return {
          id: `${key}_${index}`, // unique id
          keys: [key],
          header: col?.header ?? key,
          value,
          isArray: Array.isArray(value),
          arr: Array.isArray(value) ? value : [],
          custom: col?.custom ?? false,
          classes: col?.classes,
          tooltip: col?.tooltip,
          showCopyIcon: col?.showCopyIcon ?? false,
          rowObj: raw,
        };
      });
    }

    // OBJECT
    return this._columns()
      .filter(
        c => c.custom || c.keys.some(k => this.getValue(raw, k) !== undefined)
      )
      .map(c => {
        const values = c.keys.map(k => this.getValue(raw, k));

        const single = values.length === 1 ? values[0] : values;
        return {
          id: c.keys.join('|'),
          keys: c.keys,
          header: c.header,
          value: single,
          isArray: Array.isArray(single),
          arr: Array.isArray(single) ? single : [],
          custom: c.custom,
          classes: c.classes,
          tooltip: c.tooltip,
          showCopyIcon: c.showCopyIcon,
          rowObj: raw,
        };
      });
  });

  unwrap(value: any) {
    return isObservable(value) ? value : of(value);
  }

  copyToClipboard(value: unknown): void {
    if (value === null || value === undefined || value === '') {
      return;
    }
    copyToClipboardWithAlert(
      String(value),
      this.alertService,
      this.translateService
    );
  }

  private ensureObject(v: unknown): AnyObject {
    if (v && typeof v === 'object' && !Array.isArray(v)) return v as AnyObject;
    return { value: v as unknown };
  }
}
