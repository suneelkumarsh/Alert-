/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { inject, Injectable, signal } from '@angular/core';
import { HttpContext, HttpEventType } from '@angular/common/http';
import { TranslateService } from '@ngx-translate/core';
import { FileSaverService } from 'ngx-filesaver';
import { finalize } from 'rxjs';
import { S3StorageService } from '../../../../openapi/output/api/s3Storage.service';
import { RanFilter } from '../../../../openapi/output/model/ranFilter.model';
import { SKIP_GLOBAL_LOADING } from '../../http-interceptors/loading-indicator.interceptor';
import { RanFilterService } from './ran-filter.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

/** S3 bucket that holds the exported RAN filter results. */
export const RAN_FILTER_EXPORT_BUCKET = 'filter';

const MESSAGE_PREFIX = 'ranFilter.list.messages.';

/** Transfer state of a running download. `total` requires a Content-Length response header. */
export interface DownloadProgress {
  loaded: number;
  total?: number;
  percent?: number;
}

/**
 * Runs the long-running RAN filter export and download operations.
 *
 * Both operations can take minutes, so they deliberately bypass the global
 * loading indicator and report progress through alerts instead. The service is
 * root-provided and does not tie its subscriptions to a component lifecycle, so
 * a running transfer survives navigation to another page.
 */
@Injectable({ providedIn: 'root' })
export class RanFilterExportService {
  private readonly ranFilterService = inject(RanFilterService);
  private readonly s3StorageService = inject(S3StorageService);
  private readonly fileSaverService = inject(FileSaverService);
  private readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);

  private readonly runningExports = signal<ReadonlySet<number>>(new Set());
  private readonly runningDownloads = signal<ReadonlySet<string>>(new Set());
  private readonly downloadProgress = signal<
    ReadonlyMap<string, DownloadProgress>
  >(new Map());

  /** Filter ids with an open export request, so callers can lock the row's upload action. */
  readonly runningExportIds = this.runningExports.asReadonly();

  /** S3 keys with an open download request, so callers can lock the row's download action. */
  readonly runningDownloadKeys = this.runningDownloads.asReadonly();

  /** Transferred bytes per S3 key. The last value is kept until the same download starts again. */
  readonly downloadProgressByKey = this.downloadProgress.asReadonly();

  /**
   * Downloads the exported filter result from S3 and saves it as a file.
   *
   * `exportPath` is the S3 object key inside {@link RAN_FILTER_EXPORT_BUCKET}.
   * Only completed exports have a readable artifact; for every other state the
   * user is told why the download is unavailable.
   */
  downloadExport(ranFilter: RanFilter): void {
    const key = ranFilter.exportPath;
    if (
      !key ||
      ranFilter.exportStatus !== RanFilter.ExportStatusEnum.COMPLETED
    ) {
      const failed =
        ranFilter.exportStatus === RanFilter.ExportStatusEnum.ERROR;
      this.notify('warn', failed ? 'uploadFailed' : 'noUploadFound', '');
      return;
    }

    const fileName = key.substring(key.lastIndexOf('/') + 1);
    if (!fileName) {
      this.notify('warn', 'noUploadFound', '');
      return;
    }
    if (this.runningDownloads().has(key)) {
      return;
    }
    const name = ranFilter.filterName ?? '';

    this.notify('info', 'downloadStarted', name);
    // Reset here instead of on completion: the progress bar keeps announcing its status for a
    // grace period after the transfer ends, and clearing earlier would drop the final percentage.
    this.clearDownloadProgress(key);
    this.setDownloadRunning(key, true);

    this.s3StorageService
      .downloadS3Object(RAN_FILTER_EXPORT_BUCKET, key, 'events', true, {
        context: new HttpContext().set(SKIP_GLOBAL_LOADING, true),
      })
      .pipe(finalize(() => this.setDownloadRunning(key, false)))
      .subscribe({
        next: event => {
          if (event.type === HttpEventType.DownloadProgress) {
            this.setDownloadProgress(key, event.loaded, event.total);
            return;
          }
          if (event.type === HttpEventType.Response) {
            if (!event.body) {
              this.notify('warn', 'noUploadFound', name);
              return;
            }
            this.fileSaverService.save(event.body, fileName);
            this.notify('success', 'downloadCompleted', name);
          }
        },
        error: () => {
          /* handled by HttpErrorInterceptor */
        },
      });
  }

  /**
   * Exports the filter's node data to a CSV file in S3.
   *
   * Refreshes the list on success so the export status and S3 key of the row
   * reflect the new artifact. The backend answers 200 with a status field even
   * when the export itself failed, so the payload is evaluated as well.
   */
  uploadExport(ranFilter: RanFilter): void {
    const filterId = ranFilter.filterId;
    if (filterId === undefined) {
      this.notify('warn', 'exportNotPossible', '');
      return;
    }
    if (this.runningExports().has(filterId)) {
      return;
    }
    const name = ranFilter.filterName ?? '';

    this.notify('info', 'uploadStarted', name);
    this.setExportRunning(filterId, true);

    this.ranFilterService
      .exportRanFilterCsv$(filterId)
      .pipe(finalize(() => this.setExportRunning(filterId, false)))
      .subscribe({
        next: response => {
          if (response.status === RanFilter.ExportStatusEnum.ERROR) {
            this.notify('warn', 'uploadFailed', name);
            return;
          }
          this.ranFilterService.refreshRanFilters();
        },
        error: () => {
          /* handled by HttpErrorInterceptor */
        },
      });
  }

  private setExportRunning(filterId: number, running: boolean): void {
    this.runningExports.update(current => {
      const next = new Set(current);
      if (running) {
        next.add(filterId);
      } else {
        next.delete(filterId);
      }
      return next;
    });
  }

  private setDownloadRunning(key: string, running: boolean): void {
    this.runningDownloads.update(current => {
      const next = new Set(current);
      if (running) {
        next.add(key);
      } else {
        next.delete(key);
      }
      return next;
    });
  }

  private setDownloadProgress(
    key: string,
    loaded: number,
    total?: number
  ): void {
    // `total` is the Content-Length, which reports compressed bytes while `loaded` counts
    // decoded ones, so the ratio can exceed 1 and has to be clamped.
    const percent =
      total && total > 0
        ? Math.min(100, Math.max(0, Math.round((loaded / total) * 100)))
        : undefined;

    // Progress events fire far more often than the bar can change, so only visible steps are published.
    const previous = this.downloadProgress().get(key);
    if (previous && previous.percent === percent) {
      return;
    }

    this.downloadProgress.update(current =>
      new Map(current).set(key, { loaded, total, percent })
    );
  }

  private clearDownloadProgress(key: string): void {
    this.downloadProgress.update(current => {
      const next = new Map(current);
      next.delete(key);
      return next;
    });
  }

  private notify(
    type: 'info' | 'success' | 'warn',
    messageKey: string,
    name: string
  ): void {
    this.alertService[type](
      this.translateService.instant(MESSAGE_PREFIX + messageKey, { name }),
      { autoClose: true, keepAfterRouteChange: true }
    );
  }
}
