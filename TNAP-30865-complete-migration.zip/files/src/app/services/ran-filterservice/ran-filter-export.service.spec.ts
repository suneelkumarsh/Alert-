/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { TestBed } from '@angular/core/testing';
import {
  HttpContext,
  HttpEvent,
  HttpEventType,
  HttpResponse,
} from '@angular/common/http';
import { TranslateService } from '@ngx-translate/core';
import { FileSaverService } from 'ngx-filesaver';
import { of, Subject, throwError } from 'rxjs';

import {
  RanFilterExportService,
  RAN_FILTER_EXPORT_BUCKET,
} from './ran-filter-export.service';
import { RanFilterService } from './ran-filter.service';
import { S3StorageService } from '../../../../openapi/output/api/s3Storage.service';
import { ExportCsvResponse } from '../../../../openapi/output/model/exportCsvResponse.model';
import { RanFilter } from '../../../../openapi/output/model/ranFilter.model';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';
import { SKIP_GLOBAL_LOADING } from '../../http-interceptors/loading-indicator.interceptor';

describe('RanFilterExportService', () => {
  let service: RanFilterExportService;
  let s3StorageServiceSpy: jasmine.SpyObj<S3StorageService>;
  let fileSaverServiceSpy: jasmine.SpyObj<FileSaverService>;
  let alertServiceSpy: jasmine.SpyObj<TnapAlertService>;
  let ranFilterServiceSpy: jasmine.SpyObj<RanFilterService>;

  // Shape delivered by the backend: bucket-relative key inside RAN_FILTER_EXPORT_BUCKET.
  const EXPORT_KEY =
    'do4/filter-data/filter_7/20260826090722/filter_7_20260826090722.zip';

  const responseEvent = (body: Blob): HttpEvent<Blob> =>
    new HttpResponse<Blob>({ body });

  const progressEvent = (loaded: number, total?: number): HttpEvent<Blob> => ({
    type: HttpEventType.DownloadProgress,
    loaded,
    total,
  });

  const ranFilter: RanFilter = {
    filterId: 7,
    filterName: 'Filtpipe_1',
    filterDescription: 'Description',
    vendor: 'Ericson',
    conditions: [],
    exportPath: EXPORT_KEY,
    exportStatus: 'completed',
  };

  beforeEach(() => {
    s3StorageServiceSpy = jasmine.createSpyObj<S3StorageService>(
      'S3StorageService',
      ['downloadS3Object']
    );
    fileSaverServiceSpy = jasmine.createSpyObj<FileSaverService>(
      'FileSaverService',
      ['save']
    );
    alertServiceSpy = jasmine.createSpyObj<TnapAlertService>(
      'TnapAlertService',
      ['info', 'success', 'warn']
    );
    ranFilterServiceSpy = jasmine.createSpyObj<RanFilterService>(
      'RanFilterService',
      ['exportRanFilterCsv$', 'refreshRanFilters']
    );

    const translateServiceSpy = jasmine.createSpyObj<TranslateService>(
      'TranslateService',
      ['instant']
    );
    translateServiceSpy.instant.and.callFake((key: string | string[]) =>
      String(key)
    );

    TestBed.configureTestingModule({
      providers: [
        RanFilterExportService,
        { provide: S3StorageService, useValue: s3StorageServiceSpy },
        { provide: FileSaverService, useValue: fileSaverServiceSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
        { provide: RanFilterService, useValue: ranFilterServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
      ],
    });

    service = TestBed.inject(RanFilterExportService);
  });

  describe('downloadExport', () => {
    it('announces the start, saves the file and announces completion', () => {
      const blob = new Blob(['csv']);
      s3StorageServiceSpy.downloadS3Object.and.returnValue(
        of(responseEvent(blob)) as never
      );

      service.downloadExport(ranFilter);

      expect(alertServiceSpy.info).toHaveBeenCalledWith(
        'ranFilter.list.messages.downloadStarted',
        { autoClose: true, keepAfterRouteChange: true }
      );
      expect(fileSaverServiceSpy.save).toHaveBeenCalledWith(
        blob,
        'filter_7_20260826090722.zip'
      );
      expect(alertServiceSpy.success).toHaveBeenCalledWith(
        'ranFilter.list.messages.downloadCompleted',
        { autoClose: true, keepAfterRouteChange: true }
      );
    });

    it('requests the object from the filter bucket without the global loader', () => {
      s3StorageServiceSpy.downloadS3Object.and.returnValue(
        of(responseEvent(new Blob())) as never
      );

      service.downloadExport(ranFilter);

      const args = s3StorageServiceSpy.downloadS3Object.calls.mostRecent()
        .args as unknown as [
        string,
        string,
        string,
        boolean,
        { context: HttpContext },
      ];
      expect(args[0]).toBe(RAN_FILTER_EXPORT_BUCKET);
      expect(args[1]).toBe(EXPORT_KEY);
      expect(args[2]).toBe('events');
      expect(args[3]).toBeTrue();
      expect(args[4].context.get(SKIP_GLOBAL_LOADING)).toBeTrue();
    });

    it('aborts with a warning when the key does not contain a file name', () => {
      service.downloadExport({
        ...ranFilter,
        exportPath: 'do4/filter-data/filter_7/20260826090722/',
      });

      expect(s3StorageServiceSpy.downloadS3Object).not.toHaveBeenCalled();
      expect(fileSaverServiceSpy.save).not.toHaveBeenCalled();
      expect(alertServiceSpy.info).not.toHaveBeenCalled();
      expect(alertServiceSpy.warn).toHaveBeenCalledWith(
        'ranFilter.list.messages.noUploadFound',
        { autoClose: true, keepAfterRouteChange: true }
      );
    });

    it('warns about a missing upload when the filter has no export path', () => {
      service.downloadExport({ ...ranFilter, exportPath: undefined });

      expect(s3StorageServiceSpy.downloadS3Object).not.toHaveBeenCalled();
      expect(alertServiceSpy.info).not.toHaveBeenCalled();
      expect(alertServiceSpy.warn).toHaveBeenCalledWith(
        'ranFilter.list.messages.noUploadFound',
        { autoClose: true, keepAfterRouteChange: true }
      );
    });

    it('warns about a failed upload when the export status is error', () => {
      service.downloadExport({ ...ranFilter, exportStatus: 'error' });

      expect(s3StorageServiceSpy.downloadS3Object).not.toHaveBeenCalled();
      expect(alertServiceSpy.warn).toHaveBeenCalledWith(
        'ranFilter.list.messages.uploadFailed',
        { autoClose: true, keepAfterRouteChange: true }
      );
    });

    it('warns about a missing upload while the export has not completed', () => {
      service.downloadExport({ ...ranFilter, exportStatus: 'in_progress' });

      expect(s3StorageServiceSpy.downloadS3Object).not.toHaveBeenCalled();
      expect(alertServiceSpy.info).not.toHaveBeenCalled();
      expect(alertServiceSpy.warn).toHaveBeenCalledWith(
        'ranFilter.list.messages.noUploadFound',
        { autoClose: true, keepAfterRouteChange: true }
      );
    });

    it('does not announce completion when the download fails', () => {
      s3StorageServiceSpy.downloadS3Object.and.returnValue(
        throwError(() => new Error('fail')) as never
      );

      service.downloadExport(ranFilter);

      expect(alertServiceSpy.info).toHaveBeenCalled();
      expect(fileSaverServiceSpy.save).not.toHaveBeenCalled();
      expect(alertServiceSpy.success).not.toHaveBeenCalled();
    });

    it('ignores further triggers while the download is still running', () => {
      const response = new Subject<HttpEvent<Blob>>();
      s3StorageServiceSpy.downloadS3Object.and.returnValue(response as never);

      service.downloadExport(ranFilter);
      service.downloadExport(ranFilter);

      expect(s3StorageServiceSpy.downloadS3Object).toHaveBeenCalledTimes(1);
      expect(alertServiceSpy.info).toHaveBeenCalledTimes(1);
      expect(service.runningDownloadKeys().has(EXPORT_KEY)).toBeTrue();

      response.next(responseEvent(new Blob()));
      response.complete();

      expect(service.runningDownloadKeys().has(EXPORT_KEY)).toBeFalse();

      service.downloadExport(ranFilter);

      expect(s3StorageServiceSpy.downloadS3Object).toHaveBeenCalledTimes(2);
    });

    it('exposes the percentage while progress events carry a total', () => {
      const response = new Subject<HttpEvent<Blob>>();
      s3StorageServiceSpy.downloadS3Object.and.returnValue(response as never);

      service.downloadExport(ranFilter);
      response.next(progressEvent(250, 1000));

      expect(service.downloadProgressByKey().get(EXPORT_KEY)).toEqual({
        loaded: 250,
        total: 1000,
        percent: 25,
      });
    });

    it('omits the percentage when the response has no content length', () => {
      const response = new Subject<HttpEvent<Blob>>();
      s3StorageServiceSpy.downloadS3Object.and.returnValue(response as never);

      service.downloadExport(ranFilter);
      response.next(progressEvent(250));

      expect(service.downloadProgressByKey().get(EXPORT_KEY)).toEqual({
        loaded: 250,
        total: undefined,
        percent: undefined,
      });
    });

    it('caps the percentage at 100 when more bytes arrive than announced', () => {
      const response = new Subject<HttpEvent<Blob>>();
      s3StorageServiceSpy.downloadS3Object.and.returnValue(response as never);

      service.downloadExport(ranFilter);
      response.next(progressEvent(1500, 1000));

      expect(service.downloadProgressByKey().get(EXPORT_KEY)?.percent).toBe(
        100
      );
    });

    it('treats a zero content length as an unknown total', () => {
      const response = new Subject<HttpEvent<Blob>>();
      s3StorageServiceSpy.downloadS3Object.and.returnValue(response as never);

      service.downloadExport(ranFilter);
      response.next(progressEvent(0, 0));

      expect(
        service.downloadProgressByKey().get(EXPORT_KEY)?.percent
      ).toBeUndefined();
    });

    it('does not emit again while the rounded percentage stays the same', () => {
      const response = new Subject<HttpEvent<Blob>>();
      s3StorageServiceSpy.downloadS3Object.and.returnValue(response as never);

      service.downloadExport(ranFilter);
      response.next(progressEvent(250, 1000));
      const first = service.downloadProgressByKey();

      response.next(progressEvent(252, 1000));

      expect(service.downloadProgressByKey()).toBe(first);

      response.next(progressEvent(300, 1000));

      expect(service.downloadProgressByKey()).not.toBe(first);
      expect(service.downloadProgressByKey().get(EXPORT_KEY)?.percent).toBe(30);
    });

    it('ignores lifecycle events other than progress and response', () => {
      const response = new Subject<HttpEvent<Blob>>();
      s3StorageServiceSpy.downloadS3Object.and.returnValue(response as never);

      service.downloadExport(ranFilter);
      response.next({ type: HttpEventType.Sent });

      expect(service.downloadProgressByKey().has(EXPORT_KEY)).toBeFalse();
      expect(fileSaverServiceSpy.save).not.toHaveBeenCalled();
      expect(alertServiceSpy.success).not.toHaveBeenCalled();
      expect(alertServiceSpy.warn).not.toHaveBeenCalled();
    });

    it('warns instead of saving when the response carries no body', () => {
      s3StorageServiceSpy.downloadS3Object.and.returnValue(
        of(new HttpResponse<Blob>({ body: null })) as never
      );

      service.downloadExport(ranFilter);

      expect(fileSaverServiceSpy.save).not.toHaveBeenCalled();
      expect(alertServiceSpy.success).not.toHaveBeenCalled();
      expect(alertServiceSpy.warn).toHaveBeenCalledWith(
        'ranFilter.list.messages.noUploadFound',
        { autoClose: true, keepAfterRouteChange: true }
      );
    });

    it('keeps the last progress entry once the download settles', () => {
      const response = new Subject<HttpEvent<Blob>>();
      s3StorageServiceSpy.downloadS3Object.and.returnValue(response as never);

      service.downloadExport(ranFilter);
      response.next(progressEvent(1000, 1000));

      response.next(responseEvent(new Blob()));
      response.complete();

      expect(service.downloadProgressByKey().get(EXPORT_KEY)?.percent).toBe(
        100
      );
    });

    it('keeps the last progress entry when the download fails', () => {
      const response = new Subject<HttpEvent<Blob>>();
      s3StorageServiceSpy.downloadS3Object.and.returnValue(response as never);

      service.downloadExport(ranFilter);
      response.next(progressEvent(500, 1000));
      response.error(new Error('fail'));

      expect(service.downloadProgressByKey().get(EXPORT_KEY)?.percent).toBe(50);
    });

    it('resets the progress entry when the same download starts again', () => {
      const response = new Subject<HttpEvent<Blob>>();
      s3StorageServiceSpy.downloadS3Object.and.returnValue(response as never);

      service.downloadExport(ranFilter);
      response.next(progressEvent(500, 1000));
      response.next(responseEvent(new Blob()));
      response.complete();

      s3StorageServiceSpy.downloadS3Object.and.returnValue(
        new Subject<HttpEvent<Blob>>() as never
      );
      service.downloadExport(ranFilter);

      expect(service.downloadProgressByKey().has(EXPORT_KEY)).toBeFalse();
    });

    it('releases the running lock when the download fails', () => {
      s3StorageServiceSpy.downloadS3Object.and.returnValue(
        throwError(() => new Error('fail')) as never
      );

      service.downloadExport(ranFilter);

      expect(service.runningDownloadKeys().has(EXPORT_KEY)).toBeFalse();
    });
  });

  describe('uploadExport', () => {
    it('announces only the start and refreshes the list', () => {
      ranFilterServiceSpy.exportRanFilterCsv$.and.returnValue(
        of({ csvFilePath: EXPORT_KEY, status: 'completed' })
      );

      service.uploadExport(ranFilter);

      expect(alertServiceSpy.info).toHaveBeenCalledWith(
        'ranFilter.list.messages.uploadStarted',
        { autoClose: true, keepAfterRouteChange: true }
      );
      expect(ranFilterServiceSpy.exportRanFilterCsv$).toHaveBeenCalledWith(7);
      expect(alertServiceSpy.success).not.toHaveBeenCalled();
      expect(ranFilterServiceSpy.refreshRanFilters).toHaveBeenCalled();
    });

    it('warns and skips the refresh when the response reports a failed export', () => {
      ranFilterServiceSpy.exportRanFilterCsv$.and.returnValue(
        of({ csvFilePath: '', status: 'error' })
      );

      service.uploadExport(ranFilter);

      expect(alertServiceSpy.warn).toHaveBeenCalledWith(
        'ranFilter.list.messages.uploadFailed',
        { autoClose: true, keepAfterRouteChange: true }
      );
      expect(ranFilterServiceSpy.refreshRanFilters).not.toHaveBeenCalled();
    });

    it('warns when the filter has no id', () => {
      service.uploadExport({ ...ranFilter, filterId: undefined });

      expect(ranFilterServiceSpy.exportRanFilterCsv$).not.toHaveBeenCalled();
      expect(alertServiceSpy.info).not.toHaveBeenCalled();
      expect(alertServiceSpy.warn).toHaveBeenCalledWith(
        'ranFilter.list.messages.exportNotPossible',
        { autoClose: true, keepAfterRouteChange: true }
      );
    });

    it('ignores further triggers while the export is still running', () => {
      const response = new Subject<ExportCsvResponse>();
      ranFilterServiceSpy.exportRanFilterCsv$.and.returnValue(response);

      service.uploadExport(ranFilter);
      service.uploadExport(ranFilter);

      expect(ranFilterServiceSpy.exportRanFilterCsv$).toHaveBeenCalledTimes(1);
      expect(alertServiceSpy.info).toHaveBeenCalledTimes(1);
      expect(service.runningExportIds().has(7)).toBeTrue();

      response.next({ csvFilePath: EXPORT_KEY, status: 'completed' });
      response.complete();

      expect(service.runningExportIds().has(7)).toBeFalse();

      service.uploadExport(ranFilter);

      expect(ranFilterServiceSpy.exportRanFilterCsv$).toHaveBeenCalledTimes(2);
    });

    it('releases the running lock when the export fails', () => {
      ranFilterServiceSpy.exportRanFilterCsv$.and.returnValue(
        throwError(() => new Error('fail'))
      );

      service.uploadExport(ranFilter);

      expect(service.runningExportIds().has(7)).toBeFalse();
    });

    it('does not refresh the list when the export fails', () => {
      ranFilterServiceSpy.exportRanFilterCsv$.and.returnValue(
        throwError(() => new Error('fail'))
      );

      service.uploadExport(ranFilter);

      expect(alertServiceSpy.success).not.toHaveBeenCalled();
      expect(ranFilterServiceSpy.refreshRanFilters).not.toHaveBeenCalled();
    });
  });
});
