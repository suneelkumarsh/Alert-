/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Component,
  ElementRef,
  HostListener,
  inject,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { CookieService } from './services/cookieservice/cookie.service';
import { environment } from '../environments/environment';
import { LoadingIndicatorService } from 'src/app/services/loading-indicator.service';
import {
  KeyboardShortcuts,
  ShortcutService,
} from './services/shortcut.service';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { LogPageUsageService } from './services/log-page-usage.service';
import { IdleDetectorService } from './services/idle-detector.service';
import { UnsubscribeService } from './services/unsubscribe/unsubscribe.service';
import { distinctUntilChanged, filter, map, takeUntil } from 'rxjs/operators';
import { AuthService } from '@portal-mfe/auth';
import { Title } from '@angular/platform-browser';
import { SnapshotService } from './services/snapshot.service';
import { OverlayService } from './components/overlay/overlay/overlay.service';
import { OfflineOverlayComponent } from './components/overlay/offline-overlay/offline-overlay.component';
import { UserInactivityWarningComponent } from './components/overlay/user-inactivity-warning/user-inactivity-warning.component';
import { UserLoggedOutOverlayComponent } from './components/overlay/user-logged-out-overlay/user-logged-out-overlay.component';
import { TranslateService } from '@ngx-translate/core';
import { LayoutService } from './services/layout.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [LogPageUsageService, UnsubscribeService],
  standalone: false,
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'frontend';
  isCustomStyleEnabled = environment.customStyleEnabled;
  readonly loading$ = this.loadingIndicator.isVisible();
  public isCollapsed = false;
  public ACCESS_KEY = KeyboardShortcuts;
  public loadingMessage = '';
  public online = navigator.onLine;
  public tokenNotValid$ = this.authService.getKeycloakTokenValidation();
  private readonly overlayService = inject(OverlayService);
  private loadingTimeout: ReturnType<typeof setTimeout> | null = null;
  @ViewChild('mainContent') mainContent!: ElementRef<HTMLElement>;
  private readonly translateService = inject(TranslateService);
  readonly layoutService = inject(LayoutService);

  constructor(
    protected alertService: TnapAlertService,
    protected cookieService: CookieService,
    private readonly loadingIndicator: LoadingIndicatorService,
    private readonly router: Router,
    public idleDetectorService: IdleDetectorService,
    private readonly unsubscribeService: UnsubscribeService,
    private readonly authService: AuthService,
    private readonly snapshotService: SnapshotService,
    private readonly titleService: Title,
    private readonly activatedRoute: ActivatedRoute,
    private readonly shortcutService: ShortcutService
  ) {
    cookieService.checkCookiePermissions();
    this.authService.getUserInfo();

    router.events.subscribe(item => {
      if (item instanceof NavigationEnd) {
        const snapshot = this.router.routerState.snapshot;
        this.snapshotService.setSnapshot(snapshot);
      }
    });
    this.tokenNotValid$.subscribe(valid => {
      if (!valid && !this.online) {
        this.overlayService.openOverlay(OfflineOverlayComponent);
      }
    });
  }

  @HostListener('window:online')
  onOnline() {
    this.online = true;
  }

  @HostListener('window:offline')
  onOffline() {
    this.online = false;
  }

  collapseChanged() {
    this.isCollapsed = !this.isCollapsed;
  }
  private handleUserInactivityWarning() {
    this.idleDetectorService.showWarning$
      .pipe(takeUntil(this.unsubscribeService.unsubscribe$))
      .subscribe(shouldShowWarning => {
        if (shouldShowWarning) {
          this.overlayService.openOverlay(UserInactivityWarningComponent);
        } else {
          this.overlayService.closeOverlay();
        }
      });
  }
  private handleUserInactiveLogout() {
    this.idleDetectorService.showLogout$
      .pipe(takeUntil(this.unsubscribeService.unsubscribe$))
      .subscribe(shouldShowWarning => {
        if (shouldShowWarning) {
          this.authService.logoutSilently();
          this.overlayService.openOverlay(UserLoggedOutOverlayComponent);
        } else {
          this.overlayService.closeOverlay();
        }
      });
  }
  private handlePageTitle() {
    this.router.events
      .pipe(
        filter(event => event instanceof NavigationEnd),
        map(() => {
          let child = this.activatedRoute.firstChild;
          while (child?.firstChild) {
            child = child.firstChild;
          }
          return child?.snapshot.data['title'];
        })
      )
      .subscribe((pageTitle: string) => {
        if (pageTitle) {
          this.titleService.setTitle(pageTitle);
        }
      });
  }
  private handleShortcuts() {
    this.shortcutService.initGlobalShortcutListener();

    // registering actions for each shortcut to with screen readers, too
    this.shortcutService.setShortcutAction(KeyboardShortcuts.SHORTCUT_0, () => {
      this.shortcutService.triggerOpenShortcut();
    });

    this.shortcutService.setShortcutAction(KeyboardShortcuts.SHORTCUT_1, () => {
      this.shortcutService.triggerHome();
    });

    this.shortcutService.setShortcutAction(KeyboardShortcuts.SHORTCUT_2, () => {
      this.mainContent?.nativeElement?.focus();
    });

    this.shortcutService.setShortcutAction(KeyboardShortcuts.SHORTCUT_4, () => {
      this.focusElementIfVisible('searchInput');
    });

    this.shortcutService.setShortcutAction(KeyboardShortcuts.SHORTCUT_5, () => {
      this.focusElementIfVisible('detail-pane');
    });

    this.shortcutService.setShortcutAction(KeyboardShortcuts.SHORTCUT_6, () => {
      this.focusElementIfVisible('sidebar');
    });
  }

  private handleLoadingAnnouncements() {
    this.loading$
      .pipe(
        distinctUntilChanged(),
        takeUntil(this.unsubscribeService.unsubscribe$)
      )
      .subscribe(isLoading => {
        if (isLoading) {
          // Clear any pending timeout
          if (this.loadingTimeout) {
            clearTimeout(this.loadingTimeout);
            this.loadingTimeout = null;
          }

          this.loadingMessage = this.translateService.instant(
            'common.loadingMessage'
          );
        } else {
          // slight delay improves screen reader clarity
          this.loadingTimeout = setTimeout(() => {
            this.loadingMessage = this.translateService.instant(
              'common.contentLoadedMessage'
            );
            this.loadingTimeout = null;
          }, 300);
        }
      });
  }

  ngOnInit(): void {
    this.idleDetectorService.initialize();
    this.handleUserInactivityWarning();
    this.handleUserInactiveLogout();
    this.handlePageTitle();
    this.handleShortcuts();
    this.handleLoadingAnnouncements();
  }

  login() {
    this.authService.login();
  }

  focusMainContent() {
    this.mainContent.nativeElement.focus();
  }

  private focusElementIfVisible(selector: string) {
    const el = document.getElementById(selector) as HTMLElement;

    if (el) {
      const observer = new IntersectionObserver(
        (entries, observer) => {
          for (const entry of entries) {
            if (entry.isIntersecting) {
              (entry.target as HTMLElement).focus();
              observer.disconnect();
              break;
            }
          }
        },
        {
          threshold: 0.1,
        }
      );

      observer.observe(el);
    }
  }

  protected readonly environment = environment;

  ngOnDestroy() {
    if (this.loadingTimeout) {
      clearTimeout(this.loadingTimeout);
    }
  }
}
