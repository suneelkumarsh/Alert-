/*
 * Copyright (c) 2025. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */
import { ConfigService } from 'src/app/services/config.service';
import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/layout/header/header/header.component';
import {
  HttpClient,
  provideHttpClient,
  withInterceptorsFromDi,
} from '@angular/common/http';
import { TnapAlertComponent } from '@portal-mfe/tnap-ui-kit/components/alert';
import { CustomHeaderComponent } from './components/layout/header/custom-header/custom-header.component';
import { ModalContentComponent } from './components/modal/modal-content';
import {
  RequestCache,
  RequestCacheService,
} from './services/cacheservice/request-cache.service';
import { httpInterceptorProviders } from './http-interceptors/interceptors';
import { SidemenuComponent } from './components/layout/sidemenu/sidemenu.component';
import { ConfirmationModalComponent } from './components/shared/confirmation-modal/confirmation-modal.component';

import { environment } from '../environments/environment';
import {
  ApiModule,
  Configuration,
  // SliceOrdersService,
} from '../../openapi/output';
import { LoadingIndicatorService } from 'src/app/services/loading-indicator.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found';
import { RouteReuseStrategy, TitleStrategy } from '@angular/router';
import { AppRouteReuseStrategy } from './router.strategy';
import { StatusPageComponent } from './components/shared/status-page/status-page.component';
import { UserAdministrationModule } from './modules/user-administration/user-administration.module';
import { SharedModule } from './shared.module';
import { AppStarterModule } from './modules/app-starter/app-starter.module';
import { KpiDashboardModule } from './modules/kpi-dashboard/kpi-dashboard.module';
import { DashboardModule } from './modules/dashboard/dashboard.module';
import { TreeviewModule } from './modules/treeview/treeview.module';
import { AlarmModule } from './modules/alarm/alarm.module';
import { ServiceModelDeploymentModule } from './modules/service-models-deployment/service-model-deployment.module';
import { TopologyModule } from './modules/topology/topology.module';
import { ServiceInstanceListModule } from './modules/service-instance-list/service-instance-list.module';
import { RuManagementModule } from 'src/app/modules/ru-management/ru-management.module';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from 'src/app/components/shared/filters/date-format';
import { SwManagementModule } from 'src/app/modules/sw-management/sw-management.module';
import {
  MissingTranslationHandler,
  TranslateLoader,
  TranslateModule,
  TranslateService,
} from '@ngx-translate/core';
import { MergedTranslateLoader } from './services/merged-translate-loader.service';
import { DatePipe, registerLocaleData } from '@angular/common';
import { YesNoPipe } from './pipes/yes-no.pipe';
import { ErrorHandlerService } from './services/error-handler.service';
import localeDe from '@angular/common/locales/de';
import { CmActionModule } from './modules/cm-action/cm-action.module';
import { SliceManagementModule } from './modules/slice-management/slice-management.module';
import { CustomPageTitleStrategy } from './custom-page-title-strategy';
import { PoliciesModule } from 'src/app/modules/policies/policies.module';
import { RanTemplateModule } from './modules/ran-template/ran-template.module';
import { DiscrepancyModule } from './modules/discrepancy/discrepancy.module';
import { OverlayComponent } from './components/overlay/overlay/overlay.component';
import { KeyValueListComponent } from './components/shared/key-value-list/key-value-list.component';
import { MyMissingTranslationHandler } from './services/fallback-translation-handler';
import { provideCharts, withDefaultRegisterables } from 'ng2-charts';
import {
  CompositePropagatorModule,
  OpenTelemetryInterceptorModule,
  ZipkinExporterModule,
} from '@jufab/opentelemetry-angular-interceptor';
import { AuthModule } from '@portal-mfe/auth';
import { authConfig } from './modules/auth/auth.config';
import { PERMISSIONS_MAP, PERMISSIONS_TOKEN } from './permissions.config';
import { MenuItemComponent } from './components/layout/menu-item/menu-item.component';
import { CollapsibleMenuItemComponent } from './components/layout/collapsible-menu-item/collapsible-menu-item.component';
import { provideTnapUiKitI18n } from './i18n/tnap-ui-kit-i18n';

registerLocaleData(localeDe);

export function translateLoaderFactory(httpClient: HttpClient) {
  return new MergedTranslateLoader(
    httpClient,
    'assets/i18n/',
    ['assets/i18n/data-table/'],
    `?t=${new Date().getTime()}`
  );
}

export function changeConfig() {
  return new Configuration({ basePath: environment.backendServerUrl });
}

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    CustomHeaderComponent,
    ModalContentComponent,
    SidemenuComponent,
    PageNotFoundComponent,
    ConfirmationModalComponent,
    StatusPageComponent,
    MenuItemComponent,
    CollapsibleMenuItemComponent,
  ],
  bootstrap: [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    TnapAlertComponent,
    AuthModule.forRoot(
      environment.backendServerUrl,
      environment.backendServerUrl,
      environment.loggingUrl,
      environment.keycloak.hostname,
      environment.keycloak.realm,
      environment.userIdleTimeoutMs,
      authConfig
    ),
    ApiModule.forRoot(changeConfig),
    BrowserAnimationsModule,
    TranslateModule.forRoot({
      missingTranslationHandler: {
        provide: MissingTranslationHandler,
        useClass: MyMissingTranslationHandler,
      },
      loader: {
        provide: TranslateLoader,
        useFactory: translateLoaderFactory,
        deps: [HttpClient],
      },
    }),
    UserAdministrationModule,
    DashboardModule,
    TreeviewModule,
    SharedModule,
    AppStarterModule,
    AlarmModule,
    KpiDashboardModule,
    ServiceModelDeploymentModule,
    TopologyModule,
    ServiceInstanceListModule,
    RuManagementModule,
    SwManagementModule,
    CmActionModule,
    SliceManagementModule,
    OpenTelemetryInterceptorModule.forRoot(environment.openTelemetryConfig),
    ZipkinExporterModule,
    CompositePropagatorModule,
    PoliciesModule,
    RanTemplateModule,
    DiscrepancyModule,
    UserAdministrationModule,
    OverlayComponent,
    KeyValueListComponent,
  ],
  providers: [
    { provide: RequestCache, useClass: RequestCacheService },
    httpInterceptorProviders,
    LoadingIndicatorService,
    { provide: RouteReuseStrategy, useClass: AppRouteReuseStrategy },
    { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter },
    { provide: ErrorHandler, useClass: ErrorHandlerService },
    { provide: TitleStrategy, useClass: CustomPageTitleStrategy },
    DatePipe,
    YesNoPipe,
    provideCharts(withDefaultRegisterables()),
    provideHttpClient(withInterceptorsFromDi()),
    { provide: PERMISSIONS_TOKEN, useValue: PERMISSIONS_MAP },
    provideTnapUiKitI18n(),
  ],
})
export class AppModule {
  constructor(
    configService: ConfigService,
    translateService: TranslateService
  ) {
    configService
      .getLanguage()
      .subscribe(language => translateService.use(language));
  }
}
