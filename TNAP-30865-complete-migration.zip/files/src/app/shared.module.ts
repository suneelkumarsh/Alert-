/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { CommonModule, NgOptimizedImage } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TableSkeletonComponent } from './components/shared/table-skeleton/table-skeleton.component';
import { PaginationComponent } from './components/shared/pagination/pagination.component';
import { NgbDropdownModule, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgModule } from '@angular/core';
import { ColonPipe } from './pipes/colon.pipe';
import { MapPipe } from './pipes/map.pipe';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { DetailRowComponent } from './components/shared/detail-row/detail-row.component';
import { HideEmptyDetailRowDirective } from './directives/hide-empty.directive';
import { InPipe } from './pipes/in.pipe';
import { IsTodayPipe } from './pipes/is-today.pipe';
import { SanitizeUrlPipe } from './pipes/sanitizeUrl.pipe';
import { SortComponent } from './components/shared/sort/sort.component';
import { EmptyComponent } from './components/shared/empty/empty.component';
import { ServiceInstanceAttributePaneComponent } from './components/aai-node-attribute-pane/service-instance-attribute-pane/service-instance-attribute-pane.component';
import { ServiceSubscriptionAttributePaneComponent } from './components/aai-node-attribute-pane/service-subscription-attribute-pane/service-subscription-attribute-pane.component';
import { OwningEntityAttributePaneComponent } from './components/aai-node-attribute-pane/owning-entity-attribute-pane/owning-entity-attribute-pane.component';
import { ProjectAttributePaneComponent } from './components/aai-node-attribute-pane/project-attribute-pane/project-attribute-pane.component';
import { TenantAttributePaneComponent } from './components/aai-node-attribute-pane/tenant-attribute-pane/tenant-attribute-pane.component';
import { CloudRegionAttributePaneComponent } from './components/aai-node-attribute-pane/cloud-region-attribute-pane/cloud-region-attribute-pane.component';
import { CustomerAttributePaneComponent } from './components/aai-node-attribute-pane/customer-attribute-pane/customer-attribute-pane.component';
import { PnfAttributePaneComponent } from './components/aai-node-attribute-pane/pnf-attribute-pane/pnf-attribute-pane.component';
import { GenericVnfAttributePaneComponent } from './components/aai-node-attribute-pane/generic-vnf-attribute-pane/generic-vnf-attribute-pane.component';
import { VfModuleAttributePaneComponent } from './components/aai-node-attribute-pane/vf-module-attribute-pane/vf-module-attribute-pane.component';
import { VserverAttributePaneComponent } from './components/aai-node-attribute-pane/vserver-attribute-pane/vserver-attribute-pane.component';
import { ComplexAttributePaneComponent } from './components/aai-node-attribute-pane/complex-attribute-pane/complex-attribute-pane.component';
import { AllottedResourceAttributePaneComponent } from './components/aai-node-attribute-pane/allotted-resource-attribute-pane/allotted-resource-attribute-pane.component';
import { AaiAttributePaneComponent } from './components/aai-node-attribute-pane/aai-attribute-pane/aai-attribute-pane.component';
import { AttributePaneComponent } from './components/shared/attribute-pane/attribute-pane.component';
import { YesNoPipe } from './pipes/yes-no.pipe';
import { TranslateModule } from '@ngx-translate/core';
import { DebugPipe } from './pipes/debug.pipe';
import { HintComponent } from './components/shared/hint/hint.component';
import { AlarmAttributePaneComponent } from './components/aai-node-attribute-pane/alarm-attribute-pane/alarm-attribute-pane.component';
import { AlarmSeverityCounterComponent } from './components/shared/alarm-severity-counter/alarm-severity-counter.component';
import { GetAlarmsByIdPipe } from './pipes/get-alarms-by-id.pipe';
import { ContextMenuModule } from '@perfectmemory/ngx-contextmenu';
import { LoadingSpinnerComponent } from './components/shared/loading-spinner/loading-spinner.component';
import { ModelDeploymentStatusContentComponent } from './components/shared/model-deployment-status-content/model-deployment-status-content.component';
import { PasswordPipe } from 'src/app/pipes/password.pipe';
import { ExpandableTypeaheadComponent } from './components/shared/expandable-typeahead/expandable-typeahead.component';
import { RelativeTimeFilterComponent } from './components/shared/filters/relative-time-filter/relative-time-filter.component';
import { UnknownPipe } from 'src/app/pipes/unknown.pipe';
import { CellNodeAttributePaneComponent } from './components/aai-node-attribute-pane/cell-attribute-pane/cell-node-attribute-pane.component';
import { GeoRegionAttributePaneComponent } from './components/aai-node-attribute-pane/geo-region-attribute-pane/geo-region-attribute-pane.component';
import { SiteResourceAttributePaneComponent } from './components/aai-node-attribute-pane/site-resource-attribute-pane/site-resource-attribute-pane.component';
import { ValidMapSearchPipe } from './pipes/validMapSearch.pipe';
import { AlarmAggregationSeverityHasAlarmIdsPipe } from './pipes/alarm-aggregation-severity-has-alarm-ids.pipe';
import { DictionaryAttributePaneComponent } from './components/dictionary-attribute-pane/dictionary-attribute-pane.component';
import { DetailSectionsComponent } from './components/detail-sections/detail-sections.component';
import { FilterOutPnfsPipe } from './pipes/filter-out-pnfs.pipe';
import { StringContainsPipe } from './pipes/string-contains.pipe';
import { HighlightPartOfTextPipe } from './pipes/highlight-part-of-text.pipe';
import { CellListPaneComponent } from './components/aai-node-attribute-pane/cells-list-pane/cells-list-pane.component';
import { GetKeyForAlarmAggregationPipe } from './pipes/get-key-for-alarm-aggregation.pipe';
import { UniversalFulltextFilterComponent } from './components/shared/filters/universal-fulltext-filter/universal-fulltext-filter.component';
import { EnsureValueIsNotArrayPipe } from './pipes/ensure-value-is-not-array.pipe';
import { EnsureValueIsArrayPipe } from './pipes/ensure-value-is-array.pipe';
import { ArrayContainsPipe } from './pipes/array-contains.pipe';
import { FindParentGnbPipe } from './pipes/find-parent-gnb.pipe';
import { SeverityClassPipe } from './pipes/severity-class.pipe';
import { NoAtPipe } from './pipes/noAt.pipe';
import { DateTimePickerComponent } from './components/shared/date-time-picker/date-time-picker.component';
import { MsToMinPipe } from './pipes/ms-to-min.pipe';
import { DateTimeFormatterPipe } from './pipes/date-time-formatter.pipe';
import { CellRebootActionButtonComponent } from './components/cell-actions/cell-reboot-action-button/cell-reboot-action-button.component';
import { CapitalLetterPipe } from 'src/app/pipes/capital-letter.pipe';
import { ShowCellSiteMapButtonComponent } from './components/shared/show-cell-site-map-button/show-cell-site-map-button.component';
import { GetIconFromConfigPipe } from './pipes/get-icon-from-config.pipe';
import { StringifyPipe } from './pipes/stringify.pipe';
import { CellGroupPaneComponent } from './modules/cell-site-map/cell-group-pane/cell-group-pane.component';
import { InputSearchComponent } from './components/shared/input-search/input-search.component';
import { CamelCasePipe } from './pipes/camel-case.pipe';
import { BranchTabsComponent } from './components/branch-tab/branch-tabs.component';
import { CodeEditor, DiffEditor } from '@acrodata/code-editor';
import { ResolveObservablePipe } from './pipes/resolve-observable.pipe';
import { PolicySetManagementComponent } from './modules/policies/policy-set-management/policy-set-management.component';
import { DecodeUriPipe } from './pipes/decode-uri.pipe';
import { HeightAdjustmentDirective } from './directives/adjust-height.directive';
import { IsVisiblePipe } from './pipes/is-visible.pipe';
import { ScrollableFocusDirective } from './directives/scrollable-focus.directive';
import { KeyValueCellDirective } from './directives/key-value-cell.directive';
import { TableControlsComponent } from './components/shared/table-lib/table-controls/table-controls.component';
import { HasPermissionsDirective, HasPermissionPipe } from '@portal-mfe/auth';
import { HasOpaDataPipe } from './pipes/has-opa-data.pipe';
import { SlicesAttributePaneComponent } from './components/aai-node-attribute-pane/slices-attribute-pane/slices-attribute-pane.component';
import { TmapHelpComponent } from './modules/policies/policy-help/tmap-help/tmap-help.component';
import { RanHelpComponent } from './modules/policies/policy-help/ran-help/ran-help.component';
import { SfcHelpComponent } from './modules/policies/policy-help/sfc-help/sfc-help.component';
import { CapacityHelpComponent } from './modules/policies/policy-help/capacity-help/capacity-help.component';
import { CellRestrictionHelpComponent } from './modules/policies/policy-help/cell-restriction-help/cell-restriction-help.component';
import { SliceProvisioningHelpComponent } from './modules/policies/policy-help/slice-provisioning-help/slice-provisioning-help.component';
import { ServicetypeLimitHelpComponent } from './modules/policies/policy-help/servicetype-limit-help/servicetype-limit-help.component';
import { SnssaiOverlapHelpComponent } from './modules/policies/policy-help/snssai-overlap-help/snssai-overlap-help.component';
import { ResourceGroupsHelpComponent } from './modules/policies/policy-help/resource-groups-help/resource-groups-help.component';
import { PolicyHelpComponent } from './modules/policies/policy-help/policy-help.component';
import { ProvisioningHelpComponent } from './modules/policies/policy-help/provisioning-help/provisioning-help.component';
import { IsColumnVisiblePipe } from './pipes/is-column-visible.pipe';
import { DateFilterComponent } from './components/shared/filters/date-filter/date-filter.component';
import { StatusKeyPipe } from './pipes/statuskey.pipe';
import { KeyValueListComponent } from './components/shared/key-value-list/key-value-list.component';
import { TitleComponent } from '@portal-mfe/tnap-ui-kit/components/title';
import { LayoutComponent } from '@portal-mfe/tnap-ui-kit/components/layout-wrapper';
import {
  BreadcrumbComponent,
  BreadcrumbItemComponent,
} from '@portal-mfe/tnap-ui-kit/components/breadcrumb';
import { TnapButtonComponent } from '@portal-mfe/tnap-ui-kit/components/button';
import { BadgeComponent } from '@portal-mfe/tnap-ui-kit/components/badge';

import {
  DataTableComponent,
  TableCellDefinitionDirective,
  TableHeaderDefinitionDirective,
} from '@portal-mfe/tnap-ui-kit/components/data-table';
import { EmptyComponent as TnapEmptyComponent } from '@portal-mfe/tnap-ui-kit/components/empty';
@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    NgbDropdownModule,
    NgOptimizedImage,
    CodeEditor,
    DiffEditor,
    DragDropModule,
    HeightAdjustmentDirective,
    StringifyPipe,
    HasPermissionsDirective,
    HasPermissionPipe,
    KeyValueListComponent,
    TitleComponent,
    LayoutComponent,
    BreadcrumbComponent,
    BreadcrumbItemComponent,
    TnapButtonComponent,
    BadgeComponent,
    DataTableComponent,
    TableCellDefinitionDirective,
    TableHeaderDefinitionDirective,
    TnapEmptyComponent,
  ],
  declarations: [
    ColonPipe,
    MapPipe,
    DebugPipe,
    InPipe,
    IsTodayPipe,
    SanitizeUrlPipe,
    YesNoPipe,
    GetAlarmsByIdPipe,
    PasswordPipe,
    UnknownPipe,
    HideEmptyDetailRowDirective,
    SortComponent,
    EmptyComponent,
    TableSkeletonComponent,
    PaginationComponent,
    DetailRowComponent,
    AttributePaneComponent,
    ServiceInstanceAttributePaneComponent,
    ServiceSubscriptionAttributePaneComponent,
    OwningEntityAttributePaneComponent,
    ProjectAttributePaneComponent,
    TenantAttributePaneComponent,
    CloudRegionAttributePaneComponent,
    CustomerAttributePaneComponent,
    PnfAttributePaneComponent,
    GenericVnfAttributePaneComponent,
    VfModuleAttributePaneComponent,
    VserverAttributePaneComponent,
    ComplexAttributePaneComponent,
    AllottedResourceAttributePaneComponent,
    AaiAttributePaneComponent,
    AttributePaneComponent,
    HintComponent,
    AlarmAttributePaneComponent,
    AlarmSeverityCounterComponent,
    LoadingSpinnerComponent,
    ModelDeploymentStatusContentComponent,
    ExpandableTypeaheadComponent,
    RelativeTimeFilterComponent,
    CellNodeAttributePaneComponent,
    GeoRegionAttributePaneComponent,
    SiteResourceAttributePaneComponent,
    ValidMapSearchPipe,
    AlarmAggregationSeverityHasAlarmIdsPipe,
    DictionaryAttributePaneComponent,
    DetailSectionsComponent,
    FilterOutPnfsPipe,
    StringContainsPipe,
    HighlightPartOfTextPipe,
    CellListPaneComponent,
    GetKeyForAlarmAggregationPipe,
    UniversalFulltextFilterComponent,
    DateTimePickerComponent,
    EnsureValueIsNotArrayPipe,
    EnsureValueIsArrayPipe,
    ArrayContainsPipe,
    FindParentGnbPipe,
    SeverityClassPipe,
    NoAtPipe,
    DateTimeFormatterPipe,
    MsToMinPipe,
    CapitalLetterPipe,
    ShowCellSiteMapButtonComponent,
    CellRebootActionButtonComponent,
    GetIconFromConfigPipe,
    CellGroupPaneComponent,
    InputSearchComponent,
    CamelCasePipe,
    BranchTabsComponent,
    ResolveObservablePipe,
    PolicySetManagementComponent,
    DecodeUriPipe,
    TableControlsComponent,
    IsVisiblePipe,
    ScrollableFocusDirective,
    KeyValueCellDirective,
    HasOpaDataPipe,
    SlicesAttributePaneComponent,
    PolicyHelpComponent,
    ServicetypeLimitHelpComponent,
    SnssaiOverlapHelpComponent,
    CellRestrictionHelpComponent,
    SliceProvisioningHelpComponent,
    ResourceGroupsHelpComponent,
    CapacityHelpComponent,
    SfcHelpComponent,
    RanHelpComponent,
    TmapHelpComponent,
    ProvisioningHelpComponent,
    IsColumnVisiblePipe,
    DateFilterComponent,
    StatusKeyPipe,
  ],
  exports: [
    CommonModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    DragDropModule,
    ContextMenuModule,
    TranslateModule,
    CodeEditor,
    DiffEditor,
    NgOptimizedImage,
    HasPermissionPipe,
    ColonPipe,
    MapPipe,
    InPipe,
    DebugPipe,
    IsTodayPipe,
    SanitizeUrlPipe,
    YesNoPipe,
    GetAlarmsByIdPipe,
    UnknownPipe,
    HideEmptyDetailRowDirective,
    SortComponent,
    EmptyComponent,
    PaginationComponent,
    TableSkeletonComponent,
    DetailRowComponent,
    AttributePaneComponent,
    ServiceInstanceAttributePaneComponent,
    ServiceSubscriptionAttributePaneComponent,
    OwningEntityAttributePaneComponent,
    ProjectAttributePaneComponent,
    TenantAttributePaneComponent,
    CloudRegionAttributePaneComponent,
    CustomerAttributePaneComponent,
    PnfAttributePaneComponent,
    GenericVnfAttributePaneComponent,
    VfModuleAttributePaneComponent,
    VserverAttributePaneComponent,
    ComplexAttributePaneComponent,
    AllottedResourceAttributePaneComponent,
    AaiAttributePaneComponent,
    AttributePaneComponent,
    HintComponent,
    AlarmAttributePaneComponent,
    AlarmSeverityCounterComponent,
    LoadingSpinnerComponent,
    ModelDeploymentStatusContentComponent,
    PasswordPipe,
    ExpandableTypeaheadComponent,
    RelativeTimeFilterComponent,
    CellNodeAttributePaneComponent,
    GeoRegionAttributePaneComponent,
    SiteResourceAttributePaneComponent,
    DictionaryAttributePaneComponent,
    DetailSectionsComponent,
    FilterOutPnfsPipe,
    StringContainsPipe,
    HighlightPartOfTextPipe,
    CellListPaneComponent,
    GetKeyForAlarmAggregationPipe,
    UniversalFulltextFilterComponent,
    DateTimePickerComponent,
    EnsureValueIsNotArrayPipe,
    EnsureValueIsArrayPipe,
    ArrayContainsPipe,
    FindParentGnbPipe,
    SeverityClassPipe,
    NoAtPipe,
    MsToMinPipe,
    DateTimeFormatterPipe,
    CapitalLetterPipe,
    ShowCellSiteMapButtonComponent,
    CellRebootActionButtonComponent,
    GetIconFromConfigPipe,
    StringifyPipe,
    CellGroupPaneComponent,
    InputSearchComponent,
    CamelCasePipe,
    BranchTabsComponent,
    ResolveObservablePipe,
    PolicySetManagementComponent,
    DecodeUriPipe,
    ScrollableFocusDirective,
    KeyValueCellDirective,
    HasPermissionsDirective,
    HasOpaDataPipe,
    SlicesAttributePaneComponent,
    PolicyHelpComponent,
    IsColumnVisiblePipe,
    DateFilterComponent,
    KeyValueListComponent,
    StatusKeyPipe,
    TitleComponent,
    LayoutComponent,
    BreadcrumbComponent,
    BreadcrumbItemComponent,
    TnapButtonComponent,
  ],
})
export class SharedModule {}
