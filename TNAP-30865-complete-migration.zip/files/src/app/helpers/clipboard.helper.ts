/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { TranslateService } from '@ngx-translate/core';

export interface AlertNotifier {
  success(message: string, options?: unknown): void;
  error(message: string, options?: unknown): void;
}

const ALERT_OPTIONS = { keepAfterRouteChange: true };

/**
 * Copies text to the clipboard and shows a success/error alert via the
 * given TnapAlertService. Explicitly checks clipboard availability first -
 * `navigator.clipboard?.writeText(...)` alone would silently do nothing
 * (neither .then nor .catch fires) when the Clipboard API isn't available,
 * leaving the user with no feedback at all.
 */
export function copyToClipboardWithAlert(
  text: string,
  alertService: AlertNotifier,
  translateService: TranslateService
): void {
  if (!text) {
    return;
  }

  if (!navigator.clipboard) {
    alertService.error(
      translateService.instant('common.copyFailed'),
      ALERT_OPTIONS
    );
    return;
  }

  navigator.clipboard
    .writeText(text)
    .then(() =>
      alertService.success(
        translateService.instant('common.copySuccess'),
        ALERT_OPTIONS
      )
    )
    .catch(() =>
      alertService.error(
        translateService.instant('common.copyFailed'),
        ALERT_OPTIONS
      )
    );
}
