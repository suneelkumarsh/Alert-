/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { copyToClipboardWithAlert, AlertNotifier } from './clipboard.helper';

describe('copyToClipboardWithAlert', () => {
  let alertServiceSpy: jasmine.SpyObj<AlertNotifier>;
  let translateService: TranslateService;
  let originalClipboard: Clipboard;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
    });
    translateService = TestBed.inject(TranslateService);
    translateService.setTranslation('en', {
      common: {
        copySuccess: 'Copied to clipboard',
        copyFailed: 'Failed to copy',
      },
    });
    translateService.use('en');

    alertServiceSpy = jasmine.createSpyObj('AlertNotifier', [
      'success',
      'error',
    ]);

    originalClipboard = navigator.clipboard;
  });

  afterEach(() => {
    Object.defineProperty(navigator, 'clipboard', {
      value: originalClipboard,
      configurable: true,
    });
  });

  it('should do nothing for empty text', () => {
    copyToClipboardWithAlert('', alertServiceSpy, translateService);

    expect(alertServiceSpy.success).not.toHaveBeenCalled();
    expect(alertServiceSpy.error).not.toHaveBeenCalled();
  });

  it('should show a success alert when the clipboard write succeeds', fakeAsync(() => {
    spyOn(navigator.clipboard, 'writeText').and.resolveTo();

    copyToClipboardWithAlert('some text', alertServiceSpy, translateService);
    tick();

    expect(navigator.clipboard.writeText).toHaveBeenCalledWith('some text');
    expect(alertServiceSpy.success).toHaveBeenCalledWith(
      translateService.instant('common.copySuccess'),
      { keepAfterRouteChange: true }
    );
    expect(alertServiceSpy.error).not.toHaveBeenCalled();
  }));

  it('should show an error alert when the clipboard write is rejected', fakeAsync(() => {
    spyOn(navigator.clipboard, 'writeText').and.rejectWith(new Error('denied'));

    copyToClipboardWithAlert('some text', alertServiceSpy, translateService);
    tick();

    expect(alertServiceSpy.error).toHaveBeenCalledWith(
      translateService.instant('common.copyFailed'),
      { keepAfterRouteChange: true }
    );
    expect(alertServiceSpy.success).not.toHaveBeenCalled();
  }));

  // This is the specific case review comment #3 flagged: previously
  // `navigator.clipboard?.writeText(...)` would silently short-circuit
  // when clipboard is unavailable, so neither .then nor .catch ever ran
  // and the user got no feedback at all.
  it('should show an error alert immediately when the Clipboard API is unavailable, without calling writeText', () => {
    Object.defineProperty(navigator, 'clipboard', {
      value: undefined,
      configurable: true,
    });

    copyToClipboardWithAlert('some text', alertServiceSpy, translateService);

    expect(alertServiceSpy.error).toHaveBeenCalledWith(
      translateService.instant('common.copyFailed'),
      { keepAfterRouteChange: true }
    );
    expect(alertServiceSpy.success).not.toHaveBeenCalled();
  });
});
