/*
 * Copyright (c) 2023. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { TestBed, waitForAsync } from '@angular/core/testing';
import {
  HttpTestingController,
  provideHttpClientTesting,
} from '@angular/common/http/testing';
import {
  HttpErrorInterceptor,
  SUPPRESS_HTTP_ERROR_ALERT,
} from './http-error.interceptor';
import { TranslateService } from '@ngx-translate/core'; // Replace with actual import
import { Router } from '@angular/router'; // Replace with actual import
import {
  HttpContext,
  HttpHandler,
  HttpRequest,
  HttpResponse,
  provideHttpClient,
  withInterceptorsFromDi,
  HttpErrorResponse,
} from '@angular/common/http';
import { BehaviorSubject, of, throwError } from 'rxjs';
import { catchError, delay, timeout } from 'rxjs/operators';
import { LoggingService } from '../services/logging.service';
import { CamelCasePipe } from '../pipes/camel-case.pipe';
import { HTTP_ERROR_MESSAGES_CONFIG_CSV } from '../../assets/error_config/http-error-messages-config.generated';
import { IdleDetectorService } from 'src/app/services/idle-detector.service';
import { LogoutReason } from 'src/app/model/logout-reason.enum';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('HttpErrorInterceptor', () => {
  let interceptor: HttpErrorInterceptor;
  let httpMock: HttpTestingController;
  let alertService: TnapAlertService;
  let loggingService: LoggingService;
  const mockIdleDetectorService = {
    logoutReason: LogoutReason.Inactivity,
    showLogout$: new BehaviorSubject<boolean>(false),
  };
  beforeEach(waitForAsync(() => {
    mockIdleDetectorService.logoutReason = LogoutReason.Inactivity;
    mockIdleDetectorService.showLogout$ = new BehaviorSubject<boolean>(false);
    TestBed.configureTestingModule({
      imports: [],
      providers: [
        HttpErrorInterceptor,
        {
          provide: TranslateService,
          useValue: { instant: (key: string) => key },
        },
        {
          provide: TnapAlertService,
          useValue: {
            // eslint-disable-next-line @typescript-eslint/no-empty-function
            error: () => {},
            // eslint-disable-next-line @typescript-eslint/no-empty-function
            warn: () => {},
          },
        },
        { provide: Router, useValue: { url: '/DEFAULT' } },
        {
          provide: LoggingService,
          useValue: {
            // eslint-disable-next-line @typescript-eslint/no-empty-function
            writeLog: () => {},
            // eslint-disable-next-line @typescript-eslint/no-empty-function
            buildLoggingMessage: () => {},
          },
        },
        CamelCasePipe,
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting(),
        { provide: IdleDetectorService, useValue: mockIdleDetectorService },
      ],
    });

    interceptor = TestBed.inject(HttpErrorInterceptor);
    httpMock = TestBed.inject(HttpTestingController);
    alertService = TestBed.inject(TnapAlertService);
    loggingService = TestBed.inject(LoggingService);
  }));

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(interceptor).toBeTruthy();
  });

  it('should handle Onap Logging error (console warn)', () => {
    const consoleSpy = spyOn(console, 'warn');

    const request = new HttpRequest('GET', 'onap_logging');

    interceptor
      .intercept(request, {
        handle: () => throwError(() => new HttpErrorResponse({ status: 404 })),
      })
      .subscribe({
        next: () => fail('expected error'),
        error: () => {
          expect(consoleSpy).toHaveBeenCalled();
        },
      });
  });

  it('should suppress global alert when the request opts out of HTTP error toast', () => {
    spyOn(alertService, 'error');

    const request = new HttpRequest('GET', 'some-url', null, {
      context: new HttpContext().set(SUPPRESS_HTTP_ERROR_ALERT, true),
    });

    interceptor
      .intercept(request, {
        handle: () =>
          throwError(
            () =>
              new HttpErrorResponse({
                status: 500,
                statusText: 'Server Error',
              })
          ),
      })
      .pipe(catchError(err => of(err)))
      .subscribe();

    expect(alertService.error).not.toHaveBeenCalled();
  });

  it('should handle Timeout error', () => {
    spyOn(loggingService, 'writeLog');

    const request = new HttpRequest('GET', 'some-url');
    interceptor
      .intercept(request, timeoutHttpHandler)
      .pipe(
        timeout(0),
        catchError(err => {
          expect(loggingService.writeLog).toHaveBeenCalled();
          return of(err);
        })
      )
      .subscribe();
  });

  it('should trigger authentication logout flow for keycloak errors', () => {
    spyOn(mockIdleDetectorService.showLogout$, 'next');

    const request = new HttpRequest('GET', '/api/keycloak/any');

    interceptor
      .intercept(request, {
        handle: () =>
          throwError(
            () =>
              new HttpErrorResponse({
                status: 0,
              })
          ),
      })
      .pipe(
        catchError(err => {
          expect(mockIdleDetectorService.logoutReason).toBe(
            LogoutReason.Authentication
          );

          expect(mockIdleDetectorService.showLogout$.next).toHaveBeenCalledWith(
            true
          );

          return of(err);
        })
      )
      .subscribe();
  });

  it('should handle Cell error - lock', () => {
    spyOn(alertService, 'error');

    const request = new HttpRequest('POST', 'cells/lock', {});

    interceptor
      .intercept(request, dummyHttpHandler(403))
      .pipe(
        catchError(err => {
          expect(alertService.error).toHaveBeenCalledWith(
            'lockFunctionality',
            jasmine.any(Object)
          );
          return of(err);
        })
      )
      .subscribe();
  });

  it('should handle Cell error - unlock', () => {
    spyOn(alertService, 'error');

    const request = new HttpRequest('POST', 'cells/unlock', {});

    interceptor
      .intercept(request, dummyHttpHandler(403))
      .pipe(
        catchError(err => {
          expect(alertService.error).toHaveBeenCalledWith(
            'unlockFunctionality',
            jasmine.any(Object)
          );
          return of(err);
        })
      )
      .subscribe();
  });

  it('should handle Cell error - ids', () => {
    spyOn(alertService, 'error');

    const request = new HttpRequest('POST', 'cells/ids', {});

    interceptor
      .intercept(request, dummyHttpHandler(403))
      .pipe(
        catchError(err => {
          expect(alertService.error).toHaveBeenCalledWith(
            'displayCells',
            jasmine.any(Object)
          );
          return of(err);
        })
      )
      .subscribe();
  });

  it('should handle Treeview No Data error', () => {
    spyOn(alertService, 'error');

    const request = new HttpRequest('GET', 'treeview/service-type');

    interceptor
      .intercept(request, dummyHttpHandler(403))
      .pipe(
        catchError(err => {
          expect(alertService.error).toHaveBeenCalledWith(
            'noDataDisplayedTreeview',
            jasmine.any(Object)
          );
          return of(err);
        })
      )
      .subscribe();
  });

  it('should handle Preference error - save', () => {
    spyOn(alertService, 'error');

    const request = new HttpRequest('POST', 'preferences', {});
    interceptor
      .intercept(request, dummyHttpHandler(400))
      .pipe(
        catchError(err => {
          expect(alertService.error).toHaveBeenCalledWith(
            'savePreferences',
            jasmine.any(Object)
          );
          return of(err);
        })
      )
      .subscribe();
  });

  it('should handle Preference error - load', () => {
    spyOn(alertService, 'error');

    const request = new HttpRequest('GET', 'preferences');

    interceptor
      .intercept(request, dummyHttpHandler(500))
      .pipe(
        catchError(err => {
          expect(alertService.error).toHaveBeenCalledWith(
            'loadPreferences',
            jasmine.any(Object)
          );
          return of(err);
        })
      )
      .subscribe();
  });

  it('should handle Action error - save', () => {
    spyOn(alertService, 'error');

    const request = new HttpRequest('POST', '/actions', {});

    interceptor
      .intercept(request, dummyHttpHandler(422))
      .pipe(
        catchError(err => {
          expect(alertService.error).toHaveBeenCalledWith(
            'saveAction',
            jasmine.any(Object)
          );
          return of(err);
        })
      )
      .subscribe();
  });

  it('should handle Validation Policies error', () => {
    spyOn(alertService, 'error');

    const request = new HttpRequest('POST', '/policies/validation', {});
    const problemError = {
      title: 'Bad Request',
      status: 400,
      detail: '',
    };

    interceptor
      .intercept(request, {
        handle: () =>
          throwError(
            () =>
              new HttpErrorResponse({
                status: 400,
                error: problemError,
              })
          ),
      })
      .pipe(
        catchError(err => {
          expect(alertService.error).toHaveBeenCalledWith(
            'common.block.validatePolicy',
            jasmine.any(Object)
          );
          return of(err);
        })
      )
      .subscribe();
  });

  it('should handle Policies error on POST', () => {
    spyOn(alertService, 'error');

    const request = new HttpRequest('POST', '/policies', {});
    const problemError = {
      title: 'Conflict',
      status: 400,
      detail: '',
    };
    interceptor
      .intercept(request, {
        handle: () =>
          throwError(
            () =>
              new HttpErrorResponse({
                status: 400,
                error: problemError,
              })
          ),
      })
      .pipe(
        catchError(err => {
          expect(alertService.error).toHaveBeenCalledWith(
            'common.block.savePolicy',
            jasmine.any(Object)
          );
          return of(err);
        })
      )
      .subscribe();
  });

  it('should handle RU Management error on GET', () => {
    spyOn(alertService, 'error');

    const request = new HttpRequest('GET', '/pnfs', {});
    const problemError = {
      title: 'Not Found',
      status: 404,
      detail: '',
    };

    interceptor
      .intercept(request, {
        handle: () =>
          throwError(
            () =>
              new HttpErrorResponse({
                status: 404,
                error: problemError,
              })
          ),
      })
      .pipe(
        catchError(err => {
          expect(alertService.error).toHaveBeenCalledWith(
            'common.block.noDataDisplayRus',
            jasmine.any(Object)
          );
          return of(err);
        })
      )
      .subscribe();
  });

  it('should handle Create Slice Template error without file exists', () => {
    const router = TestBed.inject(Router);
    (router as any).url = '/slice-template/create';
    spyOn(alertService, 'error');

    const request = new HttpRequest('POST', '/api/service-templates', {});
    const problemError = {
      title: 'Bad Request',
      status: 400,
      detail: 'Some other error',
    };

    interceptor
      .intercept(request, {
        handle: () =>
          throwError(
            () =>
              new HttpErrorResponse({
                status: 400,
                error: problemError,
              })
          ),
      })
      .pipe(
        catchError(err => {
          expect(alertService.error).toHaveBeenCalledWith(
            'sliceManagement.sliceTemplate.messages.saveError',
            jasmine.any(Object)
          );
          return of(err);
        })
      )
      .subscribe();
  });

  it('should handle User Administration error - delete permissions missing', () => {
    spyOn(alertService, 'error');

    const request = new HttpRequest('DELETE', 'user-administration');
    const problemError = {
      title: 'Not authorized',
      status: 403,
      detail: 'Some other error',
    };

    interceptor
      .intercept(request, {
        handle: () =>
          throwError(
            () =>
              new HttpErrorResponse({
                status: 403,
                error: problemError,
              })
          ),
      })
      .pipe(
        catchError(err => {
          expect(alertService.error).toHaveBeenCalledWith(
            'common.block.error403NotAuthorized',
            jasmine.any(Object)
          );
          return of(err);
        })
      )
      .subscribe();
  });

  it('should handle User Administration error - create', () => {
    spyOn(alertService, 'error');

    const request = new HttpRequest('POST', 'user-administration/create', {});

    interceptor
      .intercept(request, dummyHttpHandler(409))
      .pipe(
        catchError(err => {
          expect(alertService.error).toHaveBeenCalledWith(
            'userAdministration.create',
            jasmine.any(Object)
          );
          return of(err);
        })
      )
      .subscribe();
  });

  it('should handle User Administration error - edit', () => {
    spyOn(alertService, 'error');

    const request = new HttpRequest('PUT', 'user-administration/edit', {});

    interceptor
      .intercept(request, dummyHttpHandler(422))
      .pipe(
        catchError(err => {
          expect(alertService.error).toHaveBeenCalledWith(
            'userAdministration.edit',
            jasmine.any(Object)
          );
          return of(err);
        })
      )
      .subscribe();
  });

  describe('rule-driven scenario checks', () => {
    interface ScenarioExpectation {
      error?: string;
      warn?: string;
      none?: true;
    }

    interface ErrorScenario {
      name: string;
      route: string;
      request: HttpRequest<any>;
      response: HttpErrorResponse;
      expected: ScenarioExpectation;
    }

    const runScenario = (scenario: ErrorScenario, done: DoneFn): void => {
      const router = TestBed.inject(Router);
      (router as any).url = scenario.route;

      const errorSpy = spyOn(alertService, 'error');
      const warnSpy = spyOn(alertService, 'warn');

      interceptor
        .intercept(scenario.request, {
          handle: () => throwError(() => scenario.response),
        })
        .subscribe({
          next: () => fail('Expected request to fail'),
          error: () => {
            if (scenario.expected.none) {
              expect(errorSpy).not.toHaveBeenCalled();
              expect(warnSpy).not.toHaveBeenCalled();
              done();
              return;
            }

            if (scenario.expected.error) {
              expect(errorSpy).toHaveBeenCalledWith(
                scenario.expected.error,
                jasmine.any(Object)
              );
            }
            if (scenario.expected.warn) {
              expect(warnSpy).toHaveBeenCalledWith(
                scenario.expected.warn,
                jasmine.any(Object)
              );
            }

            done();
          },
        });
    };

    const scenarios: ErrorScenario[] = [
      {
        name: 'api/users generic rule precedence',
        route: '/user-administration',
        request: new HttpRequest('GET', '/api/users', {}),
        response: new HttpErrorResponse({
          status: 404,
          error: {
            title: 'Not Found',
            status: 404,
            detail: 'no users found',
          },
        }),
        expected: { error: 'common.block.noDataForUserAdmin' },
      },
      {
        name: 'custom create-slice-template warning',
        route: '/slice-template/create',
        request: new HttpRequest('POST', '/api/service-templates', {}),
        response: new HttpErrorResponse({
          status: 409,
          error: {
            title: 'Conflict',
            status: 409,
            detail: 'Service template exists',
          },
        }),
        expected: {
          warn: 'sliceManagement.sliceTemplate.messages.saveErrorFileExists',
        },
      },
      {
        name: 'default fallback when no rule matches',
        route: '/totally-unmatched-route',
        request: new HttpRequest('GET', '/unmatched-backend-url'),
        response: new HttpErrorResponse({
          status: 418,
          error: { title: 'Teapot', status: 418, detail: 'short and stout' },
        }),
        expected: { error: 'common.block.defaultMessage' },
      },
      {
        name: 'ran-filters query-attributes maps to search failed',
        route: '/ran-filter',
        request: new HttpRequest('GET', '/api/ran-filters/query-attributes'),
        response: new HttpErrorResponse({
          status: 400,
          error: {
            title: 'Bad Request',
            status: 400,
            detail: 'invalid query attributes',
          },
        }),
        expected: { error: 'common.block.ranFilterSearchFailed' },
      },
      {
        name: 'ran-filters vendor maps to vendor load failed',
        route: '/ran-filter',
        request: new HttpRequest('GET', '/api/ran-filters/vendor'),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'vendor service unavailable',
          },
        }),
        expected: { error: 'common.block.ranFilterVendorLoadFailed' },
      },
      {
        name: 'ran-filters test endpoint has precedence over generic GET ran-filter rule',
        route: '/ran-filter',
        request: new HttpRequest('GET', '/api/ran-filters/abc/test'),
        response: new HttpErrorResponse({
          status: 400,
          error: {
            title: 'Bad Request',
            status: 400,
            detail: 'verification failed',
          },
        }),
        expected: { error: 'common.block.ranFilterVerifyFailed' },
      },
      {
        name: 'ran-filters execute endpoint maps to execute failed',
        route: '/ran-filter',
        request: new HttpRequest('POST', '/api/ran-filters/abc/execute', {}),
        response: new HttpErrorResponse({
          status: 400,
          error: {
            title: 'Bad Request',
            status: 400,
            detail: 'execution failed',
          },
        }),
        expected: { error: 'common.block.ranFilterExecuteFailed' },
      },
      {
        name: 'ran-filters DELETE maps to delete failed',
        route: '/ran-filter',
        request: new HttpRequest('DELETE', '/api/ran-filters/abc'),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'delete failed',
          },
        }),
        expected: { error: 'common.block.ranFilterDeleteFailed' },
      },
      {
        name: 'ran-filters PUT maps to update failed',
        route: '/ran-filter',
        request: new HttpRequest('PUT', '/api/ran-filters/abc', {}),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'update failed',
          },
        }),
        expected: { error: 'common.block.ranFilterUpdateFailed' },
      },
      {
        name: 'ran-filters POST maps to save failed',
        route: '/ran-filter',
        request: new HttpRequest('POST', '/api/ran-filters', {}),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'save failed',
          },
        }),
        expected: { error: 'common.block.ranFilterSaveFailed' },
      },
      {
        name: 'ran-filters GET maps to load failed',
        route: '/ran-filter',
        request: new HttpRequest('GET', '/api/ran-filters'),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'load failed',
          },
        }),
        expected: { error: 'common.block.ranFilterLoadFailed' },
      },
      {
        name: 'actions GET maps to loadAction',
        route: '/user-administration/edit',
        request: new HttpRequest('GET', '/api/actions'),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'action load failed',
          },
        }),
        expected: { error: 'common.block.loadAction' },
      },
      {
        name: 'slice list endpoint maps to noDataDisplayedSliceMngmt',
        route: '/slice-management',
        request: new HttpRequest('GET', '/api/network/v2/slices'),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'slice list failed',
          },
        }),
        expected: { error: 'common.block.noDataDisplayedSliceMngmt' },
      },
      {
        name: 'slice detail endpoint with UUID maps to noDetailDisplayedSliceMngmt',
        route: '/slice-management',
        request: new HttpRequest(
          'GET',
          '/api/network/v2/slices/123e4567-e89b-12d3-a456-426614174000'
        ),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'slice detail failed',
          },
        }),
        expected: { error: 'common.block.noDetailDisplayedSliceMngmt' },
      },
      {
        name: 'slice detail endpoint without UUID falls back to list message',
        route: '/slice-management',
        request: new HttpRequest('GET', '/api/network/v2/slices/not-a-uuid'),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'invalid slice id path',
          },
        }),
        expected: { error: 'common.block.noDataDisplayedSliceMngmt' },
      },
      {
        name: 'portal route fallback for cell-site-map',
        route: '/cell-site-map',
        request: new HttpRequest('GET', '/api/unmatched-backend-url'),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'cell-site-map fallback',
          },
        }),
        expected: { error: 'common.block.cellSiteMap' },
      },
      {
        name: 'portal route fallback for alarm',
        route: '/alarm',
        request: new HttpRequest('GET', '/api/unmatched-backend-url'),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'alarm fallback',
          },
        }),
        expected: { error: 'common.block.alarm' },
      },
      {
        name: 'portal route fallback for topology',
        route: '/topology',
        request: new HttpRequest('GET', '/api/unmatched-backend-url'),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'topology fallback',
          },
        }),
        expected: { error: 'common.block.topology' },
      },
      {
        name: 'portal route fallback for kpi-dashboard',
        route: '/kpi-dashboard',
        request: new HttpRequest('GET', '/api/unmatched-backend-url'),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'kpi fallback',
          },
        }),
        expected: { error: 'common.block.kpiDashboard' },
      },
      {
        name: 'portal route fallback for grafana',
        route: '/grafana',
        request: new HttpRequest('GET', '/api/unmatched-backend-url'),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'grafana fallback',
          },
        }),
        expected: { error: 'common.block.grafana' },
      },
      {
        name: 'portal route fallback for dashboard',
        route: '/dashboard',
        request: new HttpRequest('GET', '/api/unmatched-backend-url'),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'dashboard fallback',
          },
        }),
        expected: { error: 'common.block.dashboard' },
      },
      {
        name: 'portal route fallback for app-starter',
        route: '/app-starter',
        request: new HttpRequest('GET', '/api/unmatched-backend-url'),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'app-starter fallback',
          },
        }),
        expected: { error: 'common.block.appStarter' },
      },
      {
        name: 'cm-action/download maps to cmActionExportFailed',
        route: '/cm-actions',
        request: new HttpRequest('GET', '/api/cm-action/download'),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'export failed',
          },
        }),
        expected: { error: 'common.block.cmActionExportFailed' },
      },
      {
        name: 'cm-action/download rule is not shadowed by generic api/cm-action rule',
        route: '/cm-actions',
        request: new HttpRequest('GET', '/api/cm-action/download'),
        response: new HttpErrorResponse({
          status: 500,
          error: {
            title: 'Internal Server Error',
            status: 500,
            detail: 'Content type application/json not supported',
          },
        }),
        expected: { error: 'common.block.cmActionExportFailed' },
      },
      {
        name: 'ran-template resourcebyname not found is handled silently',
        route: '/ran-template/edit',
        request: new HttpRequest(
          'GET',
          '/api/service-design-and-creation/taskworkflow/resourcebyname'
        ),
        response: new HttpErrorResponse({
          status: 404,
          error: {
            title: '404_NOT_FOUND',
            status: 404,
            detail: 'any message',
          },
        }),
        expected: { none: true },
      },
    ];

    scenarios.forEach(scenario => {
      it(`should handle scenario: ${scenario.name}`, done => {
        runScenario(scenario, done);
      });
    });
  });

  describe('csv precedence safety checks', () => {
    interface CsvRule {
      index: number;
      northboundMethod: string;
      northboundUrlContains: string;
      southboundUrlContains: string;
      southboundStatus?: number;
      southboundMsgContains: string;
      specialFunction: string;
    }

    const parseCsvRules = (): CsvRule[] => {
      const lines = HTTP_ERROR_MESSAGES_CONFIG_CSV.split('\n')
        .map(line => line.trim())
        .filter(line => line && !line.startsWith('#'));

      return lines.slice(1).map((line, idx) => {
        const parts = line.split(',').map(part => part.trim());
        const southboundStatusRaw = parts[3] || '';
        const southboundStatus = Number(southboundStatusRaw);

        return {
          index: idx + 2, // +1 for zero-based, +1 for header line
          northboundMethod: (parts[0] || '').toUpperCase(),
          northboundUrlContains: parts[1] || '',
          southboundUrlContains: parts[2] || '',
          southboundStatus:
            southboundStatusRaw && Number.isFinite(southboundStatus)
              ? southboundStatus
              : undefined,
          southboundMsgContains: (parts[4] || '').toLowerCase(),
          specialFunction: parts[7] || '',
        };
      });
    };

    const toTokenSet = (value: string): Set<string> =>
      new Set(
        value
          .split('|')
          .map(token => token.trim().toLowerCase())
          .filter(Boolean)
      );

    const isSubset = (subset: Set<string>, superset: Set<string>): boolean => {
      for (const token of subset) {
        if (!superset.has(token)) {
          return false;
        }
      }
      return true;
    };

    const methodsOverlap = (a: string, b: string): boolean => {
      if (!a || !b) {
        return true;
      }
      const aSet = toTokenSet(a);
      const bSet = toTokenSet(b);
      for (const method of aSet) {
        if (bSet.has(method)) {
          return true;
        }
      }
      return false;
    };

    const earlierRuleCoversLaterRule = (
      earlier: CsvRule,
      later: CsvRule
    ): boolean => {
      if (earlier.specialFunction) {
        return false;
      }

      if (!methodsOverlap(earlier.northboundMethod, later.northboundMethod)) {
        return false;
      }

      const earlierNorthboundTokens = toTokenSet(earlier.northboundUrlContains);
      const laterNorthboundTokens = toTokenSet(later.northboundUrlContains);
      if (!isSubset(earlierNorthboundTokens, laterNorthboundTokens)) {
        return false;
      }

      const earlierSouthboundTokens = toTokenSet(earlier.southboundUrlContains);
      const laterSouthboundTokens = toTokenSet(later.southboundUrlContains);
      if (!isSubset(earlierSouthboundTokens, laterSouthboundTokens)) {
        return false;
      }

      if (
        earlier.southboundStatus !== undefined &&
        earlier.southboundStatus !== later.southboundStatus
      ) {
        return false;
      }

      if (
        earlier.southboundMsgContains &&
        !later.southboundMsgContains.includes(earlier.southboundMsgContains)
      ) {
        return false;
      }

      return true;
    };

    it('should not have broad earlier csv rules shadowing more specific later rules', () => {
      const rules = parseCsvRules();
      const shadowPairs: string[] = [];

      for (let i = 0; i < rules.length; i++) {
        for (let j = i + 1; j < rules.length; j++) {
          if (earlierRuleCoversLaterRule(rules[i], rules[j])) {
            shadowPairs.push(
              `line ${rules[i].index} may shadow line ${rules[j].index}`
            );
          }
        }
      }

      expect(shadowPairs).withContext(shadowPairs.join('\n')).toEqual([]);
    });
  });

  it('should handle successful response', () => {
    const request = new HttpRequest('GET', 'some-url');
    const response = new HttpResponse({ body: {} });

    interceptor
      .intercept(request, httpOkHandler)
      .pipe(
        catchError(err => {
          // This shouldn't be called in case of a successful response
          expect(true).toBe(false);
          return of(err);
        })
      )
      .subscribe(res => {
        expect(res).toEqual(response);
      });
  });
});
const httpOkHandler: HttpHandler = {
  handle: () => of(new HttpResponse({ status: 200, body: {} })),
};
const dummyHttpHandler = (status: number): HttpHandler => ({
  handle: () => of(new HttpResponse({ status })),
});

const timeoutHttpHandler: HttpHandler = {
  handle: () => of(new HttpResponse()).pipe(delay(1000)),
};
