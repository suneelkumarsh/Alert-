/*
 * Copyright (c) 2022. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  HttpContextToken,
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError, TimeoutError } from 'rxjs';
import { catchError, take } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { Problem } from '../../../openapi/output';
import { Router } from '@angular/router';
import { DEFAULT_TIMEOUT } from './timeout.interceptor';
import { LoggingService } from '../services/logging.service';
import { toCamelCase } from '../helpers/helpers';
import { HTTP_ERROR_MESSAGES_CONFIG_CSV } from '../../assets/error_config/http-error-messages-config.generated';
import { IdleDetectorService } from '../services/idle-detector.service';
import { LogoutReason } from '../model/logout-reason.enum';
import {
  TnapAlertService,
  CauseType,
} from '@portal-mfe/tnap-ui-kit/components/alert';

/**
 * This class adds global handling of http-request related errors
 */

export const SUPPRESS_HTTP_ERROR_ALERT = new HttpContextToken<boolean>(
  () => false
);

export enum RequestMethod {
  DELETE = 'DELETE',
  POST = 'POST',
  GET = 'GET',
}

/**
 * (Browser sees portalURL) -> northbound leg    -> (BFF) -> southbound leg    -> (Southbound system)
 *                          <- northboundProblem <- (BFF) <- southboundProblem <-
 *
 * northBoundProblem: Any issue from browser SPA towards the portal BFF
 *   will be visible at the top level of the response object
 *
 * southBoundProblem: Any issue from the portal BFF to another system
 *   will be visible in the error attribute of the response object
 *
 * portalURL: The URL the user gets displayed in the browser
 *
 */
interface ProblemDetail {
  cause: CauseType;
  portalURL: string;
  northboundProblem: NorthboundProblem | null;
  southboundProblem: Problem | null; //Problem Interface defined by BFF OpenAPI file
  traceId?: string;
}

export interface NorthboundProblem {
  message: string;
  status: number;
}

type ConfiguredErrorType = 'error' | 'warn' | 'none' | 'custom';

interface ConfiguredErrorRule {
  northboundMethod: string;
  northboundUrlContains: string;
  southboundUrlContains: string;
  southboundStatus?: number;
  southboundMsgContains: string;
  errorType: ConfiguredErrorType;
  errorMessage: string;
  specialFunction: string;
}

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {
  verbose = false; // Preparation for future config of warning verbosity
  private readonly slicesIdRegex =
    /[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/;

  private readonly configuredErrorRules = this.parseConfiguredErrorRules(
    HTTP_ERROR_MESSAGES_CONFIG_CSV
  );
  constructor(
    private readonly alertService: TnapAlertService<Problem>,
    private readonly translateService: TranslateService,
    private readonly router: Router,
    private readonly loggingService: LoggingService,
    public idleDetectorService: IdleDetectorService
  ) {}
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    if (!navigator.onLine) {
      this.handleOfflineError();
      return throwError('No internet connection');
    }

    if (request.context.get(SUPPRESS_HTTP_ERROR_ALERT)) {
      return next.handle(request).pipe(
        catchError((error: HttpErrorResponse | TimeoutError) => {
          return throwError(() => error);
        })
      );
    }

    return next.handle(request).pipe(
      catchError((error: HttpErrorResponse | TimeoutError) => {
        return this.handleErrorResponse(request, error);
      })
    );
  }

  private handleOfflineError(): void {
    this.alertService.warn(
      this.translateService.instant('common.connectivityLoss.warning')
    );
  }

  private handleErrorResponse(
    request: HttpRequest<any>,
    response: HttpErrorResponse | TimeoutError
  ): Observable<never> {
    const detail = this.gatherErrorDetails(request, response);

    if (response instanceof TimeoutError) {
      this.handleTimeoutError(request, detail);
      return throwError(response);
    }

    const ruleResult = this.applyConfiguredRules(request, response, detail);

    if (ruleResult === 'noMatch') {
      this.logPotentialErrorRuleCandidate(request, detail);
      this.raiseErrorMessage('common.block.defaultMessage', detail);
    }

    return throwError(response);
  }

  private logKeycloakIssue(
    request: HttpRequest<any>,
    response: HttpErrorResponse
  ): void {
    if (this.verbose) {
      console.log('KeyCloak auth issue: %s ----- %s', request, response);
    }
  }

  private gatherErrorDetails(
    request: HttpRequest<any>,
    response: HttpErrorResponse | TimeoutError
  ): ProblemDetail {
    const portalURL = this.router.url;
    const southboundProblem = this.southboundProblemIfExists(response);
    const northboundProblem = this.northboundProblemIfExists(response);
    const traceId = request.headers.get('x-b3-traceid') || undefined;
    const cause = this.checkOnProblemCause(
      northboundProblem,
      southboundProblem
    );
    return {
      cause,
      northboundProblem,
      southboundProblem,
      traceId,
      portalURL,
    };
  }

  checkOnProblemCause(
    northboundProblem: any,
    southboundProblem: any
  ): CauseType {
    if (northboundProblem) {
      return 'NORTHBOUND';
    }
    if (southboundProblem) {
      return 'SOUTHBOUND';
    }
    return 'SYSTEM';
  }

  private parseCSVLine(line: string): string[] {
    /**
     * RFC-4180 compliant CSV parser to handle quoted fields containing commas.
     * Fields wrapped in double quotes can contain commas without breaking the structure.
     * Example: "value, with, commas" is treated as a single field.
     */
    const parts: string[] = [];
    let current = '';
    let insideQuotes = false;

    for (let i = 0; i < line.length; i++) {
      const char = line[i];

      if (char === '"') {
        insideQuotes = !insideQuotes;
      } else if (char === ',' && !insideQuotes) {
        parts.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }

    parts.push(current.trim());
    return parts;
  }

  private parseConfiguredErrorRules(csv: string): ConfiguredErrorRule[] {
    const lines = csv
      .split('\n')
      .map(line => line.trim())
      .filter(line => line && !line.startsWith('#'));

    if (lines.length <= 1) {
      return [];
    }

    return lines.slice(1).map((line, index) => {
      const parts = this.parseCSVLine(line);
      const southboundStatusRaw = parts[3] || '';
      const southboundStatus = Number(southboundStatusRaw);

      // Validate that we have at least 8 columns (indices 0-7)
      if (parts.length < 8) {
        console.warn(
          `HttpErrorInterceptor: CSV line ${index + 2} has fewer than 8 columns. Expected at least 8, got ${parts.length}. This rule may not work correctly.`,
          { line, parts }
        );
      }

      return {
        northboundMethod: (parts[0] || '').toUpperCase(),
        northboundUrlContains: parts[1] || '',
        southboundUrlContains: parts[2] || '',
        southboundStatus:
          southboundStatusRaw && Number.isFinite(southboundStatus)
            ? southboundStatus
            : undefined,
        southboundMsgContains: parts[4] || '',
        errorType: (parts[5] || 'error') as ConfiguredErrorType,
        errorMessage: parts[6] || '',
        specialFunction: parts[7] || '',
      };
    });
  }

  private applyConfiguredRules(
    request: HttpRequest<any>,
    response: HttpErrorResponse | TimeoutError,
    detail: ProblemDetail
  ): 'handled' | 'noMatch' {
    // hard guard against recursive logging loops
    if (request.url.includes('onap_logging')) {
      this.handleFrontendLoggingError();
      return 'handled';
    }

    for (const rule of this.configuredErrorRules) {
      if (!this.matchesConfiguredRule(rule, request, detail, response)) {
        continue;
      }

      if (this.applySpecialFunction(rule, request, response, detail)) {
        return 'handled';
      }

      if (rule.errorType === 'custom') {
        continue;
      }

      if (rule.errorType === 'none') {
        return 'handled';
      }

      if (rule.errorType === 'warn') {
        this.raiseWarningMessage(rule.errorMessage, detail);
        return 'handled';
      }

      if (rule.errorType === 'error') {
        this.raiseErrorMessage(rule.errorMessage, detail);
        return 'handled';
      }

      // No handler fired for a matched non-custom rule — log to make misconfiguration visible
      console.warn(
        'HttpErrorInterceptor: rule matched but no handler applied (errorType: ' +
          rule.errorType +
          '). Please check CSV configuration.',
        { rule, detail }
      );
      return 'handled';
    }

    return 'noMatch';
  }

  private matchesConfiguredRule(
    rule: ConfiguredErrorRule,
    request: HttpRequest<any>,
    detail: ProblemDetail,
    response: HttpErrorResponse | TimeoutError
  ): boolean {
    if (!this.matchesMethod(request.method, rule.northboundMethod)) {
      return false;
    }

    if (
      !this.matchesContainsTokens(detail.portalURL, rule.northboundUrlContains)
    ) {
      return false;
    }

    if (!this.matchesContainsTokens(request.url, rule.southboundUrlContains)) {
      return false;
    }

    if (rule.southboundStatus !== undefined) {
      const status = this.extractRelevantStatus(detail, response);
      if (status !== rule.southboundStatus) {
        return false;
      }
    }

    if (rule.southboundMsgContains) {
      const combinedMessage = [
        detail.southboundProblem?.detail,
        detail.northboundProblem?.message,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();

      if (!combinedMessage.includes(rule.southboundMsgContains.toLowerCase())) {
        return false;
      }
    }

    return true;
  }

  private matchesMethod(requestMethod: string, methodConfig: string): boolean {
    if (!methodConfig) {
      return true;
    }

    return methodConfig
      .split('|')
      .map(token => token.trim().toUpperCase())
      .filter(Boolean)
      .some(token => token === requestMethod.toUpperCase());
  }

  private matchesContainsTokens(
    value: string,
    containsConfig: string
  ): boolean {
    if (!containsConfig) {
      return true;
    }

    return containsConfig
      .split('|')
      .map(token => token.trim())
      .filter(Boolean)
      .every(token => value.includes(token));
  }

  private extractRelevantStatus(
    detail: ProblemDetail,
    response: HttpErrorResponse | TimeoutError
  ): number | undefined {
    if (detail.southboundProblem?.downstreamStatus) {
      return detail.southboundProblem.downstreamStatus;
    }
    if (detail.southboundProblem?.status) {
      return detail.southboundProblem.status;
    }
    if (response instanceof HttpErrorResponse) {
      return response.status;
    }
    return undefined;
  }

  private handleErrorSilently(): void {
    // Silently handle the error without showing alerts
  }

  /**
   * Handle policy validation errors.
   * If the error response contains a 'violations' array (from Rego linting),
   * suppress the global alert toast to allow the policy builder component
   * to display the violations inline instead.
   * Otherwise, show the standard error message.
   */
  private handlePolicyValidationError(
    response: HttpErrorResponse,
    detail: ProblemDetail
  ): boolean {
    if (response.error && typeof response.error === 'object') {
      // Check for violations in error body (nested in errorDetails or at top level)
      const errorDetails = response.error.errorDetails as
        | Record<string, unknown>
        | undefined;
      const violations =
        (errorDetails?.violations as unknown[]) ||
        (response.error.violations as unknown[]);

      if (Array.isArray(violations) && violations.length > 0) {
        // Violations are present — suppress the alert and let the component handle it
        return true;
      }
    }

    // No violations found — show the standard error message
    this.raiseErrorMessage(
      detail.southboundProblem?.detail || 'common.block.validatePolicy',
      detail
    );
    return true;
  }

  private handleSliceIdRegexMatch(
    rule: ConfiguredErrorRule,
    request: HttpRequest<any>,
    detail: ProblemDetail
  ): boolean {
    const id = request.url.split('/').at(-1) || '';
    if (!id || !this.slicesIdRegex.test(id)) {
      return false;
    }

    this.raiseErrorMessage(rule.errorMessage, detail);
    return true;
  }

  private applySpecialFunction(
    rule: ConfiguredErrorRule,
    request: HttpRequest<any>,
    response: HttpErrorResponse | TimeoutError,
    detail: ProblemDetail
  ): boolean {
    switch (rule.specialFunction) {
      case 'handleKeycloakError':
        if (response instanceof HttpErrorResponse) {
          this.logKeycloakIssue(request, response);
        }
        this.handleKeycloakError();
        return true;
      case 'handleErrorSilently':
        this.handleErrorSilently();
        return true;
      case 'handlePolicyValidationError':
        if (response instanceof HttpErrorResponse) {
          return this.handlePolicyValidationError(response, detail);
        }
        return false;
      case 'sliceIdRegexMatch':
        return this.handleSliceIdRegexMatch(rule, request, detail);
      default:
        return false;
    }
  }

  private logPotentialErrorRuleCandidate(
    request: HttpRequest<any>,
    detail: ProblemDetail
  ): void {
    console.log('CHECK IF THIS CAN BECOME AN ERROR MESSAGE', {
      request_method: request.method,
      request_url_contains: detail.portalURL,
      service_url_contains: request.url,
      service_status:
        detail.southboundProblem?.downstreamStatus ||
        detail.southboundProblem?.status ||
        detail.northboundProblem?.status,
      service_msg_contains:
        detail.southboundProblem?.detail || detail.northboundProblem?.message,
    });
  }

  /**
   * New standard for "frontend logging" error is to only log to console.
   * For "debugging" verbosity == true enables alerting messages.
   */
  private handleFrontendLoggingError(): void {
    console.warn(this.translateService.instant('common.block.logging'));
    if (this.verbose) {
      this.alertService.warn(
        this.translateService.instant('common.block.logging')
      );
    }
  }

  /**
   * User will have seen a loading spinner for some time and here gets the info that
   * the request timed out.
   * It will also try to log this in the backend.
   */
  private handleTimeoutError(
    request: HttpRequest<any>,
    detail: ProblemDetail
  ): void {
    if (detail.northboundProblem) {
      detail.northboundProblem.status = 408;
    }
    this.alertService.error(
      this.translateService.instant('common.block.timeout', {
        value: DEFAULT_TIMEOUT / 1000,
      }),
      detail
    );
    this.loggingService
      .writeLog(this.loggingService.buildTimeoutError(request.url))
      .pipe(take(1))
      .subscribe();
  }

  private handleKeycloakError(): void {
    // authentication is no longer valid
    this.idleDetectorService.logoutReason = LogoutReason.Authentication;
    this.idleDetectorService.showLogout$.next(true);
  }

  // The OpenAPI "Problem" is the BFF error structure that is sent to the
  // frontend if an error occurs. If present it is in the error attribute of
  // the HTTPErrorResponse
  private southboundProblemIfExists(
    response: HttpErrorResponse | TimeoutError
  ): Problem | null {
    // Open issue is that at runtime we do not know which sort of issue we are handling
    // is it of type Problem as defined by the BFF or of just an error dict from
    // the ordinary HttpErrorResponse?
    // TO CONSIDER change API contract and add fixed string. e.g. "error": "BffProblem"
    function isProblem(arg: any): arg is Problem {
      return (
        arg &&
        arg.title &&
        typeof arg.title == 'string' &&
        arg.status &&
        typeof arg.status == 'number'
      );
    }
    if (!(response instanceof HttpErrorResponse)) {
      return null;
    }
    return isProblem(response.error) ? response.error : null;
  }

  private northboundProblemIfExists(
    response: HttpErrorResponse | TimeoutError
  ): NorthboundProblem | null {
    if (!(response instanceof HttpErrorResponse)) {
      return null;
    }
    if (response.status >= 400) {
      return { status: response.status, message: response.message };
    }
    return null;
  }

  // msgKey is a key for a string in i18n files.
  private raiseWarningMessage(msgKey: string, detail: ProblemDetail): void {
    this.alertService.warn(
      `${this.translateService.instant(toCamelCase(msgKey))}`,
      detail
    );
  }

  // msgKey is a key for a string in i18n files.
  private raiseErrorMessage(msgKey: string, detail: ProblemDetail): void {
    if (this.verbose) {
      console.log(JSON.stringify(detail, null, 4));
    }
    this.alertService.error(
      `${this.translateService.instant(toCamelCase(msgKey))}`,
      detail
    );
  }
}
