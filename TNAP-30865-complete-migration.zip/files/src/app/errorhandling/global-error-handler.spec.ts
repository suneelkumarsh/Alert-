/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { TestBed } from '@angular/core/testing';
import { GlobalErrorHandler } from './global-error-handler';
import { HttpErrorResponse } from '@angular/common/http';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('GlobalErrorHandler', () => {
  let errorHandler: GlobalErrorHandler;
  let alertServiceSpy: jasmine.SpyObj<TnapAlertService>;

  beforeEach(() => {
    const spy = jasmine.createSpyObj('TnapAlertService', ['error']);

    TestBed.configureTestingModule({
      providers: [
        GlobalErrorHandler,
        { provide: TnapAlertService, useValue: spy },
      ],
    });

    errorHandler = TestBed.inject(GlobalErrorHandler);
    alertServiceSpy = TestBed.inject(
      TnapAlertService
    ) as jasmine.SpyObj<TnapAlertService>;
  });

  it('should be created', () => {
    expect(errorHandler).toBeTruthy();
  });

  it('should call alertService.error with message for standard Error', () => {
    const error = new Error('Test error');
    errorHandler.handleError(error);
    expect(alertServiceSpy.error).toHaveBeenCalledWith('Test error');
  });

  it('should call alertService.error with empty message for standard Error', () => {
    const error = new Error('');
    errorHandler.handleError(error);
    expect(alertServiceSpy.error).toHaveBeenCalledWith('');
  });

  it('should call alertService.error with message for HttpErrorResponse', () => {
    const httpError = new HttpErrorResponse({
      error: 'Server error',
      status: 500,
    });
    errorHandler.handleError(httpError);
    expect(alertServiceSpy.error).toHaveBeenCalledWith(httpError.message);
    expect(alertServiceSpy.error).toHaveBeenCalledTimes(1);
  });
});
