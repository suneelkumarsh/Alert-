/*
 * Copyright (c) 2023. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, Input } from '@angular/core';
import {
  ActionRowModel,
  ActionType,
  EntityPnfHistoryActionModel,
  EntityType,
} from '../../../../../model/user-last-action.model';
import { Router } from '@angular/router';
import { exhaustMap, filter, switchMap, take, takeUntil } from 'rxjs/operators';
import { PnfsService } from '../../../../../../../openapi/output';
import { HistoryService } from '../../../../../services/history.service';
import { ConfirmationModalComponent } from 'src/app/components/shared/confirmation-modal/confirmation-modal.component';
import { EMPTY } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { UnsubscribeService } from '../../../../../services/unsubscribe/unsubscribe.service';
import { AuthService } from '@portal-mfe/auth';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-entity-pnf-row',
  templateUrl: './entity-pnf-row.component.html',
  styleUrls: ['./entity-pnf-row.component.css'],
  standalone: false,
})
export class EntityPnfRowComponent {
  ActionType = ActionType;
  EntityType = EntityType;
  @Input()
  action: ActionRowModel<EntityPnfHistoryActionModel> | undefined;
  public loggedUserId$ = this.authService.getLoggedUserId();

  constructor(
    private router: Router,
    private pnfService: PnfsService,
    private historyService: HistoryService,
    private modalService: NgbModal,
    private translateService: TranslateService,
    private unsubscribeService: UnsubscribeService,
    private authService: AuthService,
    private alertService: TnapAlertService
  ) {}

  public navigateToTopology(
    action: ActionRowModel<EntityPnfHistoryActionModel>
  ): void {
    this.router.navigate(['/topology', action.entityParams.pnfName], {
      queryParams: { type: 'pnf' },
    });
  }

  public rebootPnf(action: ActionRowModel<EntityPnfHistoryActionModel>): void {
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalRef.componentInstance.okText = this.translateService.instant(
      'topology.labels.cell.reboot'
    );
    modalRef.componentInstance.title = this.translateService.instant(
      'topology.labels.cell.modal.reboot.title'
    );
    modalRef.componentInstance.text = this.translateService.instant(
      'topology.labels.cell.modal.reboot.text',
      {
        cellName: action.entityParams.pnfName,
      }
    );
    modalRef.closed
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap((confirm: boolean) => {
          if (confirm === true) {
            return this.loggedUserId$.pipe(
              filter((userName): userName is string => !!userName),
              take(1),
              exhaustMap(userName => {
                return this.pnfService
                  .rebootPnf(action.entityParams.pnfName, {
                    jobName: `reboot_${Date.now()}`,
                    userName,
                  })
                  .pipe(
                    switchMap(() =>
                      this.historyService.createRuRebootHistoryAction({
                        type: ActionType.REBOOT,
                        entity: EntityType.PNF,
                        entityParams: {
                          pnfName: action.entityParams.pnfName,
                          userName,
                        },
                      })
                    )
                  );
              }),
              take(1)
            );
          }
          return EMPTY;
        })
      )
      .subscribe(() => {
        this.alertService.success(
          this.translateService.instant(
            'topology.labels.cell.modal.reboot.messages.success',
            {
              cellName: action.entityParams.pnfName,
            }
          ),
          { keepAfterRouteChange: true }
        );
      });
  }
}
