/*
 * Copyright (c) 2024. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, DestroyRef, inject, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { EMPTY, Observable, of } from 'rxjs';
import {
  RanTemplateFilesPageDataModel,
  RanTemplateModel,
  RanTemplateValidationErrorResponse,
  RanTemplateValidationResponse,
  RanTemplateValidationSuccessResponse,
  RESPONSE_OK,
} from '../../../model/ran-template.model';
import { QueryParamService } from '../../../services/query-param.service';
import { RanTemplateService } from '../../../services/ran-templateservice/ran-template.service';
import { filter, map, switchMap, take, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ModalConfirmationService } from '../../../services/common-functionalities/modal-confirmation.service';
import {
  BranchTabDataModel,
  BranchTabDiffEditor,
  BranchTabDraftEditor,
  BranchTabMainEditor,
  BranchTabsModel,
} from '../../../model/branch-tabs.model';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-ran-template-details',
  templateUrl: './ran-template-details.component.html',
  styleUrl: './ran-template-details.component.css',
  standalone: false,
})
export class RanTemplateDetailsComponent implements OnInit {
  ranTemplatesValidation: RanTemplateValidationSuccessResponse[] = [];
  public activeTabIndex$ = this.ranTemplateService.getActiveTabIndex$();
  public data$ = this.ranTemplateService.getRanTemplatePageData();
  readonly permissions = inject(PERMISSIONS_TOKEN);

  branchTabs: BranchTabsModel[] = [
    BranchTabDraftEditor,
    BranchTabDiffEditor,
    BranchTabMainEditor,
  ];

  ranTemplatesChanged = false;
  ranTemplatesSaved = false;

  constructor(
    private readonly queryParamService: QueryParamService,
    private readonly ranTemplateService: RanTemplateService,
    private readonly router: Router,
    private readonly destroyRef: DestroyRef,
    private readonly alertService: TnapAlertService,
    private readonly translateService: TranslateService,
    private readonly confirmationService: ModalConfirmationService
  ) {}

  hasDraftDelta(ranTemplates: RanTemplateModel[]) {
    return ranTemplates.some(
      item =>
        this.ranTemplateService.normalizeContent(item.mainContent) !==
        this.ranTemplateService.normalizeContent(item.draftContent)
    );
  }

  modifiedValueChangelog(branchTabData: BranchTabDataModel) {
    this.ranTemplatesChanged =
      this.ranTemplateService.normalizeContent(
        branchTabData.modifiedContent
      ) !==
      this.ranTemplateService.normalizeContent(branchTabData.draftContent);
  }

  onTabClick(templateFileName: string) {
    this.queryParamService.updateQueryParam({ file: templateFileName });
  }

  save() {
    this.ranTemplateService
      .getRanTemplatePageData()
      .pipe(
        take(1),
        switchMap(updatedBranchTabData => {
          if (!updatedBranchTabData) {
            return EMPTY;
          }
          return this.handleTemplateSave(
            this.openSaveModal(),
            updatedBranchTabData.templateFiles
          );
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(response => {
        this.validateSaveResponse(response);
      });
  }

  deploy(ranTemplates: RanTemplateModel[]) {
    this.ranTemplateService
      .getRanTemplatePageData()
      .pipe(
        take(1),
        switchMap(updatedBranchTabData => {
          if (!updatedBranchTabData) {
            return EMPTY;
          }
          return this.handleTemplateSave(
            this.openDeployModal(),
            ranTemplates
          ).pipe(
            switchMap(response => {
              const isValid = this.allTemplatesValid(
                response as RanTemplateValidationSuccessResponse[]
              );

              if (!isValid) {
                return of({
                  deployed: false,
                  response,
                });
              }

              const draftName = this.getDraftName(
                response as RanTemplateValidationSuccessResponse[]
              );

              if (!draftName) {
                return of({
                  deployed: false,
                  response,
                });
              }

              return this.ranTemplateService.deployTemplates(draftName).pipe(
                map(() => ({
                  deployed: true,
                  response,
                }))
              );
            }),
            takeUntilDestroyed(this.destroyRef)
          );
        })
      )
      .subscribe(result => {
        if (!result.deployed) {
          this.validateSaveResponse(result.response);
          this.alertService.error(
            this.translateService.instant('ranTemplate.message.error.deploy')
          );
        } else {
          this.alertService.success(
            this.translateService.instant('ranTemplate.message.success.deploy')
          );
          this.queryParamService.updateQueryParam({ ref: undefined });
        }
      });
  }

  private handleTemplateSave(
    modalObservable: Observable<boolean>,
    templateData: any
  ) {
    return modalObservable.pipe(
      filter(confirm => confirm === true),
      tap(() => (this.ranTemplatesValidation = [])),
      switchMap(() => this.getTemplateRef()),
      switchMap((templateRef: string | null) =>
        this.ranTemplateService.saveTemplate(templateData, templateRef)
      )
    );
  }

  private validateSaveResponse(
    response: (
      | RanTemplateValidationResponse
      | RanTemplateValidationErrorResponse
      | RanTemplateValidationSuccessResponse
    )[]
  ) {
    this.alertService.success(
      this.translateService.instant('ranTemplate.message.success.save')
    );

    // Copy validation response to show on page in each file tab
    this.ranTemplatesValidation = [...response.filter(this.isSuccessResponse)];

    // Show one message if syntax errors are available
    if (
      response
        .filter(this.isSuccessResponse)
        .find(item => item.response.status.toUpperCase() != RESPONSE_OK)
    ) {
      this.alertService.error(
        this.translateService.instant('ranTemplate.message.error.validation')
      );
    }

    // show technical errors from the validation request
    const errorResponses = response.filter(
      r => !this.isSuccessResponse(r)
    ) as RanTemplateValidationErrorResponse[];
    errorResponses.forEach(response =>
      response.error.forEach(resp => {
        this.alertService.error(resp);
      })
    );
    const draftName = this.getDraftName(
      response as RanTemplateValidationSuccessResponse[]
    );
    this.queryParamService.updateQueryParam({ ref: draftName });
    // Reload data
    this.refreshData();
    this.ranTemplatesSaved = true;

    // Disable buttons
    this.ranTemplatesChanged = false;
  }

  reset(templateListFiles: RanTemplateFilesPageDataModel) {
    this.openResetModal()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((confirm: boolean) => {
        if (confirm) {
          this.resetTemplateFiles(templateListFiles.templateFiles);
          this.alertService.success(
            this.translateService.instant('ranTemplate.message.success.reset')
          );
        }
      });
  }

  close(templateListFiles: RanTemplateFilesPageDataModel) {
    if (this.ranTemplatesChanged) {
      this.openResetModal()
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe((confirm: boolean) => {
          if (confirm) {
            this.resetTemplateFiles(templateListFiles.templateFiles);
            this.redirectToTemplateRootFolder();
          }
        });
    } else {
      this.redirectToTemplateRootFolder();
    }
  }

  public redirectToTemplateRootFolder() {
    this.router.navigate(['ran-template/templates']);
  }

  openResetModal() {
    return this.confirmationService.openConfirmationModal(
      'common.buttons.yes',
      'ranTemplate.modal.reset.title',
      'ranTemplate.modal.reset.text'
    );
  }

  openSaveModal() {
    return this.confirmationService.openConfirmationModal(
      'common.buttons.yes',
      'ranTemplate.modal.save.title',
      'ranTemplate.modal.save.text'
    );
  }

  openDeployModal() {
    return this.confirmationService.openConfirmationModal(
      'common.buttons.yes',
      'ranTemplate.modal.deploy.title',
      'ranTemplate.modal.deploy.text'
    );
  }

  private resetTemplateFiles(templateFileList: RanTemplateModel[]) {
    templateFileList.forEach(
      templateFile => (templateFile.modifiedContent = templateFile.draftContent)
    );
  }

  private getTemplateRef(): Observable<string | null> {
    return this.queryParamService.getValueOf('ref').pipe(take(1));
  }

  private refreshData() {
    this.ranTemplateService.updateRanTemplatePageData(undefined);
    this.ranTemplateService
      .initialRanTemplatePageData$()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(resp => {
        this.ranTemplateService.updateRanTemplatePageData(resp);
      });
  }

  private isSuccessResponse(
    response: RanTemplateValidationResponse
  ): response is RanTemplateValidationSuccessResponse {
    return (
      (response as RanTemplateValidationSuccessResponse).response !== undefined
    );
  }

  public hasTemplateError(
    templatesValidation: RanTemplateValidationSuccessResponse[] | undefined
  ): boolean {
    return templatesValidation
      ? templatesValidation.some(
          item => item.response.status.toUpperCase() !== RESPONSE_OK
        )
      : false;
  }

  public hasFileError(
    templateName: string,
    templatesValidation: RanTemplateValidationSuccessResponse[] | undefined
  ): boolean {
    return templatesValidation
      ? templatesValidation.some(
          item =>
            item.name === templateName &&
            item.response.status.toUpperCase() !== RESPONSE_OK
        )
      : false;
  }

  private allTemplatesValid(
    ranTemplatesValidation:
      | RanTemplateValidationSuccessResponse[]
      | undefined
      | null[]
  ): boolean {
    if (ranTemplatesValidation && !ranTemplatesValidation.some(Boolean)) {
      return true;
    }
    if (ranTemplatesValidation !== undefined) {
      return ranTemplatesValidation.every(
        item => item?.response.status.toUpperCase() === RESPONSE_OK
      );
    }
    return false;
  }

  private getDraftName(response: RanTemplateValidationSuccessResponse[]) {
    if (response) {
      return response.find(item => item.draftName !== '')?.draftName;
    }
    return '';
  }

  public ngOnInit(): void {
    this.refreshData();
  }
}
