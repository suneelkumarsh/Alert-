/*
 * Copyright (c) 2024. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
} from '@angular/core/testing';

import { RanTemplateDetailsComponent } from './ran-template-details.component';
import { SharedModule } from '../../../shared.module';
import { TranslateModule } from '@ngx-translate/core';
import { RanTemplateService } from '../../../services/ran-templateservice/ran-template.service';
import { CodeEditorService } from '../../../services/common-functionalities/code-editor.service';
import { QueryParamService } from '../../../services/query-param.service';
import { ModalService } from '../../../components/modal/modal.service';
import { ModalConfirmationService } from '../../../services/common-functionalities/modal-confirmation.service';
import {
  RanTemplateFilesPageDataModel,
  RanTemplateModel,
  RanTemplateValidationErrorResponse,
  RanTemplateValidationSuccessResponse,
} from '../../../model/ran-template.model';
import { BranchTabDataModel } from '../../../model/branch-tabs.model';
import { firstValueFrom, of, throwError } from 'rxjs';
import {
  HttpErrorResponse,
  provideHttpClient,
  withInterceptorsFromDi,
} from '@angular/common/http';
import {
  AuthConfig,
  OAuthLogger,
  OAuthModule,
  OAuthService,
  OAuthStorage,
} from 'angular-oauth2-oidc';
import { AuthConfigService } from '../../../services/authconfig.service';
import { authConfig } from '../../auth/auth.config';
import { ACL_CONFIG } from '../../auth/injection-tokens';
import { Orientation, RevertControls } from '@acrodata/code-editor';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import {
  KEYCLOAK_HOSTNAME,
  KEYCLOAK_REALM,
  RBAC_BACKENDS,
} from '@portal-mfe/auth';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('RanTemplateDetailsComponent', () => {
  let component: RanTemplateDetailsComponent;
  let fixture: ComponentFixture<RanTemplateDetailsComponent>;
  let ranTemplateServiceSpy: jasmine.SpyObj<RanTemplateService>;
  let codeEditorServiceSpy: jasmine.SpyObj<CodeEditorService>;
  let queryParamServiceSpy: jasmine.SpyObj<QueryParamService>;
  let alertServiceSpy: jasmine.SpyObj<TnapAlertService>;
  let modalServiceSpy: jasmine.SpyObj<ModalService>;
  let confirmationServiceSpy: jasmine.SpyObj<ModalConfirmationService>;
  // Spies on the real Router from RouterTestingModule (rather than replacing it
  // with a bare SpyObj) because ActivatedRoute's factory reads router.routerState.root
  // and breaks if Router is a plain spy without a real internal state. The spy is
  // kept in its own typed variable so the expectations below go through Jasmine's
  // typed Spy overload instead of the untyped Function one.
  let navigateSpy: jasmine.Spy<Router['navigate']>;

  beforeEach(async () => {
    ranTemplateServiceSpy = jasmine.createSpyObj('RanTemplateService', [
      'getTemplateSet',
      'normalizeContent',
      'getActiveTabIndex$',
      'getRanTemplatePageData',
      'updateRanTemplatePageData',
      'initialRanTemplatePageData$',
      'saveTemplate',
      'deployTemplates',
    ]);
    codeEditorServiceSpy = jasmine.createSpyObj('CodeEditorService', [
      'getEditTheme',
      'getReadOnlyTheme',
      'getSupportedLanguages',
      'getDiffEditorSettings',
      'getFileExtension',
      'getEditorTheme',
      'a11yLabelledBy',
    ]);

    codeEditorServiceSpy.getEditorTheme.and.returnValue([]); // Empty array is valid Extension
    codeEditorServiceSpy.getSupportedLanguages.and.returnValue([]); // Mock LanguageDescription[]
    codeEditorServiceSpy.getDiffEditorSettings.and.returnValue({
      orientation: 'a-b' as Orientation,
      highlightChanges: true,
      gutter: true,
      revertControls: 'a-to-b' as RevertControls,
    });
    codeEditorServiceSpy.a11yLabelledBy.and.returnValue([]);
    queryParamServiceSpy = jasmine.createSpyObj('QueryParamService', [
      'getValueOf',
      'updateQueryParam',
    ]);
    alertServiceSpy = jasmine.createSpyObj('AlertServiceSpy', [
      'success',
      'error',
    ]);
    modalServiceSpy = jasmine.createSpyObj('ModalService', ['open']);
    confirmationServiceSpy = jasmine.createSpyObj('ModalConfirmationService', [
      'openConfirmationModal',
    ]);

    // Setup the spies to return observables
    queryParamServiceSpy.getValueOf.and.callFake((param: string) => {
      switch (param) {
        case 'templateSet':
        case 'ref':
        case 'file':
          return of('testValue');
        default:
          return of(null);
      }
    });

    ranTemplateServiceSpy.getTemplateSet.and.returnValue(
      of([{ name: 'testTemplate' } as RanTemplateModel])
    );

    const mockRanTemplatePageData: RanTemplateFilesPageDataModel = {
      templateFiles: [],
      templateSetName: '',
    };

    ranTemplateServiceSpy.initialRanTemplatePageData$.and.returnValue(
      of(mockRanTemplatePageData)
    );

    await TestBed.configureTestingModule({
      declarations: [RanTemplateDetailsComponent],
      imports: [
        SharedModule,
        OAuthModule.forRoot(),
        TranslateModule.forRoot(),
        RouterTestingModule,
      ],
      providers: [
        { provide: RanTemplateService, useValue: ranTemplateServiceSpy },
        { provide: CodeEditorService, useValue: codeEditorServiceSpy },
        { provide: QueryParamService, useValue: queryParamServiceSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
        { provide: ModalService, useValue: modalServiceSpy },
        { provide: ModalConfirmationService, useValue: confirmationServiceSpy },
        { provide: AuthConfig, useValue: authConfig },
        {
          provide: ACL_CONFIG,
          useValue: {},
        },
        AuthConfigService,
        provideHttpClient(withInterceptorsFromDi()),
        { provide: PERMISSIONS_TOKEN, useValue: [] },
        { provide: OAuthStorage, useValue: localStorage },
        { provide: AuthConfig, useValue: {} },
        { provide: KEYCLOAK_REALM, useValue: '' },
        { provide: KEYCLOAK_HOSTNAME, useValue: '' },
        { provide: RBAC_BACKENDS, useValue: ['portal-bff'] },
        OAuthService,
        OAuthLogger,
      ],
    }).compileComponents();

    navigateSpy = spyOn(TestBed.inject(Router), 'navigate');

    fixture = TestBed.createComponent(RanTemplateDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should load and combine template files and URL parameter', async () => {
    const mockTemplateSet = [
      {
        folderName: 'Ericsson_2024_Q1',
        name: 'BaseTemplate.jinja',
        fileNodeType: 'FILE',
        nodePath: 'Ericsson_2024_Q1/BaseTemplate.jinja',
        mainContent: '{# Ericsson_2024_Q1/BaseTemplate.jinja #}\n',
        draftContent: '{# Ericsson_2024_Q1/BaseTemplate.jinja #}\n',
        modifiedContent: '{# Ericsson_2024_Q1/BaseTemplate.jinja #}\n',
      },
      {
        folderName: 'Ericsson_2024_Q1',
        name: 'cell_config.jinja',
        fileNodeType: 'FILE',
        nodePath: 'Ericsson_2024_Q1/cell_config.jinja',
        mainContent: '        {#- Ericsson_2024_Q1/cell_config.jinja -#}\n',
        draftContent: '        {#- Ericsson_2024_Q1/cell_config.jinja -#}\n',
        modifiedContent: '        {#- Ericsson_2024_Q1/cell_config.jinja -#}\n',
      },
    ] as RanTemplateModel[];

    ranTemplateServiceSpy.getRanTemplatePageData.and.returnValue(
      of({
        templateFiles: mockTemplateSet,
        templateSetName: 'Ericsson_2024_Q1',
      })
    );

    codeEditorServiceSpy.getDiffEditorSettings.and.returnValue({
      orientation: 'b-a',
      revertControls: 'b-to-a',
      highlightChanges: true,
      gutter: false,
    });

    fixture = TestBed.createComponent(RanTemplateDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    const result = await firstValueFrom(component.data$!);

    expect(result).toBeDefined();
    expect(result?.templateSetName).toBe('Ericsson_2024_Q1');
    expect(result?.templateFiles.length).toBe(2);
  });

  describe('reset', () => {
    it('restores each file to its draft content and reports success', () => {
      confirmationServiceSpy.openConfirmationModal.and.returnValue(of(true));
      const pageData = {
        templateSetName: 'Ericsson_2024_Q1/activation',
        templateFiles: [
          {
            name: 'a.jinja',
            draftContent: 'draft-a',
            modifiedContent: 'edited-a',
          },
          {
            name: 'b.jinja',
            draftContent: 'draft-b',
            modifiedContent: 'edited-b',
          },
        ],
      } as RanTemplateFilesPageDataModel;

      component.reset(pageData);

      expect(pageData.templateFiles[0].modifiedContent).toBe('draft-a');
      expect(pageData.templateFiles[1].modifiedContent).toBe('draft-b');
      // The TestBed loads no translations, so translateService.instant() hands
      // the key straight back - which makes asserting on the key free and keeps
      // the toasts of the reset/save/deploy flows distinguishable from each other.
      expect(alertServiceSpy.success).toHaveBeenCalledWith(
        'ranTemplate.message.success.reset'
      );
    });

    it('changes nothing when the confirmation is declined', () => {
      confirmationServiceSpy.openConfirmationModal.and.returnValue(of(false));
      const pageData = {
        templateSetName: 'x',
        templateFiles: [
          {
            name: 'a.jinja',
            draftContent: 'draft-a',
            modifiedContent: 'edited-a',
          },
        ],
      } as RanTemplateFilesPageDataModel;

      component.reset(pageData);

      expect(pageData.templateFiles[0].modifiedContent).toBe('edited-a');
      expect(alertServiceSpy.success).not.toHaveBeenCalled();
    });

    it('opens the reset modal with the reset title and text', () => {
      component.openResetModal();

      expect(confirmationServiceSpy.openConfirmationModal).toHaveBeenCalledWith(
        'common.buttons.yes',
        'ranTemplate.modal.reset.title',
        'ranTemplate.modal.reset.text'
      );
    });
  });

  describe('close', () => {
    it('navigates away without asking when nothing changed', () => {
      component.ranTemplatesChanged = false;

      component.close({
        templateSetName: 'x',
        templateFiles: [],
      } as RanTemplateFilesPageDataModel);

      expect(
        confirmationServiceSpy.openConfirmationModal
      ).not.toHaveBeenCalled();
      expect(navigateSpy).toHaveBeenCalledWith(['ran-template/templates']);
    });

    /*
     * close() reuses openResetModal(), so an unsaved close shows the RESET modal's
     * strings. Asserted explicitly because it is surprising, not because it is desired —
     * a dedicated "discard changes" modal is a follow-up, not covered here.
     */
    it('asks with the reset modal and discards changes when confirmed', () => {
      component.ranTemplatesChanged = true;
      confirmationServiceSpy.openConfirmationModal.and.returnValue(of(true));
      const pageData = {
        templateSetName: 'x',
        templateFiles: [
          {
            name: 'a.jinja',
            draftContent: 'draft-a',
            modifiedContent: 'edited-a',
          },
        ],
      } as RanTemplateFilesPageDataModel;

      component.close(pageData);

      expect(confirmationServiceSpy.openConfirmationModal).toHaveBeenCalledWith(
        'common.buttons.yes',
        'ranTemplate.modal.reset.title',
        'ranTemplate.modal.reset.text'
      );
      expect(pageData.templateFiles[0].modifiedContent).toBe('draft-a');
      expect(navigateSpy).toHaveBeenCalledWith(['ran-template/templates']);
    });

    it('stays on the page when the confirmation is declined', () => {
      component.ranTemplatesChanged = true;
      confirmationServiceSpy.openConfirmationModal.and.returnValue(of(false));

      component.close({
        templateSetName: 'x',
        templateFiles: [
          {
            name: 'a.jinja',
            draftContent: 'draft-a',
            modifiedContent: 'edited-a',
          },
        ],
      } as RanTemplateFilesPageDataModel);

      expect(navigateSpy).not.toHaveBeenCalled();
    });
  });

  describe('change tracking', () => {
    beforeEach(() => {
      // hasDraftDelta/modifiedValueChangelog delegate the actual comparison to
      // RanTemplateService.normalizeContent, which is a bare spy by default.
      // Delegating to the real implementation (rather than re-typing trim +
      // CRLF-normalization by hand, as the sibling ran-template-edit spec does)
      // keeps these tests bound to the service's current contract: they follow
      // along if normalization changes instead of asserting stale semantics.
      // Safe to call detached from an instance - normalizeContent uses no `this`.
      ranTemplateServiceSpy.normalizeContent.and.callFake(
        RanTemplateService.prototype.normalizeContent
      );
    });

    it('reports a draft delta when main and draft content differ', () => {
      expect(
        component.hasDraftDelta([
          { name: 'a', mainContent: 'one', draftContent: 'two' },
        ] as RanTemplateModel[])
      ).toBeTrue();
    });

    it('ignores whitespace and CRLF differences', () => {
      // normalizeContent trims and converts \r\n to \n.
      expect(
        component.hasDraftDelta([
          { name: 'a', mainContent: 'one\r\n', draftContent: '  one\n' },
        ] as RanTemplateModel[])
      ).toBeFalse();
    });

    it('marks the page changed only when modified differs from draft', () => {
      component.modifiedValueChangelog({
        modifiedContent: 'edited',
        draftContent: 'original',
      } as BranchTabDataModel);
      expect(component.ranTemplatesChanged).toBeTrue();

      component.modifiedValueChangelog({
        modifiedContent: 'original\r\n',
        draftContent: '  original',
      } as BranchTabDataModel);
      expect(component.ranTemplatesChanged).toBeFalse();
    });

    it('writes the opened file into the query params', () => {
      component.onTabClick('cell_config.jinja');

      expect(queryParamServiceSpy.updateQueryParam).toHaveBeenCalledWith({
        file: 'cell_config.jinja',
      });
    });
  });

  describe('hasFileError', () => {
    const validation = [
      { name: 'broken.jinja', draftName: 'd', response: { status: 'ERROR' } },
      { name: 'fine.jinja', draftName: 'd', response: { status: 'OK' } },
    ] as RanTemplateValidationSuccessResponse[];

    it('is true only for the named file whose status is not OK', () => {
      expect(component.hasFileError('broken.jinja', validation)).toBeTrue();
      expect(component.hasFileError('fine.jinja', validation)).toBeFalse();
      expect(component.hasFileError('absent.jinja', validation)).toBeFalse();
    });

    it('is false when there is no validation result at all', () => {
      expect(component.hasFileError('broken.jinja', undefined)).toBeFalse();
    });

    it('compares the status case-insensitively', () => {
      expect(
        component.hasFileError('a.jinja', [
          { name: 'a.jinja', draftName: 'd', response: { status: 'ok' } },
        ] as RanTemplateValidationSuccessResponse[])
      ).toBeFalse();
    });
  });

  describe('hasTemplateError', () => {
    it('is true when at least one file in the set is not OK', () => {
      expect(
        component.hasTemplateError([
          {
            name: 'broken.jinja',
            draftName: 'd',
            response: { status: 'ERROR' },
          },
          { name: 'fine.jinja', draftName: 'd', response: { status: 'OK' } },
        ] as RanTemplateValidationSuccessResponse[])
      ).toBeTrue();
    });

    it('is false when there is no validation result at all', () => {
      expect(component.hasTemplateError(undefined)).toBeFalse();
    });
  });

  describe('save', () => {
    it('opens the save modal with the save strings', () => {
      component.openSaveModal();

      expect(confirmationServiceSpy.openConfirmationModal).toHaveBeenCalledWith(
        'common.buttons.yes',
        'ranTemplate.modal.save.title',
        'ranTemplate.modal.save.text'
      );
    });

    it('leaves ranTemplatesChanged untouched when the save pipeline does not emit', () => {
      component.ranTemplatesChanged = true;
      ranTemplateServiceSpy.getRanTemplatePageData.and.returnValue(
        of(undefined)
      );
      confirmationServiceSpy.openConfirmationModal.and.returnValue(of(true));

      component.save();

      expect(component.ranTemplatesChanged).toBeTrue();
      expect(ranTemplateServiceSpy.saveTemplate).not.toHaveBeenCalled();
    });

    it('saves the current template files and applies the validation response', () => {
      component.ranTemplatesChanged = true;
      const templateFiles = [
        { name: 'a.jinja', modifiedContent: 'edited-a', nodePath: 'a.jinja' },
      ] as RanTemplateModel[];
      ranTemplateServiceSpy.getRanTemplatePageData.and.returnValue(
        of({ templateFiles, templateSetName: 'set' })
      );
      confirmationServiceSpy.openConfirmationModal.and.returnValue(of(true));
      ranTemplateServiceSpy.saveTemplate.and.returnValue(
        of([
          { name: 'a.jinja', draftName: 'draft-1', response: { status: 'OK' } },
        ] as RanTemplateValidationSuccessResponse[])
      );

      component.save();

      // 'testValue' is the top-level queryParamServiceSpy.getValueOf('ref') stub.
      expect(ranTemplateServiceSpy.saveTemplate).toHaveBeenCalledWith(
        templateFiles,
        'testValue'
      );
      // Starting from true proves the pipeline actually reached
      // validateSaveResponse() rather than relying on the field's default.
      expect(component.ranTemplatesChanged).toBeFalse();
      expect(component.ranTemplatesSaved).toBeTrue();
      expect(component.ranTemplatesValidation.length).toBe(1);
      expect(alertServiceSpy.success).toHaveBeenCalledWith(
        'ranTemplate.message.success.save'
      );
      expect(alertServiceSpy.error).not.toHaveBeenCalled();
      expect(queryParamServiceSpy.updateQueryParam).toHaveBeenCalledWith({
        ref: 'draft-1',
      });
    });

    /*
     * Product finding TNAP-32910: validateSaveResponse() ends by setting
     * ranTemplatesSaved = true and ranTemplatesChanged = false unconditionally,
     * i.e. also for a save whose validation came back with errors. Reset and Save
     * are bound to [disabled]="!ranTemplatesChanged" (details template), so the
     * user is left with a red validation toast, the failing file still open, and
     * no way to retry the save until they edit a file again. Asserted as-is
     * because it is the current behaviour, not because it is desired.
     */
    it('disables reset and save even though validation failed', () => {
      component.ranTemplatesChanged = true;
      ranTemplateServiceSpy.getRanTemplatePageData.and.returnValue(
        of({
          templateFiles: [{ name: 'a.jinja' }] as RanTemplateModel[],
          templateSetName: 'set',
        })
      );
      confirmationServiceSpy.openConfirmationModal.and.returnValue(of(true));
      ranTemplateServiceSpy.saveTemplate.and.returnValue(
        of([
          {
            name: 'a.jinja',
            draftName: 'draft-1',
            response: { status: 'ERROR' },
          },
        ] as RanTemplateValidationSuccessResponse[])
      );

      component.save();

      expect(alertServiceSpy.error).toHaveBeenCalledWith(
        'ranTemplate.message.error.validation'
      );
      // ... yet the save is still reported as successful, and the buttons go dead.
      expect(alertServiceSpy.success).toHaveBeenCalledWith(
        'ranTemplate.message.success.save'
      );
      expect(component.ranTemplatesChanged).toBeFalse();
      expect(component.ranTemplatesSaved).toBeTrue();
      expect(
        component.hasTemplateError(component.ranTemplatesValidation)
      ).toBeTrue();
    });

    it('surfaces every technical error of a failed validation request', () => {
      ranTemplateServiceSpy.getRanTemplatePageData.and.returnValue(
        of({
          templateFiles: [{ name: 'a.jinja' }] as RanTemplateModel[],
          templateSetName: 'set',
        })
      );
      confirmationServiceSpy.openConfirmationModal.and.returnValue(of(true));
      // The shape RanTemplateService.validateTemplates' catchError produces when
      // the validation endpoint itself fails (4xx/5xx): no `response`, an `error`
      // list instead. Those strings come from the backend and are shown verbatim,
      // without going through translateService.
      ranTemplateServiceSpy.saveTemplate.and.returnValue(
        of([
          { name: 'a.jinja', error: ['line 3: unexpected token', 'aborted'] },
        ] as RanTemplateValidationErrorResponse[])
      );

      component.save();

      expect(alertServiceSpy.error).toHaveBeenCalledWith(
        'line 3: unexpected token'
      );
      expect(alertServiceSpy.error).toHaveBeenCalledWith('aborted');
      // Nothing to render in the per-file tabs, and no draft to keep in the URL.
      expect(component.ranTemplatesValidation).toEqual([]);
      expect(queryParamServiceSpy.updateQueryParam).toHaveBeenCalledWith({
        ref: undefined,
      });
    });
  });

  describe('deploy', () => {
    it('opens the deploy modal with the deploy strings', () => {
      component.openDeployModal();

      expect(confirmationServiceSpy.openConfirmationModal).toHaveBeenCalledWith(
        'common.buttons.yes',
        'ranTemplate.modal.deploy.title',
        'ranTemplate.modal.deploy.text'
      );
    });

    it('does not deploy when a template failed validation', () => {
      ranTemplateServiceSpy.getRanTemplatePageData.and.returnValue(
        of({ templateFiles: [], templateSetName: 'x' })
      );
      confirmationServiceSpy.openConfirmationModal.and.returnValue(of(true));
      // A mixed OK+ERROR set — the realistic "one bad file in the template
      // set" case — is what pins allTemplatesValid() on `every` rather than
      // `some`: a single-ERROR array can't tell the two apart, since both
      // would agree the set is invalid. The ERROR status is what makes it
      // invalid here — not the draftName, which stays non-empty on both
      // entries so an empty draftName can't be mistaken for the cause.
      ranTemplateServiceSpy.saveTemplate.and.returnValue(
        of([
          {
            name: 'a.jinja',
            draftName: 'draft-1',
            response: { status: 'OK' },
          },
          {
            name: 'b.jinja',
            draftName: 'draft-1',
            response: { status: 'ERROR' },
          },
        ] as RanTemplateValidationSuccessResponse[])
      );

      component.deploy([{ name: 'a.jinja' }] as RanTemplateModel[]);

      expect(ranTemplateServiceSpy.deployTemplates).not.toHaveBeenCalled();
      expect(alertServiceSpy.error).toHaveBeenCalledWith(
        'ranTemplate.message.error.validation'
      );
      expect(alertServiceSpy.error).toHaveBeenCalledWith(
        'ranTemplate.message.error.deploy'
      );
      /*
       * Product finding TNAP-32910: the failure branch delegates to
       * validateSaveResponse(), whose first statement is an unconditional success
       * toast. So a deploy that fails validation greets the user with a green
       * "templates saved successfully" next to the two red errors above. Pinned
       * rather than fixed - this MR touches no production code - so that whoever
       * moves the success toast out of validateSaveResponse() comes back here.
       */
      expect(alertServiceSpy.success).toHaveBeenCalledWith(
        'ranTemplate.message.success.save'
      );
    });

    it('does not deploy when the page data is gone', () => {
      // The deploy button is only reachable with page data on screen, but the
      // observable can complete empty between click and emission - save() has
      // the same guard and the same test.
      ranTemplateServiceSpy.getRanTemplatePageData.and.returnValue(
        of(undefined)
      );
      confirmationServiceSpy.openConfirmationModal.and.returnValue(of(true));

      component.deploy([{ name: 'a.jinja' }] as RanTemplateModel[]);

      expect(ranTemplateServiceSpy.saveTemplate).not.toHaveBeenCalled();
      expect(ranTemplateServiceSpy.deployTemplates).not.toHaveBeenCalled();
      expect(alertServiceSpy.success).not.toHaveBeenCalled();
      expect(alertServiceSpy.error).not.toHaveBeenCalled();
    });

    it('deploys the draft when every template passes validation', () => {
      component.ranTemplatesChanged = true;
      ranTemplateServiceSpy.getRanTemplatePageData.and.returnValue(
        of({ templateFiles: [], templateSetName: 'x' })
      );
      confirmationServiceSpy.openConfirmationModal.and.returnValue(of(true));
      ranTemplateServiceSpy.saveTemplate.and.returnValue(
        of([
          {
            name: 'a.jinja',
            draftName: '',
            response: { status: 'OK' },
          },
          {
            name: 'b.jinja',
            draftName: 'draft-42',
            response: { status: 'OK' },
          },
        ] as RanTemplateValidationSuccessResponse[])
      );
      // The deploy endpoint's 200 response has no content in the spec; a falsy
      // emission is what makes allTemplatesValid()'s "nothing to check" branch
      // treat the deploy result as valid rather than reading a .response.status
      // that a real deploy response does not carry.
      ranTemplateServiceSpy.deployTemplates.and.returnValue(of(null));

      component.deploy([
        { name: 'a.jinja' },
        { name: 'b.jinja' },
      ] as RanTemplateModel[]);

      expect(ranTemplateServiceSpy.deployTemplates).toHaveBeenCalledWith(
        'draft-42'
      );
      expect(alertServiceSpy.success).toHaveBeenCalledWith(
        'ranTemplate.message.success.deploy'
      );
      expect(alertServiceSpy.error).not.toHaveBeenCalled();
      // The user-visible "leave the draft view after a successful deploy"
      // effect — the only thing that distinguishes this from a no-op in the UI.
      expect(queryParamServiceSpy.updateQueryParam).toHaveBeenCalledWith({
        ref: undefined,
      });
      /*
       * Product finding TNAP-32910: unlike the failure branch, the success branch
       * never reaches validateSaveResponse(), the only place that resets
       * ranTemplatesChanged / sets ranTemplatesSaved. Starting from `true` above
       * is what makes that visible: after a successful deploy the flag survives,
       * so Reset and Save ([disabled]="!ranTemplatesChanged") stay enabled on a
       * page whose validation results handleTemplateSave() has already cleared.
       * Pinned, not fixed - see the note in the save block.
       */
      expect(component.ranTemplatesChanged).toBeTrue();
      expect(component.ranTemplatesSaved).toBeFalse();
    });

    it('does not deploy when valid results contain no draft name', () => {
      ranTemplateServiceSpy.getRanTemplatePageData.and.returnValue(
        of({ templateFiles: [], templateSetName: 'x' })
      );
      confirmationServiceSpy.openConfirmationModal.and.returnValue(of(true));
      ranTemplateServiceSpy.saveTemplate.and.returnValue(
        of([
          {
            name: 'a.jinja',
            draftName: '',
            response: { status: 'OK' },
          },
          {
            name: 'b.jinja',
            draftName: '',
            response: { status: 'OK' },
          },
        ] as RanTemplateValidationSuccessResponse[])
      );

      component.deploy([
        { name: 'a.jinja' },
        { name: 'b.jinja' },
      ] as RanTemplateModel[]);

      expect(ranTemplateServiceSpy.deployTemplates).not.toHaveBeenCalled();
      expect(alertServiceSpy.error).toHaveBeenCalledWith(
        'ranTemplate.message.error.deploy'
      );
      expect(alertServiceSpy.success).toHaveBeenCalledWith(
        'ranTemplate.message.success.save'
      );
    });
  });

  describe('ngOnInit', () => {
    it('currently swallows a load failure and rethrows it unhandled (TNAP-32885)', fakeAsync(() => {
      ranTemplateServiceSpy.initialRanTemplatePageData$.and.returnValue(
        throwError(
          () =>
            new HttpErrorResponse({
              status: 500,
              statusText: 'Internal Server Error',
              url: '/api/ran-templates',
            })
        )
      );

      component.ngOnInit();

      /*
       * Product finding TNAP-32885: refreshData()'s subscribe supplies
       * only a `next` callback, so there is no error state and no
       * alertService.error call — RxJS instead treats the failure as an
       * *unhandled* error and rethrows it asynchronously (via setTimeout).
       * Confirmed empirically: without this fakeAsync/tick containment, the
       * rethrow escaped as an uncaught exception that broke later specs in
       * this same file. tick() forces that rethrow to happen here, inside a
       * try/catch, so this test documents the gap without taking the rest
       * of the suite down with it. updateRanTemplatePageData(undefined) from
       * the top of refreshData() is left as the last write either way, so
       * the page data — and the skeleton it feeds — is stuck at undefined.
       */
      let unhandledError: unknown;
      try {
        tick();
      } catch (err) {
        unhandledError = err;
      }

      expect(unhandledError).toEqual(jasmine.any(HttpErrorResponse));
      expect(alertServiceSpy.error).not.toHaveBeenCalled();
      // The part the user actually experiences: the reset-to-undefined at the
      // top of refreshData() is the last write, so data$ stays empty and the
      // skeleton (details template's @else branch) never resolves.
      expect(
        ranTemplateServiceSpy.updateRanTemplatePageData.calls.mostRecent().args
      ).toEqual([undefined]);
    }));
  });
});
