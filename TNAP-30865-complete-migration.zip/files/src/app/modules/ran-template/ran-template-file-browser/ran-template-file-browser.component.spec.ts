/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
  ControlValueAccessor,
  FormsModule,
  NG_VALUE_ACCESSOR,
} from '@angular/forms';
import {
  Component,
  EventEmitter,
  forwardRef,
  Input,
  NO_ERRORS_SCHEMA,
  Output,
  WritableSignal,
} from '@angular/core';
import { BehaviorSubject, of, throwError } from 'rxjs';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

import { RanTemplateFileBrowserComponent } from './ran-template-file-browser.component';

import { CodeEditorService } from '../../../services/common-functionalities/code-editor.service';
import { QueryParamService } from 'src/app/services/query-param.service';
import { ModalConfirmationService } from 'src/app/services/common-functionalities/modal-confirmation.service';
import { DirectoryTreeNode } from 'src/app/model/ran-template.model';
import { RanTemplateService } from 'src/app/services/ran-templateservice/ran-template.service';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { GetBranchPipe } from 'src/app/pipes/get-branch.pipe';
import { Draft } from 'openapi/output/model/models';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-input-search',
  template: '',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => MockInputSearchComponent),
      multi: true,
    },
  ],
  standalone: false,
})
class MockInputSearchComponent implements ControlValueAccessor {
  @Input() placeholder = '';
  @Input() ngModel = '';
  @Output() ngModelChange = new EventEmitter<string>();
  @Output() resetFilter = new EventEmitter<void>();

  writeValue(): void {}
  registerOnChange(): void {}
  registerOnTouched(): void {}
}

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'code-editor',
  template: '',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => MockCodeEditorComponent),
      multi: true,
    },
  ],
  standalone: false,
})
class MockCodeEditorComponent implements ControlValueAccessor {
  @Input() theme: unknown;
  @Input() readonly = false;
  @Input() setup = '';
  @Input() languages: unknown;
  @Input() language = '';
  @Input() extensions: unknown;
  @Input() ngModel = '';
  @Output() ngModelChange = new EventEmitter<string>();

  writeValue(): void {}
  registerOnChange(): void {}
  registerOnTouched(): void {}
}

type FileBrowserTestAccess = RanTemplateFileBrowserComponent & {
  loading: WritableSignal<boolean>;
  treeData: WritableSignal<DirectoryTreeNode[]>;
  searchQuery: WritableSignal<string>;
  newFolderParentPath: WritableSignal<string | null>;
  newFolderName: WritableSignal<string>;
  toggleExpand(node: DirectoryTreeNode): void;
  onRefresh(): void;
  onAddFile(node: DirectoryTreeNode, ref: string): void;
  onEditClick(param: Record<string, unknown>): void;
  onAddFolder(node: DirectoryTreeNode): void;
  onSaveNewFolder(): void;
  onCancelNewFolder(): void;
  onDeleteFile(node: DirectoryTreeNode): void;
  getFileExtension(fileName: string): string;
  isSelectedDraftNode(node: DirectoryTreeNode): boolean;
  getDraftBranchName(
    path: string,
    branches: { name: string }[] | undefined
  ): string;
  onSearchQueryChange(query: string): void;
};

// Deliberately unlike any real environment's repository, so the href assertion below can only
// pass if the link takes its value from the source draft.
const SOURCE_DRAFT_URL =
  'https://gitlab.example/tnap/ran-templates/-/tree/main';

describe('RanTemplateFileBrowserComponent', () => {
  let component: RanTemplateFileBrowserComponent;
  let componentAccess: FileBrowserTestAccess;
  let fixture: ComponentFixture<RanTemplateFileBrowserComponent>;
  let ranTemplateServiceMock: jasmine.SpyObj<RanTemplateService>;
  let codeEditorServiceMock: jasmine.SpyObj<CodeEditorService>;
  let queryParamServiceMock: jasmine.SpyObj<QueryParamService>;
  let confirmationServiceMock: jasmine.SpyObj<ModalConfirmationService>;
  let alertServiceMock: jasmine.SpyObj<TnapAlertService>;
  let translateServiceMock: jasmine.SpyObj<TranslateService>;
  let sourceDraft$: BehaviorSubject<Draft | null>;

  const mockTree: DirectoryTreeNode[] = [
    {
      name: 'Ericsson_2024_Q1',
      path: 'Ericsson_2024_Q1',
      type: 'folder',
      expanded: false,
      children: [
        {
          name: 'activation',
          path: 'Ericsson_2024_Q1/activation',
          type: 'folder',
          expanded: false,
          children: [
            {
              name: 'template.jinja',
              path: 'Ericsson_2024_Q1/activation/template.jinja',
              type: 'file',
            },
          ],
        },
        { name: 'README.md', path: 'Ericsson_2024_Q1/README.md', type: 'file' },
      ],
    },
    {
      name: 'Nokia_2024_Q2',
      path: 'Nokia_2024_Q2',
      type: 'folder',
      expanded: false,
      children: [],
    },
  ];

  beforeEach(async () => {
    sourceDraft$ = new BehaviorSubject<Draft | null>({
      name: 'main',
      url: SOURCE_DRAFT_URL,
      isDefault: true,
    });
    ranTemplateServiceMock = jasmine.createSpyObj(
      'RanTemplateService',
      [
        'getDirectoryTree',
        'loadChildren',
        'createDirectoryWithFreshDraft',
        'deleteFileWithFreshDraft',
        'deployTemplates',
        'fetchTemplateDraftsOnce',
        'getRootReadmeForBranch',
      ],
      {
        getSourceDraft$: sourceDraft$.asObservable(),
        getDefaultBranch$: of('main'),
        getRootReadmeFile$: of({ name: 'README.md', content: '# README' }),
        getTemplateDrafts$: of({
          items: [{ name: 'main', isDefault: true }, { name: 'draft-a' }],
        }),
      }
    );
    ranTemplateServiceMock.fetchTemplateDraftsOnce.and.returnValue(
      of({
        items: [{ name: 'main', isDefault: true }, { name: 'draft-a' }],
      } as any)
    );
    ranTemplateServiceMock.getDirectoryTree.and.returnValue(of(mockTree));
    ranTemplateServiceMock.loadChildren.and.returnValue(of([]));
    ranTemplateServiceMock.getRootReadmeForBranch.and.returnValue(
      of({ name: 'README.md', content: '# README' } as any)
    );
    ranTemplateServiceMock.createDirectoryWithFreshDraft.and.returnValue(
      of({ name: 'draft-a' } as any)
    );
    ranTemplateServiceMock.deleteFileWithFreshDraft.and.returnValue(
      of({ name: 'draft-a' } as any)
    );
    ranTemplateServiceMock.deployTemplates.and.returnValue(of(null));

    codeEditorServiceMock = jasmine.createSpyObj('CodeEditorService', [
      'getSupportedLanguages',
      'getEditorTheme',
      'getFileExtension',
      'a11yNameKey',
    ]);
    codeEditorServiceMock.getSupportedLanguages.and.returnValue([]);
    codeEditorServiceMock.getEditorTheme.and.returnValue([]);
    codeEditorServiceMock.getFileExtension.and.callFake((name: string) => {
      if (!name) return '';
      const ext = name.split('.').pop() || '';
      return ext;
    });
    codeEditorServiceMock.a11yNameKey.and.returnValue([]);
    queryParamServiceMock = jasmine.createSpyObj('QueryParamService', [
      'updateQueryParam',
      'getValueOf',
    ]);
    queryParamServiceMock.getValueOf.and.returnValue(of(null));
    confirmationServiceMock = jasmine.createSpyObj('ModalConfirmationService', [
      'openConfirmationModal',
    ]);
    confirmationServiceMock.openConfirmationModal.and.returnValue(of(true));
    alertServiceMock = jasmine.createSpyObj('TnapAlertService', [
      'error',
      'success',
    ]);
    translateServiceMock = jasmine.createSpyObj(
      'TranslateService',
      ['instant', 'get', 'stream'],
      {
        onLangChange: of({}),
        onTranslationChange: of({}),
        onDefaultLangChange: of({}),
      }
    );
    translateServiceMock.instant.and.returnValue('translated error');
    translateServiceMock.get.and.callFake((key: string | string[]) => of(key));
    translateServiceMock.stream.and.callFake((key: string | string[]) =>
      of(key)
    );

    await TestBed.configureTestingModule({
      declarations: [
        RanTemplateFileBrowserComponent,
        MockInputSearchComponent,
        MockCodeEditorComponent,
      ],
      imports: [FormsModule, TranslateModule.forRoot(), GetBranchPipe],
      providers: [
        { provide: RanTemplateService, useValue: ranTemplateServiceMock },
        { provide: CodeEditorService, useValue: codeEditorServiceMock },
        { provide: QueryParamService, useValue: queryParamServiceMock },
        {
          provide: ModalConfirmationService,
          useValue: confirmationServiceMock,
        },
        {
          provide: TnapAlertService,
          useValue: alertServiceMock,
        },
        {
          provide: TranslateService,
          useValue: translateServiceMock,
        },
        { provide: PERMISSIONS_TOKEN, useValue: [] },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(RanTemplateFileBrowserComponent);
    component = fixture.componentInstance;
    componentAccess = component as FileBrowserTestAccess;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('loadTree', () => {
    it('should load tree data on init', () => {
      expect(componentAccess.treeData()).toEqual(mockTree);
      expect(componentAccess.loading()).toBeFalse();
    });

    it('should set loading to false when loading fails', () => {
      ranTemplateServiceMock.getDirectoryTree.and.returnValue(
        throwError(() => new Error('Network error'))
      );

      componentAccess.onRefresh();

      expect(componentAccess.loading()).toBeFalse();
    });
  });

  describe('filteredTree', () => {
    it('should return full tree when search query is empty', () => {
      componentAccess.searchQuery.set('');
      expect(component.filteredTree()).toEqual(mockTree);
    });

    it('should return full tree when search query is whitespace', () => {
      componentAccess.searchQuery.set('   ');
      expect(component.filteredTree()).toEqual(mockTree);
    });

    it('should filter nodes by name (case-insensitive)', () => {
      componentAccess.searchQuery.set('nokia');
      const result = component.filteredTree();
      expect(result.length).toBe(1);
      expect(result[0].name).toBe('Nokia_2024_Q2');
    });

    it('should return parent with matching children when child matches', () => {
      componentAccess.searchQuery.set('template.jinja');
      const result = component.filteredTree();
      expect(result.length).toBe(1);
      expect(result[0].name).toBe('Ericsson_2024_Q1');
      expect(result[0].expanded).toBeTrue();
      expect(result[0].children!.length).toBe(1);
      expect(result[0].children![0].name).toBe('activation');
      expect(result[0].children![0].expanded).toBeTrue();
    });

    it('should return empty array when no nodes match', () => {
      componentAccess.searchQuery.set('nonexistent');
      expect(component.filteredTree()).toEqual([]);
    });

    it('should match parent folder name and include all its children', () => {
      componentAccess.searchQuery.set('ericsson');
      const result = component.filteredTree();
      expect(result.length).toBe(1);
      expect(result[0].name).toBe('Ericsson_2024_Q1');
      // Parent matched, so children remain as-is
      expect(result[0].children!.length).toBe(2);
    });

    it('should be case-insensitive for uppercase queries', () => {
      componentAccess.searchQuery.set('README');
      const result = component.filteredTree();
      expect(result.length).toBe(1);
      expect(result[0].name).toBe('Ericsson_2024_Q1');
      expect(result[0].children!.some(c => c.name === 'README.md')).toBeTrue();
    });
  });

  describe('toggleExpand', () => {
    it('should toggle expanded state from true to false for loaded folder', () => {
      const node: DirectoryTreeNode = {
        name: 'test',
        path: 'test',
        type: 'folder',
        expanded: true,
        childrenLoaded: true,
        children: [],
      };
      componentAccess.treeData.set([node]);
      componentAccess.toggleExpand(node);
      const updated = componentAccess.treeData().find(n => n.path === 'test')!;
      expect(updated.expanded).toBeFalse();
    });

    it('should load children and expand when folder not yet loaded', () => {
      ranTemplateServiceMock.loadChildren = jasmine
        .createSpy('loadChildren')
        .and.returnValue(
          of([
            {
              name: 'child.ts',
              path: 'test/child.ts',
              type: 'file' as const,
              expanded: false,
              childrenLoaded: false,
              children: undefined,
            },
          ])
        );
      const node: DirectoryTreeNode = {
        name: 'test',
        path: 'test',
        type: 'folder',
        expanded: false,
        childrenLoaded: false,
        children: [],
      };
      componentAccess.treeData.set([node]);
      componentAccess.toggleExpand(node);
      const updated = componentAccess.treeData().find(n => n.path === 'test')!;
      expect(updated.expanded).toBeTrue();
      expect(updated.childrenLoaded).toBeTrue();
      expect(updated.children!.length).toBe(1);
    });

    it('should not attempt to expand a file node', () => {
      ranTemplateServiceMock.loadChildren = jasmine.createSpy('loadChildren');
      const node: DirectoryTreeNode = {
        name: 'file.txt',
        path: 'file.txt',
        type: 'file',
        expanded: false,
        childrenLoaded: false,
      };
      componentAccess.treeData.set([node]);
      componentAccess.toggleExpand(node);
      const updated = componentAccess
        .treeData()
        .find(n => n.path === 'file.txt')!;
      expect(updated.expanded).toBeTrue();
      expect(ranTemplateServiceMock.loadChildren).not.toHaveBeenCalled();
    });

    it('should collapse an already-loaded expanded folder without re-fetching', () => {
      ranTemplateServiceMock.loadChildren = jasmine.createSpy('loadChildren');
      const node: DirectoryTreeNode = {
        name: 'loaded',
        path: 'loaded',
        type: 'folder',
        expanded: true,
        childrenLoaded: true,
        children: [{ name: 'a.ts', path: 'loaded/a.ts', type: 'file' }],
      };
      componentAccess.treeData.set([node]);
      componentAccess.toggleExpand(node);
      const updated = componentAccess
        .treeData()
        .find(n => n.path === 'loaded')!;
      expect(updated.expanded).toBeFalse();
      expect(ranTemplateServiceMock.loadChildren).not.toHaveBeenCalled();
    });

    it('should re-expand a previously collapsed loaded folder without re-fetching', () => {
      ranTemplateServiceMock.loadChildren = jasmine.createSpy('loadChildren');
      const node: DirectoryTreeNode = {
        name: 'loaded',
        path: 'loaded',
        type: 'folder',
        expanded: false,
        childrenLoaded: true,
        children: [{ name: 'a.ts', path: 'loaded/a.ts', type: 'file' }],
      };
      componentAccess.treeData.set([node]);
      componentAccess.toggleExpand(node);
      const updated = componentAccess
        .treeData()
        .find(n => n.path === 'loaded')!;
      expect(updated.expanded).toBeTrue();
      expect(ranTemplateServiceMock.loadChildren).not.toHaveBeenCalled();
    });
  });

  describe('onRefresh', () => {
    it('should reload the tree', () => {
      ranTemplateServiceMock.getDirectoryTree.calls.reset();
      componentAccess.onRefresh();
      expect(ranTemplateServiceMock.getDirectoryTree).toHaveBeenCalled();
    });

    it('loads the tree once per ref change however often it was refreshed', () => {
      const ref$ = new BehaviorSubject<string | null>(null);
      queryParamServiceMock.getValueOf.and.returnValue(ref$);
      fixture.destroy();
      fixture = TestBed.createComponent(RanTemplateFileBrowserComponent);
      componentAccess = fixture.componentInstance as FileBrowserTestAccess;
      fixture.detectChanges();

      componentAccess.onRefresh();
      componentAccess.onRefresh();
      componentAccess.onRefresh();
      ranTemplateServiceMock.getDirectoryTree.calls.reset();
      ranTemplateServiceMock.getRootReadmeForBranch.calls.reset();

      ref$.next('draft-a');

      expect(ranTemplateServiceMock.getDirectoryTree).toHaveBeenCalledOnceWith(
        'draft-a'
      );
      expect(
        ranTemplateServiceMock.getRootReadmeForBranch
      ).toHaveBeenCalledOnceWith('draft-a');
    });
  });

  describe('getFileExtension', () => {
    it('should delegate to codeEditorService', () => {
      componentAccess.getFileExtension('test.yaml');
      expect(codeEditorServiceMock.getFileExtension).toHaveBeenCalledWith(
        'test.yaml'
      );
    });
  });

  describe('edit navigation', () => {
    it('should navigate to ran-template edit in add mode when adding a file', () => {
      const node: DirectoryTreeNode = {
        name: 'templates',
        path: 'templates',
        type: 'folder',
      };

      componentAccess.onAddFile(node, 'draft_templates');

      expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith(
        {
          templateSet: 'templates',
          ref: 'draft_templates',
          mode: 'add',
        },
        ['/ran-template/edit']
      );
    });

    it('should navigate to ran-template edit in edit mode when editing a file', () => {
      const params = {
        name: 'template.jinja',
        path: 'templates/template.jinja',
        type: 'file',
      };

      componentAccess.onEditClick(params);

      expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith(
        {
          ...params,
          path: undefined,
          file: undefined,
          ref: null,
          mode: 'edit',
        },
        ['/ran-template/edit']
      );
    });
  });

  describe('folder creation', () => {
    it('should open inline folder creation and expand collapsed folder', () => {
      const node: DirectoryTreeNode = {
        name: 'templates',
        path: 'templates',
        type: 'folder',
        expanded: false,
        childrenLoaded: true,
        children: [],
      };
      componentAccess.treeData.set([node]);

      componentAccess.onAddFolder(node);

      expect(componentAccess.treeData()[0].expanded).toBeTrue();
      expect(componentAccess.newFolderParentPath()).toBe('templates');
      expect(componentAccess.newFolderName()).toBe('');
    });

    it('should save new folder, deploy draft, and refresh tree', () => {
      componentAccess.newFolderParentPath.set('templates');
      componentAccess.newFolderName.set('new-folder');
      ranTemplateServiceMock.getDirectoryTree.calls.reset();

      componentAccess.onSaveNewFolder();

      expect(
        ranTemplateServiceMock.createDirectoryWithFreshDraft
      ).toHaveBeenCalledWith('templates/new-folder');
      expect(ranTemplateServiceMock.deployTemplates).toHaveBeenCalledWith(
        'draft-a'
      );
      expect(componentAccess.newFolderParentPath()).toBeNull();
      expect(componentAccess.newFolderName()).toBe('');
      expect(ranTemplateServiceMock.getDirectoryTree).toHaveBeenCalled();
    });

    it('should not save a folder without parent or name', () => {
      componentAccess.newFolderParentPath.set(null);
      componentAccess.newFolderName.set('new-folder');

      componentAccess.onSaveNewFolder();

      expect(
        ranTemplateServiceMock.createDirectoryWithFreshDraft
      ).not.toHaveBeenCalled();

      componentAccess.newFolderParentPath.set('templates');
      componentAccess.newFolderName.set('   ');
      componentAccess.onSaveNewFolder();

      expect(
        ranTemplateServiceMock.createDirectoryWithFreshDraft
      ).not.toHaveBeenCalled();
    });

    it('should not create folder when confirmation is rejected', () => {
      confirmationServiceMock.openConfirmationModal.and.returnValue(of(false));
      componentAccess.newFolderParentPath.set('templates');
      componentAccess.newFolderName.set('new-folder');

      componentAccess.onSaveNewFolder();

      expect(
        ranTemplateServiceMock.createDirectoryWithFreshDraft
      ).not.toHaveBeenCalled();
    });

    it('should show translated error when folder creation fails without detail', () => {
      ranTemplateServiceMock.createDirectoryWithFreshDraft.and.returnValue(
        throwError(() => ({ error: {} }))
      );
      componentAccess.newFolderParentPath.set('templates');
      componentAccess.newFolderName.set('new-folder');

      componentAccess.onSaveNewFolder();

      expect(alertServiceMock.error).toHaveBeenCalledWith('translated error');
    });

    it('should cancel inline folder creation', () => {
      componentAccess.newFolderParentPath.set('templates');
      componentAccess.newFolderName.set('new-folder');

      componentAccess.onCancelNewFolder();

      expect(componentAccess.newFolderParentPath()).toBeNull();
      expect(componentAccess.newFolderName()).toBe('');
    });
  });

  describe('draft branch lookup', () => {
    it('should return matching draft branch for a nested node path', () => {
      expect(
        componentAccess.getDraftBranchName('vendor/model/template.jinja', [
          { name: 'draft_vendor_model' },
        ])
      ).toBe('');
    });

    it('should not match sibling branches that only share the root folder name', () => {
      expect(
        componentAccess.getDraftBranchName('Ericsson_2024_Q3/activation', [
          { name: 'draft_Ericsson_2024_Q3_termination' },
          { name: 'draft_Ericsson_2024_Q3_Static' },
        ])
      ).toBe('');
    });

    it('should return main when path or branches are missing', () => {
      expect(componentAccess.getDraftBranchName('', [{ name: 'draft' }])).toBe(
        ''
      );
      expect(componentAccess.getDraftBranchName('vendor', undefined)).toBe('');
      expect(
        componentAccess.getDraftBranchName('vendor', [{ name: 'other' }])
      ).toBe('');
    });
  });

  describe('file deletion', () => {
    const mockFileNode: DirectoryTreeNode = {
      name: 'template.jinja',
      path: 'Ericsson_2024_Q1/activation/template.jinja',
      type: 'file',
    };

    beforeEach(() => {
      confirmationServiceMock.openConfirmationModal.and.returnValue(of(true));
      ranTemplateServiceMock.deleteFileWithFreshDraft.and.returnValue(
        of({ name: 'draft-a' } as any)
      );
      ranTemplateServiceMock.deployTemplates.and.returnValue(of(null));
      ranTemplateServiceMock.getDirectoryTree.calls.reset();
    });

    it('should delete file, show success message, and refresh tree', () => {
      spyOn(componentAccess, 'getDraftBranchName').and.returnValue(
        'draft_template'
      );

      ranTemplateServiceMock.fetchTemplateDraftsOnce.and.returnValue(
        of({
          items: [{ name: 'draft_template' }],
        } as any)
      );

      componentAccess.onDeleteFile(mockFileNode);

      expect(
        ranTemplateServiceMock.deleteFileWithFreshDraft
      ).toHaveBeenCalledWith('draft_template');
    });

    it('should not delete file when confirmation is rejected', () => {
      confirmationServiceMock.openConfirmationModal.and.returnValue(of(false));

      componentAccess.onDeleteFile(mockFileNode);

      expect(ranTemplateServiceMock.deployTemplates).not.toHaveBeenCalled();
      expect(alertServiceMock.success).not.toHaveBeenCalled();
    });

    it('should show error message with detail when deletion fails', () => {
      const errorDetail = 'File is locked';
      ranTemplateServiceMock.deleteFileWithFreshDraft.and.returnValue(
        throwError(() => ({ error: { detail: errorDetail } }))
      );

      componentAccess.onDeleteFile(mockFileNode);

      expect(alertServiceMock.error).toHaveBeenCalledWith(errorDetail);
      expect(alertServiceMock.success).not.toHaveBeenCalled();
    });

    it('should show error message with title when deletion fails without detail', () => {
      const errorTitle = 'Deletion failed';
      ranTemplateServiceMock.deleteFileWithFreshDraft.and.returnValue(
        throwError(() => ({ error: { title: errorTitle } }))
      );

      componentAccess.onDeleteFile(mockFileNode);

      expect(alertServiceMock.error).toHaveBeenCalledWith(errorTitle);
    });

    it('should show translated error when deletion fails without detail or title', () => {
      ranTemplateServiceMock.deleteFileWithFreshDraft.and.returnValue(
        throwError(() => ({ error: {} }))
      );

      componentAccess.onDeleteFile(mockFileNode);

      expect(translateServiceMock.instant).toHaveBeenCalledWith(
        'ranTemplate.message.error.delete'
      );
      expect(alertServiceMock.error).toHaveBeenCalledWith('translated error');
    });
  });
  it('should update query param when branch changes', () => {
    (component as any).onBranchChange('draft-a');

    expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
      ref: 'draft-a',
    });
  });
  it('should return matching draft name', () => {
    expect(
      componentAccess.getDraftBranchName(
        'Ericsson_2024_Q1/activation/template.jinja',
        [
          {
            name: '123_Ericsson_2024_Q1_activation_template',
          },
        ]
      )
    ).toBe('123_Ericsson_2024_Q1_activation_template');
  });
  it('should show title error when folder creation fails', () => {
    ranTemplateServiceMock.createDirectoryWithFreshDraft.and.returnValue(
      throwError(() => ({
        error: {
          title: 'Folder already exists',
        },
      }))
    );

    componentAccess.newFolderParentPath.set('templates');
    componentAccess.newFolderName.set('new-folder');

    componentAccess.onSaveNewFolder();

    expect(alertServiceMock.error).toHaveBeenCalledWith(
      'Folder already exists'
    );
  });
  it('should show translated error when deploy fails', () => {
    ranTemplateServiceMock.deployTemplates.and.returnValue(
      throwError(() => ({ error: {} }))
    );

    componentAccess.newFolderParentPath.set('templates');
    componentAccess.newFolderName.set('new-folder');

    componentAccess.onSaveNewFolder();

    expect(alertServiceMock.error).toHaveBeenCalled();
  });
  it('should return extension', () => {
    const result = componentAccess.getFileExtension('template.jinja');

    expect(result).toBe('jinja');
  });
  it('should reload tree on consecutive refreshes', () => {
    componentAccess.onRefresh();
    componentAccess.onRefresh();

    expect(ranTemplateServiceMock.getDirectoryTree).toHaveBeenCalledTimes(3); // init(refreshTrigger$ + loadTree)
  });

  describe('deep search functionality', () => {
    it('should update search query when onSearchQueryChange is called', () => {
      componentAccess.onSearchQueryChange('test');

      expect(componentAccess.searchQuery()).toBe('test');
    });

    it('should clear search query when empty string is passed', () => {
      componentAccess.searchQuery.set('previous query');
      componentAccess.onSearchQueryChange('');

      expect(componentAccess.searchQuery()).toBe('');
    });

    it('should load full tree when search query is not empty', done => {
      const mockChildren: DirectoryTreeNode[] = [
        {
          name: 'child.txt',
          path: 'Ericsson_2024_Q1/activation/child.txt',
          type: 'file',
        },
      ];

      ranTemplateServiceMock.loadChildren.and.returnValue(of(mockChildren));
      componentAccess.treeData.set(mockTree);

      componentAccess.onSearchQueryChange('search term');

      // Wait for async operation
      setTimeout(() => {
        expect(ranTemplateServiceMock.loadChildren).toHaveBeenCalled();
        done();
      }, 100);
    });

    it('should not load full tree if already loaded', () => {
      componentAccess.searchQuery.set('test');
      // Simulate that full tree is already cached by setting a previous query
      componentAccess.onSearchQueryChange('test query');

      ranTemplateServiceMock.loadChildren.calls.reset();

      // Try to search again
      componentAccess.onSearchQueryChange('another test');

      // Since full tree should be cached, loadChildren should not be called again
      expect(ranTemplateServiceMock.loadChildren).not.toHaveBeenCalled();
    });

    it('should handle errors during full tree loading gracefully', done => {
      ranTemplateServiceMock.loadChildren.and.returnValue(
        throwError(() => new Error('Network error'))
      );
      componentAccess.treeData.set(mockTree);

      componentAccess.onSearchQueryChange('test');

      // Wait for async operation
      setTimeout(() => {
        // Should not crash, error is handled
        expect(componentAccess.searchQuery()).toBe('test');
        done();
      }, 100);
    });

    it('should search through fully loaded tree when available', done => {
      const mockChildren: DirectoryTreeNode[] = [
        {
          name: 'nested.txt',
          path: 'Ericsson_2024_Q1/activation/nested.txt',
          type: 'file',
        },
      ];

      ranTemplateServiceMock.loadChildren.and.returnValue(of(mockChildren));
      componentAccess.treeData.set([mockTree[0]]); // Only Ericsson folder

      componentAccess.onSearchQueryChange('nested');

      setTimeout(() => {
        component.filteredTree();
        // After full tree is loaded, search should find nested files
        expect(ranTemplateServiceMock.loadChildren).toHaveBeenCalled();
        done();
      }, 100);
    });

    it('should clear full tree cache when search is cleared', done => {
      const mockChildren: DirectoryTreeNode[] = [
        {
          name: 'child.txt',
          path: 'Ericsson_2024_Q1/activation/child.txt',
          type: 'file',
        },
      ];

      ranTemplateServiceMock.loadChildren.and.returnValue(of(mockChildren));
      componentAccess.treeData.set(mockTree);

      // First search to load full tree
      componentAccess.onSearchQueryChange('test');

      setTimeout(() => {
        ranTemplateServiceMock.loadChildren.calls.reset();

        // Clear search
        componentAccess.onSearchQueryChange('');

        // Search again should reload full tree
        componentAccess.onSearchQueryChange('new search');

        setTimeout(() => {
          // Full tree should be loaded again after clearing
          expect(ranTemplateServiceMock.loadChildren).toHaveBeenCalled();
          done();
        }, 100);
      }, 100);
    });

    it('should return lazy-loaded tree when search query is empty', () => {
      componentAccess.searchQuery.set('');

      const result = component.filteredTree();

      expect(result).toEqual(mockTree);
    });
  });

  it('should load only uuid based drafts and prepend Main option', () => {
    (component as any).defaultBranch.set('main');

    translateServiceMock.instant.and.returnValue('Main');

    ranTemplateServiceMock.fetchTemplateDraftsOnce.and.returnValue(
      of({
        items: [
          {
            name: 'main',
          },
          {
            name: '123e4567-e89b-12d3-a456-426614174000_templates',
          },
          {
            name: 'draft_Ericsson_activation',
          },
        ],
      } as any)
    );

    (component as any).loadBranches();

    expect(translateServiceMock.instant).toHaveBeenCalledWith(
      'ranTemplate.modal.branch.main'
    );

    expect((component as any).branches()).toEqual([
      {
        value: '',
        label: 'Main',
      },
      {
        value: '123e4567-e89b-12d3-a456-426614174000_templates',
        label: '123e4567-e89b-12d3-a456-426614174000_templates',
      },
    ]);
  });

  describe('isSelectedDraftNode', () => {
    it('should return true when no branch is selected', () => {
      (component as any).selectedBranch.set('');

      expect(
        componentAccess.isSelectedDraftNode({
          name: 'Ericsson_2024_Q1',
          path: 'Ericsson_2024_Q1',
          type: 'folder',
        })
      ).toBeTrue();
    });

    it('should enable Q1 root and disable Q1_Static root for Q1 branch', () => {
      (component as any).selectedBranch.set(
        '123_Ericsson_2024_Q1_activation_BaseTemplate'
      );

      expect(
        componentAccess.isSelectedDraftNode({
          name: 'Ericsson_2024_Q1',
          path: 'Ericsson_2024_Q1',
          type: 'folder',
        })
      ).toBeTrue();

      expect(
        componentAccess.isSelectedDraftNode({
          name: 'Ericsson_2024_Q1_Static',
          path: 'Ericsson_2024_Q1_Static',
          type: 'folder',
        })
      ).toBeFalse();
    });

    it('should enable Q1_Static root and disable Q1 root for static branch', () => {
      (component as any).selectedBranch.set(
        '123_Ericsson_2024_Q1_Static_activation_BaseTemplate'
      );

      expect(
        componentAccess.isSelectedDraftNode({
          name: 'Ericsson_2024_Q1_Static',
          path: 'Ericsson_2024_Q1_Static',
          type: 'folder',
        })
      ).toBeTrue();

      expect(
        componentAccess.isSelectedDraftNode({
          name: 'Ericsson_2024_Q1',
          path: 'Ericsson_2024_Q1',
          type: 'folder',
        })
      ).toBeFalse();
    });

    it('should enable child folder of selected branch', () => {
      (component as any).selectedBranch.set(
        '123_Ericsson_2024_Q1_activation_BaseTemplate'
      );

      expect(
        componentAccess.isSelectedDraftNode({
          name: 'activation',
          path: 'Ericsson_2024_Q1/activation',
          type: 'folder',
        })
      ).toBeTrue();
    });

    it('should disable unrelated child folder', () => {
      (component as any).selectedBranch.set(
        '123_Ericsson_2024_Q1_activation_BaseTemplate'
      );

      expect(
        componentAccess.isSelectedDraftNode({
          name: 'activation',
          path: 'Ericsson_2024_Q3/activation',
          type: 'folder',
        })
      ).toBeFalse();
    });
  });

  describe('handleNodeAction', () => {
    it('should do nothing when node is disabled', () => {
      spyOn(componentAccess, 'onEditClick');
      spyOn(componentAccess, 'toggleExpand');

      (component as any).handleNodeAction(
        {
          name: 'template.jinja',
          path: 'templates/template.jinja',
          type: 'file',
        },
        false,
        []
      );

      expect(componentAccess.onEditClick).not.toHaveBeenCalled();
      expect(componentAccess.toggleExpand).not.toHaveBeenCalled();
    });

    it('should call onEditClick for enabled file node', () => {
      spyOn(componentAccess, 'onEditClick');
      spyOn(componentAccess, 'getDraftBranchName').and.returnValue(
        'draft_template'
      );

      (component as any).handleNodeAction(
        {
          name: 'template.jinja',
          path: 'templates/template.jinja',
          type: 'file',
        },
        true,
        [{ name: 'draft_template' }]
      );

      expect(componentAccess.onEditClick).toHaveBeenCalledWith({
        templateSet: 'templates/template.jinja',
        ref: 'draft_template',
      });
    });

    it('should call toggleExpand for enabled folder node', () => {
      spyOn(componentAccess, 'toggleExpand');

      const node: DirectoryTreeNode = {
        name: 'templates',
        path: 'templates',
        type: 'folder',
      };

      (component as any).handleNodeAction(node, true, []);

      expect(componentAccess.toggleExpand).toHaveBeenCalledWith(node);
    });
  });

  describe('open GitLab link', () => {
    it('should link to the repository of the environment the portal runs against', () => {
      const link = fixture.nativeElement.querySelector('a.btn-outline-primary');

      expect(link).toBeTruthy();
      expect(link.getAttribute('href')).toBe(SOURCE_DRAFT_URL);
    });

    it('should hide the link when no source draft is available', () => {
      sourceDraft$.next(null);
      fixture.detectChanges();

      expect(fixture.nativeElement.querySelector('a.qa_open_btn')).toBeNull();
    });
  });

  describe('template accessibility bindings', () => {
    it('should render nested list markup and node button hook', async () => {
      componentAccess.treeData.set([
        {
          name: 'Ericsson_2024_Q1',
          path: 'Ericsson_2024_Q1',
          type: 'folder',
          expanded: true,
          children: [
            {
              name: 'activation',
              path: 'Ericsson_2024_Q1/activation',
              type: 'folder',
              expanded: false,
            },
          ],
        },
      ]);
      fixture.detectChanges();
      await fixture.whenStable();
      fixture.detectChanges();

      const rootTree = fixture.nativeElement.querySelector(
        'ul.qa_tree_container'
      );
      const treeNodes =
        fixture.nativeElement.querySelectorAll('li.qa_tree_node');
      const nestedTree = fixture.nativeElement.querySelector(
        'ul.qa_tree_children'
      );
      const nodeButton = fixture.nativeElement.querySelector(
        'button.qa_tree_item_button'
      );
      const folderButton = fixture.nativeElement.querySelector(
        'button.qa_add_folder_btn'
      );
      const fileButton = fixture.nativeElement.querySelector(
        'button.qa_add_file_btn'
      );

      expect(rootTree).withContext('rootTree').toBeTruthy();
      expect(treeNodes.length).withContext('treeNodes').toBeGreaterThan(0);
      expect(nestedTree).withContext('nestedTree').toBeTruthy();
      expect(nodeButton).withContext('nodeButton').toBeTruthy();
      expect(folderButton).withContext('folderButton').toBeTruthy();
      expect(fileButton).withContext('fileButton').toBeTruthy();
    });

    it('should expose disabled state through aria-disabled without native disabled on tree node button', async () => {
      (component as any).selectedBranch.set('123_Ericsson_2024_Q1_activation');

      componentAccess.treeData.set([
        {
          name: 'Nokia_2024_Q2',
          path: 'Nokia_2024_Q2',
          type: 'folder',
          expanded: true,
        },
      ]);
      fixture.detectChanges();
      await fixture.whenStable();
      fixture.detectChanges();

      const treeButton = fixture.nativeElement.querySelector(
        'button.qa_tree_item_button'
      ) as HTMLButtonElement;

      expect(treeButton).toBeTruthy();
      expect(treeButton.getAttribute('aria-disabled')).toBe('true');
      expect(treeButton.hasAttribute('disabled')).toBeFalse();
    });
  });
});
