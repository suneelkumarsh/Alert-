/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  inject,
  OnInit,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { CodeEditorService } from '../../../services/common-functionalities/code-editor.service';
import { ModalConfirmationService } from '../../../services/common-functionalities/modal-confirmation.service';
import { RanTemplateService } from '../../../services/ran-templateservice/ran-template.service';
import { Extension } from '@codemirror/state';
import { BehaviorSubject, Subject, forkJoin, of, Observable } from 'rxjs';
import {
  startWith,
  switchMap,
  filter,
  map,
  take,
  catchError,
  tap,
} from 'rxjs/operators';
import { QueryParamService } from 'src/app/services/query-param.service';
import { TranslateService } from '@ngx-translate/core';
import { DirectoryTreeNode } from 'src/app/model/ran-template.model';
import { Draft, DraftList, FileContent } from 'openapi/output/model/models';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-ran-template-file-browser',
  templateUrl: './ran-template-file-browser.component.html',
  styleUrl: './ran-template-file-browser.component.css',
  standalone: false,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RanTemplateFileBrowserComponent implements OnInit {
  private readonly codeEditorService = inject(CodeEditorService);
  private readonly confirmationService = inject(ModalConfirmationService);
  private readonly alertService = inject(TnapAlertService);
  private readonly ranTemplateService = inject(RanTemplateService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly queryParamService = inject(QueryParamService);
  private readonly translateService = inject(TranslateService);
  protected readonly supportedLanguages =
    this.codeEditorService.getSupportedLanguages();
  protected readonly editorTheme: Extension =
    this.codeEditorService.getEditorTheme();
  protected readonly codeEditorExtensions: Extension[] = [
    this.codeEditorService.a11yNameKey('ranTemplate.details.readOnly-label'),
  ];
  protected readonly readmeFile$ = new BehaviorSubject<FileContent | null>(
    null
  );

  protected readonly searchQuery = signal('');
  protected readonly loading = signal(false);
  protected readonly treeData = signal<DirectoryTreeNode[]>([]);
  protected readonly newFolderParentPath = signal<string | null>(null);
  protected readonly newFolderName = signal('');
  protected branches = signal<Array<{ value: string; label: string }>>([]);
  protected selectedBranch = signal<string>('');
  protected readonly repositoryUrl = signal('');

  private readonly defaultBranch = signal('');
  private readonly refreshTrigger$ = new Subject<void>();
  protected readonly draftBranches$ = this.refreshTrigger$.pipe(
    startWith(undefined),
    switchMap(() => this.ranTemplateService.fetchTemplateDraftsOnce())
  );
  private readonly fullTree = signal<DirectoryTreeNode[]>([]);
  private readonly isLoadingFullTree = signal(false);

  constructor() {
    this.destroyRef.onDestroy(() => this.refreshTrigger$.complete());
  }

  readonly filteredTree = computed(() => {
    const query = this.searchQuery().trim().toLowerCase();
    if (!query) {
      return this.treeData();
    }
    const treeToSearch =
      this.fullTree().length > 0 ? this.fullTree() : this.treeData();
    return this.filterNodes(treeToSearch, query);
  });

  ngOnInit(): void {
    this.ranTemplateService.getSourceDraft$
      .pipe(
        switchMap(sourceDraft =>
          this.draftBranches$.pipe(
            map(drafts => ({
              sourceDraft,
              drafts,
            }))
          )
        ),
        tap((result: { sourceDraft: Draft | null; drafts: DraftList }) => {
          const { sourceDraft, drafts } = result;
          const defaultBranch = sourceDraft?.name ?? '';

          this.defaultBranch.set(defaultBranch);
          this.repositoryUrl.set(sourceDraft?.url ?? '');
          const draftOptions = drafts.items
            .filter(
              (d: Draft) =>
                d.name !== defaultBranch && /^[0-9a-f-]+_.+/i.test(d.name)
            )
            .map((d: Draft) => ({
              value: d.name,
              label: d.name,
            }));

          const options = [{ value: '', label: 'Main' }, ...draftOptions];

          this.branches.set(options);
        }),
        switchMap(() =>
          this.queryParamService
            .getValueOf('ref')
            .pipe(map(queryRef => queryRef ?? ''))
        ),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(branchRef => {
        this.selectedBranch.set(branchRef);

        this.loadTree(branchRef);
        this.loadReadme(branchRef);
      });
    this.loadBranches();
  }

  private loadTree(branchValue: string | null | undefined): void {
    const branchToUse =
      branchValue === '' || branchValue == null
        ? this.defaultBranch()
        : branchValue;
    this.loading.set(true);
    this.ranTemplateService
      .getDirectoryTree(branchToUse || undefined)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: tree => {
          this.treeData.set(tree);
          this.loading.set(false);
        },
        error: () => this.loading.set(false),
      });
  }

  private loadReadme(branchValue: string | null | undefined): void {
    const branchToUse =
      branchValue === '' || branchValue == null
        ? this.defaultBranch()
        : branchValue;
    this.ranTemplateService
      .getRootReadmeForBranch(branchToUse || undefined)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(resp => this.readmeFile$.next(resp || null));
  }

  private filterNodes(
    nodes: DirectoryTreeNode[],
    query: string
  ): DirectoryTreeNode[] {
    return nodes
      .map(node => {
        if (node.name.toLowerCase().includes(query)) {
          return { ...node };
        }
        if (node.children) {
          const filteredChildren = this.filterNodes(node.children, query);
          if (filteredChildren.length > 0) {
            return { ...node, expanded: true, children: filteredChildren };
          }
        }
        return null;
      })
      .filter((n): n is DirectoryTreeNode => n !== null);
  }

  protected onBranchChange(value: string | null | undefined): void {
    const branch = value === '' || value == null ? undefined : value;
    this.selectedBranch.set(value ?? '');

    this.queryParamService.updateQueryParam({ ref: branch });
    this.fullTree.set([]);
  }

  protected toggleExpand(node: DirectoryTreeNode): void {
    if (!node.expanded && !node.childrenLoaded && node.type === 'folder') {
      if (node.loadingChildren) {
        return;
      }
      this.treeData.update(tree =>
        this.updateNode(tree, node.path, { loadingChildren: true })
      );

      const sel = this.selectedBranch();
      const branchToUse = sel === '' ? this.defaultBranch() : sel;

      this.ranTemplateService
        .loadChildren(node, branchToUse || undefined)
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe(children => {
          this.treeData.update(tree =>
            this.updateNode(tree, node.path, {
              children,
              childrenLoaded: true,
              expanded: true,
              loadingChildren: false,
            })
          );
        });
    } else {
      this.treeData.update(tree =>
        this.updateNode(tree, node.path, { expanded: !node.expanded })
      );
    }
  }

  private updateNode(
    nodes: DirectoryTreeNode[],
    path: string,
    changes: Partial<DirectoryTreeNode>
  ): DirectoryTreeNode[] {
    return nodes.map(n => {
      if (n.path === path) {
        return { ...n, ...changes };
      }
      if (n.children) {
        return { ...n, children: this.updateNode(n.children, path, changes) };
      }
      return n;
    });
  }

  private loadBranches(): void {
    this.ranTemplateService
      .fetchTemplateDraftsOnce()
      .pipe(take(1))
      .subscribe(drafts => {
        const draftOptions = drafts.items
          .filter(
            d =>
              d.name !== this.defaultBranch() && /^[0-9a-f-]+_.+/i.test(d.name)
          )
          .map(d => ({
            value: d.name,
            label: d.name,
          }));
        this.branches.set([
          {
            value: '',
            label: this.translateService.instant(
              'ranTemplate.modal.branch.main'
            ),
          },
          ...draftOptions,
        ]);
      });
  }

  protected onRefresh(): void {
    this.loadBranches();
    this.refreshTrigger$.next();
    this.fullTree.set([]);
  }

  protected onAddFile(node: DirectoryTreeNode, ref: string): void {
    this.queryParamService.updateQueryParam(
      {
        templateSet: node.path,
        ref,
        mode: 'add',
      },
      ['/ran-template/edit']
    );
  }

  protected onEditClick(param: Record<string, unknown>): void {
    this.ranTemplateService
      .fetchTemplateDraftsOnce()
      .pipe(take(1))
      .subscribe(drafts => {
        const branchName = this.getDraftBranchName(
          param['templateSet'] as string,
          drafts.items
        );
        const finalParam = {
          ...param,
          path: undefined,
          file: undefined,
          ref: branchName || null,
          mode: 'edit',
        };
        this.queryParamService.updateQueryParam(finalParam, [
          '/ran-template/edit',
        ]);
      });
  }

  protected onAddFolder(node: DirectoryTreeNode): void {
    if (!node.expanded) {
      this.toggleExpand(node);
    }
    this.newFolderParentPath.set(node.path);
    this.newFolderName.set('');
  }

  protected onSaveNewFolder(): void {
    const parentPath = this.newFolderParentPath();
    const name = this.newFolderName().trim();
    if (!parentPath || !name) {
      return;
    }

    const fullPath = `${parentPath}/${name}`;

    this.confirmationService
      .openConfirmationModal(
        'common.buttons.yes',
        'ranTemplate.modal.save.title',
        'ranTemplate.fileBrowser.newFolderConfirmText'
      )
      .pipe(
        filter((confirmed: boolean) => confirmed === true),
        switchMap(() =>
          this.ranTemplateService.createDirectoryWithFreshDraft(fullPath)
        ),
        switchMap(draft => this.ranTemplateService.deployTemplates(draft.name)),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: () => {
          this.newFolderParentPath.set(null);
          this.newFolderName.set('');
          this.refreshTrigger$.next();
        },
        error: err => {
          const message =
            err?.error?.detail ||
            err?.error?.title ||
            this.translateService.instant(
              'ranTemplate.fileBrowser.createDirectoryError'
            );
          this.alertService.error(message);
        },
      });
  }

  protected onCancelNewFolder(): void {
    this.newFolderParentPath.set(null);
    this.newFolderName.set('');
  }

  protected onDeleteFile(node: DirectoryTreeNode): void {
    this.confirmationService
      .openConfirmationModal(
        'common.buttons.yes',
        'ranTemplate.modal.delete.title',
        'ranTemplate.modal.delete.text'
      )
      .pipe(
        filter((confirmed: boolean) => confirmed === true),
        switchMap(() => this.ranTemplateService.fetchTemplateDraftsOnce()),
        switchMap(drafts => {
          const branchName = this.getDraftBranchName(node.path, drafts.items);

          return this.ranTemplateService.deleteFileWithFreshDraft(branchName);
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: () => {
          this.alertService.success(
            this.translateService.instant('ranTemplate.message.success.delete')
          );
          this.selectedBranch.set('');
          this.queryParamService.updateQueryParam({ ref: undefined });
          this.refreshTrigger$.next();
        },
        error: err => {
          const message =
            err?.error?.detail ||
            err?.error?.title ||
            this.translateService.instant('ranTemplate.message.error.delete');
          this.alertService.error(message);
        },
      });
  }

  protected getFileExtension(fileName: string): string {
    return this.codeEditorService.getFileExtension(fileName);
  }

  protected getDraftBranchName(
    nodePath: string,
    branches: Array<{ name?: string }> | undefined
  ): string {
    if (!nodePath || !branches?.length) {
      return '';
    }

    const normalizedPath = nodePath
      .replace(/\.jinja$/, '')
      .replaceAll('/', '_');

    const match = branches.find(branch =>
      branch.name?.includes(normalizedPath)
    );

    return match?.name ?? '';
  }

  private loadFullTree(
    nodes: DirectoryTreeNode[],
    branch: string | undefined
  ): Observable<DirectoryTreeNode[]> {
    if (nodes.length === 0) {
      return of([]);
    }

    return forkJoin(
      nodes.map(node => {
        if (node.type === 'file') {
          return of(node);
        }
        return this.ranTemplateService.loadChildren(node, branch).pipe(
          switchMap(children => {
            if (children.length === 0) {
              return of({
                ...node,
                children: [],
                childrenLoaded: true,
                expanded: false,
              });
            }
            return this.loadFullTree(children, branch).pipe(
              map(fullyLoadedChildren => ({
                ...node,
                children: fullyLoadedChildren,
                childrenLoaded: true,
                expanded: false,
              }))
            );
          }),
          catchError(() =>
            of({ ...node, children: [], childrenLoaded: true, expanded: false })
          )
        );
      })
    ).pipe(catchError(() => of(nodes)));
  }

  protected onSearchQueryChange(query: string): void {
    this.searchQuery.set(query || '');

    const trimmedQuery = (query || '').trim();

    if (!trimmedQuery) {
      this.fullTree.set([]);
      return;
    }

    if (this.isLoadingFullTree() || this.fullTree().length > 0) {
      return;
    }
    this.isLoadingFullTree.set(true);
    const sel = this.selectedBranch();
    const branchToUse = sel === '' ? this.defaultBranch() : sel;

    this.loadFullTree(this.treeData(), branchToUse || undefined)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: fullyLoadedTree => {
          this.fullTree.set(fullyLoadedTree);
          this.isLoadingFullTree.set(false);
        },
        error: () => {
          this.isLoadingFullTree.set(false);
        },
      });
  }

  protected isSelectedDraftNode(node: DirectoryTreeNode): boolean {
    const selected = this.selectedBranch();

    if (!selected) {
      return true;
    }

    const selectedPath = selected.replace(/^[0-9a-f-]+_/i, '');
    const nodePath = node.path.replace(/\.jinja$/, '').replaceAll('/', '_');
    if (node.type === 'folder' && !node.path.includes('/')) {
      if (selectedPath === nodePath) {
        return true;
      }
      if (!selectedPath.startsWith(`${nodePath}_`)) {
        return false;
      }
      const remainder = selectedPath.slice(nodePath.length + 1);
      return !remainder.startsWith('Static_');
    }

    return selectedPath === nodePath || selectedPath.startsWith(nodePath + '_');
  }

  protected handleNodeAction(
    node: DirectoryTreeNode,
    isEnabled: boolean,
    draftBranches: Draft[] | undefined
  ): void {
    if (!isEnabled) {
      return;
    }
    if (node.type === 'file') {
      this.onEditClick({
        templateSet: node.path,
        ref: this.getDraftBranchName(node.path, draftBranches),
      });
    } else {
      this.toggleExpand(node);
    }
  }
}
