/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  HostListener,
  inject,
  OnInit,
  signal,
  ViewChild,
  viewChild,
} from '@angular/core';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { TranslateService } from '@ngx-translate/core';
import { EMPTY, forkJoin, Observable, of } from 'rxjs';
import { TreeNode } from '@portal-mfe/ng-tree-lib';
import { type ContextMenuComponent } from '@perfectmemory/ngx-contextmenu';
import { BranchTabsComponent } from '../../../components/branch-tab/branch-tabs.component';
import {
  AddModeSaveContext,
  RanTemplateFilesPageDataModel,
  RanTemplateFormData,
  RanTemplateModel,
  RanTemplateValidationErrorResponse,
  RanTemplateValidationResponse,
  RanTemplateValidationSuccessResponse,
  RESPONSE_OK,
} from '../../../model/ran-template.model';
import { QueryParamService } from '../../../services/query-param.service';
import { RanTemplateService } from '../../../services/ran-templateservice/ran-template.service';
import {
  filter,
  catchError,
  finalize,
  map,
  switchMap,
  take,
  tap,
} from 'rxjs/operators';
import { Router } from '@angular/router';
import { ModalConfirmationService } from '../../../services/common-functionalities/modal-confirmation.service';
import {
  BranchTabDataModel,
  BranchTabDiffEditor,
  BranchTabDraftEditor,
  BranchTabMainEditor,
  BranchTabsModel,
} from '../../../model/branch-tabs.model';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { FileTreeNodeType } from 'openapi/output';
import { SelectOption } from '@portal-mfe/tnap-ui-kit/components/select';
import { updateWasEditorLastFocused } from '../../policy-builder/shared/code-mirror-focus-helper';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-ran-template-edit',
  templateUrl: './ran-template-edit.component.html',
  styleUrls: ['./ran-template-edit.component.css'],
  standalone: false,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RanTemplateEditComponent implements OnInit {
  private static readonly TEMPLATE_NAME_PATTERN = /^[A-Za-z0-9_]+$/;
  private readonly queryParamService = inject(QueryParamService);
  private readonly ranTemplateService = inject(RanTemplateService);
  private readonly router = inject(Router);
  private readonly destroyRef = inject(DestroyRef);
  private readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);
  private readonly confirmationService = inject(ModalConfirmationService);
  protected readonly permissions = inject(PERMISSIONS_TOKEN);
  protected schemaSelectedNodeIds: string[] = [];
  protected ranTemplatesValidation: RanTemplateValidationSuccessResponse[] = [];
  protected activeTabIndex$ = this.ranTemplateService.getActivefileTabIndex$();
  protected readonly data = toSignal(
    this.ranTemplateService.getRanTemplatePageData()
  );

  protected branchTabs: BranchTabsModel[] = [
    BranchTabDraftEditor,
    BranchTabDiffEditor,
    BranchTabMainEditor,
  ];

  protected ranTemplatesChanged = signal(false);
  protected ranTemplatesSaved = signal(false);
  protected isEditMode = signal(false);
  protected readonly draftBranchRef = toSignal(
    this.queryParamService.getValueOf('ref'),
    { initialValue: null }
  );
  protected readonly hasDraftBranch = computed(
    () => !!this.draftBranchRef()?.trim()
  );
  private readonly preserveCurrentTemplateFile = signal(false);
  protected readonly isActionLocked = signal(false);

  protected readonly treeData = signal<TreeNode[]>([]);
  protected readonly selectedNodeIds = signal<string[]>([]);
  protected readonly treeLoading = signal(false);
  protected readonly treeTotalCount = signal(0);
  protected readonly treeCurrentPage = signal(1);
  protected readonly searchQuery = signal('');
  protected readonly showValidationError = signal(false);
  protected readonly schemaTreeVisible = signal(false);
  protected readonly schemaTreeError = signal(false);
  protected readonly distributionStatus = signal<string>('');
  private readonly schemaTreeAutoOpened = signal(false);
  protected readonly treeContextMenu =
    viewChild<ContextMenuComponent<TreeNode>>('treeContextMenu');
  @ViewChild('branchTabsCmp')
  private branchTabsComponent?: BranchTabsComponent;
  private wasEditorLastFocused = false;

  protected formData = signal<RanTemplateFormData>({
    templateName: '',
    vendor: '',
    release: '',
    version: '0.1',
    model: '',
    description: '',
    onlyJinja: 'true',
  });

  protected readonly schemaPaneWidth = signal(25);
  protected readonly unit: '%' | 'px' = '%';
  protected readonly minWidth = 20;
  protected readonly maxWidth = 50;
  protected readonly step = 2;

  protected readonly vendors = signal<string[]>([]);
  protected readonly models = signal<string[]>([]);
  protected readonly versions = signal<string[]>([]);
  protected readonly isTemplateNameFormatValid = computed(() => {
    const name = this.formData().templateName?.trim();
    return !!name && RanTemplateEditComponent.TEMPLATE_NAME_PATTERN.test(name);
  });
  protected readonly isTemplateNameValid = signal(false);
  protected readonly resourceVersion = signal<string>('');
  protected readonly vendorOptions = computed<SelectOption<string>[]>(() =>
    this.vendors().map(v => ({
      value: v,
      label: v,
    }))
  );

  protected readonly versionOptions = computed<SelectOption<string>[]>(() =>
    this.versions().map(v => ({
      value: v,
      label: v,
    }))
  );
  protected readonly modelOptions = computed<SelectOption<string>[]>(() =>
    this.models().map(m => ({
      value: m,
      label: m,
    }))
  );

  protected readonly filteredTreeData = computed(() => {
    const query = this.searchQuery().toLowerCase();

    if (!query || query.length < 3) {
      return this.treeData();
    }

    return this.filterNodes(this.treeData(), query);
  });

  protected toggleSchemaTree(): void {
    this.schemaTreeVisible.update(isVisible => !isVisible);
  }

  protected updateFormData(
    field: keyof RanTemplateFormData,
    value: string
  ): void {
    this.formData.update(data => ({ ...data, [field]: value }));
    if (field === 'templateName') {
      this.isTemplateNameValid.set(false);
    }
    if (!this.isEditMode()) {
      this.syncAddModePageData();
    }
    if (field === 'vendor' || field === 'model' || field === 'release') {
      this.loadSchemaTree();
    }
    this.ranTemplatesSaved.set(false);
    this.ranTemplatesChanged.set(true);
  }

  protected validateNameOnCheck(event?: Event): void {
    event?.preventDefault();
    if (this.isEditMode()) return;
    this.validateName();
  }

  ngOnInit(): void {
    this.loadMetadataOptions();

    this.queryParamService
      .getValueOf('mode')
      .pipe(take(1))
      .subscribe(mode => {
        this.isEditMode.set(mode === 'edit');
        if (this.isEditMode()) {
          this.refreshData();
        } else {
          this.initAddMode();
        }
      });
  }

  protected hasDraftDelta(ranTemplates: RanTemplateModel[]): boolean {
    return ranTemplates.some(
      item =>
        this.ranTemplateService.normalizeContent(item.mainContent) !==
        this.ranTemplateService.normalizeContent(item.draftContent)
    );
  }

  protected modifiedValueChangelog(branchTabData: BranchTabDataModel): void {
    this.ranTemplatesSaved.set(false);

    this.ranTemplatesChanged.set(
      this.ranTemplateService.normalizeContent(
        branchTabData.modifiedContent
      ) !== this.ranTemplateService.normalizeContent(branchTabData.draftContent)
    );
  }

  protected onDescriptionChange(newDescription: string): void {
    this.formData.update(data => ({
      ...data,
      description: newDescription,
    }));

    this.ranTemplatesSaved.set(false);
    this.ranTemplatesChanged.set(true);
  }

  protected validateName(): void {
    const name = this.formData().templateName?.trim();
    if (!name) {
      this.isTemplateNameValid.set(false);
      this.alertService.error(
        this.translateService.instant('ranTemplate.message.error.nameRequired')
      );
      return;
    }
    if (!RanTemplateEditComponent.TEMPLATE_NAME_PATTERN.test(name)) {
      this.isTemplateNameValid.set(false);
      this.alertService.error(
        this.translateService.instant(
          'ranTemplate.message.error.nameInvalidFormat'
        )
      );
      return;
    }
    this.queryParamService
      .getValueOf('path')
      .pipe(
        take(1),
        switchMap(folderPath => {
          const resolvedFolderPath = folderPath ?? this.data()?.templateSetName;
          return this.ranTemplateService.validateTemplateName(
            name,
            resolvedFolderPath
          );
        })
      )
      .subscribe({
        next: isValid => {
          this.isTemplateNameValid.set(isValid);
          if (isValid) {
            this.alertService.success(
              this.translateService.instant(
                'ranTemplate.message.success.nameValid'
              )
            );
          } else {
            this.alertService.error(
              this.translateService.instant(
                'ranTemplate.message.error.nameInvalid'
              )
            );
          }
        },
        error: () => {
          this.isTemplateNameValid.set(false);
          this.alertService.error(
            this.translateService.instant(
              'ranTemplate.message.error.nameValidationUnavailable'
            )
          );
        },
      });
  }

  private bumpVersion(type: 'save' | 'deploy'): void {
    const currentVersion =
      type === 'deploy'
        ? this.resourceVersion() || '0.1'
        : this.formData().version || '0.1';

    const nextVersion =
      type === 'save'
        ? this.getNextMinorVersion(currentVersion)
        : this.getNextMajorVersion(currentVersion);

    this.formData.update(data => ({
      ...data,
      version: nextVersion,
    }));

    this.resourceVersion.set(nextVersion);
  }

  private handleTemplateSave(
    modalObservable: Observable<boolean>,
    templateData: RanTemplateModel[],
    type: 'save' | 'deploy'
  ): Observable<
    (
      | RanTemplateValidationResponse
      | RanTemplateValidationErrorResponse
      | RanTemplateValidationSuccessResponse
    )[]
  > {
    return modalObservable.pipe(
      filter(confirm => confirm === true),

      tap(() => {
        this.ranTemplatesValidation = [];
        this.bumpVersion(type);
      }),

      switchMap(() => this.getTemplateRef()),

      switchMap(() =>
        this.ranTemplateService.saveRanTemplate(
          templateData.map(item => ({
            ...item,
            modifiedContent: this.buildSavedContent(item.modifiedContent),
          }))
        )
      )
    );
  }

  private validateSaveResponse(
    response: (
      | RanTemplateValidationResponse
      | RanTemplateValidationErrorResponse
      | RanTemplateValidationSuccessResponse
    )[]
  ) {
    this.alertService.success(
      this.translateService.instant('ranTemplate.message.success.save')
    );

    this.ranTemplatesValidation = [...response.filter(this.isSuccessResponse)];

    if (
      this.ranTemplatesValidation.some(
        item => item.response.status.toUpperCase() !== RESPONSE_OK
      )
    ) {
      this.alertService.error(
        this.translateService.instant('ranTemplate.message.error.validation')
      );
    }

    this.showValidationDetails(response);
    const draftName = this.getDraftName(response);

    if (draftName) {
      this.queryParamService.updateQueryParam({ ref: draftName });
    }
    this.applySavedDraftContent();
    this.ranTemplatesSaved.set(true);
    this.ranTemplatesChanged.set(false);
  }

  private applySavedDraftContent(): void {
    const pageData = this.data();
    if (!pageData) return;

    this.ranTemplateService.updateRanTemplatePageData({
      ...pageData,
      templateFiles: pageData.templateFiles.map(templateFile => ({
        ...templateFile,
        draftContent: templateFile.modifiedContent,
      })),
    });
  }

  private showValidationDetails(
    response: RanTemplateValidationResponse[]
  ): void {
    const errors = response.flatMap(item =>
      this.isSuccessResponse(item)
        ? (item.response.errors ?? [])
        : Array.isArray(item.error)
          ? item.error
          : [item.error]
    );
    errors.forEach(error => {
      const resolvedError = error?.error ?? error;
      const validationFailedMessage = this.translateService.instant(
        'ranTemplate.message.error.validationFailed'
      );
      const message =
        typeof resolvedError === 'string'
          ? resolvedError
          : resolvedError?.errorReason ||
            resolvedError?.title ||
            resolvedError?.detail ||
            resolvedError?.message;

      this.alertService.error(
        message
          ? `${validationFailedMessage} ${message}`
          : validationFailedMessage
      );
    });
  }

  protected reset(templateListFiles: RanTemplateFilesPageDataModel): void {
    this.openResetModal()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((confirm: boolean) => {
        if (confirm) {
          this.resetTemplateFiles(templateListFiles.templateFiles);
          this.alertService.success(
            this.translateService.instant('ranTemplate.message.success.reset')
          );
        }
      });
  }

  private redirectToTemplateRootFolder(): void {
    this.router.navigate(['ran-template/file-browser']);
  }

  private openResetModal(): Observable<boolean> {
    return this.confirmationService.openConfirmationModal(
      'common.buttons.yes',
      'ranTemplate.modal.reset.title',
      'ranTemplate.modal.reset.text'
    );
  }

  private resetTemplateFiles(templateFileList: RanTemplateModel[]): void {
    const resetFiles = templateFileList.map(templateFile => ({
      ...templateFile,
      modifiedContent: templateFile.draftContent,
    }));
    this.ranTemplateService
      .getRanTemplatePageData()
      .pipe(take(1))
      .subscribe(pageData => {
        if (pageData) {
          this.ranTemplateService.updateRanTemplatePageData({
            ...pageData,
            templateFiles: resetFiles,
          });
        }
      });
  }

  private getTemplateRef(): Observable<string | null> {
    return this.queryParamService.getValueOf('ref').pipe(take(1));
  }

  private refreshData() {
    const currentTemplateFile = this.preserveCurrentTemplateFile()
      ? this.data()?.templateFiles?.[0]
      : undefined;
    this.ranTemplateService.updateRanTemplatePageData(undefined);
    this.ranTemplateService.reloadTemplateFiles();
    this.ranTemplateService
      .initialRanTemplateFilePageData$()
      .pipe(take(1))
      .subscribe(resp => {
        const nextTemplateFiles = resp?.templateFiles?.map(
          (templateFile, index) =>
            index === 0 && currentTemplateFile
              ? {
                  ...templateFile,
                  name: currentTemplateFile.name,
                  nodePath: currentTemplateFile.nodePath,
                  folderName:
                    currentTemplateFile.folderName ?? templateFile.folderName,
                }
              : templateFile
        );
        const nextPageData = resp
          ? {
              ...resp,
              templateFiles: nextTemplateFiles ?? resp.templateFiles,
            }
          : resp;

        this.ranTemplateService.updateRanTemplatePageData(nextPageData);
        const content = nextPageData?.templateFiles?.[0]?.draftContent;
        const nodePath = nextPageData?.templateFiles?.[0]?.nodePath;
        if (content) {
          const meta = this.ranTemplateService.parseTemplateMeta(content);
          if (meta) {
            this.formData.set(meta);
            const resourceName = nodePath
              ? nodePath.replace(/\.[^/.]+$/, '').replace(/\//g, '-')
              : meta.templateName;
            this.ranTemplateService
              .getResourceByNameAndVersion(resourceName, meta.version || '1.0')
              .pipe(
                take(1),
                catchError(() => of(null))
              )
              .subscribe(response => {
                this.resourceVersion.set(
                  response?.version || meta.version || '1.0'
                );
                this.distributionStatus.set(response?.distributionStatus ?? '');
              });

            this.loadSchemaTree();
          }
        }
        this.ranTemplateService.updateRanTemplatePageData(
          nextPageData
            ? this.ranTemplateService.stripMetadataFromPageData(nextPageData)
            : nextPageData
        );
        this.preserveCurrentTemplateFile.set(false);
      });
  }

  private loadSchemaTree(): void {
    const schemaTemplateName = this.getSchemaTemplateName();
    if (!schemaTemplateName) {
      this.treeData.set([]);
      this.treeTotalCount.set(0);
      this.treeLoading.set(false);
      this.schemaTreeAutoOpened.set(false);
      this.schemaTreeVisible.set(false);
      return;
    }

    this.schemaTreeError.set(false);
    this.treeLoading.set(true);
    this.ranTemplateService
      .getRanTemplateJsonSchema(schemaTemplateName)
      .pipe(
        map(response =>
          this.toTreeNodes(response.ranTemplateJsonSchema ?? response)
        ),
        catchError(() => {
          this.schemaTreeError.set(true);
          return of([] as TreeNode[]);
        }),
        finalize(() => this.treeLoading.set(false)),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(nodes => {
        this.treeData.set(this.expandFirstTreeNode(nodes));
        this.treeTotalCount.set(this.countTreeNodes(nodes));
        if (!this.schemaTreeAutoOpened()) {
          this.schemaTreeVisible.set(true);
          this.schemaTreeAutoOpened.set(true);
        }
      });
  }

  protected readonly canShowSchemaTree = computed(() => {
    return !!this.getSchemaTemplateName();
  });

  private expandFirstTreeNode(nodes: TreeNode[]): TreeNode[] {
    return nodes.map(node => ({ ...node, isExpanded: true }));
  }

  private toJinjaPath(path: string, key: string): string {
    if (/^\d+$/.test(key)) {
      return `${path}[${key}]`;
    }

    if (/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(key)) {
      return `${path}.${key}`;
    }

    return `${path}["${key}"]`;
  }

  private toTreeNodes(value: unknown, path = 'schema'): TreeNode[] {
    if (!value || typeof value !== 'object') {
      return [];
    }

    const entries = Array.isArray(value)
      ? value.map((item, index) => [String(index), item] as const)
      : Object.entries(value as Record<string, unknown>);

    const filteredEntries =
      path === 'schema' ? entries.filter(([key]) => key !== 'type') : entries;

    return filteredEntries.map(([key, childValue]) => {
      const childPath = this.toJinjaPath(path, key);

      const children = this.toTreeNodes(childValue, childPath);
      const isBranch = children.length > 0;

      return {
        id: childPath,
        label: key,
        children: isBranch ? children : [],
        hasChildren: isBranch,
        isExpanded: false,
        isLoading: false,
      } as TreeNode;
    });
  }

  private countTreeNodes(nodes: TreeNode[]): number {
    return nodes.reduce((count, node) => {
      const childCount = node.children?.length
        ? this.countTreeNodes(node.children)
        : 0;
      return count + 1 + childCount;
    }, 0);
  }

  private loadMetadataOptions(subCategory = 'BBU'): void {
    this.ranTemplateService
      .getMetadataFromResources(subCategory)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(metadata => {
        this.vendors.set(metadata.vendors);
        this.models.set(metadata.models);
        this.versions.set(metadata.versions);
      });
  }

  private getSchemaTemplateName(): string {
    const data = this.formData();
    const parts = [data.vendor, data.model, data.release]
      .map(value => value.trim())
      .filter(Boolean);

    return parts.length === 3 ? `${parts[0]}_${parts[1]}_${parts[2]}` : '';
  }

  private isSuccessResponse(
    response:
      | RanTemplateValidationResponse
      | RanTemplateValidationErrorResponse
      | RanTemplateValidationSuccessResponse
      | null
      | undefined
  ): response is RanTemplateValidationSuccessResponse {
    if (!response) {
      return false;
    }
    return (
      (response as RanTemplateValidationSuccessResponse).response !== undefined
    );
  }

  protected hasTemplateError(
    templatesValidation: RanTemplateValidationSuccessResponse[] | undefined
  ): boolean {
    return templatesValidation
      ? templatesValidation.some(
          item => item.response.status.toUpperCase() !== RESPONSE_OK
        )
      : false;
  }

  private getDraftName(
    response: (
      | RanTemplateValidationResponse
      | RanTemplateValidationErrorResponse
      | RanTemplateValidationSuccessResponse
    )[]
  ): string {
    const successResponse = response.find(this.isSuccessResponse);
    return successResponse?.draftName ?? '';
  }

  protected onTreeSelectionChange(selectedIds: string[]): void {
    this.selectedNodeIds.set(selectedIds);
  }

  protected save(): void {
    this.showValidationError.set(true);

    if (!this.isFormValid()) {
      return;
    }
    this.isActionLocked.set(true);
    if (!this.isEditMode()) {
      this.saveNewTemplate();
      return;
    }

    this.ranTemplateService
      .getRanTemplatePageData()
      .pipe(
        take(1),
        switchMap(updatedBranchTabData => {
          if (!updatedBranchTabData) {
            return EMPTY;
          }
          return this.handleTemplateSave(
            this.openSaveModal(),
            updatedBranchTabData.templateFiles,
            'save'
          );
        }),
        finalize(() => this.isActionLocked.set(false)),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(response => {
        this.validateSaveResponse(response);
      });
  }

  private applySavedNewTemplateState(
    saveContext: AddModeSaveContext,
    savedDraftVersion: string | undefined
  ): void {
    this.preserveCurrentTemplateFile.set(true);
    this.ranTemplateService.updateRanTemplatePageData(
      this.ranTemplateService.createAddModePageData(saveContext)
    );

    this.ranTemplatesSaved.set(true);
    this.ranTemplatesChanged.set(false);
    this.isEditMode.set(true);

    this.queryParamService.updateQueryParam(
      {
        path: `${saveContext.folderPath}/${saveContext.fileName}`,
        ref: savedDraftVersion,
        mode: 'edit',
      },
      ['/ran-template/edit']
    );
  }

  protected deploy(ranTemplates: RanTemplateModel[]): void {
    const previousVersion = this.resourceVersion();
    const previousFormVersion = this.formData().version;
    if (!this.isEditMode()) {
      this.deployNewTemplate();
      return;
    }

    this.ranTemplateService
      .getRanTemplatePageData()
      .pipe(
        take(1),
        switchMap(updatedBranchTabData => {
          if (!updatedBranchTabData) {
            return EMPTY;
          }

          return this.handleTemplateSave(
            this.openDeployModal(),
            ranTemplates,
            'deploy'
          ).pipe(
            switchMap(saveResponse => {
              const draftName = this.getDraftName(saveResponse);
              return this.ranTemplateService
                .deployTemplates(draftName)
                .pipe(map(() => ({ deployed: true })));
            })
          );
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: result => {
          if (result.deployed) {
            this.ranTemplatesSaved.set(false);
            this.ranTemplatesChanged.set(false);

            this.alertService.success(
              this.translateService.instant(
                'ranTemplate.message.success.deploy'
              )
            );

            this.queryParamService.updateQueryParam({
              ref: undefined,
            });
            this.refreshData();
          }
        },
        error: () => {
          this.resourceVersion.set(previousVersion);

          this.formData.update(data => ({
            ...data,
            version: previousFormVersion,
          }));

          this.ranTemplateService
            .saveRanTemplate(
              ranTemplates.map(item => ({
                ...item,
                modifiedContent: this.buildSavedContent(item.modifiedContent),
              }))
            )
            .subscribe();

          this.alertService.error(
            this.translateService.instant('ranTemplate.message.error.deploy')
          );
        },
      });
  }

  private processNewTemplate(
    modal$: Observable<boolean>,
    deploy = false
  ): void {
    this.showValidationError.set(true);

    if (!this.isFormValid() || (deploy && !this.isTemplateNameValid())) {
      return;
    }

    this.isActionLocked.set(true);
    modal$
      .pipe(
        filter(Boolean),
        switchMap(() => this.prepareAddModeSave()),
        switchMap(saveContext =>
          this.ranTemplateService.createNewTemplateInDraft(saveContext).pipe(
            map(draft => ({
              draft,
              saveContext,
            }))
          )
        ),
        switchMap(({ draft, saveContext }) => {
          const savedDraftVersion = draft.name;

          this.applySavedNewTemplateState(saveContext, savedDraftVersion);

          if (!deploy) {
            return of({
              deployed: false,
              validationFailed: false,
              validationResponses: [],
            });
          }

          return this.ranTemplateService
            .deployTemplates(savedDraftVersion)
            .pipe(map(() => ({ deployed: true })));
        }),
        finalize(() => this.isActionLocked.set(false)),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: result => {
          if (result?.deployed) {
            this.alertService.success(
              this.translateService.instant(
                'ranTemplate.message.success.deploy'
              )
            );

            this.queryParamService.updateQueryParam({
              ref: undefined,
            });
          } else {
            this.alertService.success(
              this.translateService.instant('ranTemplate.message.success.save')
            );
          }
        },
        error: () => {
          this.alertService.error(
            this.translateService.instant(
              deploy
                ? 'ranTemplate.message.error.deploy'
                : 'ranTemplate.message.error.save'
            )
          );
        },
      });
  }

  private saveNewTemplate(): void {
    this.processNewTemplate(this.openSaveModal(), false);
  }

  private deployNewTemplate(): void {
    this.processNewTemplate(this.openDeployModal(), true);
  }

  protected openSaveModal(): Observable<boolean> {
    return this.confirmationService.openConfirmationModal(
      'common.buttons.yes',
      'ranTemplate.modal.save.title',
      'ranTemplate.modal.save.text'
    );
  }

  protected openDeployModal(): Observable<boolean> {
    return this.confirmationService.openConfirmationModal(
      'common.buttons.yes',
      'ranTemplate.modal.deploy.title',
      'ranTemplate.modal.deploy.text'
    );
  }

  protected close(templateListFiles: RanTemplateFilesPageDataModel): void {
    if (this.ranTemplatesChanged()) {
      this.openResetModal()
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe((confirm: boolean) => {
          if (confirm) {
            this.resetTemplateFiles(templateListFiles.templateFiles);
            this.redirectToTemplateRootFolder();
          }
        });
    } else {
      this.redirectToTemplateRootFolder();
    }
  }

  private syncAddModePageData(): void {
    this.ranTemplateService
      .getRanTemplatePageData()
      .pipe(take(1))
      .subscribe(pageData => {
        if (!pageData?.templateFiles?.length) return;
        this.ranTemplateService.updateRanTemplatePageData({
          ...pageData,
          templateFiles: [
            {
              ...pageData.templateFiles[0],
              mainContent:
                this.ranTemplateService.removeMetadataBlockFromContent(
                  pageData.templateFiles[0].mainContent
                ),
              draftContent:
                this.ranTemplateService.removeMetadataBlockFromContent(
                  pageData.templateFiles[0].draftContent
                ),
              modifiedContent:
                this.ranTemplateService.removeMetadataBlockFromContent(
                  pageData.templateFiles[0].modifiedContent
                ),
            },
          ],
        });
      });
  }

  private prepareAddModeSave(): Observable<AddModeSaveContext> {
    return forkJoin({
      folderPath: this.queryParamService
        .getValueOf('templateSet')
        .pipe(take(1)),
      pageData: this.ranTemplateService.getRanTemplatePageData().pipe(take(1)),
    }).pipe(
      map(({ folderPath, pageData }) =>
        this.buildAddModeSaveContext(folderPath, pageData)
      ),
      switchMap(saveContext => (saveContext ? of(saveContext) : EMPTY))
    );
  }

  private buildAddModeSaveContext(
    folderPath: string | null,
    pageData: RanTemplateFilesPageDataModel | undefined
  ): AddModeSaveContext | null {
    const file = pageData?.templateFiles?.[0];

    if (!file) {
      return null;
    }

    const fileName = this.getAddModeFileName();

    return {
      fileName,
      folderPath: folderPath ?? '',
      content: this.buildSavedContent(file.modifiedContent),
    };
  }

  private getAddModeFileName(): string {
    const templateName = this.formData().templateName.trim();
    if (!templateName) return 'new-template.jinja';
    return templateName.endsWith('.jinja')
      ? templateName
      : `${templateName}.jinja`;
  }

  private getAddModeContent(): string {
    return '';
  }

  private initAddMode(): void {
    const fileName = this.getAddModeFileName();
    const defaultContent = this.getAddModeContent();

    this.queryParamService
      .getValueOf('templateSet')
      .pipe(take(1))
      .subscribe(folderPath => {
        const nodePath = folderPath ? `${folderPath}/${fileName}` : fileName;

        const pageData: RanTemplateFilesPageDataModel = {
          templateSetName: folderPath ?? '',
          templateFiles: [
            {
              folderName: folderPath ?? undefined,
              name: fileName,
              fileNodeType: FileTreeNodeType.FILE,
              nodePath,
              mainContent: defaultContent,
              draftContent: defaultContent,
              modifiedContent: defaultContent,
            },
          ],
        };

        this.ranTemplateService.updateRanTemplatePageData(pageData);
      });
  }

  private buildMetadataBlock(): string {
    const data = this.formData();
    const onlyJinja = data.onlyJinja?.trim();
    const onlyJinjaLine = onlyJinja ? `onlyJinja: ${onlyJinja}\n` : '';
    return `{#\nname: ${data.templateName}\nvendor: ${data.vendor}\nrelease: ${data.release}\nversion: ${data.version || '0.1'}\nvendorModelNumber: ${data.model}\ndescription: ${data.description}\n${onlyJinjaLine}#}\n`;
  }

  private buildSavedContent(content: string | undefined): string {
    return `${this.buildMetadataBlock()}${this.ranTemplateService.removeMetadataBlockFromContent(content)}`;
  }

  private isFormValid(): boolean {
    const data = this.formData();

    return !!(
      data.templateName?.trim() &&
      this.isTemplateNameFormatValid() &&
      data.vendor?.trim() &&
      data.release?.trim() &&
      data.model?.trim() &&
      data.description?.trim()
    );
  }

  protected onSchemaNodeInsert(node: TreeNode): void {
    void navigator.clipboard?.writeText(node.id);
    if (this.wasEditorLastFocused) {
      this.branchTabsComponent?.insertPath(node.id);
    }
  }

  private filterNodes(nodes: TreeNode[], query: string): TreeNode[] {
    return nodes.reduce((result: TreeNode[], node) => {
      const children = node.children
        ? this.filterNodes(node.children, query)
        : [];

      const matches = node.label?.toLowerCase().includes(query.toLowerCase());

      if (matches || children.length > 0) {
        result.push({
          ...node,
          children,
          isExpanded: true,
        });
      }

      return result;
    }, []);
  }

  protected onSearchQueryChange(query: string): void {
    this.searchQuery.set(query);
  }

  protected clearSearch(): void {
    this.searchQuery.set('');
  }

  private getNextMinorVersion(version: string): string {
    const [major, minor] = version.split('.').map(Number);
    return `${major}.${minor + 1}`;
  }

  private getNextMajorVersion(version: string): string {
    const [major] = version.split('.').map(Number);
    return `${major + 1}.0`;
  }

  @HostListener('document:mousedown', ['$event'])
  protected onDocumentMouseDown(event: MouseEvent): void {
    updateWasEditorLastFocused({
      target: event.target as HTMLElement | null,
      setWasEditorLastFocused: value => (this.wasEditorLastFocused = value),
    });
  }
}
