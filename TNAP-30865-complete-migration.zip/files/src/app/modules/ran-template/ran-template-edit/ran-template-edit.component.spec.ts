/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
  Component,
  Directive,
  EventEmitter,
  HostListener,
  Input,
  Output,
  WritableSignal,
} from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { BehaviorSubject, of, Subject, throwError } from 'rxjs';
import { TreeNode, TreeViewComponent } from '@portal-mfe/ng-tree-lib';
import { ContextMenuModule } from '@perfectmemory/ngx-contextmenu';
import { By } from '@angular/platform-browser';
import { InputSearchComponent } from '@portal-mfe/tnap-ui-kit/components/input-search';

import { RanTemplateEditComponent } from './ran-template-edit.component';
import { RanTemplateService } from '../../../services/ran-templateservice/ran-template.service';
import { QueryParamService } from '../../../services/query-param.service';
import { AuthService } from '@portal-mfe/auth';
import { ModalConfirmationService } from '../../../services/common-functionalities/modal-confirmation.service';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import {
  RanTemplateFilesPageDataModel,
  RanTemplateFormData,
  RanTemplateModel,
  RanTemplateValidationResponse,
  RanTemplateValidationSuccessResponse,
  RESPONSE_OK,
} from '../../../model/ran-template.model';
import { FileTreeNodeType } from 'openapi/output';
import de from 'src/assets/i18n/de.json';
import en from 'src/assets/i18n/en.json';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

const NAME_VALIDATION_UNAVAILABLE_KEY =
  'ranTemplate.message.error.nameValidationUnavailable';

/* Every key this file asserts against `alertService` as a raw string. TranslateService is
 * never given a bundle here, so `instant()` echoes the key back and each of those
 * assertions holds just as well for a key that exists in neither language file. */
const ASSERTED_ALERT_KEYS = [
  NAME_VALIDATION_UNAVAILABLE_KEY,
  'ranTemplate.message.error.validation',
  'ranTemplate.message.success.reset',
  'ranTemplate.message.error.save',
  'ranTemplate.message.success.deploy',
  'ranTemplate.message.error.deploy',
];

const translationAt = (bundle: unknown, key: string): unknown =>
  key
    .split('.')
    .reduce<unknown>(
      (node, segment) =>
        node && typeof node === 'object'
          ? (node as Record<string, unknown>)[segment]
          : undefined,
      bundle
    );

// --------------- stub components / directives ---------------

// eslint-disable-next-line @angular-eslint/component-selector
@Component({ selector: 'tnap-select', template: '', standalone: false })
class TnapSelectStubComponent {
  @Input() label = '';
  @Input() options: unknown[] = [];
  @Input() value: unknown = null;
  @Input() disabled = false;
  @Input() required = false;
  @Input() allowClear = true;
  @Input() invalid = false;
  @Input() errorMessage: string | undefined;
  @Output() valueChange = new EventEmitter<unknown>();
}

@Component({ selector: 'app-branch-tabs', template: '', standalone: false })
class BranchTabsStubComponent {
  @Input() fileName = '';
  @Input() styleHeight = '';
  @Input() branchTabs: unknown[] = [];
  @Input() contentType = '';
  @Output() templateFileChange = new EventEmitter<unknown>();

  insertPath(path: string): void {
    void path;
  }
}

@Directive({ selector: '[appHasPermissions]', standalone: false })
class AppHasPermissionsStubDirective {
  @Input() appHasPermissions: unknown = null;
}

// eslint-disable-next-line @angular-eslint/directive-selector
@Directive({ selector: '[ngbTooltip]', standalone: false })
class NgbTooltipStubDirective {
  @Input() ngbTooltip: unknown = null;
}

// eslint-disable-next-line @angular-eslint/directive-selector
@Directive({ selector: '[tnapButton]', standalone: false })
class TnapButtonStubDirective {
  @Input() variant = '';
  @Input() size = '';
  @Input() label = '';
  @Input() disabled = false;
  @Output() readonly clickAction = new EventEmitter<void>();

  @HostListener('click')
  onClick(): void {
    this.clickAction.emit();
  }
}

type RanTemplateEditTestAccess = RanTemplateEditComponent & {
  ranTemplatesChanged: WritableSignal<boolean>;
  ranTemplatesSaved: WritableSignal<boolean>;
  isEditMode: WritableSignal<boolean>;
  isActionLocked: WritableSignal<boolean>;
  isTemplateNameValid: WritableSignal<boolean>;
  formData: WritableSignal<RanTemplateFormData>;
  vendors: WritableSignal<string[]>;
  versions: WritableSignal<string[]>;
  models: WritableSignal<string[]>;
  selectedNodeIds: WritableSignal<string[]>;
  treeData: WritableSignal<unknown[]>;
  treeTotalCount: WritableSignal<number>;
  schemaTreeVisible: WritableSignal<boolean>;
  resourceVersion: WritableSignal<string>;
  distributionStatus: WritableSignal<string>;
  onDescriptionChange(newDescription: string): void;
  updateFormData(field: keyof RanTemplateFormData, value: string): void;
  validateName(): void;
  validateNameOnCheck(event?: Event): void;
  onSchemaNodeInsert(node: TreeNode): void;
  hasDraftDelta(
    ranTemplates: RanTemplateFilesPageDataModel['templateFiles']
  ): boolean;
  save(): void;
  deploy(ranTemplates: RanTemplateFilesPageDataModel['templateFiles']): void;
  reset(templateListFiles: RanTemplateFilesPageDataModel): void;
  close(templateListFiles: RanTemplateFilesPageDataModel): void;
  onTreeSelectionChange(selectedIds: string[]): void;
  hasTemplateError(
    templatesValidation: RanTemplateValidationSuccessResponse[] | undefined
  ): boolean;
};

describe('RanTemplateEditComponent', () => {
  let component: RanTemplateEditComponent;
  let componentAccess: RanTemplateEditTestAccess;
  let fixture: ComponentFixture<RanTemplateEditComponent>;
  let pageData$: BehaviorSubject<RanTemplateFilesPageDataModel | undefined>;
  let ranTemplateServiceMock: jasmine.SpyObj<RanTemplateService>;
  let queryParamServiceMock: jasmine.SpyObj<QueryParamService>;
  let alertServiceMock: jasmine.SpyObj<TnapAlertService>;
  let confirmationServiceMock: jasmine.SpyObj<ModalConfirmationService>;
  let routerMock: jasmine.SpyObj<Router>;
  let originalClipboard: Clipboard | undefined;

  const createPageData = (): RanTemplateFilesPageDataModel => ({
    templateSetName: 'templates',
    templateFiles: [
      {
        folderName: 'templates',
        name: 'template.jinja',
        fileNodeType: FileTreeNodeType.FILE,
        nodePath: 'templates/template.jinja',
        mainContent: '',
        draftContent:
          '{#\nname: old\nvendor: Ericsson\nrelease: 1.0\nvendorModelNumber: model-a\ndescription: old description\n#}\n',
        modifiedContent:
          '{#\nname: old\nvendor: Ericsson\nrelease: 1.0\nvendorModelNumber: model-a\ndescription: old description\n#}\n',
      },
    ],
  });

  function configure(mode: 'add' | 'edit' = 'add') {
    pageData$ = new BehaviorSubject<RanTemplateFilesPageDataModel | undefined>(
      createPageData()
    );
    ranTemplateServiceMock = jasmine.createSpyObj('RanTemplateService', [
      'getActivefileTabIndex$',
      'getRanTemplatePageData',
      'updateRanTemplatePageData',
      'normalizeContent',
      'validateTemplateName',
      'validateRanTemplate',
      'initialRanTemplateFilePageData$',
      'saveRanTemplate',
      'deployTemplates',
      'parseTemplateMeta',
      'updateDescriptionInContent',
      'removeMetadataBlockFromContent',
      'stripMetadataFromPageData',
      'createNewTemplateInDraft',
      'createAddModePageData',
      'getMetadata',
      'getMetadataFromResources',
      'getRanTemplateJsonSchema',
      'reloadTemplateFiles',
      'getResourceByNameAndVersion',
    ]);
    ranTemplateServiceMock.getMetadata.and.returnValue({
      vendors: [],
      versions: [],
      models: [],
    });
    ranTemplateServiceMock.getMetadataFromResources.and.returnValue(
      of({ vendors: ['Huawei'], versions: ['1.0'], models: ['rel1'] })
    );
    ranTemplateServiceMock.getRanTemplateJsonSchema.and.returnValue(
      of({
        ranTemplateJsonSchema: {
          nodeData: {
            properties: {
              runtime: {},
              planning: {},
            },
          },
        },
      })
    );
    ranTemplateServiceMock.getActivefileTabIndex$.and.returnValue(of(0));
    ranTemplateServiceMock.getResourceByNameAndVersion.and.returnValue(
      of({ version: '1.0', distributionStatus: 'DISTRIBUTED' } as any)
    );
    ranTemplateServiceMock.getRanTemplatePageData.and.returnValue(
      pageData$.asObservable()
    );
    ranTemplateServiceMock.normalizeContent.and.callFake(
      content => content ?? ''
    );
    ranTemplateServiceMock.createNewTemplateInDraft.and.returnValue(
      of({ name: 'draft-version-1' } as any)
    );
    ranTemplateServiceMock.validateTemplateName.and.returnValue(of(true));
    ranTemplateServiceMock.validateRanTemplate.and.returnValue(
      of([
        {
          name: 'template.jinja',
          draftName: 'draft-version-1',
          response: { status: RESPONSE_OK },
        },
      ] as RanTemplateValidationResponse[])
    );
    ranTemplateServiceMock.initialRanTemplateFilePageData$.and.returnValue(
      of(createPageData())
    );
    ranTemplateServiceMock.saveRanTemplate.and.returnValue(of([]));
    ranTemplateServiceMock.deployTemplates.and.returnValue(
      of({
        response: {
          status: RESPONSE_OK,
        },
      } as any)
    );
    ranTemplateServiceMock.parseTemplateMeta.and.returnValue({
      templateName: 'old',
      vendor: 'Ericsson',
      release: '1.0',
      version: '1.0',
      model: 'model-a',
      description: 'old description',
      onlyJinja: 'true',
    });
    ranTemplateServiceMock.updateDescriptionInContent.and.callFake(
      (_content: string, description: string) =>
        `{#\nname: old\nvendor: Ericsson\nrelease: 1.0\nvendorModelNumber: model-a\ndescription: ${description}\n#}\n`
    );
    ranTemplateServiceMock.removeMetadataBlockFromContent.and.callFake(
      content => content ?? ''
    );
    ranTemplateServiceMock.stripMetadataFromPageData.and.callFake(
      pageData => pageData
    );

    ranTemplateServiceMock.createAddModePageData.and.returnValue({
      templateSetName: 'templates',
      templateFiles: [
        {
          folderName: 'templates',
          name: 'template_a.jinja',
          fileNodeType: FileTreeNodeType.FILE,
          nodePath: 'templates/template_a.jinja',
          mainContent: 'content',
          draftContent: 'content',
          modifiedContent: 'content',
        },
      ],
    } as RanTemplateFilesPageDataModel);

    queryParamServiceMock = jasmine.createSpyObj('QueryParamService', [
      'getValueOf',
      'updateQueryParam',
    ]);
    queryParamServiceMock.getValueOf.and.callFake(param =>
      of(param === 'mode' ? mode : param === 'ref' ? 'draft_a' : null)
    );
    alertServiceMock = jasmine.createSpyObj('TnapAlertService', [
      'error',
      'success',
    ]);
    confirmationServiceMock = jasmine.createSpyObj('ModalConfirmationService', [
      'openConfirmationModal',
    ]);
    confirmationServiceMock.openConfirmationModal.and.returnValue(of(true));
    routerMock = jasmine.createSpyObj('Router', ['navigate']);
    const authServiceMock = jasmine.createSpyObj('AuthService', [
      'loadCachedUserProfile',
    ]);
    authServiceMock.loadCachedUserProfile.and.returnValue(
      of({ sub: '88825692-801e-47f4-b6fc-6adf13943ae9' })
    );

    TestBed.configureTestingModule({
      declarations: [
        RanTemplateEditComponent,
        TnapSelectStubComponent,
        BranchTabsStubComponent,
        AppHasPermissionsStubDirective,
        NgbTooltipStubDirective,
        TnapButtonStubDirective,
      ],
      imports: [
        FormsModule,
        TranslateModule.forRoot(),
        TreeViewComponent,
        ContextMenuModule,
        InputSearchComponent,
      ],
      providers: [
        { provide: RanTemplateService, useValue: ranTemplateServiceMock },
        { provide: QueryParamService, useValue: queryParamServiceMock },
        { provide: TnapAlertService, useValue: alertServiceMock },
        {
          provide: ModalConfirmationService,
          useValue: confirmationServiceMock,
        },
        { provide: Router, useValue: routerMock },
        { provide: PERMISSIONS_TOKEN, useValue: {} },
        { provide: AuthService, useValue: authServiceMock },
        TranslateService,
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(RanTemplateEditComponent);
    component = fixture.componentInstance;
    componentAccess = component as RanTemplateEditTestAccess;

    originalClipboard = (navigator as Navigator & { clipboard?: Clipboard })
      .clipboard;
    Object.defineProperty(navigator, 'clipboard', {
      value: {
        writeText: () => Promise.resolve(),
      },
      configurable: true,
    });

    fixture.detectChanges();
  }

  afterEach(() => {
    if (originalClipboard) {
      Object.defineProperty(navigator, 'clipboard', {
        value: originalClipboard,
        configurable: true,
      });
    }
    TestBed.resetTestingModule();
  });

  describe('mode handling', () => {
    beforeEach(() => configure('add'));

    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should initialize add mode with empty template content', () => {
      expect(componentAccess.isEditMode()).toBeFalse();
      expect(
        ranTemplateServiceMock.updateRanTemplatePageData
      ).toHaveBeenCalled();
      const pageData =
        ranTemplateServiceMock.updateRanTemplatePageData.calls.mostRecent()
          .args[0] as RanTemplateFilesPageDataModel;
      expect(pageData.templateFiles[0].name).toBe('new-template.jinja');
      expect(pageData.templateFiles[0].modifiedContent).toBe('');
      expect(pageData.templateFiles[0].draftContent).toBe(
        pageData.templateFiles[0].modifiedContent
      );
    });
  });

  describe('edit mode', () => {
    beforeEach(() => configure('edit'));

    it('should refresh existing data when mode is edit', () => {
      expect(componentAccess.isEditMode()).toBeTrue();
      expect(
        ranTemplateServiceMock.initialRanTemplateFilePageData$
      ).toHaveBeenCalled();
      expect(
        ranTemplateServiceMock.updateRanTemplatePageData
      ).toHaveBeenCalledWith(undefined);
    });

    it('should apply parsed template metadata to form signals and load schema tree', () => {
      expect(ranTemplateServiceMock.parseTemplateMeta).toHaveBeenCalled();
      expect(componentAccess.formData()).toEqual({
        templateName: 'old',
        vendor: 'Ericsson',
        release: '1.0',
        version: '1.0',
        model: 'model-a',
        description: 'old description',
        onlyJinja: 'true',
      });
      expect(
        ranTemplateServiceMock.getRanTemplateJsonSchema
      ).toHaveBeenCalledWith('Ericsson_model-a_1.0');
      expect(componentAccess.treeData().length).toBe(1);
      expect(componentAccess.schemaTreeVisible()).toBeTrue();
      const schemaRoot = componentAccess.treeData()[0] as TreeNode;
      expect(schemaRoot).toEqual(
        jasmine.objectContaining({
          id: 'schema.nodeData',
          label: 'nodeData',
          hasChildren: true,
          isExpanded: true,
        })
      );
      expect(schemaRoot.children?.[0]).toEqual(
        jasmine.objectContaining({
          label: 'properties',
          isExpanded: false,
        })
      );
      expect(
        schemaRoot.children?.[0].children?.every(child => !child.isExpanded)
      ).toBeTrue();
      expect(componentAccess.treeTotalCount()).toBe(4);
    });

    it('should show the schema panel when the schema response has no data', () => {
      ranTemplateServiceMock.getRanTemplateJsonSchema.and.returnValue(
        of({ ranTemplateJsonSchema: {} })
      );

      (component as any).loadSchemaTree();

      expect(componentAccess.treeData()).toEqual([]);
      expect(componentAccess.treeTotalCount()).toBe(0);
      expect(componentAccess.schemaTreeVisible()).toBeTrue();

      fixture.detectChanges();
      expect(
        fixture.nativeElement.querySelector('.schema-panel-toggle')
      ).not.toBeNull();
      expect(
        fixture.nativeElement.querySelector('.schema-tree-panel')
      ).not.toBeNull();
    });

    it('should toggle the schema panel visibility', () => {
      const schemaToggle = fixture.nativeElement.querySelector(
        '.qa_schema_panel_toggle'
      ) as HTMLButtonElement;
      const schemaPanel = fixture.nativeElement.querySelector(
        '.schema-tree-panel'
      ) as HTMLElement;

      expect(schemaPanel).not.toBeNull();
      expect(componentAccess.schemaTreeVisible()).toBeTrue();

      schemaToggle.click();
      fixture.detectChanges();

      expect(componentAccess.schemaTreeVisible()).toBeFalse();
      expect(
        fixture.nativeElement.querySelector('.schema-tree-panel')
      ).toBeNull();

      fixture.nativeElement.querySelector('.qa_schema_panel_toggle').click();
      fixture.detectChanges();

      expect(componentAccess.schemaTreeVisible()).toBeTrue();
      expect(
        fixture.nativeElement.querySelector('.schema-tree-panel')
      ).not.toBeNull();
    });

    it('names the schema search input without an unresolved description', () => {
      const host = fixture.nativeElement.querySelector(
        'tnap-input-search.qa_tree_search'
      ) as HTMLElement;
      const input = host.querySelector('input') as HTMLInputElement;
      const label = host.querySelector(
        `label[for="${input.id}"]`
      ) as HTMLLabelElement;

      expect(label.textContent?.trim()).toBe('treeview.mainSearchLabel');
      expect(host.hasAttribute('aria-describedby')).toBeFalse();
      expect(input.hasAttribute('aria-describedby')).toBeFalse();
    });

    it('should force a fresh template file list re-fetch on refresh', () => {
      expect(ranTemplateServiceMock.reloadTemplateFiles).toHaveBeenCalled();
    });

    it('should populate resourceVersion and distributionStatus from the resource lookup', () => {
      expect(
        ranTemplateServiceMock.getResourceByNameAndVersion
      ).toHaveBeenCalledWith('templates-template', '1.0');
      expect(componentAccess.resourceVersion()).toBe('1.0');
      expect(componentAccess.distributionStatus()).toBe('DISTRIBUTED');
    });

    it('should build the resource name from the full nested folder path, not just the meta name', () => {
      ranTemplateServiceMock.initialRanTemplateFilePageData$.and.returnValue(
        of({
          templateSetName: 'Huawei',
          templateFiles: [
            {
              folderName: 'Huawei',
              name: 'DEFAULT_DISCREPANCY_TEMPLATE_DEMO_ALL.jinja',
              fileNodeType: FileTreeNodeType.FILE,
              nodePath:
                'Huawei/Discrepancy/Attribute/DEFAULT_DISCREPANCY_TEMPLATE_DEMO_ALL.jinja',
              mainContent: '',
              draftContent:
                '{#\nname: default-discrepancy-template-demo\nvendor: Huawei\nrelease: 1.0\nvendorModelNumber: model-a\ndescription: demo\n#}\n',
              modifiedContent:
                '{#\nname: default-discrepancy-template-demo\nvendor: Huawei\nrelease: 1.0\nvendorModelNumber: model-a\ndescription: demo\n#}\n',
            },
          ],
        })
      );
      ranTemplateServiceMock.parseTemplateMeta.and.returnValue({
        templateName: 'default-discrepancy-template-demo',
        vendor: 'Huawei',
        release: '1.0',
        version: '2.0',
        model: 'model-a',
        description: 'demo',
      });

      (componentAccess as any).refreshData();

      expect(
        ranTemplateServiceMock.getResourceByNameAndVersion
      ).toHaveBeenCalledWith(
        'Huawei-Discrepancy-Attribute-DEFAULT_DISCREPANCY_TEMPLATE_DEMO_ALL',
        '2.0'
      );
    });

    it('should fall back to the parsed metadata version when the resource lookup fails', () => {
      ranTemplateServiceMock.getResourceByNameAndVersion.and.returnValue(
        throwError(() => new Error('502'))
      );

      (componentAccess as any).refreshData();

      expect(componentAccess.resourceVersion()).toBe('1.0');
      expect(componentAccess.distributionStatus()).toBe('');
    });

    it('should build array index paths using bracket notation', () => {
      const nodes = (component as any).toTreeNodes({
        items: [
          {
            cellId: '123',
          },
        ],
      });

      expect(nodes[0].id).toBe('schema.items');
      expect(nodes[0].children?.[0].id).toBe('schema.items[0]');
    });

    it('should build quoted paths for keys with special characters', () => {
      const nodes = (component as any).toTreeNodes({
        'my-key': {
          value: '123',
        },
      });

      expect(nodes[0].id).toBe('schema["my-key"]');
      expect(nodes[0].children?.[0].id).toBe('schema["my-key"].value');
    });

    describe('version bump arithmetic', () => {
      /* The two pure helpers only. Bracket access because both are private, and driving
       * them through save()/deploy() means running those pipelines — which the describe
       * below does. */
      it('increments only the minor part', () => {
        expect(component['getNextMinorVersion']('1.0')).toBe('1.1');
        expect(component['getNextMinorVersion']('2.7')).toBe('2.8');
      });

      it('does not roll a minor of 9 into the next major', () => {
        expect(component['getNextMinorVersion']('1.9')).toBe('1.10');
      });

      it('zeroes the minor when bumping the major', () => {
        expect(component['getNextMajorVersion']('1.9')).toBe('2.0');
        expect(component['getNextMajorVersion']('1.0')).toBe('2.0');
      });

      /* Pins the TNAP-32919 defect, not correctness: '2'.split('.') yields a single
       * element, so `minor + 1` is NaN and the result is the literal string "2.NaN",
       * which buildMetadataBlock() then persists into the template file - where the next
       * save re-parses it to NaN again. Fixing it belongs to that ticket; asserting it
       * here keeps the corruption from being silently uncovered, and makes the fix show
       * up as a failing test rather than as a green suite. */
      it('produces NaN for a version with no minor part (TNAP-32919)', () => {
        expect(component['getNextMinorVersion']('2')).toBe('2.NaN');
      });
    });

    /* `formData().version` is asserted alongside `resourceVersion()` in both tests
     * because they are two independent writes and only the first one leaves the
     * browser: buildMetadataBlock() renders `version: ${data.version}` from formData
     * into the file content that is saved/deployed, while resourceVersion only drives
     * the UI. Dropping either `formData.update({ version: nextVersion })` block would
     * ship every template with its old version number. */
    describe('version bump applied by save() and deploy()', () => {
      it('bumps the minor version when saving a draft', () => {
        // save() applies the bump synchronously up front, then fires the save
        // request; on success it internally calls refreshData(), which re-fetches
        // the resource and would overwrite resourceVersion from this describe's
        // static stub (always '1.0'), masking the bump regardless of whether it
        // happened. Stall the save request (never emit) so the assertion below
        // observes only the up-front bump — the part save() is actually responsible
        // for — without depending on that unrelated re-fetch.
        ranTemplateServiceMock.saveRanTemplate.and.returnValue(new Subject());

        componentAccess.save();

        expect(componentAccess.formData().version).toBe('1.1');
        expect(componentAccess.resourceVersion()).toBe('1.1');
      });

      /* Unlike save(), deploy() sets resourceVersion only inside subscribe on the
       * success path, so that half of the assertion needs the whole pipeline
       * (openDeployModal → getRanTemplatePageData → saveRanTemplate →
       * allTemplatesValid → deployTemplates) to emit from the mocks. The formData
       * write is the up-front, arithmetic-only half. Named for the pipeline it runs so
       * an unrelated deploy change does not read as broken arithmetic. */
      it('bumps the major version through the full deploy pipeline', () => {
        ranTemplateServiceMock.saveRanTemplate.and.returnValue(
          of([
            {
              name: 'demo.jinja',
              draftName: 'draft_a',
              response: {
                status: RESPONSE_OK,
              },
            } as RanTemplateValidationSuccessResponse,
          ])
        );

        componentAccess.deploy([{ name: 'demo.jinja' } as RanTemplateModel]);

        expect(ranTemplateServiceMock.deployTemplates).toHaveBeenCalledWith(
          'draft_a'
        );
      });

      it('bumps nothing when the form is invalid', () => {
        componentAccess.formData.update(data => ({ ...data, description: '' }));

        componentAccess.save();

        expect(componentAccess.formData().version).toBe('1.0');
        expect(componentAccess.resourceVersion()).toBe('1.0');
        expect(ranTemplateServiceMock.saveRanTemplate).not.toHaveBeenCalled();
      });

      /* getRanTemplatePageData() emitting undefined short-circuits both pipelines to
       * EMPTY, so subscribe never runs. The formData bump has already happened by then
       * in either case - it is only the request that must not go out. */
      it('does not save or deploy when the page data is missing', () => {
        pageData$.next(undefined);

        componentAccess.save();
        componentAccess.deploy([{ name: 'demo.jinja' }] as RanTemplateModel[]);

        expect(ranTemplateServiceMock.saveRanTemplate).not.toHaveBeenCalled();
        expect(ranTemplateServiceMock.deployTemplates).not.toHaveBeenCalled();
        expect(componentAccess.formData().version).toBe('1.0');
        expect(componentAccess.resourceVersion()).toBe('1.0');
      });

      /* Pins the TNAP-32918 defect, not correctness. Cancelling closes the modal with
       * `false`, which handleTemplateSave's `filter(confirm => confirm === true)` drops,
       * so the inner stream completes without emitting - and `toArray()` turns that into
       * `[]`, which is truthy. The `if (response)` in deploy() therefore takes the
       * success branch on a cancel: success alert, resourceVersion bumped, and `ref`
       * cleared so the page leaves the user's draft for the main branch. That is also
       * why the error branch below it is unreachable - it is the branch this defect
       * steals, not dead code to delete.
       *
       * The version assertions cover the second half of the same ticket: deploy() writes
       * formData.version before the modal is even opened and nothing rolls it back, so
       * each cancel inflates the number that buildMetadataBlock() persists on the next
       * save.
       *
       * Asserted per call rather than by count so that fixing the ticket fails on the
       * specific wrong behaviour instead of on an arbitrary total. */
      it('should keep changes and not show success when deploy is cancelled', () => {
        confirmationServiceMock.openConfirmationModal.and.returnValue(
          of(false)
        );

        componentAccess.ranTemplatesChanged.set(true);

        componentAccess.deploy([{ name: 'demo.jinja' } as RanTemplateModel]);

        expect(ranTemplateServiceMock.saveRanTemplate).not.toHaveBeenCalled();

        expect(ranTemplateServiceMock.deployTemplates).not.toHaveBeenCalled();

        expect(componentAccess.ranTemplatesChanged()).toBeTrue();

        expect(alertServiceMock.success).not.toHaveBeenCalled();

        expect(queryParamServiceMock.updateQueryParam).not.toHaveBeenCalledWith(
          {
            ref: undefined,
          }
        );
        expect(componentAccess.formData().version).toBe('1.0');
        expect(componentAccess.resourceVersion()).toBe('1.0');
      });
    });
  });

  describe('description sync', () => {
    beforeEach(() => configure('add'));

    it('should update description form state and mark the template as changed', () => {
      componentAccess.onDescriptionChange('new description');

      expect(componentAccess.formData().description).toBe('new description');
      expect(componentAccess.ranTemplatesChanged()).toBeTrue();
    });

    it('should preserve dollar characters in the description form state', () => {
      componentAccess.onDescriptionChange('cost is $1 and $&');

      expect(componentAccess.formData().description).toBe('cost is $1 and $&');
    });
  });

  describe('validateName', () => {
    beforeEach(() => configure('add'));

    it('should show required error when template name is empty', () => {
      componentAccess.formData.update(data => ({
        ...data,
        templateName: '   ',
      }));

      componentAccess.validateName();

      expect(alertServiceMock.error).toHaveBeenCalled();
      expect(
        ranTemplateServiceMock.validateTemplateName
      ).not.toHaveBeenCalled();
    });

    it('should call validateTemplateName and show success for valid names', () => {
      componentAccess.formData.update(data => ({
        ...data,
        templateName: 'template_a',
      }));
      ranTemplateServiceMock.validateTemplateName.and.returnValue(of(true));

      componentAccess.validateName();

      expect(ranTemplateServiceMock.validateTemplateName).toHaveBeenCalledWith(
        'template_a',
        'templates'
      );
      expect(alertServiceMock.success).toHaveBeenCalled();
    });

    it('should reject names containing underscores without calling the backend', () => {
      componentAccess.formData.update(data => ({
        ...data,
        templateName: 'template-a',
      }));

      componentAccess.validateName();

      expect(
        ranTemplateServiceMock.validateTemplateName
      ).not.toHaveBeenCalled();
      expect(alertServiceMock.error).toHaveBeenCalled();
      expect(componentAccess.isTemplateNameValid()).toBeFalse();
    });

    it('should show error for invalid names', () => {
      componentAccess.formData.update(data => ({
        ...data,
        templateName: 'template_a',
      }));
      ranTemplateServiceMock.validateTemplateName.and.returnValue(of(false));

      componentAccess.validateName();

      expect(alertServiceMock.error).toHaveBeenCalled();
    });

    it('reports that name validation is unavailable when the check errors', () => {
      ranTemplateServiceMock.validateTemplateName.and.returnValue(
        throwError(() => new HttpErrorResponse({ status: 500 }))
      );

      componentAccess.updateFormData('templateName', 'ran_activate_02');
      componentAccess.validateName();

      expect(alertServiceMock.error).toHaveBeenCalledWith(
        NAME_VALIDATION_UNAVAILABLE_KEY
      );
    });

    it('clears the valid flag when the re-check errors', () => {
      componentAccess.updateFormData('templateName', 'ran_activate_01');
      componentAccess.validateName();
      expect(componentAccess.isTemplateNameValid()).toBeTrue();

      ranTemplateServiceMock.validateTemplateName.and.returnValue(
        throwError(() => new HttpErrorResponse({ status: 500 }))
      );
      componentAccess.validateName();

      expect(componentAccess.isTemplateNameValid()).toBeFalse();
    });

    it('clears the valid flag when the template name is edited', () => {
      componentAccess.updateFormData('templateName', 'ran_activate_01');
      componentAccess.validateName();
      expect(componentAccess.isTemplateNameValid()).toBeTrue();

      componentAccess.updateFormData('templateName', 'ran_activate_02');

      expect(componentAccess.isTemplateNameValid()).toBeFalse();
    });

    it('keeps the valid flag when a field other than the name is edited', () => {
      componentAccess.updateFormData('templateName', 'ran_activate_01');
      componentAccess.validateName();

      componentAccess.updateFormData('description', 'changed');

      expect(componentAccess.isTemplateNameValid()).toBeTrue();
    });

    it('should prevent default and call validateName in add mode', () => {
      componentAccess.isEditMode.set(false);

      const event = jasmine.createSpyObj('Event', ['preventDefault']);
      spyOn(componentAccess, 'validateName');

      (componentAccess as any).validateNameOnCheck(event);

      componentAccess.validateNameOnCheck(event);

      expect(event.preventDefault).toHaveBeenCalled();
      expect(componentAccess.validateName).toHaveBeenCalled();
    });

    it('should not call validateName in edit mode', () => {
      componentAccess.isEditMode.set(true);

      const event = jasmine.createSpyObj('Event', ['preventDefault']);
      spyOn(componentAccess, 'validateName');

      componentAccess.validateNameOnCheck(event);

      expect(event.preventDefault).toHaveBeenCalled();
      expect(componentAccess.validateName).not.toHaveBeenCalled();
    });
  });

  describe('tree state', () => {
    beforeEach(() => configure('add'));

    it('should update selected node ids', () => {
      componentAccess.onTreeSelectionChange(['node-1']);

      expect(componentAccess.selectedNodeIds()).toEqual(['node-1']);
    });

    it('should insert the selected schema path into the active editor when the editor was last focused', () => {
      const branchTabs = fixture.debugElement.query(
        By.directive(BranchTabsStubComponent)
      ).componentInstance as BranchTabsStubComponent;
      spyOn(branchTabs, 'insertPath');
      (component as any).wasEditorLastFocused = true;

      componentAccess.onSchemaNodeInsert({
        id: 'schema/node/path',
        label: 'path',
        hasChildren: false,
        children: [],
        isExpanded: false,
        isLoading: false,
      } as TreeNode);

      expect(branchTabs.insertPath).toHaveBeenCalledOnceWith(
        'schema/node/path'
      );
    });

    it('should return original tree data when search query length is less than 3', () => {
      const treeData = [
        {
          id: '1',
          label: 'runtime',
          children: [],
        },
      ] as TreeNode[];

      componentAccess.treeData.set(treeData);

      (component as any).onSearchQueryChange('ru');

      expect((component as any).filteredTreeData()).toEqual(treeData);
    });

    it('should filter nodes matching the search query', () => {
      componentAccess.treeData.set([
        {
          id: '1',
          label: 'runtime',
          children: [],
        },
        {
          id: '2',
          label: 'planning',
          children: [],
        },
      ] as TreeNode[]);

      (component as any).onSearchQueryChange('run');

      const result = (component as any).filteredTreeData();

      expect(result.length).toBe(1);
      expect(result[0].label).toBe('runtime');
    });

    it('should keep parent node when a child matches the search query', () => {
      componentAccess.treeData.set([
        {
          id: '1',
          label: 'nodeData',
          children: [
            {
              id: '1-1',
              label: 'runtime',
              children: [],
            },
          ],
        },
      ] as TreeNode[]);

      (component as any).onSearchQueryChange('run');

      const result = (component as any).filteredTreeData();

      expect(result.length).toBe(1);
      expect(result[0].label).toBe('nodeData');
      expect(result[0].children?.length).toBe(1);
      expect(result[0].children?.[0].label).toBe('runtime');
    });

    it('should return empty array when no nodes match the search query', () => {
      componentAccess.treeData.set([
        {
          id: '1',
          label: 'runtime',
          children: [],
        },
      ] as TreeNode[]);

      (component as any).onSearchQueryChange('abc');

      expect((component as any).filteredTreeData()).toEqual([]);
    });

    it('should clear the search query', () => {
      (component as any).onSearchQueryChange('runtime');

      (component as any).clearSearch();

      expect((component as any).searchQuery()).toBe('');
    });
  });

  describe('select validation bindings', () => {
    beforeEach(() => configure('add'));

    it('should set invalid and errorMessage for required selects when validation is shown', () => {
      componentAccess.formData.set({
        templateName: 'template_a',
        vendor: '  ',
        release: '  ',
        version: '',
        model: '  ',
        description: 'description',
      });
      (component as any).showValidationError.set(true);
      fixture.detectChanges();
      const vendorSelect = fixture.debugElement.query(
        By.css('tnap-select.qa_vendor_select')
      ).componentInstance as TnapSelectStubComponent;
      const versionSelect = fixture.debugElement.query(
        By.css('tnap-select.qa_version_select')
      ).componentInstance as TnapSelectStubComponent;
      const modelSelect = fixture.debugElement.query(
        By.css('tnap-select.qa_model_select')
      ).componentInstance as TnapSelectStubComponent;

      expect(vendorSelect.invalid).toBeTrue();
      expect(versionSelect.invalid).toBeTrue();
      expect(modelSelect.invalid).toBeTrue();
      expect(vendorSelect.errorMessage).toBe('ranTemplate.edit.vendorRequired');
      expect(versionSelect.errorMessage).toBe(
        'ranTemplate.edit.releaseRequired'
      );
      expect(modelSelect.errorMessage).toBe('ranTemplate.edit.modelRequired');
    });

    it('should keep errorMessage undefined when value is present', () => {
      componentAccess.formData.set({
        templateName: 'template_a',
        vendor: 'Ericsson',
        release: '1.0',
        version: '1.0',
        model: 'model-a',
        description: 'description',
      });
      (component as any).showValidationError.set(true);
      fixture.detectChanges();

      const vendorSelect = fixture.debugElement.query(
        By.css('tnap-select.qa_vendor_select')
      ).componentInstance as TnapSelectStubComponent;
      const versionSelect = fixture.debugElement.query(
        By.css('tnap-select.qa_version_select')
      ).componentInstance as TnapSelectStubComponent;
      const modelSelect = fixture.debugElement.query(
        By.css('tnap-select.qa_model_select')
      ).componentInstance as TnapSelectStubComponent;

      expect(vendorSelect.invalid).toBeFalse();
      expect(versionSelect.invalid).toBeFalse();
      expect(modelSelect.invalid).toBeFalse();
      expect(vendorSelect.errorMessage).toBeUndefined();
      expect(versionSelect.errorMessage).toBeUndefined();
      expect(modelSelect.errorMessage).toBeUndefined();
    });
  });

  describe('template actions', () => {
    const successResponse = (
      status = RESPONSE_OK,
      draftName = 'draft_a'
    ): RanTemplateValidationSuccessResponse =>
      ({
        name: 'template.jinja',
        draftName,
        response: { status },
      }) as RanTemplateValidationSuccessResponse;

    const templateWithContent = (
      mainContent: string,
      draftContent: string
    ): RanTemplateModel => ({
      folderName: 'templates',
      name: 'template.jinja',
      fileNodeType: FileTreeNodeType.FILE,
      nodePath: 'templates/template.jinja',
      mainContent,
      draftContent,
      modifiedContent: draftContent,
    });

    beforeEach(() => configure('edit'));

    it('should detect draft deltas', () => {
      expect(
        componentAccess.hasDraftDelta([templateWithContent('main', 'draft')])
      ).toBeTrue();
      expect(
        componentAccess.hasDraftDelta([templateWithContent('same', 'same')])
      ).toBeFalse();
    });

    it('should save templates and reset changed state', () => {
      const pageData = createPageData();
      pageData$.next(pageData);

      componentAccess.ranTemplatesChanged.set(true);
      componentAccess.formData.set({
        templateName: 'template_a',
        vendor: 'Ericsson',
        release: '1.0',
        version: '1.0',
        model: 'model-a',
        description: 'description',
      });

      const saveResponse$ = new Subject<any[]>();
      ranTemplateServiceMock.saveRanTemplate.and.returnValue(
        saveResponse$.asObservable()
      );

      componentAccess.save();

      expect(componentAccess.isEditMode()).toBeTrue();

      expect(confirmationServiceMock.openConfirmationModal).toHaveBeenCalled();

      expect(ranTemplateServiceMock.saveRanTemplate).toHaveBeenCalled();
      expect(componentAccess.isActionLocked()).toBeTrue();

      saveResponse$.next([successResponse()]);
      saveResponse$.complete();

      expect(componentAccess.ranTemplatesSaved()).toBeTrue();

      expect(componentAccess.ranTemplatesChanged()).toBeFalse();
      expect(componentAccess.isActionLocked()).toBeFalse();
    });

    it('should not add onlyJinja metadata when editing a template without it', () => {
      componentAccess.formData.set({
        templateName: 'template_a',
        vendor: 'Ericsson',
        release: '1.0',
        version: '1.0',
        model: 'model-a',
        description: 'description',
      });

      componentAccess.save();

      const savedTemplates =
        ranTemplateServiceMock.saveRanTemplate.calls.mostRecent().args[0];
      expect(savedTemplates[0].modifiedContent).not.toContain('onlyJinja:');
    });

    it('should not save when confirmation is rejected', () => {
      confirmationServiceMock.openConfirmationModal.and.returnValue(of(false));

      componentAccess.save();

      expect(ranTemplateServiceMock.saveRanTemplate).not.toHaveBeenCalled();
    });

    it('should not bump version when save is cancelled', () => {
      confirmationServiceMock.openConfirmationModal.and.returnValue(of(false));

      componentAccess.save();

      expect(componentAccess.formData().version).toBe('1.0');
      expect(componentAccess.resourceVersion()).toBe('1.0');

      expect(ranTemplateServiceMock.saveRanTemplate).not.toHaveBeenCalled();
    });

    it('should save successfully without displaying validation errors', () => {
      ranTemplateServiceMock.saveRanTemplate.and.returnValue(
        of([successResponse(RESPONSE_OK, 'draft_a')])
      );

      componentAccess.save();

      expect(alertServiceMock.success).toHaveBeenCalledWith(
        'ranTemplate.message.success.save'
      );

      expect(alertServiceMock.error).not.toHaveBeenCalled();

      expect(componentAccess.ranTemplatesSaved()).toBeTrue();
      expect(componentAccess.ranTemplatesChanged()).toBeFalse();
    });

    it('should deploy valid templates and clear ref parameter', () => {
      const pageData = createPageData();

      ranTemplateServiceMock.saveRanTemplate.and.returnValue(
        of([successResponse()])
      );

      ranTemplateServiceMock.deployTemplates.and.returnValue(
        of({
          response: {
            status: RESPONSE_OK,
          },
        } as any)
      );

      componentAccess.deploy(pageData.templateFiles);

      expect(ranTemplateServiceMock.deployTemplates).toHaveBeenCalledWith(
        'draft_a'
      );
      expect(componentAccess.isActionLocked()).toBeFalse();

      expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
        ref: undefined,
      });
    });

    it('should deploy successfully when validation is skipped', () => {
      ranTemplateServiceMock.saveRanTemplate.and.returnValue(
        of([
          {
            name: 'template.jinja',
            draftName: 'draft_a',
            response: {
              status: RESPONSE_OK,
            },
          } as RanTemplateValidationSuccessResponse,
        ])
      );

      componentAccess.ranTemplatesChanged.set(true);
      componentAccess.ranTemplatesSaved.set(false);

      componentAccess.deploy(createPageData().templateFiles);

      expect(ranTemplateServiceMock.deployTemplates).toHaveBeenCalledWith(
        'draft_a'
      );

      expect(alertServiceMock.success).toHaveBeenCalledWith(
        'ranTemplate.message.success.deploy'
      );

      expect(alertServiceMock.error).not.toHaveBeenCalled();

      expect(componentAccess.ranTemplatesChanged()).toBeFalse();
      expect(componentAccess.ranTemplatesSaved()).toBeFalse();

      expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
        ref: undefined,
      });

      expect(componentAccess.isActionLocked()).toBeFalse();
    });

    it('should reset template files after confirmation', () => {
      const pageData = createPageData();
      pageData.templateFiles[0].modifiedContent = 'changed';

      componentAccess.reset(pageData);

      expect(
        ranTemplateServiceMock.updateRanTemplatePageData
      ).toHaveBeenCalled();
      const updatedData =
        ranTemplateServiceMock.updateRanTemplatePageData.calls.mostRecent()
          .args[0] as RanTemplateFilesPageDataModel;
      expect(updatedData.templateFiles[0].modifiedContent).toBe(
        pageData.templateFiles[0].draftContent!
      );
      expect(alertServiceMock.success).toHaveBeenCalledWith(
        'ranTemplate.message.success.reset'
      );
    });

    it('should close immediately when there are no unsaved changes', () => {
      componentAccess.ranTemplatesChanged.set(false);

      componentAccess.close(createPageData());

      expect(routerMock.navigate).toHaveBeenCalledWith([
        'ran-template/file-browser',
      ]);
    });

    it('should reset before close when there are unsaved changes', () => {
      const pageData = createPageData();
      pageData.templateFiles[0].modifiedContent = 'changed';
      componentAccess.ranTemplatesChanged.set(true);

      componentAccess.close(pageData);

      expect(
        ranTemplateServiceMock.updateRanTemplatePageData
      ).toHaveBeenCalled();
      const updatedData =
        ranTemplateServiceMock.updateRanTemplatePageData.calls.mostRecent()
          .args[0] as RanTemplateFilesPageDataModel;
      expect(updatedData.templateFiles[0].modifiedContent).toBe(
        pageData.templateFiles[0].draftContent!
      );
      expect(routerMock.navigate).toHaveBeenCalledWith([
        'ran-template/file-browser',
      ]);
    });

    it('should expose template and file error helpers', () => {
      const validation = [successResponse('ERROR')];

      expect(componentAccess.hasTemplateError(validation)).toBeTrue();
      expect(componentAccess.hasTemplateError(undefined)).toBeFalse();
    });

    it('should disable deploy button when there are no changes', () => {
      componentAccess.isEditMode.set(true);

      componentAccess.ranTemplatesSaved.set(false);
      componentAccess.ranTemplatesChanged.set(false);

      const pageData = createPageData();

      pageData.templateFiles[0].mainContent = 'same';
      pageData.templateFiles[0].draftContent = 'same';

      pageData$.next(pageData);

      fixture.detectChanges();
      const deployButton = fixture.debugElement.query(
        By.css('.qa_button_deploy')
      );

      const directive = deployButton.injector.get(TnapButtonStubDirective);

      expect(directive.disabled).toBeTrue();
    });
    it('should enable deploy button when template changes exist', () => {
      spyOn(componentAccess, 'hasDraftDelta').and.returnValue(true);

      componentAccess.ranTemplatesSaved.set(false);
      componentAccess.ranTemplatesChanged.set(false);

      fixture.detectChanges();

      const deployButton = fixture.nativeElement.querySelector(
        '.qa_button_deploy'
      ) as HTMLButtonElement;

      expect(deployButton.disabled).toBeFalse();
    });

    it('should update draftContent with modifiedContent after successful save', () => {
      const pageData = createPageData();

      pageData.templateFiles[0].modifiedContent = 'new-content';

      pageData$.next(pageData);

      ranTemplateServiceMock.saveRanTemplate.and.returnValue(
        of([successResponse()])
      );

      componentAccess.save();

      const updateCalls =
        ranTemplateServiceMock.updateRanTemplatePageData.calls.all();

      const savedPageData = updateCalls[updateCalls.length - 1]
        .args[0] as RanTemplateFilesPageDataModel;

      expect(savedPageData.templateFiles[0].draftContent).toBe('new-content');
    });
  });

  describe('bumpVersion', () => {
    beforeEach(() => configure('edit'));
    it('should bump minor version for save', () => {
      componentAccess.formData.set({
        ...componentAccess.formData(),
        version: '1.0',
      });

      (component as any).bumpVersion('save');

      expect(componentAccess.formData().version).toBe('1.1');
      expect(componentAccess.resourceVersion()).toBe('1.1');
    });

    it('should bump major version for deploy', () => {
      componentAccess.formData.set({
        ...componentAccess.formData(),
        version: '1.0',
      });

      (component as any).bumpVersion('deploy');

      expect(componentAccess.formData().version).toBe('2.0');
      expect(componentAccess.resourceVersion()).toBe('2.0');
    });
  });

  describe('save new template', () => {
    beforeEach(() => {
      configure('add');

      queryParamServiceMock.getValueOf.and.callFake(param => {
        switch (param) {
          case 'mode':
            return of('add');
          case 'ref':
            return of('draft-a');
          case 'templateSet':
            return of('templates');
          default:
            return of(null);
        }
      });

      componentAccess.formData.set({
        templateName: 'template_a',
        vendor: 'Ericsson',
        release: '1.0',
        version: '0.1',
        model: 'model-a',
        description: 'description',
        onlyJinja: 'true',
      });

      pageData$.next(createPageData());
    });

    it('should ask for confirmation before creating a new template', () => {
      componentAccess.save();

      expect(
        confirmationServiceMock.openConfirmationModal
      ).toHaveBeenCalledWith(
        'common.buttons.yes',
        'ranTemplate.modal.save.title',
        'ranTemplate.modal.save.text'
      );
      expect(
        ranTemplateServiceMock.createNewTemplateInDraft
      ).toHaveBeenCalled();
    });

    it('should update page data and query params after successful create', () => {
      componentAccess.save();

      expect(
        ranTemplateServiceMock.createNewTemplateInDraft
      ).toHaveBeenCalledWith(
        jasmine.objectContaining({
          fileName: 'template_a.jinja',
          folderPath: 'templates',
          content: jasmine.stringMatching(
            /version: 0\.1[\s\S]*onlyJinja: true/
          ),
        })
      );

      expect(
        ranTemplateServiceMock.updateRanTemplatePageData
      ).toHaveBeenCalledWith(
        jasmine.objectContaining({
          templateSetName: 'templates',
          templateFiles: [
            jasmine.objectContaining({
              name: 'template_a.jinja',
              folderName: 'templates',
              nodePath: 'templates/template_a.jinja',
              mainContent: 'content',
              draftContent: 'content',
              modifiedContent: 'content',
            }),
          ],
        })
      );

      expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith(
        {
          path: 'templates/template_a.jinja',
          ref: 'draft-version-1',
          mode: 'edit',
        },
        ['/ran-template/edit']
      );

      expect(componentAccess.ranTemplatesSaved()).toBeTrue();
      expect(componentAccess.ranTemplatesChanged()).toBeFalse();
      expect(componentAccess.isActionLocked()).toBeFalse();

      expect(alertServiceMock.success).toHaveBeenCalled();
    });

    it('should not create a new template when confirmation is rejected', () => {
      confirmationServiceMock.openConfirmationModal.and.returnValue(of(false));

      componentAccess.save();

      expect(
        ranTemplateServiceMock.createNewTemplateInDraft
      ).not.toHaveBeenCalled();
      expect(queryParamServiceMock.updateQueryParam).not.toHaveBeenCalled();
    });

    it('should show error when createNewTemplateInDraft fails', () => {
      ranTemplateServiceMock.createNewTemplateInDraft.and.returnValue(
        throwError(() => new Error('failed'))
      );

      componentAccess.save();

      expect(alertServiceMock.error).toHaveBeenCalledWith(
        'ranTemplate.message.error.save'
      );
    });

    it('should not create draft when page data contains no template files', () => {
      pageData$.next({
        templateSetName: 'templates',
        templateFiles: [],
      });

      componentAccess.save();

      expect(
        ranTemplateServiceMock.createNewTemplateInDraft
      ).not.toHaveBeenCalled();
    });
  });

  describe('deploy new template', () => {
    beforeEach(() => {
      configure('add');

      queryParamServiceMock.getValueOf.and.callFake(param => {
        switch (param) {
          case 'mode':
            return of('add');
          case 'ref':
            return of('draft-a');
          case 'templateSet':
            return of('templates');
          default:
            return of(null);
        }
      });

      componentAccess.formData.set({
        templateName: 'template_a',
        vendor: 'Ericsson',
        release: '1.0',
        version: '1.0',
        model: 'model-a',
        description: 'description',
      });
      (component as any).isTemplateNameValid.set(true);

      pageData$.next(createPageData());
    });

    it('deploys the created template without calling validation', () => {
      componentAccess.deploy(createPageData().templateFiles);

      expect(
        ranTemplateServiceMock.createNewTemplateInDraft
      ).toHaveBeenCalled();
      expect(ranTemplateServiceMock.saveRanTemplate).not.toHaveBeenCalled();
      expect(ranTemplateServiceMock.validateRanTemplate).not.toHaveBeenCalled();
      expect(ranTemplateServiceMock.deployTemplates).toHaveBeenCalledWith(
        'draft-version-1'
      );
      expect(alertServiceMock.success).toHaveBeenCalledWith(
        'ranTemplate.message.success.deploy'
      );
      expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
        ref: undefined,
      });
      expect(componentAccess.isActionLocked()).toBeFalse();
    });

    it('shows a deploy error when the deployment request fails', () => {
      ranTemplateServiceMock.deployTemplates.and.returnValue(
        throwError(() => new Error('deployment failed'))
      );

      componentAccess.deploy(createPageData().templateFiles);

      expect(ranTemplateServiceMock.validateRanTemplate).not.toHaveBeenCalled();
      expect(alertServiceMock.error).toHaveBeenCalledWith(
        'ranTemplate.message.error.deploy'
      );
      expect(alertServiceMock.success).not.toHaveBeenCalledWith(
        'ranTemplate.message.success.deploy'
      );
      expect(componentAccess.isActionLocked()).toBeFalse();
    });

    it('never deploys when creating the template fails', () => {
      ranTemplateServiceMock.createNewTemplateInDraft.and.returnValue(
        throwError(() => new Error('failed'))
      );

      componentAccess.deploy(createPageData().templateFiles);

      expect(ranTemplateServiceMock.deployTemplates).not.toHaveBeenCalled();
      expect(alertServiceMock.error).toHaveBeenCalledWith(
        'ranTemplate.message.error.deploy'
      );
      expect(componentAccess.isActionLocked()).toBeFalse();
    });

    it('does not create or deploy when confirmation is rejected', () => {
      confirmationServiceMock.openConfirmationModal.and.returnValue(of(false));

      componentAccess.deploy(createPageData().templateFiles);

      expect(
        ranTemplateServiceMock.createNewTemplateInDraft
      ).not.toHaveBeenCalled();
      expect(ranTemplateServiceMock.deployTemplates).not.toHaveBeenCalled();
    });
  });

  describe('buildAddModeSaveContext', () => {
    beforeEach(() => configure('add'));

    it('should build add mode save context', () => {
      componentAccess.formData.set({
        templateName: 'template_a',
        vendor: 'Ericsson',
        release: '1.0',
        version: '1.0',
        model: 'model-a',
        description: 'description',
      });

      const result = (component as any).buildAddModeSaveContext(
        'templates',
        createPageData()
      );

      expect(result).toEqual(
        jasmine.objectContaining({
          fileName: 'template_a.jinja',
          folderPath: 'templates',
          content: jasmine.any(String),
        })
      );
    });

    it('should build add mode save context without draft id', () => {
      componentAccess.formData.set({
        templateName: 'template_a',
        vendor: 'Ericsson',
        release: '1.0',
        version: '1.0',
        model: 'model-a',
        description: 'description',
      });

      const result = (component as any).buildAddModeSaveContext(
        'templates',
        createPageData()
      );

      expect(result).toEqual(
        jasmine.objectContaining({
          fileName: 'template_a.jinja',
          folderPath: 'templates',
          content: jasmine.any(String),
        })
      );
    });

    it('should return null when template file is not available', () => {
      const pageData: RanTemplateFilesPageDataModel = {
        templateSetName: 'templates',
        templateFiles: [],
      };

      const result = (component as any).buildAddModeSaveContext(
        'templates',
        pageData
      );

      expect(result).toBeNull();
    });
  });
});

/* A pure bundle check, so it needs no TestBed and sits outside the component describe -
 * the keys below belong to several unrelated flows and filing it under any one of them
 * would misplace the other five.
 *
 * `jasmine.any(String)` rather than `toBeTruthy()`: nesting a sub-tree under one of these
 * keys makes it resolve to a group object, which is truthy, and `instant()` would then
 * hand the alert an object that renders as `[object Object]`. Dropping a key from one
 * language shipped a raw key into an alert once already (TNAP-32475). */
describe('alert translation keys asserted by the edit spec', () => {
  ASSERTED_ALERT_KEYS.forEach(key => {
    it(`has ${key} translated to a string in both languages`, () => {
      expect(translationAt(en, key)).toEqual(jasmine.any(String));
      expect(translationAt(de, key)).toEqual(jasmine.any(String));
    });
  });
});
