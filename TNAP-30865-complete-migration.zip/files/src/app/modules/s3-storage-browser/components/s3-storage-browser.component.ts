/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Component,
  OnInit,
  signal,
  computed,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  inject,
  DestroyRef,
} from '@angular/core';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

import {
  ColumnDefinition,
  TableConfigService,
} from '@portal-mfe/tnap-ui-kit/components/data-table';
import { Sort, SortDirection } from '@portal-mfe/tnap-ui-kit/components/sort';

import { TranslateService } from '@ngx-translate/core';

import { S3StorageService } from '../../../../../openapi/output/api/s3Storage.service';
import { BucketObjectInfo } from '../../../../../openapi/output/model/bucketObjectInfo.model';

import { BucketObjectsList } from '../../../../../openapi/output/model/bucketObjectsList.model';

import { BucketObjectCountsList } from '../../../../../openapi/output/model/bucketObjectCountsList.model';
import { FileSaverService } from 'ngx-filesaver';
import { PaginationService } from 'src/app/services/common-functionalities/pagination.service';
import { environment } from '../../../../environments/environment';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

type S3SortBy = 'key' | 'lastModifiedAt';
type S3SortDirection = 'ASC' | 'DESC';

const DEFAULT_SORT: Sort = { parameter: '', direction: SortDirection.NONE };

interface Bucket {
  id: string;
  label: string;
  count: number;
  truncated: boolean;
  tooltipKey: string;
}

const BUCKET_DISPLAY_LABELS: Record<string, string> = {
  planning: 's3Storage.buckets.planning',
  network: 's3Storage.buckets.network',
  filter: 's3Storage.buckets.filter',
  payload: 's3Storage.buckets.payload',
  day0: 's3Storage.buckets.day0',
};

function toDisplayLabel(bucketName: string): string {
  return BUCKET_DISPLAY_LABELS[bucketName] ?? bucketName;
}

const BUCKET_ORDER: string[] = ['planning', 'payload', 'network', 'filter'];

function sortBucketsByCanonicalOrder(buckets: Bucket[]): Bucket[] {
  return [...buckets].sort((a, b) => {
    const rankA = BUCKET_ORDER.indexOf(a.id);
    const rankB = BUCKET_ORDER.indexOf(b.id);
    const orderA = rankA === -1 ? BUCKET_ORDER.length : rankA;
    const orderB = rankB === -1 ? BUCKET_ORDER.length : rankB;
    return orderA - orderB;
  });
}

interface S3FilesState {
  loading: boolean;
  data:
    | {
        items: BucketObjectInfo[];
        totalCount: number;
        truncated: boolean;
        nextContinuationToken?: string;
      }
    | undefined;
}

const INITIAL_S3_FILES_STATE: S3FilesState = {
  loading: true,
  data: undefined,
};

@Component({
  selector: 'app-s3-storage-browser',
  standalone: false,
  templateUrl: './s3-storage-browser.component.html',
  styleUrls: ['./s3-storage-browser.component.css'],
  providers: [TableConfigService],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class S3StorageBrowserComponent implements OnInit {
  private readonly destroyRef$ = inject(DestroyRef);
  private readonly search$ = new Subject<string>();
  private readonly translateService = inject(TranslateService);
  private readonly fileSaverService = inject(FileSaverService);
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly lang = toSignal(this.translateService.onLangChange);

  private readonly paginationService = inject(PaginationService);
  private readonly alertService = inject(TnapAlertService);

  constructor(private readonly s3StorageService: S3StorageService) {}

  readonly buckets = signal<Bucket[]>([]);

  readonly selectedBucketId = signal<string>('');
  readonly searchQuery = signal<string>('');

  readonly currentSort = signal<Sort>(DEFAULT_SORT);

  readonly filesState = signal<S3FilesState>(INITIAL_S3_FILES_STATE);

  readonly selectedBucket = computed<Bucket | undefined>(() => {
    const id = this.selectedBucketId();
    return this.buckets().find(b => b.id === id);
  });

  readonly selectedBucketLabel = computed<string>(() => {
    this.lang();
    const bucket = this.selectedBucket();
    return bucket ? this.translateService.instant(bucket.label) : '';
  });

  readonly bucketTooltips = computed<Record<string, string | null>>(() => {
    this.lang();
    return Object.fromEntries(
      this.buckets().map(bucket => [
        bucket.id,
        this.resolveTooltip(bucket.tooltipKey),
      ])
    );
  });

  readonly dateTimeFormat = environment.dateTimeFormat;
  readonly DEFAULT_PAGE = 1;
  readonly DEFAULT_PAGE_SIZE = 100;
  readonly page$ = this.paginationService.page$;
  readonly pageSize$ = this.paginationService.pageSize$;

  private readonly page = toSignal(this.page$, {
    initialValue: this.DEFAULT_PAGE,
  });
  private readonly pageSize = toSignal(this.pageSize$, {
    initialValue: this.DEFAULT_PAGE_SIZE,
  });

  private readonly FETCH_CHUNK_SIZE = 1000;

  readonly pagedFilesState = computed<S3FilesState>(() => {
    const state = this.filesState();
    if (!state.data) {
      return state;
    }

    const page = this.page();
    const pageSize = this.pageSize();
    const start = (page - 1) * pageSize;

    return {
      ...state,
      data: {
        ...state.data,
        items: state.data.items.slice(start, start + pageSize),
        totalCount: state.data.items.length,
      },
    };
  });

  readonly tableData = computed<S3FilesState['data']>(() => {
    const data = this.pagedFilesState().data;
    if (!data) {
      return data;
    }

    const pageSize = this.pageSize();

    return {
      ...data,
      totalCount: data.truncated ? data.totalCount + pageSize : data.totalCount,
    };
  });

  readonly columns = computed<ColumnDefinition<BucketObjectInfo>[]>(() => {
    this.lang();
    return [
      {
        key: 'key',
        label: this.translateService.instant('s3Storage.list.fields.key'),
        value: row => row.key ?? '',
        sorting: { enabled: true },
      },
      {
        key: 'size',
        label: this.translateService.instant('s3Storage.list.fields.size'),
        value: row => this.formatSize(row.size ?? 0),
      },
      {
        key: 'acl',
        label: this.translateService.instant('s3Storage.list.fields.acl'),
        value: row => row.acl ?? '',
      },
      {
        key: 'lastModifiedAt',
        label: this.translateService.instant(
          's3Storage.list.fields.lastModifiedAt'
        ),
        value: row => row.lastModifiedAt ?? '',
        sorting: { enabled: true },
      },
      {
        key: 'actions',
        label: this.translateService.instant('s3Storage.list.fields.actions'),
        value: () => '',
      },
    ];
  });

  ngOnInit(): void {
    this.searchQuery.set('');
    this.filesState.set(INITIAL_S3_FILES_STATE);
    this.currentSort.set(DEFAULT_SORT);

    this.search$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeUntilDestroyed(this.destroyRef$)
      )
      .subscribe(searchValue => {
        this.searchQuery.set(searchValue);
        this.resetToFirstPage();
        this.loadBucketData();
      });

    this.loadBuckets();
  }

  private loadBuckets(): void {
    this.s3StorageService
      .getBucketObjectCounts()
      .pipe(takeUntilDestroyed(this.destroyRef$))
      .subscribe({
        next: (response: BucketObjectCountsList) => {
          const buckets = sortBucketsByCanonicalOrder(
            (response.bucketObjectCounts ?? [])
              .filter(c => !!c.bucket)
              .map(c => ({
                id: c.bucket as string,
                label: toDisplayLabel(c.bucket as string),
                count: c.count ?? 0,
                truncated: c.truncated ?? false,
                tooltipKey: `s3Storage.buckets.tooltips.${c.bucket}`,
              }))
          );

          this.buckets.set(buckets);

          if (!this.selectedBucketId() && buckets.length > 0) {
            this.selectedBucketId.set(buckets[0].id);
            this.loadBucketData();
          }
        },
        error: () => {
          this.alertService.error(
            this.translateService.instant('s3Storage.errors.loadFailed'),
            { keepAfterRouteChange: true }
          );
          this.cdr.markForCheck();
        },
      });
  }

  private mapObjects(response: BucketObjectsList): BucketObjectInfo[] {
    return (response.objects ?? []).map(o => ({
      bucket: o.bucket,
      key: o.key,
      size: o.size,
      acl: o.acl,
      lastModifiedAt: o.lastModifiedAt,
    }));
  }

  private loadBucketData(): void {
    const bucketId = this.selectedBucketId();

    if (!bucketId) {
      this.filesState.set({
        loading: false,
        data: { items: [], totalCount: 0, truncated: false },
      });
      this.cdr.markForCheck();
      return;
    }

    this.filesState.update(state => ({ ...state, loading: true }));

    const keyFilter = this.searchQuery().trim() || undefined;
    const { sortBy, sortDirection } = this.buildSortParams();
    this.s3StorageService
      .getObjectsByBucket(
        bucketId,
        this.FETCH_CHUNK_SIZE,
        undefined,
        keyFilter,
        sortBy,
        sortDirection
      )
      .pipe(takeUntilDestroyed(this.destroyRef$))
      .subscribe({
        next: (response: BucketObjectsList) => {
          const items = this.mapObjects(response);

          this.filesState.set({
            loading: false,
            data: {
              items,
              totalCount: items.length,
              truncated: !!response.nextContinuationToken,
              nextContinuationToken:
                response.nextContinuationToken ?? undefined,
            },
          });

          this.cdr.markForCheck();
        },
        error: () => {
          this.filesState.update(state => ({ ...state, loading: false }));
          this.alertService.error(
            this.translateService.instant('s3Storage.errors.loadFailed'),
            { keepAfterRouteChange: true }
          );
          this.cdr.markForCheck();
        },
      });
  }

  private fetchNextChunkThenChangePage(
    page: number,
    continuationToken: string
  ): void {
    const bucketId = this.selectedBucketId();

    if (!bucketId) {
      return;
    }

    this.filesState.update(state => ({ ...state, loading: true }));

    const keyFilter = this.searchQuery().trim() || undefined;
    const { sortBy, sortDirection } = this.buildSortParams();

    this.s3StorageService
      .getObjectsByBucket(
        bucketId,
        this.FETCH_CHUNK_SIZE,
        continuationToken,
        keyFilter,
        sortBy,
        sortDirection
      )
      .pipe(takeUntilDestroyed(this.destroyRef$))
      .subscribe({
        next: (response: BucketObjectsList) => {
          const newItems = this.mapObjects(response);

          this.filesState.update(state => {
            const items = [...(state.data?.items ?? []), ...newItems];
            return {
              loading: false,
              data: {
                items,
                totalCount: items.length,
                truncated: !!response.nextContinuationToken,
                nextContinuationToken:
                  response.nextContinuationToken ?? undefined,
              },
            };
          });

          this.paginationService.changePage(page);
          this.cdr.markForCheck();
        },
        error: () => {
          this.filesState.update(state => ({ ...state, loading: false }));
          this.alertService.error(
            this.translateService.instant('s3Storage.errors.loadFailed'),
            { keepAfterRouteChange: true }
          );
          this.cdr.markForCheck();
        },
      });
  }

  private resetToFirstPage(): void {
    this.paginationService.changePage(this.DEFAULT_PAGE);
  }

  selectBucket(bucketId: string): void {
    if (this.selectedBucketId() === bucketId) return;

    this.selectedBucketId.set(bucketId);
    this.searchQuery.set('');
    this.filesState.set(INITIAL_S3_FILES_STATE);
    this.currentSort.set(DEFAULT_SORT);

    this.resetToFirstPage();
    this.loadBucketData();
  }

  onSearchChange(searchValue: string): void {
    this.search$.next(searchValue);
  }

  onSortChange(sort: Sort): void {
    this.currentSort.set(sort);
    this.resetToFirstPage();
    this.loadBucketData();
  }

  private resolveTooltip(key: string): string | null {
    const text: string = this.translateService.instant(key);
    return text && text !== key ? text : null;
  }

  private buildSortParams(): {
    sortBy: S3SortBy | undefined;
    sortDirection: S3SortDirection | undefined;
  } {
    const { parameter, direction } = this.currentSort();

    if (
      direction === SortDirection.NONE ||
      (parameter !== 'key' && parameter !== 'lastModifiedAt')
    ) {
      return { sortBy: undefined, sortDirection: undefined };
    }

    return {
      sortBy: parameter,
      sortDirection: direction === SortDirection.ASC ? 'ASC' : 'DESC',
    };
  }

  public onChangePage(page: number): void {
    const state = this.filesState();

    if (state.loading) {
      return;
    }

    const pageSize = this.pageSize();
    const loadedCount = state.data?.items.length ?? 0;
    const continuationToken = state.data?.nextContinuationToken;

    if (page * pageSize > loadedCount && continuationToken) {
      this.fetchNextChunkThenChangePage(page, continuationToken);
      return;
    }

    this.paginationService.changePage(page);
  }

  public onChangePageSize(pageSize: number): void {
    this.paginationService.changePageSize(pageSize);
  }

  onDownload(file: BucketObjectInfo): void {
    const bucketId = this.selectedBucketId();

    if (!bucketId || !file.key) {
      return;
    }

    this.s3StorageService
      .downloadS3Object(bucketId, file.key)
      .pipe(takeUntilDestroyed(this.destroyRef$))
      .subscribe({
        next: (blob: Blob) => {
          const fileName = file.key;
          this.fileSaverService.save(blob, fileName);
        },
        error: () => {
          this.alertService.error(
            this.translateService.instant('s3Storage.errors.downloadFailed'),
            { keepAfterRouteChange: true }
          );
        },
      });
  }

  formatSize(bytes: number): string {
    if (bytes >= 1_073_741_824)
      return (bytes / 1_073_741_824).toFixed(2) + ' GB';
    if (bytes >= 1_048_576) return (bytes / 1_048_576).toFixed(2) + ' MB';
    if (bytes >= 1_024) return (bytes / 1_024).toFixed(2) + ' KB';
    return bytes + ' B';
  }
}
