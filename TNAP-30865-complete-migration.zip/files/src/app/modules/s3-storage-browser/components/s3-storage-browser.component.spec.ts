/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ComponentFixture,
  TestBed,
  fakeAsync,
  tick,
} from '@angular/core/testing';
import { Pipe, PipeTransform } from '@angular/core';
import { of, throwError } from 'rxjs';

import { S3StorageBrowserComponent } from './s3-storage-browser.component';

import { Component, EventEmitter, Input, Output } from '@angular/core';
import { By } from '@angular/platform-browser';

import { S3StorageService } from '../../../../../openapi/output/api/s3Storage.service';
import { PaginationService } from 'src/app/services/common-functionalities/pagination.service';
import { TranslateService } from '@ngx-translate/core';
import { FileSaverService } from 'ngx-filesaver';
import { TableConfigService } from '@portal-mfe/tnap-ui-kit/components/data-table';
import { SortDirection } from '@portal-mfe/tnap-ui-kit/components/sort';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Pipe({
  name: 'translate',
  standalone: false,
})
class MockTranslatePipe implements PipeTransform {
  transform(value: string): string {
    return value;
  }
}

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector -- mocks the real tnap-data-table selector used in the template under test
  selector: 'tnap-data-table',
  template: '',
  standalone: false,
})
class MockDataTableComponent {
  @Input() columns: any;
  @Input() data: any;
  @Input() isLoading: any;
  @Input() showPagination: any;
  @Input() showColumnConfig: any;
}

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'tnap-input-search',
  template: '',
  standalone: false,
})
class MockInputSearchComponent {
  @Input() value?: string;

  @Output() filterChange = new EventEmitter<string>();
  @Output() resetFilter = new EventEmitter<void>();
}

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'tnap-badge',
  template: '',
  standalone: false,
})
class MockBadgeComponent {
  @Input() type?: string;
  @Input() label?: string;
  @Input() mode?: string;
  @Input() pill?: boolean;
}
describe('S3StorageBrowserComponent', () => {
  let component: S3StorageBrowserComponent;
  let fixture: ComponentFixture<S3StorageBrowserComponent>;

  let s3StorageService: jasmine.SpyObj<S3StorageService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let paginationService: jasmine.SpyObj<PaginationService>;
  let translateService: jasmine.SpyObj<TranslateService>;
  let fileSaverService: jasmine.SpyObj<FileSaverService>;

  beforeEach(async () => {
    s3StorageService = jasmine.createSpyObj('S3StorageService', [
      'getObjectsByBucket',
      'getBucketObjectCounts',
      'downloadS3Object',
    ]);

    alertService = jasmine.createSpyObj('TnapAlertService', [
      'error',
      'success',
    ]);

    paginationService = jasmine.createSpyObj(
      'PaginationService',
      ['changePage', 'changePageSize'],
      {
        page$: of(1),
        pageSize$: of(100),
      }
    );

    translateService = jasmine.createSpyObj('TranslateService', ['instant'], {
      onLangChange: of({ lang: 'en' }),
    });

    translateService.instant.and.callFake((key: string) => key);

    fileSaverService = jasmine.createSpyObj('FileSaverService', ['save']);

    (s3StorageService.getBucketObjectCounts as any).and.returnValue(
      of({
        bucketObjectCounts: [
          { bucket: 'planning', count: 5, truncated: false },
        ],
      })
    );

    s3StorageService.getObjectsByBucket.and.returnValue(
      of({
        objects: [],
        nextContinuationToken: undefined,
      } as any)
    );

    await TestBed.configureTestingModule({
      declarations: [
        S3StorageBrowserComponent,
        MockTranslatePipe,
        MockDataTableComponent,
        MockInputSearchComponent,
        MockBadgeComponent,
      ],
      providers: [
        {
          provide: S3StorageService,
          useValue: s3StorageService,
        },
        {
          provide: TnapAlertService,
          useValue: alertService,
        },
        {
          provide: PaginationService,
          useValue: paginationService,
        },
        {
          provide: TranslateService,
          useValue: translateService,
        },
        {
          provide: FileSaverService,
          useValue: fileSaverService,
        },
        TableConfigService,
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(S3StorageBrowserComponent);

    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load buckets on init', () => {
    expect(s3StorageService.getBucketObjectCounts).toHaveBeenCalled();
  });

  it('should load bucket data on init', () => {
    expect(s3StorageService.getObjectsByBucket).toHaveBeenCalled();
  });

  it('should format bytes', () => {
    expect(component.formatSize(100)).toBe('100 B');
  });

  it('should format KB', () => {
    expect(component.formatSize(1024)).toBe('1.00 KB');
  });

  it('should format MB', () => {
    expect(component.formatSize(1048576)).toBe('1.00 MB');
  });

  it('should format GB', () => {
    expect(component.formatSize(1073741824)).toBe('1.00 GB');
  });

  it('should not throw when searching', () => {
    expect(() => component.onSearchChange('abc')).not.toThrow();
  });

  it('should update search query', fakeAsync(() => {
    component.onSearchChange('abc');

    tick(301);

    expect(component.searchQuery()).toBe('abc');
  }));

  it('should change page', () => {
    component.onChangePage(2);

    expect(paginationService.changePage).toHaveBeenCalledWith(2);
  });

  it('should fetch the next chunk via continuation token when the requested page needs data beyond what is loaded', () => {
    const firstChunk = Array.from({ length: 1000 }, (_, i) => ({
      key: `file-${i}.txt`,
    }));
    s3StorageService.getObjectsByBucket.and.returnValue(
      of({
        objects: firstChunk,
        nextContinuationToken: 'token-1',
      } as any)
    );
    (component as any).loadBucketData();
    expect(component.filesState().data?.items.length).toBe(1000);
    expect(component.filesState().data?.truncated).toBeTrue();

    const secondChunk = Array.from({ length: 500 }, (_, i) => ({
      key: `file-${1000 + i}.txt`,
    }));
    s3StorageService.getObjectsByBucket.calls.reset();
    s3StorageService.getObjectsByBucket.and.returnValue(
      of({
        objects: secondChunk,
        nextContinuationToken: undefined,
      } as any)
    );
    component.onChangePage(11);

    expect(s3StorageService.getObjectsByBucket).toHaveBeenCalledWith(
      'planning',
      jasmine.any(Number),
      'token-1',
      undefined,
      undefined,
      undefined
    );
    expect(component.filesState().data?.items.length).toBe(1500);
    expect(component.filesState().data?.truncated).toBeFalse();
    expect(component.filesState().data?.nextContinuationToken).toBeUndefined();
    expect(paginationService.changePage).toHaveBeenCalledWith(11);
  });

  it('should not fetch more when the requested page is already covered by loaded items', () => {
    s3StorageService.getObjectsByBucket.and.returnValue(
      of({
        objects: Array.from({ length: 1000 }, (_, i) => ({ key: `f${i}` })),
        nextContinuationToken: 'token-1',
      } as any)
    );
    (component as any).loadBucketData();
    s3StorageService.getObjectsByBucket.calls.reset();
    component.onChangePage(5);

    expect(s3StorageService.getObjectsByBucket).not.toHaveBeenCalled();
    expect(paginationService.changePage).toHaveBeenCalledWith(5);
  });

  it('should not attempt to fetch more when there is no continuation token left', () => {
    s3StorageService.getObjectsByBucket.and.returnValue(
      of({
        objects: Array.from({ length: 200 }, (_, i) => ({ key: `f${i}` })),
        nextContinuationToken: undefined,
      } as any)
    );
    (component as any).loadBucketData();
    s3StorageService.getObjectsByBucket.calls.reset();
    component.onChangePage(50);

    expect(s3StorageService.getObjectsByBucket).not.toHaveBeenCalled();
    expect(paginationService.changePage).toHaveBeenCalledWith(50);
  });

  it('should ignore page change requests while a fetch is already in progress', () => {
    s3StorageService.getObjectsByBucket.calls.reset();
    paginationService.changePage.calls.reset();
    component.filesState.update(state => ({ ...state, loading: true }));

    component.onChangePage(3);

    expect(s3StorageService.getObjectsByBucket).not.toHaveBeenCalled();
    expect(paginationService.changePage).not.toHaveBeenCalled();
  });

  describe('tableData (padded totalCount for tnap-data-table)', () => {
    it('should pad totalCount by one pageSize while truncated, without affecting pagedFilesState', () => {
      s3StorageService.getObjectsByBucket.and.returnValue(
        of({
          objects: Array.from({ length: 1000 }, (_, i) => ({ key: `f${i}` })),
          nextContinuationToken: 'token-1',
        } as any)
      );

      (component as any).loadBucketData();
      expect(component.tableData()?.totalCount).toBe(1100);
      expect(component.pagedFilesState().data?.totalCount).toBe(1000);
    });

    it('should leave totalCount unpadded once the bucket is fully loaded', () => {
      s3StorageService.getObjectsByBucket.and.returnValue(
        of({
          objects: Array.from({ length: 200 }, (_, i) => ({ key: `f${i}` })),
          nextContinuationToken: undefined,
        } as any)
      );

      (component as any).loadBucketData();

      expect(component.tableData()?.totalCount).toBe(200);
      expect(component.pagedFilesState().data?.totalCount).toBe(200);
    });

    it('should keep padding by one pageSize as more chunks are fetched, until the final chunk arrives', () => {
      s3StorageService.getObjectsByBucket.and.returnValue(
        of({
          objects: Array.from({ length: 1000 }, (_, i) => ({ key: `f${i}` })),
          nextContinuationToken: 'token-1',
        } as any)
      );
      (component as any).loadBucketData();
      expect(component.tableData()?.totalCount).toBe(1100);

      s3StorageService.getObjectsByBucket.and.returnValue(
        of({
          objects: Array.from({ length: 500 }, (_, i) => ({ key: `g${i}` })),
          nextContinuationToken: undefined,
        } as any)
      );
      component.onChangePage(11);

      expect(component.tableData()?.totalCount).toBe(1500);
    });
  });

  describe('sorting', () => {
    it('should reload from the first page with the new sort when a header is clicked', () => {
      spyOn<any>(component, 'loadBucketData');

      component.onSortChange({
        parameter: 'key',
        direction: SortDirection.ASC,
      });

      expect(component.currentSort()).toEqual({
        parameter: 'key',
        direction: SortDirection.ASC,
      });
      expect(paginationService.changePage).toHaveBeenCalledWith(1);
      expect((component as any).loadBucketData).toHaveBeenCalled();
    });

    it('should request ascending sort by key', () => {
      s3StorageService.getObjectsByBucket.calls.reset();

      component.onSortChange({
        parameter: 'key',
        direction: SortDirection.ASC,
      });

      expect(s3StorageService.getObjectsByBucket).toHaveBeenCalledWith(
        'planning',
        jasmine.any(Number),
        undefined,
        undefined,
        'key',
        'ASC'
      );
    });

    it('should request descending sort by lastModifiedAt', () => {
      s3StorageService.getObjectsByBucket.calls.reset();

      component.onSortChange({
        parameter: 'lastModifiedAt',
        direction: SortDirection.DESC,
      });

      expect(s3StorageService.getObjectsByBucket).toHaveBeenCalledWith(
        'planning',
        jasmine.any(Number),
        undefined,
        undefined,
        'lastModifiedAt',
        'DESC'
      );
    });

    it('should send no sort params when the sort is cleared', () => {
      s3StorageService.getObjectsByBucket.calls.reset();

      component.onSortChange({
        parameter: 'key',
        direction: SortDirection.NONE,
      });

      expect(s3StorageService.getObjectsByBucket).toHaveBeenCalledWith(
        'planning',
        jasmine.any(Number),
        undefined,
        undefined,
        undefined,
        undefined
      );
    });

    it('should ignore sort parameters the API does not support', () => {
      s3StorageService.getObjectsByBucket.calls.reset();

      component.onSortChange({
        parameter: 'size',
        direction: SortDirection.ASC,
      });

      expect(s3StorageService.getObjectsByBucket).toHaveBeenCalledWith(
        'planning',
        jasmine.any(Number),
        undefined,
        undefined,
        undefined,
        undefined
      );
    });

    it('should keep the active sort when fetching the next chunk', () => {
      s3StorageService.getObjectsByBucket.and.returnValue(
        of({
          objects: Array.from({ length: 1000 }, (_, i) => ({ key: `f${i}` })),
          nextContinuationToken: 'token-1',
        } as any)
      );
      component.onSortChange({
        parameter: 'lastModifiedAt',
        direction: SortDirection.DESC,
      });
      s3StorageService.getObjectsByBucket.calls.reset();

      component.onChangePage(11);

      expect(s3StorageService.getObjectsByBucket).toHaveBeenCalledWith(
        'planning',
        jasmine.any(Number),
        'token-1',
        undefined,
        'lastModifiedAt',
        'DESC'
      );
    });

    it('should reset the sort when switching buckets', () => {
      component.onSortChange({
        parameter: 'key',
        direction: SortDirection.DESC,
      });

      component.selectBucket('network');

      expect(component.currentSort()).toEqual({
        parameter: '',
        direction: SortDirection.NONE,
      });
    });
  });

  it('should change page size', () => {
    component.onChangePageSize(50);

    expect(paginationService.changePageSize).toHaveBeenCalledWith(50);
  });

  it('should select bucket', () => {
    component.selectBucket('network');

    expect(component.selectedBucketId()).toBe('network');
  });

  it('should handle invalid bucket id', () => {
    component.selectedBucketId.set('invalid-bucket');

    (component as any).loadBucketData();

    expect(component.filesState().loading).toBeFalse();
    expect(component.filesState().data?.totalCount).toBe(0);
  });

  it('should reload data when bucket changes', () => {
    spyOn<any>(component, 'loadBucketData');

    component.selectBucket('network');

    expect(component.selectedBucketId()).toBe('network');

    expect((component as any).loadBucketData).toHaveBeenCalled();
  });

  it('should slice fetched items into the current page', () => {
    const items = Array.from({ length: 150 }, (_, i) => ({
      bucket: 'planning',
      key: `file-${i}.txt`,
      size: 1,
      acl: 'private',
      lastModifiedAt: '2026-01-01',
    }));

    s3StorageService.getObjectsByBucket.and.returnValue(
      of({ objects: items, nextContinuationToken: undefined } as any)
    );

    (component as any).loadBucketData();
    const paged = component.pagedFilesState();
    expect(paged.data?.items.length).toBe(100);
    expect(paged.data?.totalCount).toBe(150);
  });

  it('should show error when download fails', () => {
    s3StorageService.downloadS3Object.and.returnValue(
      throwError(() => new Error('download failed'))
    );

    component.onDownload({
      key: 'file.txt',
      bucket: 'planning',
    } as any);

    expect(alertService.error).toHaveBeenCalledWith(
      's3Storage.errors.downloadFailed',
      { keepAfterRouteChange: true }
    );
  });

  it('should not download when key is missing', () => {
    component.onDownload({
      bucket: 'planning',
    } as any);

    expect(s3StorageService.downloadS3Object).not.toHaveBeenCalled();
  });

  it('should return when file key missing', () => {
    component.onDownload({} as any);

    expect(s3StorageService.downloadS3Object).not.toHaveBeenCalled();
  });

  it('should show alert when download fails', () => {
    s3StorageService.downloadS3Object.and.returnValue(
      throwError(() => new Error())
    );

    component.onDownload({
      key: 'sample.txt',
    } as any);

    expect(alertService.error).toHaveBeenCalledWith(
      's3Storage.errors.downloadFailed',
      { keepAfterRouteChange: true }
    );
  });

  it('should update buckets on load', () => {
    s3StorageService.getBucketObjectCounts.and.returnValue(
      of({
        bucketObjectCounts: [
          { bucket: 'planning', count: 10, truncated: false },
        ],
      } as any)
    );

    component.ngOnInit();

    expect(component.buckets().length).toBeGreaterThan(0);
  });

  it('should flag a bucket as truncated when the counts response says so', () => {
    s3StorageService.getBucketObjectCounts.and.returnValue(
      of({
        bucketObjectCounts: [
          { bucket: 'planning', count: 1000, truncated: true },
        ],
      } as any)
    );

    component.ngOnInit();

    const planningBucket = component.buckets().find(b => b.id === 'planning');
    expect(planningBucket?.truncated).toBeTrue();
  });

  it('should flag file list data as truncated when a continuation token is returned', () => {
    s3StorageService.getObjectsByBucket.and.returnValue(
      of({
        objects: [{ key: 'a' }, { key: 'b' }],
        nextContinuationToken: 'token-1',
      } as any)
    );
    component.selectBucket('filter');

    expect(component.filesState().data?.truncated).toBeTrue();
  });

  it('should not fetch further pages via continuation tokens', () => {
    s3StorageService.getObjectsByBucket.calls.reset();
    s3StorageService.getObjectsByBucket.and.returnValue(
      of({
        objects: [{ key: 'a' }],
        nextContinuationToken: 'token-1',
      } as any)
    );

    component.selectBucket('filter');

    expect(s3StorageService.getObjectsByBucket).toHaveBeenCalledTimes(1);
  });

  it('should handle getBuckets error', () => {
    s3StorageService.getBucketObjectCounts.and.returnValue(
      throwError(() => new Error())
    );

    expect(() => component.ngOnInit()).not.toThrow();
  });

  it('should auto-select the first bucket returned and load its data', () => {
    component.selectedBucketId.set('');

    s3StorageService.getBucketObjectCounts.and.returnValue(
      of({
        bucketObjectCounts: [
          { bucket: 'planning', count: 3, truncated: false },
          { bucket: 'filter', count: 1, truncated: false },
        ],
      } as any)
    );

    component.ngOnInit();

    expect(component.selectedBucketId()).toBe('planning');
    expect(s3StorageService.getObjectsByBucket).toHaveBeenCalledWith(
      'planning',
      jasmine.any(Number),
      undefined,
      undefined,
      undefined,
      undefined
    );
  });

  it('should not crash and should not select a bucket when none are returned', () => {
    component.selectedBucketId.set('');

    s3StorageService.getBucketObjectCounts.and.returnValue(
      of({ bucketObjectCounts: [] } as any)
    );

    expect(() => component.ngOnInit()).not.toThrow();
    expect(component.selectedBucketId()).toBe('');
    expect(component.buckets().length).toBe(0);
  });

  it('should reorder buckets into the fixed planning/payload/network/filter sequence regardless of API response order', () => {
    s3StorageService.getBucketObjectCounts.and.returnValue(
      of({
        bucketObjectCounts: [
          { bucket: 'network', count: 1000, truncated: true },
          { bucket: 'planning', count: 795, truncated: false },
          { bucket: 'filter', count: 25, truncated: false },
          { bucket: 'payload', count: 817, truncated: false },
        ],
      } as any)
    );

    component.ngOnInit();

    expect(component.buckets().map(b => b.id)).toEqual([
      'planning',
      'payload',
      'network',
      'filter',
    ]);
  });

  it('should reorder buckets consistently even when the response order changes between loads', () => {
    s3StorageService.getBucketObjectCounts.and.returnValue(
      of({
        bucketObjectCounts: [
          { bucket: 'planning', count: 795, truncated: false },
          { bucket: 'payload', count: 817, truncated: false },
          { bucket: 'network', count: 1000, truncated: true },
          { bucket: 'filter', count: 25, truncated: false },
        ],
      } as any)
    );
    component.ngOnInit();
    const firstLoadOrder = component.buckets().map(b => b.id);

    s3StorageService.getBucketObjectCounts.and.returnValue(
      of({
        bucketObjectCounts: [
          { bucket: 'filter', count: 25, truncated: false },
          { bucket: 'network', count: 1000, truncated: true },
          { bucket: 'payload', count: 817, truncated: false },
          { bucket: 'planning', count: 795, truncated: false },
        ],
      } as any)
    );
    component.ngOnInit();
    const secondLoadOrder = component.buckets().map(b => b.id);

    expect(firstLoadOrder).toEqual([
      'planning',
      'payload',
      'network',
      'filter',
    ]);
    expect(secondLoadOrder).toEqual(firstLoadOrder);
  });

  it('should append unrecognized buckets after the canonically-ordered ones instead of dropping them', () => {
    s3StorageService.getBucketObjectCounts.and.returnValue(
      of({
        bucketObjectCounts: [
          { bucket: 'day0', count: 2, truncated: false },
          { bucket: 'filter', count: 25, truncated: false },
          { bucket: 'mystery-bucket', count: 4, truncated: false },
          { bucket: 'planning', count: 795, truncated: false },
        ],
      } as any)
    );

    component.ngOnInit();

    expect(component.buckets().map(b => b.id)).toEqual([
      'planning',
      'filter',
      'day0',
      'mystery-bucket',
    ]);
  });

  it('should compute the selected bucket and its translated label', () => {
    const bucket = component
      .buckets()
      .find(b => b.id === component.selectedBucketId());

    expect(component.selectedBucket()).toEqual(bucket);
    expect(component.selectedBucketLabel()).toBe(bucket?.label ?? '');
  });

  it('should return an undefined bucket and empty label when the selected id matches nothing', () => {
    component.selectedBucketId.set('does-not-exist');

    expect(component.selectedBucket()).toBeUndefined();
    expect(component.selectedBucketLabel()).toBe('');
  });

  it('should show each bucket count in a ui-kit badge, with + for truncated buckets', () => {
    s3StorageService.getBucketObjectCounts.and.returnValue(
      of({
        bucketObjectCounts: [
          { bucket: 'planning', count: 808, truncated: false },
          { bucket: 'network', count: 1000, truncated: true },
        ],
      } as any)
    );

    component.ngOnInit();
    fixture.detectChanges();

    const badges = fixture.debugElement
      .queryAll(By.directive(MockBadgeComponent))
      .map(debugEl => debugEl.componentInstance as MockBadgeComponent);

    expect(badges.map(badge => badge.label)).toEqual(['808', '1000+']);
    expect(
      badges.every(badge => !!badge.type && badge.type === badges[0].type)
    ).toBeTrue();
  });

  it('should highlight only the selected bucket badge', () => {
    s3StorageService.getBucketObjectCounts.and.returnValue(
      of({
        bucketObjectCounts: [
          { bucket: 'planning', count: 808, truncated: false },
          { bucket: 'network', count: 1000, truncated: true },
        ],
      } as any)
    );

    component.ngOnInit();
    component.selectBucket('network');
    fixture.detectChanges();

    const badges = fixture.debugElement
      .queryAll(By.directive(MockBadgeComponent))
      .map(debugEl => debugEl.componentInstance as MockBadgeComponent);

    expect(badges.map(badge => badge.mode)).toEqual(['light', 'regular']);
  });

  describe('bucket tooltips', () => {
    const ALL_BUCKETS = [
      { bucket: 'planning', count: 1, truncated: false },
      { bucket: 'payload', count: 2, truncated: false },
      { bucket: 'network', count: 3, truncated: false },
      { bucket: 'filter', count: 4, truncated: false },
      { bucket: 'day0', count: 5, truncated: false },
    ];

    const CONFIGURED_TOOLTIPS = [
      'planning',
      'payload',
      'network',
      'filter',
      'day0',
    ];

    const translateTooltips = () =>
      translateService.instant.and.callFake((key: string) => {
        const id = key.replace('s3Storage.buckets.tooltips.', '');
        return key !== id && CONFIGURED_TOOLTIPS.includes(id)
          ? `text for ${id}`
          : key;
      });

    it('should build each bucket tooltip key from the bucket id on load', () => {
      s3StorageService.getBucketObjectCounts.and.returnValue(
        of({
          bucketObjectCounts: [
            ...ALL_BUCKETS,
            { bucket: 'mystery-bucket', count: 1, truncated: false },
          ],
        } as any)
      );

      component.ngOnInit();

      expect(component.buckets().map(b => b.tooltipKey)).toEqual(
        jasmine.arrayContaining([
          's3Storage.buckets.tooltips.planning',
          's3Storage.buckets.tooltips.payload',
          's3Storage.buckets.tooltips.network',
          's3Storage.buckets.tooltips.filter',
          's3Storage.buckets.tooltips.day0',
          's3Storage.buckets.tooltips.mystery-bucket',
        ])
      );
    });

    it('should provide a translated tooltip for every known bucket', () => {
      s3StorageService.getBucketObjectCounts.and.returnValue(
        of({ bucketObjectCounts: ALL_BUCKETS } as any)
      );
      translateTooltips();

      component.ngOnInit();

      expect(component.bucketTooltips()).toEqual({
        planning: 'text for planning',
        payload: 'text for payload',
        network: 'text for network',
        filter: 'text for filter',
        day0: 'text for day0',
      });
    });

    it('should look up each tooltip by its own translation key', () => {
      s3StorageService.getBucketObjectCounts.and.returnValue(
        of({ bucketObjectCounts: ALL_BUCKETS } as any)
      );

      component.ngOnInit();
      component.bucketTooltips();

      [
        's3Storage.buckets.tooltips.planning',
        's3Storage.buckets.tooltips.payload',
        's3Storage.buckets.tooltips.network',
        's3Storage.buckets.tooltips.filter',
        's3Storage.buckets.tooltips.day0',
      ].forEach(key =>
        expect(translateService.instant).toHaveBeenCalledWith(key)
      );
    });

    it('should return no tooltip for a bucket without a configured description', () => {
      s3StorageService.getBucketObjectCounts.and.returnValue(
        of({
          bucketObjectCounts: [
            { bucket: 'planning', count: 1, truncated: false },
            { bucket: 'mystery-bucket', count: 1, truncated: false },
          ],
        } as any)
      );
      translateTooltips();

      component.ngOnInit();

      expect(component.bucketTooltips()['mystery-bucket']).toBeNull();
      expect(component.bucketTooltips()['planning']).toBe('text for planning');
    });

    it('should return no tooltip when the translation is missing, instead of showing the raw key', () => {
      s3StorageService.getBucketObjectCounts.and.returnValue(
        of({ bucketObjectCounts: ALL_BUCKETS } as any)
      );

      component.ngOnInit();

      Object.values(component.bucketTooltips()).forEach(tooltip =>
        expect(tooltip).toBeNull()
      );
    });

    it('should return no tooltip when the translation is empty', () => {
      s3StorageService.getBucketObjectCounts.and.returnValue(
        of({ bucketObjectCounts: ALL_BUCKETS } as any)
      );
      translateService.instant.and.callFake((key: string) =>
        key === 's3Storage.buckets.tooltips.filter' ? '' : key
      );

      component.ngOnInit();

      expect(component.bucketTooltips()['filter']).toBeNull();
    });
  });

  it('should map the day0 bucket to its own translation key rather than falling back to the raw id', () => {
    s3StorageService.getBucketObjectCounts.and.returnValue(
      of({
        bucketObjectCounts: [
          { bucket: 'planning', count: 1, truncated: false },
          { bucket: 'day0', count: 2, truncated: false },
        ],
      } as any)
    );

    component.ngOnInit();

    const day0Bucket = component.buckets().find(b => b.id === 'day0');
    expect(day0Bucket?.label).toBe('s3Storage.buckets.day0');
  });

  it('should resolve the translated label for the day0 bucket when selected', () => {
    s3StorageService.getBucketObjectCounts.and.returnValue(
      of({
        bucketObjectCounts: [
          { bucket: 'planning', count: 1, truncated: false },
          { bucket: 'day0', count: 2, truncated: false },
        ],
      } as any)
    );
    translateService.instant.and.callFake((key: string) =>
      key === 's3Storage.buckets.day0' ? 'Day0' : key
    );

    component.ngOnInit();
    component.selectBucket('day0');

    expect(component.selectedBucketLabel()).toBe('Day0');
  });

  it('should map the network bucket to its own translation key rather than a legacy "runtime" key', () => {
    s3StorageService.getBucketObjectCounts.and.returnValue(
      of({
        bucketObjectCounts: [
          { bucket: 'planning', count: 1, truncated: false },
          { bucket: 'network', count: 2, truncated: false },
        ],
      } as any)
    );

    component.ngOnInit();

    const networkBucket = component.buckets().find(b => b.id === 'network');
    expect(networkBucket?.label).toBe('s3Storage.buckets.network');
  });

  it('should update selectedBucketLabel once buckets load, even when it was read before any data arrived', () => {
    const freshFixture = TestBed.createComponent(S3StorageBrowserComponent);
    const freshComponent = freshFixture.componentInstance;

    expect(freshComponent.selectedBucketLabel()).toBe('');

    freshComponent.ngOnInit();

    expect(freshComponent.selectedBucketId()).toBe('planning');
    expect(freshComponent.selectedBucketLabel()).toBe(
      's3Storage.buckets.planning'
    );
  });

  it('should build column value accessors that read row fields', () => {
    const cols = component.columns();
    const row = {
      key: 'path/to/file.txt',
      size: 2048,
      acl: 'private',
      lastModifiedAt: '2026-01-01',
    } as any;

    expect(cols.find(c => c.key === 'key')?.value(row)).toBe(
      'path/to/file.txt'
    );
    expect(cols.find(c => c.key === 'size')?.value(row)).toBe('2.00 KB');
    expect(cols.find(c => c.key === 'acl')?.value(row)).toBe('private');
    expect(cols.find(c => c.key === 'lastModifiedAt')?.value(row)).toBe(
      '2026-01-01'
    );
    expect(cols.find(c => c.key === 'actions')?.value(row)).toBe('');
  });

  it('should fall back to empty/zero values for missing row fields', () => {
    const cols = component.columns();
    const row = {} as any;

    expect(cols.find(c => c.key === 'key')?.value(row)).toBe('');
    expect(cols.find(c => c.key === 'size')?.value(row)).toBe('0 B');
    expect(cols.find(c => c.key === 'acl')?.value(row)).toBe('');
    expect(cols.find(c => c.key === 'lastModifiedAt')?.value(row)).toBe('');
  });

  it('should save the file when download succeeds', () => {
    const blob = new Blob(['content']);
    s3StorageService.downloadS3Object.and.returnValue(of(blob) as any);

    component.onDownload({ key: 'file.txt', bucket: 'planning' } as any);

    expect(s3StorageService.downloadS3Object).toHaveBeenCalledWith(
      'planning',
      'file.txt'
    );
    expect(fileSaverService.save).toHaveBeenCalledWith(blob, 'file.txt');
  });

  it('should not download when no bucket is selected', () => {
    component.selectedBucketId.set('');

    component.onDownload({ key: 'file.txt' } as any);

    expect(s3StorageService.downloadS3Object).not.toHaveBeenCalled();
  });

  it('should do nothing when selecting the already-selected bucket', () => {
    spyOn<any>(component, 'loadBucketData');
    const current = component.selectedBucketId();

    component.selectBucket(current);

    expect((component as any).loadBucketData).not.toHaveBeenCalled();
  });

  it('should reset filesState when loadBucketData runs with no bucket selected', () => {
    component.selectedBucketId.set('');

    (component as any).loadBucketData();

    expect(component.filesState().loading).toBeFalse();
    expect(component.filesState().data).toEqual({
      items: [],
      totalCount: 0,
      truncated: false,
    });
  });

  it('should pass a trimmed keyFilter when a search query is set', () => {
    component.searchQuery.set('  abc  ');

    (component as any).loadBucketData();

    expect(s3StorageService.getObjectsByBucket).toHaveBeenCalledWith(
      'planning',
      jasmine.any(Number),
      undefined,
      'abc',
      undefined,
      undefined
    );
  });

  it('should reset to the first page and reload data when the search query changes', fakeAsync(() => {
    spyOn<any>(component, 'loadBucketData');

    component.onSearchChange('xyz');
    tick(301);

    expect(paginationService.changePage).toHaveBeenCalledWith(
      component.DEFAULT_PAGE
    );
    expect((component as any).loadBucketData).toHaveBeenCalled();
  }));

  it('should return the raw state when no data has loaded yet', () => {
    component.filesState.set({ loading: true, data: undefined });

    const state = component.pagedFilesState();

    expect(state.data).toBeUndefined();
    expect(state.loading).toBeTrue();
  });
});
