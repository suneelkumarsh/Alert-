/*
 * Copyright (c) 2022. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, inject, OnInit } from '@angular/core';
import { ActionsResponse, PnfsService } from 'openapi/output';
import { ConfirmationModalComponent } from 'src/app/components/shared/confirmation-modal/confirmation-modal.component';
import {
  catchError,
  debounceTime,
  distinctUntilChanged,
  map,
  repeatWhen,
  shareReplay,
  switchMap,
  takeUntil,
  tap,
} from 'rxjs/operators';
import { ActionType, EntityType } from 'src/app/model/user-last-action.model';
import { combineLatest, EMPTY, Observable, of, Subject } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { HistoryService } from 'src/app/services/history.service';
import { UnsubscribeService } from 'src/app/services/unsubscribe/unsubscribe.service';
import { KeyboardShortcuts } from 'src/app/services/shortcut.service';
import { QueryParamService } from '../../../services/query-param.service';
import { BaseFilterService } from '../../../services/common-functionalities/base-filter.service';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-ru-management-list',
  templateUrl: './ru-management-list.component.html',
  styleUrls: ['./ru-management-list.component.css'],
  providers: [UnsubscribeService],
  standalone: false,
})
export class RuManagementListComponent implements OnInit {
  public ACCESS_KEY = KeyboardShortcuts;
  private readonly reload$ = new Subject<void>();
  private addToHistory$ = new Subject<string>();

  readonly filter$ = this.queryParamService.getValueOf('filter');
  readonly permissions = inject(PERMISSIONS_TOKEN);

  onSearchChange(filterValue: string) {
    this.addToHistory$.next(filterValue);
    this.filterService.changeFilter(filterValue);
  }

  resetSearch() {
    this.filterService.changeFilter(undefined);
  }

  pnfs = this.pnfsService.listPnfs().pipe(
    repeatWhen(() => this.reload$),
    shareReplay({ refCount: true, bufferSize: 1 })
  );
  filteredPnfs$ = combineLatest([
    this.filter$.pipe(debounceTime(1000)),
    this.pnfs,
  ]).pipe(
    map(([searchValue, response]) => {
      const newResponse = { ...response };
      if (!searchValue) {
        return newResponse;
      }
      const value = searchValue.toLowerCase();
      newResponse.items = newResponse.items.filter(ru => {
        return (
          ru.pnfName.toLowerCase().includes(value) ||
          ru.ipv4Address.toLowerCase().includes(value) ||
          ru.subnetwork?.toLowerCase().includes(value) ||
          ru.gateway?.toLowerCase().includes(value) ||
          ru.serialNumber?.toLowerCase().includes(value) ||
          ru.username.toLowerCase().includes(value) ||
          ru.mac?.toLowerCase().includes(value)
        );
      });
      return newResponse;
    })
  );

  constructor(
    private filterService: BaseFilterService,
    private pnfsService: PnfsService,
    private readonly modalService: NgbModal,
    private readonly translateService: TranslateService,
    private readonly historyService: HistoryService,
    private readonly unsubscribeService: UnsubscribeService,
    private readonly alertService: TnapAlertService,
    private queryParamService: QueryParamService
  ) {}

  ngOnInit() {
    this.addToHistory$
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        debounceTime(1000),
        distinctUntilChanged(),
        switchMap(pnfName =>
          this.historyService.createRuManagementHistoryAction({
            type: ActionType.SEARCH,
            entity: EntityType.RUMANAGEMENT,
            entityParams: { pnfName },
          })
        )
      )
      .subscribe();
  }

  openModal(pnfName: string): void {
    // open confirmation modal for pnf deletion
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalRef.componentInstance.okText = this.translateService.instant(
      'common.buttons.delete'
    );
    modalRef.componentInstance.title = this.translateService.instant(
      'ruManagement.list.modal.delete.title'
    );
    modalRef.componentInstance.text = this.translateService.instant(
      'ruManagement.list.modal.delete.text',
      {
        pnfName,
      }
    );
    modalRef.closed
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap((confirm: boolean) => {
          if (confirm) {
            return this.pnfsService
              .deletePnf(pnfName)
              .pipe(
                switchMap(() =>
                  this.addHistoryAction(ActionType.DELETE, pnfName)
                )
              );
          }
          return EMPTY;
        }),
        tap(() => {
          this.successDeleteMessage();
        })
      )
      .subscribe(() => this.reload());
  }

  private addHistoryAction(
    actionType: ActionType,
    pnfName: string
  ): Observable<ActionsResponse | null> {
    return this.historyService
      .createRuManagementHistoryAction({
        type: actionType,
        entity: EntityType.USERADMINISTRATION,
        entityParams: { pnfName },
      })
      .pipe(catchError(() => of(null)));
  }

  private successDeleteMessage(): void {
    this.alertService.success(
      this.translateService.instant(
        'ruManagement.list.messages.success.deleted'
      ),
      { keepAfterRouteChange: true }
    );
  }

  private reload() {
    this.reload$.next();
  }
}
