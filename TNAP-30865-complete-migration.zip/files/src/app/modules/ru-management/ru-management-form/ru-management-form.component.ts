/*
 * Copyright (c) 2022. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, OnInit } from '@angular/core';
import {
  AbstractControl,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { PNF, PnfsService } from 'openapi/output';
import { ActivatedRoute, Router } from '@angular/router';
import {
  distinctUntilChanged,
  switchMap,
  take,
  takeUntil,
} from 'rxjs/operators';
import { UnsubscribeService } from 'src/app/services/unsubscribe/unsubscribe.service';
import { markAsDirtyAndValidate } from 'src/app/helpers/helpers';
import { HistoryService } from 'src/app/services/history.service';
import { TranslateService } from '@ngx-translate/core';
import {
  CIDR_PATTERN,
  IP_ADDRESS_PATTERN,
  MAC_ADDRESS_PATTERN,
} from 'src/app/model/validation-pattern.model';
import { ActionType, EntityType } from 'src/app/model/user-last-action.model';
import { FormValidators } from 'src/app/helpers/form-validators';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-ru-management-form',
  templateUrl: './ru-management-form.component.html',
  styleUrls: ['./ru-management-form.component.css'],
  providers: [UnsubscribeService],
  standalone: false,
})
export class RuManagementFormComponent implements OnInit {
  public readonly pnfId: string | null;
  public readonly pnfForm: UntypedFormGroup;
  public showPassword = false;
  public showRepeatPassword = false;

  constructor(
    private route: ActivatedRoute,
    private pnfsService: PnfsService,
    private unsubscribeService: UnsubscribeService,
    private historyService: HistoryService,
    private alertService: TnapAlertService,
    private translateService: TranslateService,
    private router: Router
  ) {
    this.pnfId = this.route.snapshot.paramMap.get('pnfId');
    this.pnfForm = new UntypedFormGroup({
      pnfName: new UntypedFormControl(
        { value: null, disabled: this.pnfId !== null },
        [Validators.required]
      ),
      ipv4Address: new UntypedFormControl(null, [
        Validators.required,
        Validators.pattern(IP_ADDRESS_PATTERN),
      ]),
      subnetwork: new UntypedFormControl(null, [
        Validators.required,
        Validators.pattern(CIDR_PATTERN),
      ]),
      gateway: new UntypedFormControl(null, [Validators.required]),
      serialNumber: new UntypedFormControl(null, [Validators.required]),
      mac: new UntypedFormControl(null, [
        Validators.required,
        Validators.pattern(MAC_ADDRESS_PATTERN),
      ]),
      username: new UntypedFormControl(null, [Validators.required]),
      password: new UntypedFormControl(null, [Validators.required]),
      repeatPassword: new UntypedFormControl(null, [
        Validators.required,
        FormValidators.confirmPassword(() => this.pnfForm, 'password'),
      ]),
      sshKey: new UntypedFormControl(null, [Validators.required]),
    });
  }

  ngOnInit(): void {
    this.pnfForm.controls.mac.valueChanges
      .pipe(
        distinctUntilChanged(),
        takeUntil(this.unsubscribeService.unsubscribe$)
      )
      .subscribe(value =>
        value ? this.serialNumber.disable() : this.serialNumber.enable()
      );

    this.pnfForm.controls.serialNumber.valueChanges
      .pipe(
        distinctUntilChanged(),
        takeUntil(this.unsubscribeService.unsubscribe$)
      )
      .subscribe(value => (value ? this.mac.disable() : this.mac.enable()));

    if (this.pnfId !== null) {
      this.pnfsService
        .getPnfByName(this.pnfId)
        .pipe(takeUntil(this.unsubscribeService.unsubscribe$))
        .subscribe(pnf => {
          this.pnfForm.patchValue({
            pnfName: pnf.pnfName,
            ipv4Address: pnf.ipv4Address,
            subnetwork: pnf.subnetwork,
            gateway: pnf.gateway,
            serialNumber: pnf.serialNumber,
            mac: pnf.mac,
            username: pnf.username,
            password: pnf.password,
            repeatPassword: pnf.password,
            sshKey: pnf.sshKey,
          });
        });
    }
    this.pnfForm.controls.password.valueChanges
      .pipe(
        distinctUntilChanged(),
        takeUntil(this.unsubscribeService.unsubscribe$)
      )
      .subscribe(() =>
        this.pnfForm.controls.repeatPassword.updateValueAndValidity()
      );
  }

  get pnfName(): UntypedFormControl {
    return this.pnfForm.get('pnfName') as UntypedFormControl;
  }

  get ipv4Address(): UntypedFormControl {
    return this.pnfForm.get('ipv4Address') as UntypedFormControl;
  }

  get subnetwork(): UntypedFormControl {
    return this.pnfForm.get('subnetwork') as UntypedFormControl;
  }

  get gateway(): UntypedFormControl {
    return this.pnfForm.get('gateway') as UntypedFormControl;
  }

  get serialNumber(): UntypedFormControl {
    return this.pnfForm.get('serialNumber') as UntypedFormControl;
  }

  get mac(): UntypedFormControl {
    return this.pnfForm.get('mac') as UntypedFormControl;
  }

  get userName(): UntypedFormControl {
    return this.pnfForm.get('username') as UntypedFormControl;
  }

  get password(): UntypedFormControl {
    return this.pnfForm.get('password') as UntypedFormControl;
  }

  get repeatPassword(): UntypedFormControl {
    return this.pnfForm.get('repeatPassword') as UntypedFormControl;
  }

  get sshKey(): UntypedFormControl {
    return this.pnfForm.get('sshKey') as UntypedFormControl;
  }

  public onSubmit(): void {
    markAsDirtyAndValidate(this.pnfForm);
    if (this.pnfForm.valid) {
      const formValue = this.pnfForm.getRawValue();
      if (this.pnfId === null) {
        this.createPnf(formValue);
      } else {
        this.updatePnf(this.pnfId, formValue);
      }
    }
  }

  public isFormControlInvalid(formControl: AbstractControl | null): boolean {
    if (formControl !== null) {
      return (
        formControl &&
        formControl?.invalid &&
        (formControl?.dirty || formControl?.touched)
      );
    }
    return false;
  }

  private pnfRequest(formValue: any): PNF {
    return {
      pnfName: formValue.pnfName,
      ipv4Address: formValue.ipv4Address,
      subnetwork: formValue.subnetwork,
      gateway: formValue.gateway,
      serialNumber: formValue.serialNumber,
      mac: formValue.mac,
      username: formValue.username,
      password: formValue.password,
      sshKey: formValue.sshKey,
    };
  }

  private createPnf(formValue: any) {
    const pnfName = formValue.pnfName;
    this.pnfsService
      .createPnf(this.pnfRequest(formValue))
      .pipe(
        switchMap(() =>
          this.historyService.createRuManagementHistoryAction({
            type: ActionType.CREATE,
            entity: EntityType.RUMANAGEMENT,
            entityParams: { pnfName },
          })
        ),
        take(1)
      )
      .subscribe(() => {
        this.alertService.success(
          this.translateService.instant(
            'ruManagement.messages.success.created'
          ),
          { keepAfterRouteChange: true }
        );
        this.router.navigate(['../list'], { relativeTo: this.route });
      });
  }

  private updatePnf(pnfId: string, formValue: any) {
    const pnfName = formValue.pnfName;
    this.pnfsService
      .updatePnf(pnfId, this.pnfRequest(formValue))
      .pipe(
        switchMap(() =>
          this.historyService.createRuManagementHistoryAction({
            type: ActionType.EDIT,
            entity: EntityType.RUMANAGEMENT,
            entityParams: { pnfName },
          })
        ),
        take(1)
      )
      .subscribe(() => {
        this.alertService.success(
          this.translateService.instant(
            'ruManagement.messages.success.updated'
          ),
          { keepAfterRouteChange: true }
        );
        this.router.navigate(['../../list'], { relativeTo: this.route });
      });
  }

  public passwordVisibility() {
    this.showPassword = !this.showPassword;
  }

  public repeatPasswordVisibility() {
    this.showRepeatPassword = !this.showRepeatPassword;
  }
}
