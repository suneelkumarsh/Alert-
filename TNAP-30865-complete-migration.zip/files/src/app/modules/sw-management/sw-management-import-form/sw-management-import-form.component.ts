/*
 * Copyright (c) 2022. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, OnInit } from '@angular/core';
import {
  AbstractControl,
  AsyncValidatorFn,
  UntypedFormControl,
  UntypedFormGroup,
  ValidationErrors,
  Validators,
} from '@angular/forms';
import { ServiceType, SoftwareManagementService } from 'openapi/output';
import { AuthService } from '@portal-mfe/auth';
import {
  catchError,
  filter,
  map,
  shareReplay,
  switchMap,
  take,
  takeUntil,
} from 'rxjs/operators';
import { markAsDirtyAndValidate } from 'src/app/helpers/helpers';
import { UnsubscribeService } from 'src/app/services/unsubscribe/unsubscribe.service';
import { TranslateService } from '@ngx-translate/core';
import { ActivatedRoute, Router } from '@angular/router';
import { VALID_SW_PACKAGE_NAME_PATTERN } from 'src/app/model/validation-pattern.model';
import { Observable, of } from 'rxjs';
import { ActionType, EntityType } from 'src/app/model/user-last-action.model';
import { HistoryService } from 'src/app/services/history.service';
import { MAX_SW_NAME_LENGTH } from 'src/app/modules/sw-management/configuration';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-sw-management-import-form',
  templateUrl: './sw-management-import-form.component.html',
  styleUrls: ['./sw-management-import-form.component.css'],
  providers: [UnsubscribeService],
  standalone: false,
})
export class SwManagementImportFormComponent implements OnInit {
  MAX_SW_NAME_LENGTH = MAX_SW_NAME_LENGTH;
  public swPackageForm: UntypedFormGroup;

  public vendorCodeOptions$ = this.swManagementService.listSwVendors().pipe(
    map(vendors => vendors.items),
    shareReplay({ refCount: true, bufferSize: 1 })
  );
  public nodeTypeOptions$ = this.swManagementService
    .listSwNodeTypes()
    .pipe(map(nodeTypes => nodeTypes.items));
  public loggedUserId$ = this.authService.getLoggedUserId();

  get file(): UntypedFormControl {
    return this.swPackageForm.get('file') as UntypedFormControl;
  }

  get packageName(): UntypedFormControl {
    return this.swPackageForm.get('packageName') as UntypedFormControl;
  }

  get vendorCode(): UntypedFormControl {
    return this.swPackageForm.get('vendorCode') as UntypedFormControl;
  }

  get nodeType(): UntypedFormControl {
    return this.swPackageForm.get('nodeType') as UntypedFormControl;
  }

  public codes: string[] = [];

  constructor(
    private swManagementService: SoftwareManagementService,
    private authService: AuthService,
    private unsubscribeService: UnsubscribeService,
    private alertService: TnapAlertService,
    private translateService: TranslateService,
    private router: Router,
    private route: ActivatedRoute,
    private historyService: HistoryService
  ) {
    this.swPackageForm = new UntypedFormGroup({
      file: new UntypedFormControl(null, null, [
        this.mustStartWithVendorCode(),
      ]),
      packageName: new UntypedFormControl({ value: null, disabled: true }, [
        Validators.required,
      ]),
      vendorCode: new UntypedFormControl({ value: null, disabled: true }, [
        Validators.required,
      ]),
      nodeType: new UntypedFormControl({ value: null, disabled: true }, [
        Validators.required,
      ]),
    });
  }

  ngOnInit(): void {
    this.file.valueChanges
      .pipe(takeUntil(this.unsubscribeService.unsubscribe$))
      .subscribe(value => {
        if (!value) {
          this.file.setErrors({ required: true });
          return;
        }
        if (value.name.length > 60) {
          this.file.setErrors({ maxlength: true });
        }
        if (!new RegExp(VALID_SW_PACKAGE_NAME_PATTERN).test(value.name)) {
          this.file.setErrors({ pattern: true });
        }
      });
    this.vendorCodeOptions$
      .pipe(
        map(vendors => vendors.map(vendor => vendor.vendorCode)),
        takeUntil(this.unsubscribeService.unsubscribe$)
      )
      .subscribe(codes => (this.codes = codes));
  }
  public onFileChange(event: any): void {
    this.swPackageForm.reset();
    this.disableInputs();
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      const isFileNamePassedValidationCriteria =
        this.codes.includes(file.name.substring(0, 2)) &&
        file.name.length < this.MAX_SW_NAME_LENGTH &&
        new RegExp(VALID_SW_PACKAGE_NAME_PATTERN).test(file.name);
      this.swPackageForm.patchValue({
        file,
        packageName: isFileNamePassedValidationCriteria
          ? file.name.split('.')[0]
          : null,
        vendorCode: isFileNamePassedValidationCriteria
          ? file.name.substring(0, 2)
          : null,
        nodeType: isFileNamePassedValidationCriteria ? ServiceType.RU : null,
      });
      this.file.markAsDirty();
      this.file.updateValueAndValidity();
      if (isFileNamePassedValidationCriteria) {
        this.enableInputs();
      }
    } else {
      this.disableInputs();
    }
  }

  public isFormControlInvalid(formControl: AbstractControl | null): boolean {
    if (formControl !== null) {
      return (
        formControl &&
        formControl?.invalid &&
        (formControl?.dirty || formControl?.touched)
      );
    }
    return false;
  }

  public onSubmit(): void {
    markAsDirtyAndValidate(this.swPackageForm);
    if (this.swPackageForm.valid) {
      const formValue = this.swPackageForm.getRawValue();
      this.loggedUserId$
        .pipe(
          take(1),
          filter((user): user is string => !!user),
          switchMap(user =>
            this.swManagementService
              .createSwPackage(
                formValue.packageName,
                formValue.vendorCode,
                formValue.nodeType,
                user,
                formValue.file
              )
              .pipe(
                switchMap(() =>
                  this.createHistoryAction(formValue.packageName, user).pipe(
                    catchError(() => of(null))
                  )
                )
              )
          )
        )
        .subscribe(() => {
          this.alertService.success(
            this.translateService.instant(
              'swManagement.messages.success.created'
            ),
            { keepAfterRouteChange: true }
          );
          this.router.navigate(['../'], { relativeTo: this.route });
        });
    }
  }

  private mustStartWithVendorCode(): AsyncValidatorFn {
    return (control: AbstractControl): Observable<ValidationErrors | null> => {
      if (control.value) {
        return this.vendorCodeOptions$.pipe(
          map(vendors => vendors.map(vendor => vendor.vendorCode)),
          map(res =>
            res.includes(control.value.name.substring(0, 2))
              ? null
              : { startWithVendorCode: true }
          )
        );
      }
      return of(null);
    };
  }

  private enableInputs(): void {
    this.packageName.enable({ onlySelf: true, emitEvent: false });
    this.vendorCode.enable({ onlySelf: true, emitEvent: false });
  }

  private disableInputs(): void {
    this.packageName.disable({ onlySelf: true, emitEvent: false });
    this.vendorCode.disable({ onlySelf: true, emitEvent: false });
  }

  private createHistoryAction(packageName: string, userId: string) {
    return this.historyService.createSwManagementHistoryAction({
      type: ActionType.IMPORT,
      entity: EntityType.SWMANAGEMENT,
      entityParams: { packageName: packageName, userId },
    });
  }
}
