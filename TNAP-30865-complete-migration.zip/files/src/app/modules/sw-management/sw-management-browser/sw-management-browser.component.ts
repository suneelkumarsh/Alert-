/*
 * Copyright (c) 2022. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, inject } from '@angular/core';
import {
  SoftwareManagementService,
  SoftwarePackageListResponse,
} from 'openapi/output';
import { environment } from 'src/environments/environment';
import {
  debounceTime,
  map,
  repeatWhen,
  switchMap,
  takeUntil,
  tap,
} from 'rxjs/operators';
import { ConfirmationModalComponent } from 'src/app/components/shared/confirmation-modal/confirmation-modal.component';
import { combineLatest, EMPTY, Subject } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { UnsubscribeService } from 'src/app/services/unsubscribe/unsubscribe.service';
import { ActionType, EntityType } from 'src/app/model/user-last-action.model';
import { HistoryService } from 'src/app/services/history.service';
import { QueryParamService } from '../../../services/query-param.service';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-sw-management-browser',
  templateUrl: './sw-management-browser.component.html',
  styleUrls: ['./sw-management-browser.component.css'],
  providers: [UnsubscribeService],
  standalone: false,
})
export class SwManagementBrowserComponent {
  private reload$ = new Subject<void>();
  public readonly dateTimeFormat = environment.dateTimeFormat;
  public software$ = this.swManagementService
    .listSwPackages()
    .pipe(repeatWhen(() => this.reload$));
  public filter$ = this.queryParamService.getValueOf('filter');
  readonly permissions = inject(PERMISSIONS_TOKEN);

  public filteredSoftware$ = combineLatest([
    this.filter$.pipe(debounceTime(500)),
    this.software$,
  ]).pipe(
    map(([filter, software]) => {
      if (!filter) {
        return software;
      }
      const filteredData: SoftwarePackageListResponse = { ...software };
      const value = filter.toLowerCase();
      filteredData.items = filteredData.items.filter(software => {
        return (
          software.packageName.toLowerCase().includes(value) ||
          software.vendorCode.toLowerCase().includes(value) ||
          software.nodeType.toLowerCase().includes(value) ||
          software.pathType.toLowerCase().includes(value) ||
          software.pathDetails.toLowerCase().includes(value) ||
          software.modifyUser.toLowerCase().includes(value) ||
          software.modifyTime.toLowerCase().includes(value)
        );
      });
      return filteredData;
    })
  );
  constructor(
    private swManagementService: SoftwareManagementService,
    private modalService: NgbModal,
    private alertService: TnapAlertService,
    private translateService: TranslateService,
    private unsubscribeService: UnsubscribeService,
    private historyService: HistoryService,
    private queryParamService: QueryParamService
  ) {}

  public openRemoveSwModal(
    packageName: string,
    vendorCode: string,
    nodeType: string
  ): void {
    // open confirmation modal for sw package deletion
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalRef.componentInstance.okText = this.translateService.instant(
      'common.buttons.delete'
    );
    modalRef.componentInstance.title = this.translateService.instant(
      'swManagement.browser.modal.delete.title'
    );
    modalRef.componentInstance.text = this.translateService.instant(
      'swManagement.browser.modal.delete.text',
      {
        packageName,
      }
    );
    modalRef.closed
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap((confirm: boolean) => {
          if (confirm) {
            return this.swManagementService
              .deleteSwPackage(packageName, vendorCode, nodeType)
              .pipe(
                switchMap(() =>
                  this.historyService.createSwManagementHistoryAction({
                    type: ActionType.DELETE,
                    entity: EntityType.SWMANAGEMENT,
                    entityParams: { packageName: packageName },
                  })
                )
              );
          }
          return EMPTY;
        }),
        tap(() => {
          this.alertService.success(
            this.translateService.instant(
              'swManagement.browser.messages.success.deleted'
            ),
            { keepAfterRouteChange: true }
          );
        })
      )
      .subscribe(() => this.reload$.next());
  }
}
