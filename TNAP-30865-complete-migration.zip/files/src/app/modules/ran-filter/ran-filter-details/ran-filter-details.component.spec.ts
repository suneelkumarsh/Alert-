/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
} from '@angular/core/testing';
import {
  Component,
  Directive,
  Input,
  Pipe,
  PipeTransform,
} from '@angular/core';
import { By } from '@angular/platform-browser';
import { OverlayContainer } from '@angular/cdk/overlay';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject, of, throwError } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';

import { RanFilterDetailsComponent } from './ran-filter-details.component';
import { RanFilterService } from '../../../services/ran-filterservice/ran-filter.service';
import {
  RanFilterCondition,
  QueryAttribute,
  RanFilter,
} from '../../../../../openapi/output';
import {
  QueryAttributeLookup,
  RAN_FILTER_SOURCES,
  SelectedCondition,
} from '../model/ran-filter.model';
import { ModalConfirmationService } from '../../../services/common-functionalities/modal-confirmation.service';
import { RanFilterInfoMessageComponent } from '../ran-filter-info-message/ran-filter-info-message.component';
import { RanFilterRequirementsComponent } from '../ran-filter-requirements/ran-filter-requirements.component';
import { RanFilterExecuteResultPanelComponent } from '../ran-filter-execute-result-panel/ran-filter-execute-result-panel.component';
/* Real ui-kit components: the show-nodes assertions read the rendered checkbox
   inside the overlay, which a template-less mock would not provide. */
import { CheckboxComponent } from '@portal-mfe/tnap-ui-kit/components/checkbox';
import { LoadingSpinnerComponent } from '@portal-mfe/tnap-ui-kit/components/loading-spinner';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

const emptyLookup = (): QueryAttributeLookup => ({
  attributes: new Map<string, QueryAttribute>(),
  requestedPaths: new Set<string>(),
  failedPaths: new Set<string>(),
});

@Pipe({ name: 'translate' })
class MockTranslatePipe implements PipeTransform {
  transform(value: string): string {
    return value;
  }
}

@Pipe({ name: 'highlight' })
class MockHighlightPipe implements PipeTransform {
  transform(value: string): string {
    return value;
  }
}

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'tnap-data-table',
  template: '<ng-content></ng-content>',
})
class MockDataTableComponent {
  @Input() localStorageKey?: string;
  @Input() columns?: unknown[];
  @Input() data?: unknown;
  @Input() noDataMessage?: string;
  @Input() isLoading?: boolean;
  @Input() showDetailButton?: boolean;
  @Input() showColumnConfig?: boolean;
  @Input() showPagination?: boolean;
  @Input() showCheckboxes?: boolean;
  @Input() enableMasterCheckBox?: boolean;
  @Input() rowIdKey?: string;
  @Input() checkedRowIds?: string[];
}

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'tnap-layout',
  template:
    '<ng-content></ng-content><ng-content select="header"></ng-content>',
})
class MockLayoutComponent {}

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'tnap-breadcrumb',
  template: '<ng-content></ng-content>',
})
class MockBreadcrumbComponent {
  @Input() separator?: string;
}

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'tnap-breadcrumb-item',
  template: '',
})
class MockBreadcrumbItemComponent {
  @Input() label?: string;
  @Input() link?: unknown;
}

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'tnap-input-search',
  template: '',
})
class MockInputSearchComponent {
  @Input() value?: string;
  @Input() placeholder?: string;
  @Input() withButton?: boolean;
}

@Directive({
  // eslint-disable-next-line @angular-eslint/directive-selector
  selector: '[tnapButton]',
})
class MockTnapButtonDirective {
  @Input() variant?: string;
  @Input() size?: string;
  @Input() loading?: boolean;
  @Input() disabled?: boolean;
}

@Directive({
  selector: '[appTableCellDefinition]',
})
class MockTableCellDefinitionDirective {
  @Input() colName?: string;
}

describe('RanFilterDetailsComponent', () => {
  let component: RanFilterDetailsComponent;
  let fixture: ComponentFixture<RanFilterDetailsComponent>;
  let ranFilterService: jasmine.SpyObj<RanFilterService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let router: jasmine.SpyObj<Router>;
  let modalConfirmationService: jasmine.SpyObj<ModalConfirmationService>;

  const resultPanels = (): HTMLElement[] =>
    Array.from(
      TestBed.inject(OverlayContainer)
        .getContainerElement()
        .querySelectorAll<HTMLElement>('.qa_execute_result_panel')
    );

  const sampleAttr: QueryAttribute = {
    name: 'node.equipType',
    conditionType: 'string',
    operator: ['=', '!='],
    source: 'AAI',
    description: 'Equipment type',
  };

  const sampleCpsAttr: QueryAttribute = {
    name: 'NE.neType',
    conditionType: 'string',
    operator: ['=', '!='],
    source: 'CPS',
    moc: 'NE',
    mocAttribute: 'neType',
  };

  const sampleCondition: SelectedCondition = {
    path: 'node.equipType',
    source: RanFilterCondition.SourceEnum.AAI,
    operator: '=',
    filterValue: 'macro',
    availableOperators: ['=', '!='],
    conditionType: 'string',
  };

  const sampleCpsCondition: SelectedCondition = {
    path: 'NE.neType',
    source: RanFilterCondition.SourceEnum.CPS,
    operator: '=',
    filterValue: 'gNB',
    availableOperators: ['=', '!='],
    conditionType: 'string',
  };

  beforeEach(async () => {
    ranFilterService = jasmine.createSpyObj('RanFilterService', [
      'listFilterVendors$',
      'listFilterQueryAttributes$',
      'saveRanFilter$',
      'updateRanFilter$',
      'getRanFilter$',
      'executeRanFilter$',
      'buildRanFilter',
      'refreshRanFilters',
      'resolveQueryAttributes$',
      'mergeConditionMetadata',
    ]);
    ranFilterService.listFilterVendors$.and.returnValue(
      of([{ vendor: 'Ericsson' }, { vendor: 'Nokia' }])
    );
    ranFilterService.listFilterQueryAttributes$.and.returnValue(
      of({ queryAttributes: [], totalCount: 0 } as any)
    );
    ranFilterService.resolveQueryAttributes$.and.returnValue(of(emptyLookup()));
    ranFilterService.mergeConditionMetadata.and.callFake(
      (conditions: any) => conditions
    );

    alertService = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
      'info',
    ]);
    router = jasmine.createSpyObj('Router', ['navigate']);
    modalConfirmationService = jasmine.createSpyObj(
      'ModalConfirmationService',
      ['openConfirmationModal']
    );
    modalConfirmationService.openConfirmationModal.and.returnValue(of(true));

    const onLangChange$ = new Subject<{
      lang: string;
      translations: unknown;
    }>();
    const translateServiceSpy = jasmine.createSpyObj(
      'TranslateService',
      ['instant'],
      { onLangChange: onLangChange$.asObservable() }
    );
    translateServiceSpy.instant.and.callFake((key: string) => key);

    await TestBed.configureTestingModule({
      declarations: [
        RanFilterDetailsComponent,
        RanFilterInfoMessageComponent,
        RanFilterRequirementsComponent,
        RanFilterExecuteResultPanelComponent,
      ],
      imports: [
        MockTranslatePipe,
        MockHighlightPipe,
        MockDataTableComponent,
        MockLayoutComponent,
        MockBreadcrumbComponent,
        MockBreadcrumbItemComponent,
        MockInputSearchComponent,
        MockTnapButtonDirective,
        MockTableCellDefinitionDirective,
        CheckboxComponent,
        LoadingSpinnerComponent,
      ],
      providers: [
        { provide: RanFilterService, useValue: ranFilterService },
        { provide: TnapAlertService, useValue: alertService },
        { provide: Router, useValue: router },
        {
          provide: ModalConfirmationService,
          useValue: modalConfirmationService,
        },
        { provide: TranslateService, useValue: translateServiceSpy },
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              paramMap: { get: () => null },
              queryParamMap: { get: () => null },
            },
          },
        },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(RanFilterDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('loads vendors on construction', () => {
    expect(ranFilterService.listFilterVendors$).toHaveBeenCalledTimes(1);
    expect(component.vendors()).toEqual([
      { vendor: 'Ericsson' },
      { vendor: 'Nokia' },
    ]);
  });

  it('capitalizes first letter of vendor names returned by the service', () => {
    ranFilterService.listFilterVendors$.and.returnValue(
      of([{ vendor: 'ericsson' }, { vendor: 'nokia' }])
    );

    fixture = TestBed.createComponent(RanFilterDetailsComponent);
    fixture.detectChanges();

    expect(component.vendors()).toEqual([
      { vendor: 'Ericsson' },
      { vendor: 'Nokia' },
    ]);
    expect(component.selectedVendor()).toBe('Ericsson');
  });

  // The base vendor mock does not contain Huawei, so the first entry is selected.
  it('triggers initial attribute load for the auto-selected vendor on construction', () => {
    expect(ranFilterService.listFilterQueryAttributes$).toHaveBeenCalledWith(
      undefined,
      'Ericsson',
      undefined,
      1,
      10
    );
  });

  describe('onVendorChange', () => {
    it('sets the selected vendor and resets search state', () => {
      component.searchTerm.set('test');
      component.searchResults.set([sampleAttr]);

      component.onVendorChange('Nokia');

      expect(component.selectedVendor()).toBe('Nokia');
      expect(component.searchTerm()).toBe('');
      expect(component.searchResults()).toEqual([]);
    });

    it('resets currentPage and searchTotalCount', () => {
      component.currentPage.set(5);
      component.searchTotalCount.set(100);

      component.onVendorChange('Nokia');

      expect(component.currentPage()).toBe(1);
      expect(component.searchTotalCount()).toBe(0);
    });

    it('triggers an attribute load for the new vendor', () => {
      ranFilterService.listFilterQueryAttributes$.calls.reset();

      component.onVendorChange('Nokia');

      expect(ranFilterService.listFilterQueryAttributes$).toHaveBeenCalledWith(
        undefined,
        'Nokia',
        undefined,
        1,
        10
      );
    });
  });

  describe('highlightPattern', () => {
    it('returns empty string for empty search term', () => {
      component.searchTerm.set('');
      expect(component.highlightPattern()).toBe('');
    });

    it('returns empty string for whitespace-only search term', () => {
      component.searchTerm.set('   ');
      expect(component.highlightPattern()).toBe('');
    });

    it('joins multiple words with pipe for regex alternation', () => {
      component.searchTerm.set('NE Cell');
      expect(component.highlightPattern()).toBe('NE|Cell');
    });

    it('handles extra whitespace between words', () => {
      component.searchTerm.set('  NE   Cell  ');
      expect(component.highlightPattern()).toBe('NE|Cell');
    });
  });

  describe('isFormValid', () => {
    it('returns false when filter name is empty', () => {
      component.filterName.set('');
      component.filterDescription.set('desc');
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition, sampleCpsCondition]);
      expect(component.isFormValid()).toBeFalse();
    });

    it('returns false when filter description is empty', () => {
      component.filterName.set('name');
      component.filterDescription.set('');
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition, sampleCpsCondition]);
      expect(component.isFormValid()).toBeFalse();
    });

    it('returns false when no vendor is selected', () => {
      component.filterName.set('name');
      component.filterDescription.set('desc');
      component.selectedVendor.set(undefined);
      component.selectedConditions.set([sampleCondition, sampleCpsCondition]);
      expect(component.isFormValid()).toBeFalse();
    });

    it('returns false when no conditions exist', () => {
      component.filterName.set('name');
      component.filterDescription.set('desc');
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([]);
      expect(component.isFormValid()).toBeFalse();
    });

    it('returns false when a condition has empty filterValue', () => {
      component.filterName.set('name');
      component.filterDescription.set('desc');
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([
        { ...sampleCondition, filterValue: '' },
        sampleCpsCondition,
      ]);
      expect(component.isFormValid()).toBeFalse();
    });

    it('returns false when a condition has a validation error', () => {
      component.filterName.set('name');
      component.filterDescription.set('desc');
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition, sampleCpsCondition]);
      component.conditionErrors.set(['integer', null]);
      expect(component.isFormValid()).toBeFalse();
    });

    it('returns false when no Topology (AAI) condition exists', () => {
      component.filterName.set('name');
      component.filterDescription.set('desc');
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCpsCondition]);
      component.conditionErrors.set([null]);
      expect(component.isFormValid()).toBeFalse();
    });

    it('returns true when only a Topology (AAI) condition exists', () => {
      component.filterName.set('name');
      component.filterDescription.set('desc');
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition]);
      component.conditionErrors.set([null]);
      expect(component.isFormValid()).toBeTrue();
    });

    it('returns true when all fields are valid and no condition errors', () => {
      component.filterName.set('name');
      component.filterDescription.set('desc');
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition, sampleCpsCondition]);
      component.conditionErrors.set([null, null]);
      expect(component.isFormValid()).toBeTrue();
    });
  });

  describe('isSaveEnabled', () => {
    beforeEach(() => {
      component.filterName.set('name');
      component.filterDescription.set('desc');
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition, sampleCpsCondition]);
      component.conditionErrors.set([null, null]);
    });

    it('returns false when form is invalid', () => {
      component.filterName.set('');
      component.verifySuccessful.set(true);
      expect(component.isSaveEnabled()).toBeFalse();
    });

    it('returns false when verify is not successful even if form is valid', () => {
      component.verifySuccessful.set(false);
      expect(component.isSaveEnabled()).toBeFalse();
    });

    it('returns true when both form is valid and verify is successful', () => {
      component.verifySuccessful.set(true);
      expect(component.isSaveEnabled()).toBeTrue();
    });
  });

  describe('onSearch', () => {
    it('does not call service when term is exactly 1 character', () => {
      component.selectedVendor.set('Ericsson');
      component.searchTerm.set('N');
      ranFilterService.listFilterQueryAttributes$.calls.reset();
      component.onSearch();
      expect(
        ranFilterService.listFilterQueryAttributes$
      ).not.toHaveBeenCalled();
    });

    it('does not call service when term is exactly 2 characters', () => {
      component.selectedVendor.set('Ericsson');
      component.searchTerm.set('NE');
      ranFilterService.listFilterQueryAttributes$.calls.reset();
      component.onSearch();
      expect(
        ranFilterService.listFilterQueryAttributes$
      ).not.toHaveBeenCalled();
    });

    it('does nothing when no vendor is selected', () => {
      component.selectedVendor.set(undefined);
      ranFilterService.listFilterQueryAttributes$.calls.reset();
      component.onSearch();
      expect(
        ranFilterService.listFilterQueryAttributes$
      ).not.toHaveBeenCalled();
    });

    it('calls service and updates search results on success', () => {
      const queryAttrs: QueryAttribute[] = [sampleAttr];
      const queryResult = { queryAttributes: queryAttrs, totalCount: 42 };
      ranFilterService.listFilterQueryAttributes$.and.returnValue(
        of(queryResult as any)
      );

      component.selectedVendor.set('Ericsson');
      component.searchTerm.set('equip');
      component.onSearch();

      expect(ranFilterService.listFilterQueryAttributes$).toHaveBeenCalledWith(
        undefined,
        'Ericsson',
        ['equip'],
        1,
        10
      );
      expect(component.searchResults()).toEqual(queryAttrs);
      expect(component.searchTotalCount()).toBe(42);
      expect(component.searchLoading()).toBeFalse();
    });

    it('splits multi-word search terms', () => {
      ranFilterService.listFilterQueryAttributes$.and.returnValue(
        of({ queryAttributes: [], totalCount: 0 } as any)
      );

      component.selectedVendor.set('Ericsson');
      component.searchTerm.set('NE Cell');
      component.onSearch();

      expect(ranFilterService.listFilterQueryAttributes$).toHaveBeenCalledWith(
        undefined,
        'Ericsson',
        ['NE', 'Cell'],
        1,
        10
      );
    });

    it('calls service with undefined search when term is empty', () => {
      ranFilterService.listFilterQueryAttributes$.and.returnValue(
        of({ queryAttributes: [], totalCount: 0 } as any)
      );
      component.selectedVendor.set('Ericsson');
      component.searchTerm.set('');
      ranFilterService.listFilterQueryAttributes$.calls.reset();
      component.onSearch();

      expect(ranFilterService.listFilterQueryAttributes$).toHaveBeenCalledWith(
        undefined,
        'Ericsson',
        undefined,
        1,
        10
      );
      expect(component.searchResults()).toEqual([]);
      expect(component.searchTotalCount()).toBe(0);
    });

    it('resets searchTotalCount to 0 on error', () => {
      ranFilterService.listFilterQueryAttributes$.and.returnValue(
        throwError(() => new Error('fail'))
      );

      component.selectedVendor.set('Ericsson');
      component.searchTerm.set('equip');
      component.searchTotalCount.set(99);
      component.onSearch();

      expect(component.searchTotalCount()).toBe(0);
    });

    it('clears results on error', () => {
      ranFilterService.listFilterQueryAttributes$.and.returnValue(
        throwError(() => new Error('fail'))
      );

      component.selectedVendor.set('Ericsson');
      component.searchTerm.set('equip');
      component.onSearch();

      expect(component.searchResults()).toEqual([]);
      expect(component.searchLoading()).toBeFalse();
    });

    it('sets empty array when response has no queryAttributes', () => {
      ranFilterService.listFilterQueryAttributes$.and.returnValue(
        of({ queryAttributes: undefined, totalCount: 0 } as any)
      );

      component.selectedVendor.set('Ericsson');
      component.searchTerm.set('node');
      component.onSearch();

      expect(component.searchResults()).toEqual([]);
    });
  });

  describe('onPageChange', () => {
    it('sets currentPage and triggers new search', () => {
      ranFilterService.listFilterQueryAttributes$.and.returnValue(
        of({ queryAttributes: [], totalCount: 0 } as any)
      );

      component.selectedVendor.set('Ericsson');
      component.searchTerm.set('cell');
      component.onPageChange(3);

      expect(component.currentPage()).toBe(3);
      expect(ranFilterService.listFilterQueryAttributes$).toHaveBeenCalledWith(
        undefined,
        'Ericsson',
        ['cell'],
        3,
        10
      );
    });
  });

  describe('onPageSizeChange', () => {
    it('sets pageLimit, resets page to 1 and triggers new search', () => {
      ranFilterService.listFilterQueryAttributes$.and.returnValue(
        of({ queryAttributes: [], totalCount: 0 } as any)
      );

      component.selectedVendor.set('Ericsson');
      component.searchTerm.set('cell');
      component.currentPage.set(4);
      component.onPageSizeChange(25);

      expect(component.pageLimit()).toBe(25);
      expect(component.currentPage()).toBe(1);
      expect(ranFilterService.listFilterQueryAttributes$).toHaveBeenCalledWith(
        undefined,
        'Ericsson',
        ['cell'],
        1,
        25
      );
    });
  });

  describe('addCondition', () => {
    it('adds a new condition from a AAI attribute', () => {
      component.addCondition(sampleAttr);

      const conditions = component.selectedConditions();
      expect(conditions).toHaveSize(1);
      expect(conditions[0].path).toBe('node.equipType');
      expect(conditions[0].source).toBe(RanFilterCondition.SourceEnum.AAI);
      expect(conditions[0].operator).toBe('=');
    });

    it('adds a new condition from a CPS attribute', () => {
      component.addCondition(sampleCpsAttr);

      const conditions = component.selectedConditions();
      expect(conditions[0].source).toBe(RanFilterCondition.SourceEnum.CPS);
    });

    it('does not add duplicate conditions', () => {
      component.addCondition(sampleAttr);
      component.addCondition(sampleAttr);

      expect(component.selectedConditions()).toHaveSize(1);
    });

    it('appends a null error entry for each new condition', () => {
      component.addCondition(sampleAttr);
      expect(component.conditionErrors()).toEqual([null]);

      component.addCondition(sampleCpsAttr);
      expect(component.conditionErrors()).toEqual([null, null]);
    });

    it('uses fallback values when attribute fields are undefined', () => {
      // Add an existing condition first so that some() callback runs
      component.addCondition(sampleAttr);
      component.addCondition({});

      const condition = component.selectedConditions()[1];
      expect(condition.path).toBe('');
      expect(condition.source).toBe(RanFilterCondition.SourceEnum.AAI);
      expect(condition.operator).toBe('');
      expect(condition.availableOperators).toEqual([]);
      expect(condition.conditionType).toBe('');
    });
  });

  describe('removeCondition', () => {
    it('removes the condition at the given index', () => {
      component.addCondition(sampleAttr);
      component.addCondition(sampleCpsAttr);
      expect(component.selectedConditions()).toHaveSize(2);

      component.removeCondition(0);

      const conditions = component.selectedConditions();
      expect(conditions).toHaveSize(1);
      expect(conditions[0].path).toBe('NE.neType');
    });

    it('also removes the path from checkedConditionIds', () => {
      component.addCondition(sampleAttr);
      component.addCondition(sampleCpsAttr);
      component.checkedConditionIds.set(['node.equipType', 'NE.neType']);

      component.removeCondition(0);

      expect(component.checkedConditionIds()).not.toContain('node.equipType');
      expect(component.checkedConditionIds()).toContain('NE.neType');
    });

    it('synchronizes conditionErrors when removing a condition', () => {
      component.addCondition(sampleAttr);
      component.addCondition(sampleCpsAttr);
      component.conditionErrors.set(['integer', null]);

      component.removeCondition(0);

      expect(component.conditionErrors()).toEqual([null]);
    });

    it('focuses the next delete button after removal', fakeAsync(() => {
      component.addCondition(sampleAttr);
      component.addCondition(sampleCpsAttr);

      const container = document.createElement('div');
      const btn0 = document.createElement('button');
      btn0.classList.add('qa_remove_condition_button');
      const btn1 = document.createElement('button');
      btn1.classList.add('qa_remove_condition_button');
      container.appendChild(btn0);
      container.appendChild(btn1);
      spyOn(btn0, 'focus');
      spyOn(btn1, 'focus');
      // Override the viewChild signal to return the mock container
      (component as any).conditionsTableSection = () => ({
        nativeElement: container,
      });

      component.removeCondition(0);
      tick(0);

      // After removing index 0, focus lands on buttons[Math.min(0, 1)] = btn0
      expect(btn0.focus).toHaveBeenCalled();
    }));

    it('focuses the last delete button when the last item is removed', fakeAsync(() => {
      component.addCondition(sampleAttr);
      component.addCondition(sampleCpsAttr);

      const container = document.createElement('div');
      const btn0 = document.createElement('button');
      btn0.classList.add('qa_remove_condition_button');
      container.appendChild(btn0);
      spyOn(btn0, 'focus');
      (component as any).conditionsTableSection = () => ({
        nativeElement: container,
      });

      component.removeCondition(1);
      tick(0);

      expect(btn0.focus).toHaveBeenCalled();
    }));

    it('falls back to chip buttons when table container is absent', fakeAsync(() => {
      component.addCondition(sampleAttr);
      component.addCondition(sampleCpsAttr);

      const chipsContainer = document.createElement('ul');
      const chipBtn = document.createElement('button');
      chipBtn.classList.add('qa_remove_condition_chip');
      chipsContainer.appendChild(chipBtn);
      spyOn(chipBtn, 'focus');
      (component as any).conditionsTableSection = () => undefined;
      (component as any).conditionsChipsList = () => ({
        nativeElement: chipsContainer,
      });

      component.removeCondition(0);
      tick(0);

      expect(chipBtn.focus).toHaveBeenCalled();
    }));
  });

  describe('updateConditionOperator', () => {
    it('updates the operator at the given index', () => {
      component.addCondition(sampleAttr);

      component.updateConditionOperator(0, '!=');

      expect(component.selectedConditions()[0].operator).toBe('!=');
    });

    describe('with a catalog value list', () => {
      const listedAttr: QueryAttribute = {
        ...sampleAttr,
        name: 'node.swVersion',
        operator: ['=', 'STARTSWITH', 'REGEX'],
        conditionValues: ['22.1.0', '22.2.0'],
      };

      it('drops the value list for a pattern operator', () => {
        component.addCondition(listedAttr);
        const offersList = () =>
          component
            .valueListConditions()
            .has(component.selectedConditions()[0]);
        expect(offersList()).withContext('=').toBeTrue();

        component.updateConditionOperator(0, 'STARTSWITH');

        expect(offersList()).toBeFalse();
      });

      it('accepts a pattern that is not a listed value', () => {
        component.addCondition(listedAttr);
        component.updateConditionOperator(0, 'REGEX');

        component.updateConditionValue(0, '^22\\.');

        expect(component.selectedConditions()[0].valueOutOfCatalog).toBeFalse();
        expect(component.hasStaleConditionSelections()).toBeFalse();
      });

      it('flags an unlisted value when switching back to an exact operator', () => {
        component.addCondition(listedAttr);
        component.updateConditionOperator(0, 'STARTSWITH');
        component.updateConditionValue(0, '22.');

        component.updateConditionOperator(0, '=');

        expect(component.selectedConditions()[0].valueOutOfCatalog).toBeTrue();
        expect(component.selectedConditions()[0].filterValue).toBe('22.');
      });

      it('keeps a listed value when switching to a pattern operator', () => {
        component.addCondition(listedAttr);
        component.updateConditionValue(0, '22.1.0');

        component.updateConditionOperator(0, 'STARTSWITH');

        expect(component.selectedConditions()[0].filterValue).toBe('22.1.0');
        expect(component.selectedConditions()[0].valueOutOfCatalog).toBeFalse();
      });
    });
  });

  describe('updateConditionValue', () => {
    it('updates the filter value at the given index', () => {
      component.addCondition(sampleAttr);

      component.updateConditionValue(0, 'newValue');

      expect(component.selectedConditions()[0].filterValue).toBe('newValue');
    });

    it('sets no error for string type condition', () => {
      component.addCondition({ ...sampleAttr, conditionType: 'string' });
      component.updateConditionValue(0, 'anyText');
      expect(component.conditionErrors()[0]).toBeNull();
    });

    it('sets no error for valid integer value', () => {
      component.addCondition({ ...sampleAttr, conditionType: 'integer' });
      component.updateConditionValue(0, '42');
      expect(component.conditionErrors()[0]).toBeNull();
    });

    it('sets no error for negative integer value', () => {
      component.addCondition({ ...sampleAttr, conditionType: 'integer' });
      component.updateConditionValue(0, '-7');
      expect(component.conditionErrors()[0]).toBeNull();
    });

    it('sets error for non-integer value with integer type', () => {
      component.addCondition({ ...sampleAttr, conditionType: 'integer' });
      component.updateConditionValue(0, 'abc');
      expect(component.conditionErrors()[0]).toBe('integer');
    });

    it('sets error for decimal value with integer type', () => {
      component.addCondition({ ...sampleAttr, conditionType: 'integer' });
      component.updateConditionValue(0, '3.14');
      expect(component.conditionErrors()[0]).toBe('integer');
    });

    it('sets no error for valid decimal number value', () => {
      component.addCondition({ ...sampleAttr, conditionType: 'number' });
      component.updateConditionValue(0, '3.14');
      expect(component.conditionErrors()[0]).toBeNull();
    });

    it('sets error for non-numeric value with number type', () => {
      component.addCondition({ ...sampleAttr, conditionType: 'number' });
      component.updateConditionValue(0, 'abc');
      expect(component.conditionErrors()[0]).toBe('number');
    });

    it('sets no error when value is empty regardless of type', () => {
      component.addCondition({ ...sampleAttr, conditionType: 'integer' });
      component.updateConditionValue(0, '');
      expect(component.conditionErrors()[0]).toBeNull();
    });
  });

  describe('updateConditionValue range validation', () => {
    const rangeAttr: QueryAttribute = {
      ...sampleAttr,
      conditionType: 'integer',
      rangeMin: 0,
      rangeMax: 1000,
    };

    it('sets no error for a value inside the range', () => {
      component.addCondition(rangeAttr);
      component.updateConditionValue(0, '500');
      expect(component.conditionErrors()[0]).toBeNull();
    });

    it('sets no error for values on the range boundaries', () => {
      component.addCondition(rangeAttr);

      component.updateConditionValue(0, '0');
      expect(component.conditionErrors()[0]).toBeNull();

      component.updateConditionValue(0, '1000');
      expect(component.conditionErrors()[0]).toBeNull();
    });

    it('sets a range error for a value above the maximum', () => {
      component.addCondition(rangeAttr);
      component.updateConditionValue(0, '1002');
      expect(component.conditionErrors()[0]).toBe('range');
    });

    it('sets a range error for a value below the minimum', () => {
      component.addCondition(rangeAttr);
      component.updateConditionValue(0, '-1');
      expect(component.conditionErrors()[0]).toBe('range');
    });

    it('reports the format error before the range error', () => {
      component.addCondition(rangeAttr);
      component.updateConditionValue(0, 'abc');
      expect(component.conditionErrors()[0]).toBe('integer');
    });

    it('sets no range error while only a minus sign is typed', () => {
      component.addCondition(rangeAttr);
      component.updateConditionValue(0, '-');
      expect(component.conditionErrors()[0]).toBeNull();
    });

    it('validates the range for number type attributes as well', () => {
      component.addCondition({
        ...rangeAttr,
        conditionType: 'number',
      });
      component.updateConditionValue(0, '1000.5');
      expect(component.conditionErrors()[0]).toBe('range');
    });

    it('ignores range metadata for non-numeric attributes', () => {
      component.addCondition({
        ...rangeAttr,
        conditionType: 'string',
      });

      const condition = component.selectedConditions()[0];
      expect(condition.rangeMin).toBeUndefined();
      expect(condition.rangeMax).toBeUndefined();

      component.updateConditionValue(0, '9999');
      expect(component.conditionErrors()[0]).toBeNull();
    });

    it('validates a minimum-only range', () => {
      component.addCondition({
        ...sampleAttr,
        conditionType: 'integer',
        rangeMin: 0,
        rangeMax: undefined,
      });

      const condition = component.selectedConditions()[0];
      expect(condition.rangeMin).toBe(0);
      expect(condition.rangeMax).toBeUndefined();

      component.updateConditionValue(0, '-50');
      expect(component.conditionErrors()[0]).toBe('rangeMin');

      component.updateConditionValue(0, '999999');
      expect(component.conditionErrors()[0]).toBeNull();
    });

    it('validates a maximum-only range', () => {
      component.addCondition({
        ...sampleAttr,
        conditionType: 'number',
        rangeMin: undefined,
        rangeMax: 30,
      });

      const condition = component.selectedConditions()[0];
      expect(condition.rangeMin).toBeUndefined();
      expect(condition.rangeMax).toBe(30);

      component.updateConditionValue(0, '30.5');
      expect(component.conditionErrors()[0]).toBe('rangeMax');

      component.updateConditionValue(0, '-999');
      expect(component.conditionErrors()[0]).toBeNull();
    });

    it('sets no error when no bound is provided at all', () => {
      component.addCondition({
        ...sampleAttr,
        conditionType: 'integer',
        rangeMin: undefined,
        rangeMax: undefined,
      });

      component.updateConditionValue(0, '-99999');
      expect(component.conditionErrors()[0]).toBeNull();
    });

    it('keeps the range metadata on the selected condition', () => {
      component.addCondition(rangeAttr);

      const condition = component.selectedConditions()[0];
      expect(condition.rangeMin).toBe(0);
      expect(condition.rangeMax).toBe(1000);
    });

    it('blocks saving while a range error is present', () => {
      component.filterName.set('name');
      component.filterDescription.set('desc');
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition, sampleCpsCondition]);
      component.conditionErrors.set(['range', null]);

      expect(component.isFormValid()).toBeFalse();
    });
  });

  describe('catalog metadata state', () => {
    const validForm = (conditions: SelectedCondition[]) => {
      component.filterName.set('name');
      component.filterDescription.set('desc');
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set(conditions);
      component.conditionErrors.set(conditions.map(() => null));
    };

    it('blocks saving when an attribute could not be resolved', () => {
      validForm([
        { ...sampleCondition, metadataResolved: false },
        sampleCpsCondition,
      ]);

      expect(component.isFormValid()).toBeFalse();
    });

    it('allows saving when every attribute was resolved', () => {
      validForm([
        { ...sampleCondition, metadataResolved: true },
        { ...sampleCpsCondition, metadataResolved: true },
      ]);

      expect(component.isFormValid()).toBeTrue();
    });

    it('blocks saving while the stored operator is out of catalog', () => {
      validForm([
        { ...sampleCondition, operatorOutOfCatalog: true },
        sampleCpsCondition,
      ]);

      expect(component.isFormValid()).toBeFalse();
    });

    it('reports unresolved conditions for the banner', () => {
      validForm([sampleCondition, sampleCpsCondition]);
      expect(component.hasUnresolvedConditions()).toBeFalse();

      validForm([
        { ...sampleCondition, metadataResolved: false },
        sampleCpsCondition,
      ]);
      expect(component.hasUnresolvedConditions()).toBeTrue();
    });

    it('clears the value flag once a new value is picked', () => {
      validForm([{ ...sampleCondition, valueOutOfCatalog: true }]);

      component.updateConditionValue(0, 'anything');

      expect(component.selectedConditions()[0].valueOutOfCatalog).toBeFalse();
    });

    it('clears the operator flag once a new operator is picked', () => {
      validForm([{ ...sampleCondition, operatorOutOfCatalog: true }]);

      component.updateConditionOperator(0, '!=');

      expect(
        component.selectedConditions()[0].operatorOutOfCatalog
      ).toBeFalse();
    });

    it('rejects a value that is not part of the catalog values', () => {
      validForm([
        {
          ...sampleCondition,
          conditionValues: ['a', 'b'],
          valueOutOfCatalog: true,
        },
      ]);

      expect(component.isFormValid()).toBeFalse();
      expect(component.hasStaleConditionSelections()).toBeTrue();
    });

    it('accepts a value that is part of the catalog values', () => {
      validForm([{ ...sampleCondition, conditionValues: ['a', 'b'] }]);

      component.updateConditionValue(0, 'a');

      expect(component.conditionErrors()[0]).toBeNull();
    });

    it('separates a failed lookup from a missing attribute in the banners', () => {
      validForm([
        {
          ...sampleCondition,
          metadataResolved: false,
          metadataLookupFailed: true,
        },
        sampleCpsCondition,
      ]);

      expect(component.hasFailedMetadataLookup()).toBeTrue();
      expect(component.hasUnresolvedConditions()).toBeFalse();
      expect(component.isFormValid()).toBeFalse();
    });

    it('re-runs the lookup on retry', () => {
      component.isEditMode.set(true);
      validForm([
        {
          ...sampleCondition,
          metadataResolved: false,
          metadataLookupFailed: true,
        },
      ]);
      ranFilterService.resolveQueryAttributes$.calls.reset();

      component.retryConditionMetadata();

      expect(ranFilterService.resolveQueryAttributes$).toHaveBeenCalledWith(
        'Ericsson',
        component.selectedConditions()
      );
    });

    it('moves focus into the conditions table when the retry succeeds', fakeAsync(() => {
      component.isEditMode.set(true);
      validForm([
        {
          ...sampleCondition,
          metadataResolved: false,
          metadataLookupFailed: true,
        },
      ]);

      const container = document.createElement('div');
      const button = document.createElement('button');
      button.classList.add('qa_remove_condition_button');
      container.appendChild(button);
      spyOn(button, 'focus');
      (component as any).conditionsTableSection = () => ({
        nativeElement: container,
      });

      component.retryConditionMetadata();
      tick(0);

      // The retry button disappears with its banner, so focus must not fall to <body>
      expect(button.focus).toHaveBeenCalled();
    }));
  });

  describe('onSave', () => {
    beforeEach(() => {
      component.filterName.set('Test Filter');
      component.filterDescription.set('Test Description');
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition, sampleCpsCondition]);
      component.conditionErrors.set([null, null]);
      component.verifySuccessful.set(true);
      ranFilterService.buildRanFilter.and.returnValue({
        filterId: 0,
        filterName: 'Test Filter',
        filterDescription: 'Test Description',
        vendor: 'Ericsson',
        conditions: [],
        owner: 'Portal',
      });
    });

    it('does nothing when form is invalid', () => {
      component.filterName.set('');
      component.onSave();
      expect(ranFilterService.saveRanFilter$).not.toHaveBeenCalled();
    });

    it('saves the filter and navigates on success', () => {
      ranFilterService.saveRanFilter$.and.returnValue(of(undefined));

      component.onSave();

      expect(component.saving()).toBeFalse();
      expect(alertService.success).toHaveBeenCalledWith(
        'ranFilter.create.saveSuccess',
        { keepAfterRouteChange: true }
      );
      expect(ranFilterService.refreshRanFilters).toHaveBeenCalled();
      expect(router.navigate).toHaveBeenCalledWith(['/ran-filter']);
    });

    it('resets saving state on save failure', () => {
      ranFilterService.saveRanFilter$.and.returnValue(
        throwError(() => new Error('fail'))
      );

      component.onSave();

      expect(component.saving()).toBeFalse();
    });
  });

  describe('onVerifyFilter', () => {
    beforeEach(() => {
      component.filterName.set('Test Filter');
      component.filterDescription.set('Test Description');
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition, sampleCpsCondition]);
      component.conditionErrors.set([null, null]);
      ranFilterService.verifyFilter = jasmine
        .createSpy('verifyFilterGrpc')
        .and.returnValue(of({}));
    });

    it('does nothing when the condition set is invalid', () => {
      component.selectedConditions.set([]);
      component.onVerifyFilter();
      expect(ranFilterService.verifyFilter).not.toHaveBeenCalled();
    });

    it('verifies without filter name and description', () => {
      component.filterName.set('');
      component.filterDescription.set('');

      component.onVerifyFilter();

      expect(ranFilterService.verifyFilter).toHaveBeenCalledTimes(1);
    });

    it('verifies the filter and sets result on success', () => {
      const result = { success: true, items: [{ id: 1 }] };
      ranFilterService.verifyFilter.and.returnValue(of(result as any));

      component.onVerifyFilter();

      expect(component.verifying()).toBeFalse();
      expect(component.verifyResult()).toEqual(result);
      expect(component.verifySuccessful()).toBeTrue();
      expect(alertService.success).toHaveBeenCalledWith(
        'ranFilter.create.verifySuccess'
      );
    });

    it('opens the result modal on success', () => {
      ranFilterService.verifyFilter.and.returnValue(of({} as any));

      component.onVerifyFilter();

      expect(resultPanels()).toHaveSize(1);
    });

    it('reuses the open modal instead of stacking overlays', () => {
      ranFilterService.verifyFilter.and.returnValue(of({} as any));
      component.onVerifyFilter();

      component.onVerifyFilter();

      expect(resultPanels()).toHaveSize(1);
    });

    it('does not open the modal when the verification fails', () => {
      ranFilterService.verifyFilter.and.returnValue(
        throwError(() => new Error('fail'))
      );

      component.onVerifyFilter();

      expect(resultPanels()).toHaveSize(0);
    });

    it('passes impactOnly=true when showNodes is false (default)', () => {
      component.showNodes.set(false);
      component.onVerifyFilter();
      expect(ranFilterService.verifyFilter).toHaveBeenCalledWith(
        jasmine.objectContaining({ impactOnly: true }),
        false
      );
    });

    it('passes impactOnly=false when showNodes is true', () => {
      component.showNodes.set(true);
      component.onVerifyFilter();
      expect(ranFilterService.verifyFilter).toHaveBeenCalledWith(
        jasmine.objectContaining({ impactOnly: false }),
        false
      );
    });

    it('resets state on verify failure', () => {
      ranFilterService.verifyFilter.and.returnValue(
        throwError(() => new Error('fail'))
      );

      component.onVerifyFilter();

      expect(component.verifying()).toBeFalse();
      expect(component.verifySuccessful()).toBeFalse();
    });
  });

  describe('showNodes', () => {
    it('starts as false by default', () => {
      expect(component.showNodes()).toBeFalse();
    });
  });

  describe('onShowNodesChange', () => {
    const impactResult = { payload: [{ impact: { nodes: 39, cells: 831 } }] };
    const nodesResult = {
      payload: [
        { impact: { nodes: 39, cells: 831 }, nodeDataList: [{ id: 1 }] },
      ],
    };

    /** The checkbox lives inside the result modal, so a verify run has to open it first. */
    const openResultModal = (): void => {
      ranFilterService.verifyFilter.and.returnValue(of(impactResult as any));
      component.onVerifyFilter();
      ranFilterService.verifyFilter.calls.reset();
      alertService.success.calls.reset();
    };

    beforeEach(() => {
      component.filterName.set('Test Filter');
      component.filterDescription.set('Test Description');
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition, sampleCpsCondition]);
      component.conditionErrors.set([null, null]);
      ranFilterService.verifyFilter = jasmine
        .createSpy('verifyFilter')
        .and.returnValue(of(impactResult));
    });

    it('updates the showNodes signal', () => {
      component.onShowNodesChange(true);
      expect(component.showNodes()).toBeTrue();
      component.onShowNodesChange(false);
      expect(component.showNodes()).toBeFalse();
    });

    it('does not request anything while no result modal is open', () => {
      component.onShowNodesChange(true);
      expect(ranFilterService.verifyFilter).not.toHaveBeenCalled();
    });

    it('fetches the node variant once when switched on', () => {
      openResultModal();
      ranFilterService.verifyFilter.and.returnValue(of(nodesResult as any));

      component.onShowNodesChange(true);

      expect(ranFilterService.verifyFilter).toHaveBeenCalledTimes(1);
      expect(ranFilterService.verifyFilter).toHaveBeenCalledWith(
        jasmine.objectContaining({ impactOnly: false }),
        true
      );
      expect(component.verifyResult()).toEqual(nodesResult);
    });

    it('serves the impact variant from cache when switched back off', () => {
      openResultModal();
      ranFilterService.verifyFilter.and.returnValue(of(nodesResult as any));
      component.onShowNodesChange(true);
      ranFilterService.verifyFilter.calls.reset();

      component.onShowNodesChange(false);

      expect(ranFilterService.verifyFilter).not.toHaveBeenCalled();
      expect(component.verifyResult()).toEqual(impactResult);
    });

    it('serves the node variant from cache when switched on again', () => {
      openResultModal();
      ranFilterService.verifyFilter.and.returnValue(of(nodesResult as any));
      component.onShowNodesChange(true);
      component.onShowNodesChange(false);
      ranFilterService.verifyFilter.calls.reset();

      component.onShowNodesChange(true);

      expect(ranFilterService.verifyFilter).not.toHaveBeenCalled();
      expect(component.verifyResult()).toEqual(nodesResult);
    });

    it('keeps the filter verified and raises no second success alert', () => {
      openResultModal();
      ranFilterService.verifyFilter.and.returnValue(of(nodesResult as any));

      component.onShowNodesChange(true);

      expect(component.verifySuccessful()).toBeTrue();
      expect(component.verifying()).toBeFalse();
      expect(alertService.success).not.toHaveBeenCalled();
    });

    it('reverts the checkbox when the node fetch fails', () => {
      openResultModal();
      ranFilterService.verifyFilter.and.returnValue(
        throwError(() => new Error('fail'))
      );

      component.onShowNodesChange(true);

      expect(component.showNodes()).toBeFalse();
      expect(component.verifyResult()).toEqual(impactResult);
      expect(component.verifySuccessful()).toBeTrue();
    });

    it('re-requests both variants after a fresh verify run', () => {
      openResultModal();
      ranFilterService.verifyFilter.and.returnValue(of(nodesResult as any));
      component.onShowNodesChange(true);
      component.onShowNodesChange(false);
      ranFilterService.verifyFilter.calls.reset();

      component.onVerifyFilter();
      ranFilterService.verifyFilter.calls.reset();
      component.onShowNodesChange(true);

      expect(ranFilterService.verifyFilter).toHaveBeenCalledTimes(1);
    });

    it('drops the cache when a condition changes', () => {
      openResultModal();
      component.updateConditionValue(0, 'changed');
      component.onShowNodesChange(false);

      expect(ranFilterService.verifyFilter).toHaveBeenCalledTimes(1);
    });
  });

  describe('result modal show-nodes state', () => {
    const showNodesCheckbox = (): HTMLInputElement | null =>
      document.querySelector<HTMLInputElement>(
        '.qa_show_nodes_checkbox input[type="checkbox"]'
      );

    beforeEach(() => {
      component.filterName.set('Test Filter');
      component.filterDescription.set('Test Description');
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition, sampleCpsCondition]);
      component.conditionErrors.set([null, null]);
      ranFilterService.verifyFilter = jasmine
        .createSpy('verifyFilter')
        .and.returnValue(of({}));
    });

    it('renders the checkbox checked while node data is shown', () => {
      component.onVerifyFilter();
      component.onShowNodesChange(true);
      fixture.detectChanges();

      expect(showNodesCheckbox()?.checked).toBeTrue();
    });

    it('reopens impact-only after the modal was closed with nodes shown', () => {
      component.onVerifyFilter();
      component.onShowNodesChange(true);
      component.clearExecuteResult();

      expect(component.showNodes()).toBeFalse();

      ranFilterService.verifyFilter.calls.reset();
      component.onVerifyFilter();
      fixture.detectChanges();

      expect(ranFilterService.verifyFilter).toHaveBeenCalledWith(
        jasmine.objectContaining({ impactOnly: true }),
        false
      );
      expect(showNodesCheckbox()?.checked).toBeFalse();
    });
  });

  describe('toggle methods', () => {
    it('toggleLeftPaneExpand toggles the expanded state', () => {
      expect(component.leftPaneExpanded()).toBeFalse();
      component.toggleLeftPaneExpand();
      expect(component.leftPaneExpanded()).toBeTrue();
      component.toggleLeftPaneExpand();
      expect(component.leftPaneExpanded()).toBeFalse();
    });
  });

  describe('clearExecuteResult', () => {
    it('clears the execute result', () => {
      component.verifyResult.set({ items: [] });
      component.clearExecuteResult();
      expect(component.verifyResult()).toBeUndefined();
    });

    it('disposes the result modal', () => {
      ranFilterService.verifyFilter = jasmine
        .createSpy('verifyFilter')
        .and.returnValue(of({}));
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition]);
      component.conditionErrors.set([null]);
      component.onVerifyFilter();
      expect(resultPanels()).toHaveSize(1);

      component.clearExecuteResult();

      expect(resultPanels()).toHaveSize(0);
    });

    it('keeps verifySuccessful so the filter can still be saved', () => {
      component.verifySuccessful.set(true);
      component.clearExecuteResult();
      expect(component.verifySuccessful()).toBeTrue();
    });
  });

  describe('vendor radio group', () => {
    const radios = (): HTMLInputElement[] =>
      Array.from(
        (
          fixture.nativeElement as HTMLElement
        ).querySelectorAll<HTMLInputElement>('.qa_vendor_radio')
      );

    const checkedVendors = (): string[] =>
      radios()
        .filter(radio => radio.checked)
        .map(radio => radio.value);

    const selectVendorRadio = (vendor: string): void => {
      const radio = radios().find(entry => entry.value === vendor)!;
      radio.checked = true;
      radio.dispatchEvent(new Event('change'));
      fixture.detectChanges();
    };

    it('renders one radio per vendor', () => {
      expect(radios()).toHaveSize(2);
      expect(radios().map(radio => radio.value)).toEqual(['Ericsson', 'Nokia']);
    });

    it('checks the selected vendor', () => {
      expect(checkedVendors()).toEqual(['Ericsson']);
    });

    it('applies the vendor change when another radio is selected', () => {
      selectVendorRadio('Nokia');

      expect(component.selectedVendor()).toBe('Nokia');
      expect(checkedVendors()).toEqual(['Nokia']);
    });

    it('restores the radio state when the vendor change is not confirmed', () => {
      modalConfirmationService.openConfirmationModal.and.returnValue(of(false));
      component.selectedConditions.set([sampleCondition]);
      fixture.detectChanges();

      selectVendorRadio('Nokia');

      expect(component.selectedVendor()).toBe('Ericsson');
      expect(checkedVendors()).toEqual(['Ericsson']);
    });
  });

  describe('filter requirements', () => {
    const setValidConditions = (): void => {
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition]);
      component.conditionErrors.set([null]);
    };

    it('is not verifiable without a topology condition', () => {
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCpsCondition]);
      component.conditionErrors.set([null]);

      expect(component.hasTopologyCondition()).toBeFalse();
      expect(component.isConditionSetValid()).toBeFalse();
    });

    it('is verifiable without filter name and description', () => {
      setValidConditions();

      expect(component.hasTopologyCondition()).toBeTrue();
      expect(component.isConditionSetValid()).toBeTrue();
      expect(component.isFormValid()).toBeFalse();
    });

    it('requires name and description for a valid form', () => {
      setValidConditions();
      component.filterName.set('Name');
      component.filterDescription.set('Description');

      expect(component.isFormValid()).toBeTrue();
    });

    it('reports an empty condition value as unfilled', () => {
      component.selectedConditions.set([
        { ...sampleCondition, filterValue: '' },
      ]);
      component.conditionErrors.set([null]);

      expect(component.hasAllConditionValues()).toBeFalse();
    });

    it('reports a condition validation error as unfilled', () => {
      setValidConditions();
      component.conditionErrors.set(['integer']);

      expect(component.hasAllConditionValues()).toBeFalse();
    });

    it('reports filled condition values', () => {
      setValidConditions();

      expect(component.hasAllConditionValues()).toBeTrue();
    });
  });

  describe('save validation', () => {
    it('flags name and description only after a save attempt', () => {
      expect(component.filterNameInvalid()).toBeFalse();
      expect(component.filterDescriptionInvalid()).toBeFalse();

      component.onSave();

      expect(component.saveAttempted()).toBeTrue();
      expect(component.filterNameInvalid()).toBeTrue();
      expect(component.filterDescriptionInvalid()).toBeTrue();
    });

    it('shows the checklist errors only after a save attempt', () => {
      expect(component.showRequirementErrors()).toBeFalse();

      component.onSave();

      expect(component.showRequirementErrors()).toBeTrue();
    });

    it('does not save an unverified filter', () => {
      component.filterName.set('Name');
      component.filterDescription.set('Description');
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition]);
      component.conditionErrors.set([null]);
      component.verifySuccessful.set(false);

      component.onSave();

      expect(ranFilterService.saveRanFilter$).not.toHaveBeenCalled();
    });

    it('keeps the save button clickable while saving is not enabled', () => {
      expect(component.isSaveEnabled()).toBeFalse();

      const saveButton = fixture.debugElement.query(By.css('.qa_save_button'));

      expect(
        saveButton.injector.get(MockTnapButtonDirective).disabled
      ).toBeFalse();
    });
  });

  describe('verification lifecycle', () => {
    beforeEach(() => {
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition]);
      component.conditionErrors.set([null]);
      component.verifySuccessful.set(true);
    });

    it('drops the verified state when a condition is added', () => {
      component.addCondition(sampleCpsAttr);

      expect(component.verifySuccessful()).toBeFalse();
    });

    it('drops the verified state when a value changes', () => {
      component.updateConditionValue(0, 'micro');

      expect(component.verifySuccessful()).toBeFalse();
    });

    it('drops the verified state when an operator changes', () => {
      component.updateConditionOperator(0, '!=');

      expect(component.verifySuccessful()).toBeFalse();
    });

    it('drops the verified state when a condition is removed', () => {
      component.removeCondition(0);

      expect(component.verifySuccessful()).toBeFalse();
    });

    it('drops the verified state when checked conditions are removed', () => {
      component.checkedConditionIds.set([sampleCondition.path]);

      component.removeSelectedConditions();

      expect(component.verifySuccessful()).toBeFalse();
    });

    it('drops the verified state when the vendor changes', () => {
      component.onVendorChange('Nokia');

      expect(component.verifySuccessful()).toBeFalse();
    });

    it('keeps the verified state when the result panel is closed', () => {
      component.verifyResult.set({ items: [] });

      component.clearExecuteResult();

      expect(component.verifyResult()).toBeUndefined();
      expect(component.verifySuccessful()).toBeTrue();
    });
  });

  describe('ready to verify alert', () => {
    const makeVerifiable = (): void => {
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition]);
      component.conditionErrors.set([null]);
      component.updateConditionValue(0, sampleCondition.filterValue);
      fixture.detectChanges();
    };

    const failVerification = (): void => {
      ranFilterService.verifyFilter = jasmine
        .createSpy('verifyFilter')
        .and.returnValue(throwError(() => new Error('failed')));
    };

    it('announces the state once when the filter becomes verifiable', () => {
      makeVerifiable();

      expect(component.showReadyToVerify()).toBeTrue();
      expect(alertService.info).toHaveBeenCalledOnceWith(
        'ranFilter.create.requirements.readyToVerify',
        { autoClose: true }
      );

      alertService.info.calls.reset();
      component.filterName.set('Name');
      fixture.detectChanges();

      expect(alertService.info).not.toHaveBeenCalled();
    });

    it('does not announce a filter the user has not edited', () => {
      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition]);
      component.conditionErrors.set([null]);
      fixture.detectChanges();

      expect(component.isConditionSetValid()).toBeTrue();
      expect(component.showReadyToVerify()).toBeFalse();
      expect(alertService.info).not.toHaveBeenCalled();
    });

    it('does not announce after a failed verification', () => {
      failVerification();
      makeVerifiable();
      alertService.info.calls.reset();

      component.onVerifyFilter();
      fixture.detectChanges();

      expect(component.verifySuccessful()).toBeFalse();
      expect(component.showReadyToVerify()).toBeFalse();
      expect(alertService.info).not.toHaveBeenCalled();
    });

    it('announces again when the user edits after a failed verification', () => {
      failVerification();
      makeVerifiable();
      component.onVerifyFilter();
      fixture.detectChanges();
      alertService.info.calls.reset();

      component.updateConditionValue(0, 'changed');
      fixture.detectChanges();

      expect(alertService.info).toHaveBeenCalledOnceWith(
        'ranFilter.create.requirements.readyToVerify',
        { autoClose: true }
      );
    });

    it('stops announcing once the component is destroyed', () => {
      fixture.destroy();

      component.selectedVendor.set('Ericsson');
      component.selectedConditions.set([sampleCondition]);
      component.conditionErrors.set([null]);

      expect(alertService.info).not.toHaveBeenCalled();
    });

    it('does not announce an already verified filter', () => {
      makeVerifiable();
      alertService.info.calls.reset();

      component.verifySuccessful.set(true);
      fixture.detectChanges();

      expect(component.showReadyToVerify()).toBeFalse();
      expect(alertService.info).not.toHaveBeenCalled();
    });
  });

  describe('onCancel', () => {
    it('navigates back to the filter list', () => {
      component.onCancel();
      expect(router.navigate).toHaveBeenCalledWith(['/ran-filter']);
    });
  });

  describe('searchResultColumns', () => {
    it('exposes seven columns with correct keys', () => {
      const columns = component.searchResultColumns();
      expect(columns.map(c => c.key)).toEqual([
        'source',
        'moc',
        'name',
        'attribute',
        'type',
        'description',
        'actions',
      ]);
    });
  });

  describe('conditionColumns', () => {
    it('exposes nine columns with correct keys', () => {
      const columns = component.conditionColumns();
      expect(columns.map(c => c.key)).toEqual([
        'source',
        'moc',
        'path',
        'attribute',
        'description',
        'type',
        'operator',
        'filterValue',
        'actions',
      ]);
    });
  });

  describe('searchResultsData', () => {
    it('wraps search results in data format', () => {
      component.searchResults.set([sampleAttr]);
      const data = component.searchResultsData();
      expect(data.items).toEqual([sampleAttr]);
      expect(data.totalCount).toBe(1);
    });
  });

  describe('gridTemplateColumns', () => {
    it('returns split layout when pane is collapsed', () => {
      component.leftPaneExpanded.set(false);
      expect(component.gridTemplateColumns()).toMatch(/^\d+% 15px 1fr$/);
    });

    it('returns 1fr when pane is expanded', () => {
      component.leftPaneExpanded.set(true);
      expect(component.gridTemplateColumns()).toBe('1fr');
    });
  });

  describe('searchResultColumns value functions', () => {
    it('return the row property when defined', () => {
      const columns = component.searchResultColumns();
      const fullRow: QueryAttribute = {
        source: 'AAI',
        moc: 'NE',
        name: 'attrName',
        mocAttribute: 'mocAttr',
        conditionType: 'string',
        description: 'A description',
      };
      expect(columns[0].value(fullRow)).toBe('AAI');
      expect(columns[1].value(fullRow)).toBe('NE');
      expect(columns[2].value(fullRow)).toBe('attrName');
      expect(columns[3].value(fullRow)).toBe('mocAttr');
      expect(columns[4].value(fullRow)).toBe('string');
      expect(columns[5].value(fullRow)).toBe('A description');
    });

    it('return empty string when row property is undefined', () => {
      const columns = component.searchResultColumns();
      const emptyRow: QueryAttribute = {};
      expect(columns[0].value(emptyRow)).toBe('');
      expect(columns[1].value(emptyRow)).toBe('');
      expect(columns[2].value(emptyRow)).toBe('');
      expect(columns[3].value(emptyRow)).toBe('');
      expect(columns[4].value(emptyRow)).toBe('');
      expect(columns[5].value(emptyRow)).toBe('');
    });
  });

  it('selects Huawei as default vendor after loading vendors', () => {
    ranFilterService.listFilterVendors$.and.returnValue(
      of([{ vendor: 'Ericsson' }, { vendor: 'Huawei' }, { vendor: 'Nokia' }])
    );

    fixture = TestBed.createComponent(RanFilterDetailsComponent);
    fixture.detectChanges();

    expect(fixture.componentInstance.selectedVendor()).toBe('Huawei');
  });

  it('matches the default vendor case-insensitively', () => {
    ranFilterService.listFilterVendors$.and.returnValue(
      of([{ vendor: 'ericsson' }, { vendor: 'huawei' }])
    );

    fixture = TestBed.createComponent(RanFilterDetailsComponent);
    fixture.detectChanges();

    expect(fixture.componentInstance.selectedVendor()).toBe('Huawei');
  });

  it('falls back to first vendor when default vendor is not in the list', () => {
    ranFilterService.listFilterVendors$.and.returnValue(
      of([{ vendor: 'Nokia' }, { vendor: 'Ericsson' }])
    );

    fixture = TestBed.createComponent(RanFilterDetailsComponent);
    fixture.detectChanges();

    expect(fixture.componentInstance.selectedVendor()).toBe('Nokia');
  });

  describe('addedConditionPaths', () => {
    it('returns a Set containing all current condition paths', () => {
      component.selectedConditions.set([sampleCondition]);
      expect(component.addedConditionPaths().has('node.equipType')).toBeTrue();
      expect(component.addedConditionPaths().has('other')).toBeFalse();
    });

    it('returns an empty Set when no conditions exist', () => {
      expect(component.addedConditionPaths().size).toBe(0);
    });
  });

  describe('hasCheckedConditions', () => {
    it('returns false when no conditions are checked', () => {
      expect(component.hasCheckedConditions()).toBeFalse();
    });

    it('returns true when at least one condition id is checked', () => {
      component.checkedConditionIds.set(['node.equipType']);
      expect(component.hasCheckedConditions()).toBeTrue();
    });
  });

  describe('onConditionRowCheckChange', () => {
    it('adds the id when checked is true', () => {
      component.onConditionRowCheckChange({
        row: sampleCondition,
        checked: true,
        id: 'node.equipType',
      });
      expect(component.checkedConditionIds()).toContain('node.equipType');
    });

    it('removes the id when checked is false', () => {
      component.checkedConditionIds.set(['node.equipType']);
      component.onConditionRowCheckChange({
        row: sampleCondition,
        checked: false,
        id: 'node.equipType',
      });
      expect(component.checkedConditionIds()).not.toContain('node.equipType');
    });

    it('does not affect other checked ids when unchecking one', () => {
      component.checkedConditionIds.set(['node.equipType', 'NE.neType']);
      component.onConditionRowCheckChange({
        row: sampleCondition,
        checked: false,
        id: 'node.equipType',
      });
      expect(component.checkedConditionIds()).toContain('NE.neType');
    });
  });

  describe('onAllConditionsCheckChange', () => {
    beforeEach(() => {
      component.selectedConditions.set([
        sampleCondition,
        {
          ...sampleCondition,
          path: 'NE.neType',
          source: RanFilterCondition.SourceEnum.CPS,
        },
      ]);
    });

    it('selects all condition paths when checked is true', () => {
      component.onAllConditionsCheckChange(true);
      expect(component.checkedConditionIds()).toEqual([
        'node.equipType',
        'NE.neType',
      ]);
    });

    it('clears all checked ids when checked is false', () => {
      component.checkedConditionIds.set(['node.equipType', 'NE.neType']);
      component.onAllConditionsCheckChange(false);
      expect(component.checkedConditionIds()).toEqual([]);
    });
  });

  describe('removeSelectedConditions', () => {
    const secondCondition: SelectedCondition = {
      path: 'NE.neType',
      source: RanFilterCondition.SourceEnum.CPS,
      operator: '=',
      filterValue: 'val',
      availableOperators: ['='],
      conditionType: 'string',
    };

    beforeEach(() => {
      component.selectedConditions.set([sampleCondition, secondCondition]);
      component.conditionErrors.set([null, 'integer']);
    });

    it('removes only the checked conditions', () => {
      component.checkedConditionIds.set(['node.equipType']);
      component.removeSelectedConditions();

      const remaining = component.selectedConditions();
      expect(remaining).toHaveSize(1);
      expect(remaining[0].path).toBe('NE.neType');
    });

    it('preserves conditionErrors for remaining conditions', () => {
      component.checkedConditionIds.set(['node.equipType']);
      component.removeSelectedConditions();

      expect(component.conditionErrors()).toEqual(['integer']);
    });

    it('clears checkedConditionIds after removal', () => {
      component.checkedConditionIds.set(['node.equipType']);
      component.removeSelectedConditions();

      expect(component.checkedConditionIds()).toEqual([]);
    });

    it('removes all conditions when all are selected', () => {
      component.checkedConditionIds.set(['node.equipType', 'NE.neType']);
      component.removeSelectedConditions();

      expect(component.selectedConditions()).toEqual([]);
      expect(component.conditionErrors()).toEqual([]);
    });

    it('does nothing to conditions when checkedConditionIds is empty', () => {
      component.checkedConditionIds.set([]);
      component.removeSelectedConditions();

      expect(component.selectedConditions()).toHaveSize(2);
    });

    it('focuses the first remaining delete button after bulk removal', fakeAsync(() => {
      component.checkedConditionIds.set(['node.equipType']);

      const container = document.createElement('div');
      const btn = document.createElement('button');
      btn.classList.add('qa_remove_condition_button');
      container.appendChild(btn);
      spyOn(btn, 'focus');
      (component as any).conditionsTableSection = () => ({
        nativeElement: container,
      });

      component.removeSelectedConditions();
      tick(0);

      expect(btn.focus).toHaveBeenCalled();
    }));
  });

  describe('conditionsData', () => {
    it('wraps conditions in data format', () => {
      component.selectedConditions.set([sampleCondition]);
      const data = component.conditionsData();
      expect(data.items).toEqual([sampleCondition]);
      expect(data.totalCount).toBe(1);
    });
  });

  describe('noDataMessageForCards', () => {
    it('returns noResults when search term is shorter than 3 characters', () => {
      component.searchTerm.set('');
      expect(component.noDataMessageForCards()).toBe(
        'common.filters.noResults'
      );

      component.searchTerm.set('NE');
      expect(component.noDataMessageForCards()).toBe(
        'common.filters.noResults'
      );
    });

    it('returns noFilterResults when search term is 3 or more characters', () => {
      component.searchTerm.set('NEC');
      expect(component.noDataMessageForCards()).toBe(
        'common.filters.noFilterResults'
      );

      component.searchTerm.set('cell type');
      expect(component.noDataMessageForCards()).toBe(
        'common.filters.noFilterResults'
      );
    });
  });

  describe('vendorItems', () => {
    it('maps vendors to segmented control items with label and value', () => {
      component.vendors.set([{ vendor: 'Ericsson' }, { vendor: 'Nokia' }]);
      const items = component.vendorItems();
      expect(items).toEqual([
        { label: 'Ericsson', value: 'Ericsson' },
        { label: 'Nokia', value: 'Nokia' },
      ]);
    });

    it('uses empty string for vendors with undefined name', () => {
      component.vendors.set([{ vendor: undefined }]);
      const items = component.vendorItems();
      expect(items[0].label).toBe('');
      expect(items[0].value).toBe('');
    });
  });

  describe('conditionsHintDismissed', () => {
    it('conditionsHintDismissed starts as false', () => {
      expect(component.conditionsHintDismissed()).toBeFalse();
    });

    it('conditionsHintDismissed can be set to true', () => {
      component.conditionsHintDismissed.set(true);
      expect(component.conditionsHintDismissed()).toBeTrue();
    });
  });

  describe('sources', () => {
    it('exposes all three source values in order', () => {
      expect(component.sources).toEqual(RAN_FILTER_SOURCES);
    });

    it('builds one segmented control item per source', () => {
      expect(component.sourceItems()).toEqual(
        RAN_FILTER_SOURCES.map(source => ({
          label: `ranFilter.sourceLabels.${source}`,
          value: source,
        }))
      );
    });
  });

  describe('selectedSource', () => {
    it('defaults to undefined on initialisation', () => {
      expect(component.selectedSource()).toBeUndefined();
    });

    it('can be changed to CPS', () => {
      component.selectedSource.set('CPS');
      expect(component.selectedSource()).toBe('CPS');
    });

    it('can be changed to PLANNING', () => {
      component.selectedSource.set('PLANNING');
      expect(component.selectedSource()).toBe('PLANNING');
    });

    it('is not reset when the vendor changes without conditions', () => {
      component.selectedSource.set('CPS');
      component.selectedConditions.set([]);
      component.onVendorChange('Nokia');
      expect(component.selectedSource()).toBe('CPS');
    });

    it('is not reset when vendor changes are confirmed via modal', () => {
      component.selectedSource.set('CPS');
      component.selectedConditions.set([sampleCondition]);
      modalConfirmationService.openConfirmationModal.and.returnValue(of(true));

      component.onVendorChange('Nokia');

      expect(component.selectedSource()).toBe('CPS');
    });
  });

  describe('onSearch source guard', () => {
    it('passes CPS source as first argument to the service', () => {
      ranFilterService.listFilterQueryAttributes$.and.returnValue(
        of({ queryAttributes: [], totalCount: 0 } as any)
      );
      component.selectedVendor.set('Ericsson');
      component.selectedSource.set('CPS');
      component.searchTerm.set('');
      ranFilterService.listFilterQueryAttributes$.calls.reset();
      component.onSearch();
      expect(ranFilterService.listFilterQueryAttributes$).toHaveBeenCalledWith(
        'CPS',
        'Ericsson',
        undefined,
        1,
        10
      );
    });

    it('passes PLANNING source as first argument to the service', () => {
      ranFilterService.listFilterQueryAttributes$.and.returnValue(
        of({ queryAttributes: [], totalCount: 0 } as any)
      );
      component.selectedVendor.set('Ericsson');
      component.selectedSource.set('PLANNING');
      component.searchTerm.set('node');
      ranFilterService.listFilterQueryAttributes$.calls.reset();
      component.onSearch();
      expect(ranFilterService.listFilterQueryAttributes$).toHaveBeenCalledWith(
        'PLANNING',
        'Ericsson',
        ['node'],
        1,
        10
      );
    });
  });

  describe('onSourceChange', () => {
    it('sets selectedSource to the given value', () => {
      component.onSourceChange('CPS');
      expect(component.selectedSource()).toBe('CPS');
    });

    it('sets selectedSource to undefined when called with empty string (deselect)', () => {
      component.selectedSource.set('AAI');
      component.onSourceChange('');
      expect(component.selectedSource()).toBeUndefined();
    });

    it('toggles off the active source when called with the same value', () => {
      component.selectedSource.set('AAI');
      component.onSourceChange('');
      expect(component.selectedSource()).toBeUndefined();
    });
  });

  describe('onVendorChange with existing conditions', () => {
    beforeEach(() => {
      component.selectedConditions.set([sampleCondition]);
      component.conditionErrors.set([null]);
      component.checkedConditionIds.set(['node.equipType']);
      ranFilterService.listFilterQueryAttributes$.calls.reset();
    });

    it('opens a confirmation modal before changing vendor', () => {
      component.onVendorChange('Nokia');
      expect(
        modalConfirmationService.openConfirmationModal
      ).toHaveBeenCalledOnceWith(
        jasmine.any(String),
        'ranFilter.create.modal.vendorChange.title',
        'ranFilter.create.modal.vendorChange.text'
      );
    });

    it('clears conditions and changes vendor when user confirms', () => {
      modalConfirmationService.openConfirmationModal.and.returnValue(of(true));

      component.onVendorChange('Nokia');

      expect(component.selectedVendor()).toBe('Nokia');
      expect(component.selectedConditions()).toEqual([]);
      expect(component.conditionErrors()).toEqual([]);
      expect(component.checkedConditionIds()).toEqual([]);
    });

    it('resets search state when user confirms vendor change', () => {
      component.searchTerm.set('test');
      component.searchResults.set([sampleAttr]);
      component.searchTotalCount.set(42);
      component.currentPage.set(3);
      modalConfirmationService.openConfirmationModal.and.returnValue(of(true));

      component.onVendorChange('Nokia');

      expect(component.searchTerm()).toBe('');
      expect(component.searchResults()).toEqual([]);
      expect(component.searchTotalCount()).toBe(0);
      expect(component.currentPage()).toBe(1);
    });

    it('does not change vendor or clear conditions when user cancels', () => {
      modalConfirmationService.openConfirmationModal.and.returnValue(of(false));
      component.selectedVendor.set('Ericsson');

      component.onVendorChange('Nokia');

      expect(component.selectedVendor()).toBe('Ericsson');
      expect(component.selectedConditions()).toHaveSize(1);
      expect(component.conditionErrors()).toEqual([null]);
    });

    it('does not call service when user cancels vendor change', () => {
      modalConfirmationService.openConfirmationModal.and.returnValue(of(false));

      component.onVendorChange('Nokia');

      expect(
        ranFilterService.listFilterQueryAttributes$
      ).not.toHaveBeenCalled();
    });

    it('does not open modal when no conditions exist', () => {
      component.selectedConditions.set([]);
      modalConfirmationService.openConfirmationModal.calls.reset();

      component.onVendorChange('Nokia');

      expect(
        modalConfirmationService.openConfirmationModal
      ).not.toHaveBeenCalled();
    });

    it('does not open modal when the same vendor is selected again', () => {
      component.selectedVendor.set('Ericsson');
      modalConfirmationService.openConfirmationModal.calls.reset();

      component.onVendorChange('Ericsson');

      expect(
        modalConfirmationService.openConfirmationModal
      ).not.toHaveBeenCalled();
    });

    it('does not change state when the same vendor is selected again', () => {
      component.selectedVendor.set('Ericsson');
      ranFilterService.listFilterQueryAttributes$.calls.reset();

      component.onVendorChange('Ericsson');

      expect(component.selectedConditions()).toHaveSize(1);
      expect(
        ranFilterService.listFilterQueryAttributes$
      ).not.toHaveBeenCalled();
    });
  });

  describe('onSearchTermChange', () => {
    beforeEach(() => {
      ranFilterService.listFilterQueryAttributes$.and.returnValue(
        of({ queryAttributes: [], totalCount: 0 } as any)
      );
      component.selectedVendor.set('Ericsson');
      ranFilterService.listFilterQueryAttributes$.calls.reset();
    });

    it('sets searchTerm and resets currentPage to 1', () => {
      component.currentPage.set(3);
      component.onSearchTermChange('node');
      expect(component.searchTerm()).toBe('node');
      expect(component.currentPage()).toBe(1);
    });

    it('calls onSearch after updating the term', () => {
      component.onSearchTermChange('node');
      expect(ranFilterService.listFilterQueryAttributes$).toHaveBeenCalled();
    });

    it('treats null/undefined event as empty string', () => {
      component.onSearchTermChange(undefined);
      expect(component.searchTerm()).toBe('');
    });
  });

  describe('onSourceChange', () => {
    beforeEach(() => {
      ranFilterService.listFilterQueryAttributes$.and.returnValue(
        of({ queryAttributes: [], totalCount: 0 } as any)
      );
      component.selectedVendor.set('Ericsson');
      ranFilterService.listFilterQueryAttributes$.calls.reset();
    });

    it('sets selectedSource and resets currentPage to 1', () => {
      component.currentPage.set(5);
      component.onSourceChange('CPS');
      expect(component.selectedSource()).toBe('CPS');
      expect(component.currentPage()).toBe(1);
    });

    it('calls onSearch with the new source', () => {
      component.onSourceChange('PLANNING');
      expect(ranFilterService.listFilterQueryAttributes$).toHaveBeenCalledWith(
        'PLANNING',
        'Ericsson',
        undefined,
        1,
        10
      );
    });
  });

  describe('onResetSearch', () => {
    beforeEach(() => {
      ranFilterService.listFilterQueryAttributes$.and.returnValue(
        of({ queryAttributes: [], totalCount: 0 } as any)
      );
      component.selectedVendor.set('Ericsson');
    });

    it('clears searchTerm, resets page and totalCount', () => {
      component.searchTerm.set('something');
      component.currentPage.set(4);
      component.searchTotalCount.set(99);

      component.onResetSearch();

      expect(component.searchTerm()).toBe('');
      expect(component.currentPage()).toBe(1);
      expect(component.searchTotalCount()).toBe(0);
    });

    it('calls onSearch after resetting', () => {
      ranFilterService.listFilterQueryAttributes$.calls.reset();
      component.onResetSearch();
      expect(ranFilterService.listFilterQueryAttributes$).toHaveBeenCalled();
    });
  });
});

describe('RanFilterDetailsComponent – edit mode', () => {
  let component: RanFilterDetailsComponent;
  let fixture: ComponentFixture<RanFilterDetailsComponent>;
  let ranFilterService: jasmine.SpyObj<RanFilterService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let router: jasmine.SpyObj<Router>;
  let modalConfirmationService: jasmine.SpyObj<ModalConfirmationService>;

  const existingFilter: RanFilter = {
    filterId: 42,
    filterName: 'My Filter',
    filterDescription: 'My Description',
    vendor: 'Nokia',
    owner: 'original-owner',
    conditions: [
      {
        path: 'node.type',
        source: RanFilterCondition.SourceEnum.AAI,
        operator: '=',
        filterValue: 'macro',
      },
      {
        path: 'NE.neType',
        source: RanFilterCondition.SourceEnum.CPS,
        operator: '!=',
        filterValue: 'cell',
        moc: 'NE',
        attribute: 'neType',
      },
    ],
  };

  function buildTestBed(filterId: string | null): void {
    ranFilterService = jasmine.createSpyObj('RanFilterService', [
      'listFilterVendors$',
      'listFilterQueryAttributes$',
      'saveRanFilter$',
      'updateRanFilter$',
      'getRanFilter$',
      'buildRanFilter',
      'refreshRanFilters',
      'resolveQueryAttributes$',
      'mergeConditionMetadata',
    ]);
    ranFilterService.listFilterVendors$.and.returnValue(
      of([{ vendor: 'Ericsson' }, { vendor: 'Nokia' }])
    );
    ranFilterService.listFilterQueryAttributes$.and.returnValue(
      of({ queryAttributes: [], totalCount: 0 } as any)
    );
    ranFilterService.resolveQueryAttributes$.and.returnValue(of(emptyLookup()));
    ranFilterService.mergeConditionMetadata.and.callFake(
      (conditions: any) => conditions
    );
    ranFilterService.getRanFilter$.and.returnValue(of(existingFilter));

    alertService = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
      'info',
    ]);
    router = jasmine.createSpyObj('Router', ['navigate']);
    modalConfirmationService = jasmine.createSpyObj(
      'ModalConfirmationService',
      ['openConfirmationModal']
    );
    modalConfirmationService.openConfirmationModal.and.returnValue(of(true));

    const onLangChange$ = new Subject<{
      lang: string;
      translations: unknown;
    }>();
    const translateServiceSpy = jasmine.createSpyObj(
      'TranslateService',
      ['instant'],
      { onLangChange: onLangChange$.asObservable() }
    );
    translateServiceSpy.instant.and.callFake((key: string) => key);

    TestBed.configureTestingModule({
      declarations: [RanFilterDetailsComponent, RanFilterRequirementsComponent],
      imports: [
        MockTranslatePipe,
        MockHighlightPipe,
        MockDataTableComponent,
        MockLayoutComponent,
        MockBreadcrumbComponent,
        MockBreadcrumbItemComponent,
        MockInputSearchComponent,
        MockTnapButtonDirective,
        MockTableCellDefinitionDirective,
        CheckboxComponent,
        LoadingSpinnerComponent,
      ],
      providers: [
        { provide: RanFilterService, useValue: ranFilterService },
        { provide: TnapAlertService, useValue: alertService },
        { provide: Router, useValue: router },
        {
          provide: ModalConfirmationService,
          useValue: modalConfirmationService,
        },
        { provide: TranslateService, useValue: translateServiceSpy },
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              paramMap: {
                get: (key: string) => (key === 'id' ? filterId : null),
              },
            },
          },
        },
      ],
    }).compileComponents();
  }

  describe('when navigated to edit/:id', () => {
    beforeEach(() => {
      buildTestBed('42');
      fixture = TestBed.createComponent(RanFilterDetailsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('sets isEditMode to true', () => {
      expect(component.isEditMode()).toBeTrue();
    });

    it('sets editFilterId to the id from the route', () => {
      expect(component.editFilterId()).toBe(42);
    });

    it('calls getRanFilter$ with the id from the route', () => {
      expect(ranFilterService.getRanFilter$).toHaveBeenCalledWith(42);
    });

    it('pre-populates filterName from the loaded filter', () => {
      expect(component.filterName()).toBe('My Filter');
    });

    it('pre-populates filterDescription from the loaded filter', () => {
      expect(component.filterDescription()).toBe('My Description');
    });

    it('preserves the original owner', () => {
      expect(component.originalOwner()).toBe('original-owner');
    });

    it('pre-populates conditions from the loaded filter', () => {
      const conditions = component.selectedConditions();
      expect(conditions).toHaveSize(2);
      expect(conditions[0].path).toBe('node.type');
      expect(conditions[0].operator).toBe('=');
      expect(conditions[0].filterValue).toBe('macro');
      expect(conditions[0].source).toBe(RanFilterCondition.SourceEnum.AAI);
    });

    it('maps moc and attribute fields from conditions', () => {
      const conditions = component.selectedConditions();
      expect(conditions[1].moc).toBe('NE');
      expect(conditions[1].mocAttribute).toBe('neType');
    });

    it('resolves catalog metadata for the loaded conditions', () => {
      expect(ranFilterService.resolveQueryAttributes$).toHaveBeenCalledWith(
        'Nokia',
        jasmine.arrayContaining([
          jasmine.objectContaining({ path: 'node.type' }),
        ])
      );
    });

    it('initialises conditionErrors with null for each condition', () => {
      expect(component.conditionErrors()).toEqual([null, null]);
    });

    it('selects the filter vendor (Nokia) after loading vendors', () => {
      expect(component.selectedVendor()).toBe('Nokia');
    });

    it('exposes pageTitle as ranFilter.breadcrumb.filterConfiguration', () => {
      expect(component.pageTitle()).toBe(
        'ranFilter.breadcrumb.filterConfiguration'
      );
    });

    it('exposes saveButtonLabel as ranFilter.edit.actions.save', () => {
      expect(component.saveButtonLabel()).toBe('ranFilter.edit.actions.save');
    });

    it('does not announce "ready to verify" just from loading the filter', () => {
      expect(component.isConditionSetValid()).toBeTrue();
      expect(component.showReadyToVerify()).toBeFalse();
      expect(alertService.info).not.toHaveBeenCalled();
    });

    describe('onSave in edit mode', () => {
      beforeEach(() => {
        component.filterName.set('Updated Filter');
        component.filterDescription.set('Updated Description');
        component.selectedVendor.set('Nokia');
        component.selectedConditions.set([
          {
            path: 'node.type',
            source: RanFilterCondition.SourceEnum.AAI,
            operator: '=',
            filterValue: 'macro',
            availableOperators: ['='],
            conditionType: 'string',
          },
          {
            path: 'NE.neType',
            source: RanFilterCondition.SourceEnum.CPS,
            operator: '=',
            filterValue: 'gNB',
            availableOperators: ['=', '!='],
            conditionType: 'string',
          },
        ]);
        component.conditionErrors.set([null, null]);
        component.verifySuccessful.set(true);
        ranFilterService.updateRanFilter$.and.returnValue(of(undefined));
      });

      it('calls updateRanFilter$ with the filter id and updated data', () => {
        component.onSave();

        expect(ranFilterService.updateRanFilter$).toHaveBeenCalledWith(
          42,
          jasmine.objectContaining({
            filterId: 42,
            filterName: 'Updated Filter',
            filterDescription: 'Updated Description',
            vendor: 'Nokia',
            owner: 'original-owner',
          })
        );
      });

      it('does not call saveRanFilter$ in edit mode', () => {
        component.onSave();
        expect(ranFilterService.saveRanFilter$).not.toHaveBeenCalled();
      });

      it('shows edit success alert and navigates to list on success', () => {
        component.onSave();

        expect(alertService.success).toHaveBeenCalledWith(
          'ranFilter.edit.saveSuccess',
          { keepAfterRouteChange: true }
        );
        expect(ranFilterService.refreshRanFilters).toHaveBeenCalled();
        expect(router.navigate).toHaveBeenCalledWith(['/ran-filter']);
      });

      it('resets saving state on update failure', () => {
        ranFilterService.updateRanFilter$.and.returnValue(
          throwError(() => new Error('fail'))
        );

        component.onSave();

        expect(component.saving()).toBeFalse();
      });

      it('does nothing when form is invalid', () => {
        component.filterName.set('');
        component.onSave();
        expect(ranFilterService.updateRanFilter$).not.toHaveBeenCalled();
      });
    });
  });

  describe('when getRanFilter$ fails', () => {
    beforeEach(() => {
      buildTestBed('42');
      ranFilterService.getRanFilter$.and.returnValue(
        throwError(() => new Error('not found'))
      );
      fixture = TestBed.createComponent(RanFilterDetailsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('resets loading state when filter cannot be loaded', () => {
      expect(component.loadingFilter()).toBeFalse();
    });

    it('navigates back to the list when filter cannot be loaded', () => {
      expect(router.navigate).toHaveBeenCalledWith(['/ran-filter']);
    });
  });

  describe('when vendor is no longer available', () => {
    let modalSubject: Subject<boolean>;

    beforeEach(() => {
      modalSubject = new Subject<boolean>();
      buildTestBed('42');
      // Vendor list does NOT contain 'Nokia' (the filter's vendor)
      ranFilterService.listFilterVendors$.and.returnValue(
        of([{ vendor: 'Ericsson' }, { vendor: 'Huawei' }])
      );
      modalConfirmationService.openConfirmationModal.and.returnValue(
        modalSubject.asObservable()
      );
      fixture = TestBed.createComponent(RanFilterDetailsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('opens the vendor-not-found confirmation modal', () => {
      expect(
        modalConfirmationService.openConfirmationModal
      ).toHaveBeenCalledWith(
        'ranFilter.edit.modal.vendorNotFound.confirmButton',
        'ranFilter.edit.modal.vendorNotFound.title',
        'ranFilter.edit.modal.vendorNotFound.text',
        { vendor: 'Nokia' }
      );
    });

    it('does NOT set a vendor until the user responds to the modal', () => {
      expect(component.selectedVendor()).toBeUndefined();
    });

    describe('when user confirms (Clear & Continue)', () => {
      beforeEach(() => {
        modalSubject.next(true);
        modalSubject.complete();
      });

      it('clears all conditions', () => {
        expect(component.selectedConditions()).toEqual([]);
      });

      it('clears conditionErrors', () => {
        expect(component.conditionErrors()).toEqual([]);
      });

      it('sets vendor to the default fallback (Huawei)', () => {
        expect(component.selectedVendor()).toBe('Huawei');
      });

      it('triggers a new attribute search for the fallback vendor', () => {
        expect(
          ranFilterService.listFilterQueryAttributes$
        ).toHaveBeenCalledWith(undefined, 'Huawei', undefined, 1, 10);
      });
    });

    describe('when user cancels', () => {
      beforeEach(() => {
        modalSubject.next(false);
        modalSubject.complete();
      });

      it('navigates back to the filter list', () => {
        expect(router.navigate).toHaveBeenCalledWith(['/ran-filter']);
      });

      it('does not select any vendor', () => {
        expect(component.selectedVendor()).toBeUndefined();
      });
    });
  });

  describe('when vendor is no longer available and no default vendor exists', () => {
    beforeEach(() => {
      buildTestBed('42');
      ranFilterService.listFilterVendors$.and.returnValue(
        of([{ vendor: 'Ericsson' }]) // no Huawei default either
      );
      modalConfirmationService.openConfirmationModal.and.returnValue(of(true));
      fixture = TestBed.createComponent(RanFilterDetailsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('falls back to the first available vendor (Ericsson)', () => {
      expect(component.selectedVendor()).toBe('Ericsson');
    });
  });

  describe('when no id in route (create mode)', () => {
    beforeEach(() => {
      buildTestBed(null);
      fixture = TestBed.createComponent(RanFilterDetailsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('stays in create mode (isEditMode is false)', () => {
      expect(component.isEditMode()).toBeFalse();
    });

    it('does not call getRanFilter$', () => {
      expect(ranFilterService.getRanFilter$).not.toHaveBeenCalled();
    });

    it('exposes pageTitle as ranFilter.breadcrumb.createFilter', () => {
      expect(component.pageTitle()).toBe('ranFilter.breadcrumb.createFilter');
    });

    it('exposes saveButtonLabel as ranFilter.create.actions.save', () => {
      expect(component.saveButtonLabel()).toBe('ranFilter.create.actions.save');
    });
  });
});
