/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ChangeDetectionStrategy,
  Component,
  ComponentRef,
  computed,
  DestroyRef,
  effect,
  ElementRef,
  inject,
  NgZone,
  signal,
  viewChild,
  viewChildren,
  ViewContainerRef,
} from '@angular/core';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import {
  take,
  filter,
  Subject,
  EMPTY,
  switchMap,
  catchError,
  tap,
  Observable,
} from 'rxjs';
import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { RanFilterExecuteResultPanelComponent } from '../ran-filter-execute-result-panel/ran-filter-execute-result-panel.component';
import { ModalConfirmationService } from '../../../services/common-functionalities/modal-confirmation.service';
import { ColumnDefinition } from '@portal-mfe/tnap-ui-kit/components/data-table';
import { SegmentedControlItem } from '@portal-mfe/tnap-ui-kit/components/segmented-control';
import { RanFilterService } from '../../../services/ran-filterservice/ran-filter.service';
import {
  QueryAttribute,
  RanFilter,
  RanFilterCondition,
  RanFilterVendor,
  TestFilterRequest,
  TestFilterResponse,
} from '../../../../../openapi/output';
import {
  SelectedCondition,
  ConditionValueError,
  isValueOutOfCatalog,
  NUMERIC_CONDITION_TYPES,
  offersValueList,
  RAN_FILTER_SOURCES,
  RAN_FILTER_SOURCE_LABEL_KEY,
  RanFilterSource,
} from '../model/ran-filter.model';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

/** Keys that move focus, as opposed to typing into the focused field. */
const FOCUS_NAVIGATION_KEYS = new Set([
  'Tab',
  'ArrowUp',
  'ArrowDown',
  'ArrowLeft',
  'ArrowRight',
  'Home',
  'End',
  'PageUp',
  'PageDown',
]);

const POINTER_FOCUS_CLASS = 'pointer-focus';

@Component({
  selector: 'app-ran-filter-details',
  templateUrl: './ran-filter-details.component.html',
  styleUrl: './ran-filter-details.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: false,
})
export class RanFilterDetailsComponent {
  private readonly ranFilterService = inject(RanFilterService);
  private readonly translateService = inject(TranslateService);
  private readonly alertService = inject(TnapAlertService);
  private readonly router = inject(Router);
  private readonly destroyRef = inject(DestroyRef);
  private readonly modalConfirmationService = inject(ModalConfirmationService);
  private readonly route = inject(ActivatedRoute);
  private readonly hostRef = inject(ElementRef);
  private readonly zone = inject(NgZone);
  private readonly overlay = inject(Overlay);
  private readonly viewContainerRef = inject(ViewContainerRef);
  private readonly lang = toSignal(this.translateService.onLangChange);

  private verifyOverlayRef: OverlayRef | null = null;
  private verifyPanelRef: ComponentRef<RanFilterExecuteResultPanelComponent> | null =
    null;
  private verifyTriggerElement: HTMLElement | null = null;

  /* Keyed by the impactOnly flag. Toggling "show nodes" is a view change, so each
     variant is requested once per verify run and served from here afterwards. */
  private readonly verifyResultCache = new Map<boolean, TestFilterResponse>();

  readonly vendors = signal<RanFilterVendor[]>([]);
  private readonly defaultVendor = 'Huawei';
  readonly selectedVendor = signal<string | undefined>(undefined);
  readonly searchTerm = signal('');
  readonly currentPage = signal(1);
  readonly pageLimit = signal(10);
  readonly searchTotalCount = signal(0);
  readonly searchResults = signal<QueryAttribute[]>([]);
  readonly searchLoading = signal(false);
  readonly selectedConditions = signal<SelectedCondition[]>([]);
  readonly conditionsHintDismissed = signal(false);
  readonly conditionErrors = signal<(ConditionValueError | null)[]>([]);
  readonly checkedConditionIds = signal<string[]>([]);
  readonly hasCheckedConditions = computed(
    () => this.checkedConditionIds().length > 0
  );
  readonly filterName = signal('');
  readonly filterDescription = signal('');
  readonly saveAttempted = signal(false);
  readonly saving = signal(false);
  readonly verifying = signal(false);
  readonly verifyResult = signal<object | undefined>(undefined);
  readonly verifySuccessful = signal(false);
  readonly showNodes = signal(false);

  readonly isEditMode = signal(false);
  readonly editFilterId = signal<number | undefined>(undefined);
  readonly originalOwner = signal<string>('Portal');
  readonly loadingFilter = signal(false);
  readonly metadataLoading = signal(false);

  readonly sources = RAN_FILTER_SOURCES;
  readonly sourceLabelKey = RAN_FILTER_SOURCE_LABEL_KEY;
  readonly selectedSource = signal<RanFilterSource | undefined>(undefined);

  private readonly searchTrigger$ = new Subject<{
    source: RanFilterSource | undefined;
    vendor: string;
    search: string[] | undefined;
    page: number;
    limit: number;
  }>();

  readonly leftPane = signal(40);
  readonly leftPaneExpanded = signal(false);
  readonly paneUnit: '%' | 'px' = '%';
  readonly minPaneWidth = 20;
  readonly maxPaneWidth = 75;
  readonly paneStep = 2;

  readonly gridTemplateColumns = computed(() =>
    this.leftPaneExpanded() ? '1fr' : `${this.leftPane()}% 15px 1fr`
  );

  readonly vendorItems = computed<SegmentedControlItem[]>(() => {
    const vendors = this.vendors();
    return vendors.map(v => ({
      label: v.vendor ?? '',
      value: v.vendor ?? '',
    }));
  });

  readonly sourceItems = computed<SegmentedControlItem[]>(() => {
    this.lang();
    return this.sources.map(s => ({
      label: this.translateService.instant(
        `${RAN_FILTER_SOURCE_LABEL_KEY}${s}`
      ),
      value: s,
    }));
  });

  readonly highlightPattern = computed(() => {
    const term = this.searchTerm().trim();
    if (!term) return '';
    return term.split(/\s+/).filter(Boolean).join('|');
  });

  readonly conditionsTableSection = viewChild<ElementRef<HTMLElement>>(
    'conditionsTableSection'
  );
  readonly conditionsChipsList = viewChild<ElementRef<HTMLElement>>(
    'conditionsChipsList'
  );

  readonly vendorRadios =
    viewChildren<ElementRef<HTMLInputElement>>('vendorRadio');

  /** Everything the backend needs for a verify run — name and description excluded. */
  readonly isConditionSetValid = computed(
    () =>
      this.selectedVendor() !== undefined &&
      this.selectedConditions().every(c => c.filterValue.trim().length > 0) &&
      this.selectedConditions().every(
        c =>
          c.metadataResolved !== false &&
          !c.operatorOutOfCatalog &&
          !c.valueOutOfCatalog
      ) &&
      !this.conditionErrors().some(Boolean) &&
      this.selectedConditions().some(
        c => c.source === RanFilterCondition.SourceEnum.AAI
      )
  );

  readonly isFormValid = computed(
    () =>
      this.isConditionSetValid() &&
      this.filterName().trim().length > 0 &&
      this.filterDescription().trim().length > 0
  );

  readonly filterNameInvalid = computed(
    () => this.saveAttempted() && this.filterName().trim().length === 0
  );

  readonly filterDescriptionInvalid = computed(
    () => this.saveAttempted() && this.filterDescription().trim().length === 0
  );

  readonly isSaveEnabled = computed(
    () => this.isFormValid() && this.verifySuccessful()
  );

  /** Conditions whose value is picked from the catalog list instead of typed. */
  readonly valueListConditions = computed(
    () => new Set(this.selectedConditions().filter(offersValueList))
  );

  readonly hasTopologyCondition = computed(() =>
    this.selectedConditions().some(
      c => c.source === RanFilterCondition.SourceEnum.AAI
    )
  );

  readonly hasAllConditionValues = computed(
    () =>
      this.selectedConditions().length > 0 &&
      this.selectedConditions().every(c => c.filterValue.trim().length > 0) &&
      !this.conditionErrors().some(Boolean)
  );

  /** The checklist errors appear only after the user tried to create the filter. */
  readonly showRequirementErrors = computed(() => this.saveAttempted());

  /** Guards the announcement: only a user edit since the last verify run may trigger it. */
  private readonly conditionsChangedSinceVerify = signal(false);

  readonly showReadyToVerify = computed(
    () =>
      this.conditionsChangedSinceVerify() &&
      this.isConditionSetValid() &&
      !this.verifying() &&
      !this.verifySuccessful()
  );

  private wasReadyToVerify = false;

  /** Announced once per transition, so editing conditions does not spam the alert area. */
  private readonly readyToVerifyAlert = effect(() => {
    const ready = this.showReadyToVerify();
    if (ready && !this.wasReadyToVerify) {
      this.alertService.info(
        this.translateService.instant(
          'ranFilter.create.requirements.readyToVerify'
        ),
        { autoClose: true }
      );
    }
    this.wasReadyToVerify = ready;
  });

  readonly pageTitle = computed(() =>
    this.isEditMode()
      ? 'ranFilter.breadcrumb.filterConfiguration'
      : 'ranFilter.breadcrumb.createFilter'
  );

  readonly saveButtonLabel = computed(() =>
    this.isEditMode()
      ? 'ranFilter.edit.actions.save'
      : 'ranFilter.create.actions.save'
  );

  readonly searchResultsData = computed(() => {
    const results = this.searchResults();
    return { items: results, totalCount: results.length };
  });

  readonly conditionsData = computed(() => {
    const conditions = this.selectedConditions();
    return { items: conditions, totalCount: conditions.length };
  });

  readonly addedConditionPaths = computed(
    () => new Set(this.selectedConditions().map(c => c.path))
  );

  readonly hasUnresolvedConditions = computed(() =>
    this.selectedConditions().some(
      c => c.metadataResolved === false && !c.metadataLookupFailed
    )
  );

  readonly hasFailedMetadataLookup = computed(() =>
    this.selectedConditions().some(c => c.metadataLookupFailed === true)
  );

  readonly hasStaleConditionSelections = computed(() =>
    this.selectedConditions().some(
      c => c.operatorOutOfCatalog || c.valueOutOfCatalog
    )
  );

  readonly noDataMessageForCards = computed(() => {
    const hasSearch = this.searchTerm().trim().length >= 3;
    return hasSearch
      ? 'common.filters.noFilterResults'
      : 'common.filters.noResults';
  });

  readonly searchResultColumns = computed<ColumnDefinition<QueryAttribute>[]>(
    () => {
      this.lang();
      return [
        {
          key: 'source',
          label: this.translateService.instant(
            'ranFilter.create.fields.source'
          ),
          classes: 'col--source',
          value: row => row.source ?? '',
        },
        {
          key: 'moc',
          label: this.translateService.instant('ranFilter.create.fields.moc'),
          classes: 'col--moc',
          value: row => row.moc ?? '',
        },
        {
          key: 'name',
          label: this.translateService.instant('ranFilter.create.fields.name'),
          classes: 'col--name',
          value: row => row.name ?? '',
        },
        {
          key: 'attribute',
          label: this.translateService.instant(
            'ranFilter.create.fields.attribute'
          ),
          classes: 'col--attribute',
          value: row => row.mocAttribute ?? '',
        },
        {
          key: 'type',
          label: this.translateService.instant('ranFilter.create.fields.type'),
          classes: 'col--type',
          value: row => row.conditionType ?? '',
        },
        {
          key: 'description',
          label: this.translateService.instant(
            'ranFilter.create.fields.description'
          ),
          classes: 'col--description',
          value: row => row.description ?? '',
        },
        {
          key: 'actions',
          label: this.translateService.instant(
            'ranFilter.create.fields.actions'
          ),
          classes: 'col--actions',
          value: () => '',
        },
      ];
    }
  );

  readonly conditionColumns = computed<ColumnDefinition<SelectedCondition>[]>(
    () => {
      this.lang();
      return [
        {
          key: 'source',
          label: this.translateService.instant(
            'ranFilter.create.fields.source'
          ),
          classes: 'col--source',
          value: row => row.source,
        },
        {
          key: 'moc',
          label: this.translateService.instant('ranFilter.create.fields.moc'),
          classes: 'col--moc',
          value: row => row.moc ?? '',
        },
        {
          key: 'path',
          label: this.translateService.instant('ranFilter.create.fields.name'),
          classes: 'col--path',
          value: row => row.path,
        },
        {
          key: 'attribute',
          label: this.translateService.instant(
            'ranFilter.create.fields.attribute'
          ),
          classes: 'col--attribute',
          value: row => row.mocAttribute ?? '',
        },
        {
          key: 'description',
          label: this.translateService.instant(
            'ranFilter.create.fields.description'
          ),
          classes: 'col--description',
          value: row => row.description ?? '',
        },
        {
          key: 'type',
          label: this.translateService.instant('ranFilter.create.fields.type'),
          classes: 'col--type',
          value: row => row.conditionType ?? '',
        },
        {
          key: 'operator',
          label: this.translateService.instant(
            'ranFilter.create.fields.operator'
          ),
          classes: 'col--operator',
          value: row => row.operator,
        },
        {
          key: 'filterValue',
          label: this.translateService.instant(
            'ranFilter.create.fields.filterValue'
          ),
          classes: 'col--filter-value',
          value: row => row.filterValue,
        },
        {
          key: 'actions',
          label: this.translateService.instant(
            'ranFilter.create.fields.actions'
          ),
          classes: 'col--actions',
          value: () => '',
        },
      ];
    }
  );

  constructor() {
    this.trackPointerFocus();
    this.destroyRef.onDestroy(() => this.disposeVerifyOverlay());

    this.searchTrigger$
      .pipe(
        switchMap(params =>
          this.ranFilterService
            .listFilterQueryAttributes$(
              params.source,
              params.vendor,
              params.search,
              params.page,
              params.limit
            )
            .pipe(
              catchError(() => {
                this.searchResults.set([]);
                this.searchTotalCount.set(0);
                this.searchLoading.set(false);
                return EMPTY;
              })
            )
        ),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(result => {
        this.searchResults.set(result.queryAttributes ?? []);
        this.searchTotalCount.set(result.totalCount);
        this.searchLoading.set(false);
      });

    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      const filterId = Number(id);
      if (!Number.isNaN(filterId) && filterId > 0) {
        this.isEditMode.set(true);
        this.editFilterId.set(filterId);
        this.loadingFilter.set(true);

        this.ranFilterService
          .getRanFilter$(filterId)
          .pipe(takeUntilDestroyed(this.destroyRef))
          .subscribe({
            next: (ranFilter: RanFilter) => {
              this.loadingFilter.set(false);
              this.filterName.set(ranFilter.filterName ?? '');
              this.filterDescription.set(ranFilter.filterDescription ?? '');
              this.originalOwner.set(ranFilter.owner ?? 'Portal');

              const conditions: SelectedCondition[] = (
                ranFilter.conditions ?? []
              ).map(c => ({
                path: c.path,
                source: c.source ?? RanFilterCondition.SourceEnum.AAI,
                operator: c.operator,
                filterValue: c.filterValue,
                availableOperators: [c.operator],
                conditionType: 'string',
                moc: c.moc ?? undefined,
                mocAttribute: c.attribute ?? undefined,
              }));
              this.selectedConditions.set(conditions);
              this.conditionErrors.set(conditions.map(() => null));
              this.loadVendors(ranFilter.vendor);
            },
            error: () => {
              this.loadingFilter.set(false);
              this.router.navigate(['/ran-filter']);
            },
          });
      } else {
        this.loadVendors();
      }
    } else {
      this.loadVendors();
    }
  }

  onVendorChange(vendor: string): void {
    if (vendor === this.selectedVendor()) {
      return;
    }
    if (this.selectedConditions().length > 0) {
      // Native radios switch instantly; revert them until the change is confirmed.
      this.syncVendorRadios();
      this.modalConfirmationService
        .openConfirmationModal(
          'common.buttons.yes',
          'ranFilter.create.modal.vendorChange.title',
          'ranFilter.create.modal.vendorChange.text'
        )
        .pipe(
          take(1),
          filter(confirmed => confirmed === true),
          takeUntilDestroyed(this.destroyRef)
        )
        .subscribe(() => this.applyVendorChange(vendor));
    } else {
      this.applyVendorChange(vendor);
    }
  }

  private syncVendorRadios(): void {
    const selected = this.selectedVendor();
    for (const radio of this.vendorRadios()) {
      radio.nativeElement.checked = radio.nativeElement.value === selected;
    }
  }

  private applyVendorChange(vendor: string): void {
    this.selectedConditions.set([]);
    this.conditionErrors.set([]);
    this.checkedConditionIds.set([]);
    this.invalidateVerification();
    this.selectedVendor.set(vendor);
    this.searchResults.set([]);
    this.searchTerm.set('');
    this.currentPage.set(1);
    this.searchTotalCount.set(0);
    this.onSearch();
  }

  onSearch(): void {
    const vendor = this.selectedVendor();
    if (!vendor) {
      return;
    }

    const source = this.selectedSource();

    const term = this.searchTerm().trim();
    if (term.length > 0 && term.length < 3) {
      return;
    }

    this.searchLoading.set(true);
    const search = term ? term.split(/\s+/) : undefined;
    this.searchTrigger$.next({
      source,
      vendor,
      search,
      page: this.currentPage(),
      limit: this.pageLimit(),
    });
  }

  onSearchTermChange(term: string | undefined): void {
    this.searchTerm.set(term || '');
    this.currentPage.set(1);
    this.onSearch();
  }

  onSourceChange(src: string): void {
    this.selectedSource.set(src ? (src as RanFilterSource) : undefined);
    this.currentPage.set(1);
    this.onSearch();
  }

  onResetSearch(): void {
    this.searchTerm.set('');
    this.currentPage.set(1);
    this.searchTotalCount.set(0);
    this.onSearch();
  }

  onPageChange(page: number): void {
    this.currentPage.set(page);
    this.onSearch();
  }

  onPageSizeChange(size: number): void {
    this.pageLimit.set(size);
    this.currentPage.set(1);
    this.onSearch();
  }

  addCondition(attr: QueryAttribute): void {
    const existing = this.selectedConditions();
    const alreadyAdded = existing.some(c => c.path === (attr.name ?? ''));
    if (alreadyAdded) {
      return;
    }
    const availableOperators = attr.operator ?? [];
    const conditionType = attr.conditionType ?? '';
    const isNumeric = NUMERIC_CONDITION_TYPES.has(conditionType.toLowerCase());
    const condition: SelectedCondition = {
      path: attr.name ?? '',
      source: attr.source ?? 'AAI',
      operator: availableOperators[0] ?? '',
      filterValue: '',
      availableOperators,
      conditionValues: attr.conditionValues,
      conditionType,
      description: attr.description ?? undefined,
      moc: attr.moc ?? undefined,
      mocAttribute: attr.mocAttribute ?? undefined,
      rangeMin: isNumeric ? (attr.rangeMin ?? undefined) : undefined,
      rangeMax: isNumeric ? (attr.rangeMax ?? undefined) : undefined,
    };

    this.selectedConditions.set([...existing, condition]);
    this.conditionErrors.set([...this.conditionErrors(), null]);
    this.invalidateVerification();
  }

  /** A verified result only stays valid while attributes, operators and values are untouched. */
  private invalidateVerification(): void {
    this.verifySuccessful.set(false);
    this.conditionsChangedSinceVerify.set(true);
    this.verifyResultCache.clear();
  }

  removeCondition(index: number): void {
    const pathToRemove = this.selectedConditions()[index].path;
    const current = this.selectedConditions();
    this.selectedConditions.set(current.filter((_, i) => i !== index));
    this.conditionErrors.set(
      this.conditionErrors().filter((_, i) => i !== index)
    );
    this.checkedConditionIds.update(ids =>
      ids.filter(id => id !== pathToRemove)
    );
    this.invalidateVerification();
    this.focusConditionRow(index);
  }

  /** Falls back to the chips list when the table is collapsed. */
  private focusConditionRow(index: number): void {
    setTimeout(() => {
      const tableEl = this.conditionsTableSection()?.nativeElement;
      if (tableEl) {
        const buttons = Array.from(
          tableEl.querySelectorAll<HTMLButtonElement>(
            '.qa_remove_condition_button'
          )
        );
        if (buttons.length > 0) {
          buttons[Math.min(index, buttons.length - 1)].focus();
          return;
        }
      }
      const chipsEl = this.conditionsChipsList()?.nativeElement;
      if (chipsEl) {
        const buttons = Array.from(
          chipsEl.querySelectorAll<HTMLButtonElement>(
            '.qa_remove_condition_chip'
          )
        );
        if (buttons.length > 0) {
          buttons[Math.min(index, buttons.length - 1)].focus();
        }
      }
    });
  }

  updateConditionOperator(index: number, operator: string): void {
    const current = [...this.selectedConditions()];
    const updated = {
      ...current[index],
      operator,
      operatorOutOfCatalog: false,
    };
    current[index] = {
      ...updated,
      valueOutOfCatalog: isValueOutOfCatalog(updated),
    };
    this.selectedConditions.set(current);
    this.invalidateVerification();
  }

  updateConditionValue(index: number, value: string): void {
    const current = [...this.selectedConditions()];
    const errors = [...this.conditionErrors()];
    errors[index] = this.validateConditionValue(current[index], value);
    this.conditionErrors.set(errors);
    current[index] = {
      ...current[index],
      filterValue: value,
      valueOutOfCatalog: false,
    };
    this.selectedConditions.set(current);
    this.invalidateVerification();
  }

  /* Text inputs match :focus-visible even on mouse click, which shows the app-wide
     keyboard focus ring on click. Tracked on the host and outside the Angular zone
     so that typing does not trigger change detection. */
  private trackPointerFocus(): void {
    const host = this.hostRef.nativeElement as HTMLElement;
    this.zone.runOutsideAngular(() => {
      host.addEventListener(
        'pointerdown',
        () => host.classList.add(POINTER_FOCUS_CLASS),
        { capture: true, passive: true }
      );
      host.addEventListener(
        'keydown',
        event => {
          if (FOCUS_NAVIGATION_KEYS.has(event.key)) {
            host.classList.remove(POINTER_FOCUS_CLASS);
          }
        },
        { capture: true, passive: true }
      );
    });
  }

  private validateConditionValue(
    condition: SelectedCondition,
    value: string
  ): ConditionValueError | null {
    if (value === '') {
      return null;
    }
    const type = condition.conditionType.toLowerCase();
    if (type === 'integer' && !/^-?\d*$/.test(value)) {
      return 'integer';
    }
    if (type === 'number' && !/^-?\d*(\.\d*)?$/.test(value)) {
      return 'number';
    }
    return this.validateRange(condition, value);
  }

  private validateRange(
    condition: SelectedCondition,
    value: string
  ): ConditionValueError | null {
    const { rangeMin, rangeMax } = condition;
    if (rangeMin == null && rangeMax == null) {
      return null;
    }
    const numericValue = Number(value);
    if (Number.isNaN(numericValue)) {
      return null;
    }
    const outOfRange =
      (rangeMin != null && numericValue < rangeMin) ||
      (rangeMax != null && numericValue > rangeMax);
    if (!outOfRange) {
      return null;
    }
    if (rangeMin != null && rangeMax != null) {
      return 'range';
    }
    return rangeMin != null ? 'rangeMin' : 'rangeMax';
  }

  onSave(): void {
    this.saveAttempted.set(true);
    if (!this.isSaveEnabled()) {
      return;
    }
    this.saving.set(true);

    if (this.isEditMode()) {
      const filterId = this.editFilterId()!;
      const filter: RanFilter = {
        filterId,
        filterName: this.filterName(),
        filterDescription: this.filterDescription(),
        vendor: this.selectedVendor()!,
        owner: this.originalOwner(),
        conditions: this.selectedConditions().map(c => ({
          path: c.path,
          source: c.source,
          operator: c.operator,
          filterValue: c.filterValue,
        })),
      };
      this.ranFilterService
        .updateRanFilter$(filterId, filter)
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe({
          next: () => {
            this.saving.set(false);
            this.alertService.success(
              this.translateService.instant('ranFilter.edit.saveSuccess'),
              { keepAfterRouteChange: true }
            );
            this.ranFilterService.refreshRanFilters();
            this.router.navigate(['/ran-filter']);
          },
          error: () => {
            this.saving.set(false);
          },
        });
    } else {
      const filter = this.ranFilterService.buildRanFilter(
        this.filterName(),
        this.filterDescription(),
        this.selectedVendor()!,
        this.selectedConditions(),
        'Portal'
      );
      this.ranFilterService
        .saveRanFilter$(filter)
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe({
          next: () => {
            this.saving.set(false);
            this.alertService.success(
              this.translateService.instant('ranFilter.create.saveSuccess'),
              { keepAfterRouteChange: true }
            );
            this.ranFilterService.refreshRanFilters();
            this.router.navigate(['/ran-filter']);
          },
          error: () => {
            this.saving.set(false);
          },
        });
    }
  }

  onVerifyFilter(): void {
    if (!this.isConditionSetValid()) {
      return;
    }
    if (!this.verifyOverlayRef) {
      this.verifyTriggerElement = document.activeElement as HTMLElement | null;
    }
    this.verifying.set(true);
    this.conditionsChangedSinceVerify.set(false);
    this.verifyResult.set(undefined);
    this.verifySuccessful.set(false);
    this.verifyResultCache.clear();

    this.requestVerifyResult(!this.showNodes())
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (result: TestFilterResponse) => {
          this.verifying.set(false);
          this.verifyResult.set(result);
          this.verifySuccessful.set(true);
          this.alertService.success(
            this.translateService.instant('ranFilter.create.verifySuccess')
          );
          this.showVerifyResult(result);
        },
        error: () => {
          this.verifying.set(false);
          this.verifySuccessful.set(false);
        },
      });
  }

  private requestVerifyResult(
    impactOnly: boolean,
    skipGlobalLoading = false
  ): Observable<TestFilterResponse> {
    const request: TestFilterRequest = {
      vendor: this.selectedVendor()!,
      conditions: this.selectedConditions(),
      impactOnly,
    };
    return this.ranFilterService
      .verifyFilter(request, skipGlobalLoading)
      .pipe(tap(result => this.verifyResultCache.set(impactOnly, result)));
  }

  /** Reuses the open modal on re-verification so toggling "show nodes" does not stack overlays. */
  private showVerifyResult(result: TestFilterResponse): void {
    if (this.verifyPanelRef) {
      this.verifyPanelRef.instance.result = result;
      this.verifyPanelRef.instance.showNodes = this.showNodes();
      return;
    }

    const overlayRef = this.overlay.create({
      positionStrategy: this.overlay
        .position()
        .global()
        .centerHorizontally()
        .centerVertically(),
      hasBackdrop: true,
      backdropClass: 'execute-result-overlay-backdrop',
      scrollStrategy: this.overlay.scrollStrategies.block(),
      width: '954px',
    });
    this.verifyOverlayRef = overlayRef;

    const panelRef = overlayRef.attach(
      new ComponentPortal(
        RanFilterExecuteResultPanelComponent,
        this.viewContainerRef
      )
    );
    this.verifyPanelRef = panelRef;
    panelRef.instance.filterName = this.filterName();
    panelRef.instance.result = result;
    panelRef.instance.showNodes = this.showNodes();

    panelRef.instance.closePanel
      .pipe(take(1), takeUntilDestroyed(this.destroyRef))
      .subscribe(() => this.clearExecuteResult());

    panelRef.instance.showNodesChange
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(checked => this.onShowNodesChange(checked));

    overlayRef
      .backdropClick()
      .pipe(take(1), takeUntilDestroyed(this.destroyRef))
      .subscribe(() => this.clearExecuteResult());
  }

  private disposeVerifyOverlay(): void {
    this.verifyOverlayRef?.dispose();
    this.verifyOverlayRef = null;
    this.verifyPanelRef = null;
  }

  removeSelectedConditions(): void {
    const checkedIds = new Set(this.checkedConditionIds());
    const conditions = this.selectedConditions();
    const errors = this.conditionErrors();
    const remaining = conditions
      .map((c, i) => ({ condition: c, error: errors[i] }))
      .filter(({ condition }) => !checkedIds.has(condition.path));
    this.selectedConditions.set(remaining.map(({ condition }) => condition));
    this.conditionErrors.set(remaining.map(({ error }) => error));
    this.checkedConditionIds.set([]);
    this.invalidateVerification();
    this.focusConditionRow(0);
  }

  onConditionRowCheckChange(event: {
    row: SelectedCondition;
    checked: boolean;
    id: string;
  }): void {
    this.checkedConditionIds.update(ids =>
      event.checked ? [...ids, event.id] : ids.filter(id => id !== event.id)
    );
  }

  onAllConditionsCheckChange(checked: boolean): void {
    this.checkedConditionIds.set(
      checked ? this.selectedConditions().map(c => c.path) : []
    );
  }

  toggleLeftPaneExpand(): void {
    this.leftPaneExpanded.update(v => !v);
  }

  onCancel(): void {
    this.router.navigate(['/ran-filter']);
  }

  /**
   * Switches the open result between the impact summary and the full node list.
   *
   * This is a view change, not a new verification: the filter stays verified, no
   * success alert is raised, and each variant is fetched at most once per run.
   */
  onShowNodesChange(checked: boolean): void {
    this.showNodes.set(checked);
    const panel = this.verifyPanelRef?.instance;
    if (!panel) {
      return;
    }
    panel.showNodes = checked;

    const impactOnly = !checked;
    const cached = this.verifyResultCache.get(impactOnly);
    if (cached) {
      this.verifyResult.set(cached);
      panel.result = cached;
      return;
    }

    panel.loadingNodes = true;
    this.requestVerifyResult(impactOnly, true)
      .pipe(
        /* The modal may be gone by the time the nodes arrive; writing to the
           detached panel would resurrect a view the user already dismissed. */
        filter(() => this.verifyPanelRef?.instance === panel),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: (result: TestFilterResponse) => {
          panel.loadingNodes = false;
          this.verifyResult.set(result);
          panel.result = result;
        },
        error: () => {
          panel.loadingNodes = false;
          this.showNodes.set(!checked);
          panel.showNodes = !checked;
        },
      });
  }

  clearExecuteResult(): void {
    this.disposeVerifyOverlay();
    this.verifyResult.set(undefined);
    /* Back to the cheap impact-only default, so the next run does not silently
       fetch the full node list and a reopened panel matches its checkbox. */
    this.showNodes.set(false);
    this.verifyTriggerElement?.focus();
    this.verifyTriggerElement = null;
  }

  /* Stored filters only carry path, operator and value. The catalog metadata that
     drives type, enum and range validation has to be looked up separately.
     Not needed in the vendor-mismatch branch: it discards all conditions. */
  private resolveConditionMetadata(vendor: string, fromRetry = false): void {
    const conditions = this.selectedConditions();
    if (!this.isEditMode() || conditions.length === 0) {
      return;
    }

    this.metadataLoading.set(true);
    this.ranFilterService
      .resolveQueryAttributes$(vendor, conditions)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(lookup => {
        this.metadataLoading.set(false);
        const merged = this.ranFilterService.mergeConditionMetadata(
          this.selectedConditions(),
          lookup
        );
        this.selectedConditions.set(merged);
        this.conditionErrors.set(
          merged.map(c => this.validateConditionValue(c, c.filterValue))
        );
        // The retry button is removed with its banner, so focus has to go somewhere.
        if (fromRetry) {
          this.focusConditionRow(0);
        }
      });
  }

  retryConditionMetadata(): void {
    const vendor = this.selectedVendor();
    if (vendor) {
      this.resolveConditionMetadata(vendor, true);
    }
  }

  private loadVendors(preferredVendor?: string): void {
    this.ranFilterService
      .listFilterVendors$()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: rawVendors => {
          const vendors = rawVendors.map(v => ({
            ...v,
            vendor: v.vendor
              ? v.vendor.charAt(0).toUpperCase() + v.vendor.slice(1)
              : v.vendor,
          }));
          this.vendors.set(vendors);

          if (preferredVendor) {
            const preferredLower = preferredVendor.toLowerCase();
            const foundVendor = vendors.find(
              v => v.vendor?.toLowerCase() === preferredLower
            );
            if (!foundVendor) {
              this.modalConfirmationService
                .openConfirmationModal(
                  'ranFilter.edit.modal.vendorNotFound.confirmButton',
                  'ranFilter.edit.modal.vendorNotFound.title',
                  'ranFilter.edit.modal.vendorNotFound.text',
                  { vendor: preferredVendor }
                )
                .pipe(take(1), takeUntilDestroyed(this.destroyRef))
                .subscribe(confirmed => {
                  if (confirmed) {
                    this.selectedConditions.set([]);
                    this.conditionErrors.set([]);
                    this.checkedConditionIds.set([]);
                    const defaultLower = this.defaultVendor.toLowerCase();
                    const fallbackVendor =
                      vendors.find(
                        v => v.vendor?.toLowerCase() === defaultLower
                      ) ?? vendors[0];
                    if (fallbackVendor?.vendor) {
                      this.selectedVendor.set(fallbackVendor.vendor);
                      this.onSearch();
                    }
                  } else {
                    this.router.navigate(['/ran-filter']);
                  }
                });
              return;
            }
            this.selectedVendor.set(foundVendor.vendor);
            this.onSearch();
            this.resolveConditionMetadata(foundVendor.vendor!);
          } else {
            const defaultLower = this.defaultVendor.toLowerCase();
            const defaultVendor =
              vendors.find(v => v.vendor?.toLowerCase() === defaultLower) ??
              vendors[0];
            if (defaultVendor?.vendor) {
              this.selectedVendor.set(defaultVendor.vendor);
              this.onSearch();
            }
          }
        },
      });
  }
}
