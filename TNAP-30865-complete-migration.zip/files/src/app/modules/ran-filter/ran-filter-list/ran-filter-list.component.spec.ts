/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
  Component,
  ContentChild,
  ContentChildren,
  DebugElement,
  Directive,
  EventEmitter,
  HostBinding,
  inject,
  Input,
  Output,
  Pipe,
  PipeTransform,
  QueryList,
  signal,
  TemplateRef,
  WritableSignal,
} from '@angular/core';
import { By } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { of, NEVER, Subject, throwError } from 'rxjs';
import { Overlay } from '@angular/cdk/overlay';
import { TranslateService } from '@ngx-translate/core';
import { ColumnDefinition } from '@portal-mfe/tnap-ui-kit/components/data-table';
import { Sort, SortDirection } from '@portal-mfe/tnap-ui-kit/components/sort';

import { RanFilterListComponent } from './ran-filter-list.component';
import {
  RanFilterListState,
  RanFilterService,
} from '../../../services/ran-filterservice/ran-filter.service';
import { RanFilter } from '../../../../../openapi/output/model/ranFilter.model';
import { RanFilterExportService } from '../../../services/ran-filterservice/ran-filter-export.service';
import type { DownloadProgress } from '../../../services/ran-filterservice/ran-filter-export.service';
import { RanFilterResponse } from '../../../../../openapi/output/model/ranFilterResponse.model';
import { ExecuteFilterResponse } from '../../../../../openapi/output/model/executeFilterResponse.model';
import { ModalConfirmationService } from '../../../services/common-functionalities/modal-confirmation.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Pipe({ name: 'translate', standalone: false })
class MockTranslatePipe implements PipeTransform {
  transform(value: string, params?: Record<string, unknown>): string {
    return params ? `${value}|${JSON.stringify(params)}` : value;
  }
}

@Pipe({ name: 'hasPermissionPipe', standalone: false })
class MockHasPermissionPipe implements PipeTransform {
  transform(): unknown {
    return of(true);
  }
}

/** Stub for NgbTooltip, exposing the resolved text as an attribute for assertions. */
@Directive({
  // eslint-disable-next-line @angular-eslint/directive-selector
  selector: '[ngbTooltip]',
  standalone: false,
})
class MockNgbTooltipDirective {
  @Input() ngbTooltip?: string;
  @Input() placement?: string;
  @Input() container?: string;

  @HostBinding('attr.data-tooltip')
  get tooltipText(): string | null {
    // NgbTooltip renders nothing for an empty value.
    return this.ngbTooltip || null;
  }
}

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'tnap-layout',
  template:
    '<ng-content></ng-content><ng-content select="header"></ng-content>',
  standalone: false,
})
class MockLayoutComponent {}

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'tnap-title',
  template: '',
  standalone: false,
})
class MockTitleComponent {
  @Input() title?: string;
}

@Directive({
  // eslint-disable-next-line @angular-eslint/directive-selector
  selector: '[tnapButton]',
  standalone: false,
})
class MockTnapButtonDirective {
  @Input() variant?: string;
  @Input() loading?: boolean;
}

@Directive({
  selector: '[appTableCellDefinition]',
  standalone: false,
})
class MockTableCellDefinitionDirective {
  @Input() colName?: string;
  readonly templateRef = inject<TemplateRef<unknown>>(TemplateRef);
}

@Directive({
  selector: '[appTableHeaderDefinition]',
  standalone: false,
})
class MockTableHeaderDefinitionDirective {
  @Input() colName?: string;
}

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'tnap-input-search',
  template: '',
  standalone: false,
})
class MockInputSearchComponent {
  @Input() value?: string;
  @Input() placeholder?: string;
  @Input() ariaLabel?: string;
  @Output() filterChange = new EventEmitter<string | undefined>();
  @Output() resetFilter = new EventEmitter<void>();
}

/**
 * Stub for the @portal-mfe/tnap-ui-kit more-actions item directive.
 */
@Directive({
  // eslint-disable-next-line @angular-eslint/directive-selector
  selector: 'ng-template[tnapMoreActionsItem]',
  standalone: false,
})
class MockMoreActionsItemDirective {
  @Input() separator?: boolean;
  @Input() disabled?: boolean;
  @Input() hint?: string;
  @Output() tnapMoreActionsItemSelect = new EventEmitter<void>();
  readonly templateRef = inject<TemplateRef<unknown>>(TemplateRef);
}

/**
 * Stub for the @portal-mfe/tnap-ui-kit more-actions button.
 *
 * Uses the same `@ContentChildren` defaults as the real component so the test
 * also covers that items declared inside `@if` blocks are still picked up.
 */
@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'tnap-more-actions-button',
  template: `@for (item of menuItems; track $index) {
    <button
      type="button"
      [attr.aria-disabled]="item.disabled ? 'true' : null"
      (click)="onItemSelect(item)">
      <ng-container [ngTemplateOutlet]="item.templateRef"></ng-container>
    </button>
    @if (item.hint) {
      <div class="mock-more-actions-hint">{{ item.hint }}</div>
    }
  }`,
  standalone: false,
  host: {
    '[attr.data-aria-label]': 'ariaLabel',
  },
})
class MockMoreActionsButtonComponent {
  @Input() ariaLabel?: string;
  @Input() placement?: string;
  @Input() buttonBorder?: boolean;
  @Input() menuWidth?: string;

  @ContentChildren(MockMoreActionsItemDirective)
  items?: QueryList<MockMoreActionsItemDirective>;

  get menuItems(): MockMoreActionsItemDirective[] {
    return this.items?.toArray() ?? [];
  }

  onItemSelect(item: MockMoreActionsItemDirective): void {
    if (item.disabled) {
      return;
    }
    item.tnapMoreActionsItemSelect.emit();
  }
}

/**
 * Stub for the @portal-mfe/tnap-ui-kit progress bar status template.
 */
@Directive({
  // eslint-disable-next-line @angular-eslint/directive-selector
  selector: 'ng-template[tnapProgressBarStatus]',
  standalone: false,
})
class MockProgressBarStatusDirective {
  readonly templateRef = inject<TemplateRef<unknown>>(TemplateRef);
}

/**
 * Stub for the @portal-mfe/tnap-ui-kit progress bar. The live region markup and
 * the ARIA attributes are covered by the kit, so the stub only exposes the
 * bindings, but it mirrors the contract detail the template relies on: the
 * status template is rendered only while the transfer is active and receives
 * the percentage. Throttling the announced value to `announceStep` is the
 * kit's job and is therefore not modelled here.
 * The kit's grace period after `active` turns false is not modelled either, so
 * tests do not have to run in `fakeAsync`.
 */
@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'tnap-progress-bar',
  template: `<div class="mock-progress-status">
    @if (status && active) {
      <ng-container
        [ngTemplateOutlet]="status.templateRef"
        [ngTemplateOutletContext]="{
          $implicit: announcedPercent,
          percent: announcedPercent,
        }"></ng-container>
    }
  </div>`,
  standalone: false,
  host: {
    '[attr.data-active]': 'active',
    '[attr.data-value]': 'value',
    '[attr.data-aria-label]': 'ariaLabel',
    '[attr.data-value-text-indeterminate]': 'valueTextIndeterminate',
  },
})
class MockProgressBarComponent {
  @Input({ required: true }) ariaLabel!: string;
  @Input() active = false;
  @Input() value?: number | null;
  @Input() valueTextIndeterminate?: string;

  @ContentChild(MockProgressBarStatusDirective)
  status?: MockProgressBarStatusDirective;

  get announcedPercent(): number | null {
    return this.value ?? null;
  }
}

/**
 * Stub for the @portal-mfe/tnap-ui-kit data-table that mirrors the
 * inputs used in the template. Used to assert bindings without
 * pulling in the real component.
 */
@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'tnap-data-table',
  template: '',
  standalone: false,
})
class MockDataTableComponent {
  @Input() localStorageKey?: string;
  @Input() columns?: ColumnDefinition<RanFilter>[];
  @Input() data?: RanFilterResponse;
  @Input() headerLeftContent?: unknown;
  @Input() noDataMessage?: string;
  @Input() isLoading?: boolean;
  @Input() showDetailButton?: boolean;
  @Input() showColumnConfig?: boolean;
  @Input() showPagination?: boolean;
  @Input() currentSort?: Sort;

  @Output() sortChange = new EventEmitter<Sort>();

  @ContentChildren(MockTableCellDefinitionDirective)
  cellDefinitions?: QueryList<MockTableCellDefinitionDirective>;
}

describe('RanFilterListComponent', () => {
  let component: RanFilterListComponent;
  let fixture: ComponentFixture<RanFilterListComponent>;
  let ranFiltersSubject: Subject<RanFilterListState>;
  let alertServiceSpy: jasmine.SpyObj<TnapAlertService>;
  let modalConfirmationService: jasmine.SpyObj<ModalConfirmationService>;
  let ranFilterExportServiceSpy: jasmine.SpyObj<RanFilterExportService>;
  let runningExportIds: WritableSignal<ReadonlySet<number>>;
  let runningDownloadKeys: WritableSignal<ReadonlySet<string>>;
  let downloadProgressByKey: WritableSignal<
    ReadonlyMap<string, DownloadProgress>
  >;
  let ranFilterServiceStub: {
    ranFilters$: Subject<RanFilterListState>;
    refreshRanFilters: jasmine.Spy;
    deleteRanFilter$: jasmine.Spy;
    executeRanFilter$: jasmine.Spy;
  };
  let mockOverlay: {
    create: jasmine.Spy;
    position: jasmine.Spy;
    scrollStrategies: { block: jasmine.Spy };
  };
  let mockOverlayRef: {
    attach: jasmine.Spy;
    dispose: jasmine.Spy;
    backdropClick: jasmine.Spy;
    detachments: jasmine.Spy;
  };
  interface MockPanelInstance {
    filterName: string;
    result: ExecuteFilterResponse;
    showNodes: boolean;
    loadingNodes: boolean;
    closePanel: Subject<void>;
    showNodesChange: Subject<boolean>;
  }
  /** Every panel the component attached, oldest first. */
  let mockPanelInstances: MockPanelInstance[];
  let mockPanelInstance: MockPanelInstance;
  let showNodesSubject: Subject<boolean>;

  const sampleResponse: RanFilterResponse = {
    items: [
      {
        filterId: 1,
        filterName: 'Filter A',
        filterDescription: 'Description A',
        vendor: 'Ericson',
        owner: 'alice',
        createdAt: '2026-05-01T10:00:00Z',
        updatedAt: '2026-05-03T11:30:00Z',
        conditions: [],
        exportStatus: 'completed',
        exportPath:
          'do4/filter-data/filter_1/20260504091500/filter_1_20260504091500.zip',
        exportModifiedTime: '2026-05-04T09:15:00Z',
      },
      {
        filterId: 2,
        filterName: 'Filter B',
        filterDescription: 'Description B',
        vendor: 'Huawei',
        owner: 'bob',
        createdAt: '2026-05-10T12:00:00Z',
        updatedAt: '2026-05-11T13:45:00Z',
        conditions: [],
        exportStatus: 'in_progress',
        exportPath:
          'do4/filter-data/filter_2/20260512142000/filter_2_20260512142000.zip',
        exportModifiedTime: '2026-05-12T14:20:00Z',
      },
    ],
    totalCount: 2,
  };

  const rowWithoutExport: RanFilter = {
    filterId: 3,
    filterName: 'Filter C',
    filterDescription: 'Description C',
    vendor: 'Nokia',
    owner: 'carol',
    createdAt: '2026-05-20T10:00:00Z',
    updatedAt: '2026-05-21T11:30:00Z',
    conditions: [],
  };

  function getDataTable(): MockDataTableComponent {
    const debugElement: DebugElement = fixture.debugElement.query(
      By.directive(MockDataTableComponent)
    );
    expect(debugElement)
      .withContext('tnap-data-table not rendered')
      .toBeTruthy();
    return debugElement.componentInstance as MockDataTableComponent;
  }

  /**
   * Renders a single cell template outside the stubbed data table, which does not
   * project its content, so the cell markup can be asserted.
   */
  function renderCell(colName: string, row: Partial<RanFilter>): HTMLElement {
    const definition = getDataTable().cellDefinitions?.find(
      def => def.colName === colName
    );
    expect(definition)
      .withContext(`no cell template for column ${colName}`)
      .toBeTruthy();

    const view = definition!.templateRef.createEmbeddedView({
      $implicit: row,
    });
    const host = document.createElement('div');
    view.rootNodes.forEach((node: Node) => host.appendChild(node));
    view.detectChanges();
    return host;
  }

  beforeEach(async () => {
    ranFiltersSubject = new Subject<RanFilterListState>();
    ranFilterServiceStub = {
      ranFilters$: ranFiltersSubject.asObservable() as any,
      refreshRanFilters: jasmine.createSpy('refreshRanFilters'),
      deleteRanFilter$: jasmine.createSpy('deleteRanFilter$'),
      executeRanFilter$: jasmine.createSpy('executeRanFilter$'),
    };

    /* A fresh instance per attach, as the real ComponentPortal gives: with one
       shared panel a second execution cannot be told apart from the first. */
    mockPanelInstances = [];
    const attachPanel = () => {
      const instance: MockPanelInstance = {
        filterName: '',
        result: {},
        showNodes: false,
        loadingNodes: false,
        closePanel: new Subject<void>(),
        showNodesChange: new Subject<boolean>(),
      };
      mockPanelInstances.push(instance);
      mockPanelInstance = instance;
      showNodesSubject = instance.showNodesChange;
      return { instance };
    };
    mockOverlayRef = {
      attach: jasmine.createSpy('attach').and.callFake(attachPanel),
      dispose: jasmine.createSpy('dispose'),
      backdropClick: jasmine.createSpy('backdropClick').and.returnValue(NEVER),
      detachments: jasmine.createSpy('detachments').and.returnValue(NEVER),
    };

    const mockGlobalStrategy: {
      bottom: jasmine.Spy;
      centerHorizontally: jasmine.Spy;
      centerVertically: jasmine.Spy;
    } = {
      bottom: jasmine
        .createSpy('bottom')
        .and.callFake(() => mockGlobalStrategy),
      centerHorizontally: jasmine
        .createSpy('centerHorizontally')
        .and.callFake(() => mockGlobalStrategy),
      centerVertically: jasmine
        .createSpy('centerVertically')
        .and.callFake(() => mockGlobalStrategy),
    };

    mockOverlay = {
      create: jasmine.createSpy('create').and.returnValue(mockOverlayRef),
      position: jasmine.createSpy('position').and.returnValue({
        global: jasmine.createSpy('global').and.returnValue(mockGlobalStrategy),
      }),
      scrollStrategies: {
        block: jasmine.createSpy('block').and.returnValue({}),
      },
    };

    const onLangChange$ = new Subject<{
      lang: string;
      translations: unknown;
    }>();
    const translateServiceSpy = jasmine.createSpyObj(
      'TranslateService',
      ['instant'],
      { onLangChange: onLangChange$.asObservable() }
    );
    translateServiceSpy.instant.and.callFake((key: string) => key);

    alertServiceSpy = jasmine.createSpyObj('TnapAlertService', [
      'warn',
      'success',
      'error',
    ]);

    modalConfirmationService = jasmine.createSpyObj(
      'ModalConfirmationService',
      ['openConfirmationModal']
    );
    modalConfirmationService.openConfirmationModal.and.returnValue(of(true));

    runningExportIds = signal<ReadonlySet<number>>(new Set());
    runningDownloadKeys = signal<ReadonlySet<string>>(new Set());
    downloadProgressByKey = signal<ReadonlyMap<string, DownloadProgress>>(
      new Map()
    );

    ranFilterExportServiceSpy = jasmine.createSpyObj<RanFilterExportService>(
      'RanFilterExportService',
      ['downloadExport', 'uploadExport'],
      {
        runningExportIds: runningExportIds.asReadonly(),
        runningDownloadKeys: runningDownloadKeys.asReadonly(),
        downloadProgressByKey: downloadProgressByKey.asReadonly(),
      }
    );

    await TestBed.configureTestingModule({
      declarations: [
        RanFilterListComponent,
        MockTranslatePipe,
        MockHasPermissionPipe,
        MockDataTableComponent,
        MockLayoutComponent,
        MockTitleComponent,
        MockTnapButtonDirective,
        MockTableCellDefinitionDirective,
        MockTableHeaderDefinitionDirective,
        MockInputSearchComponent,
        MockMoreActionsButtonComponent,
        MockMoreActionsItemDirective,
        MockProgressBarComponent,
        MockProgressBarStatusDirective,
        MockNgbTooltipDirective,
      ],
      providers: [
        { provide: RanFilterService, useValue: ranFilterServiceStub },
        { provide: TranslateService, useValue: translateServiceSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
        {
          provide: RanFilterExportService,
          useValue: ranFilterExportServiceSpy,
        },
        {
          provide: ModalConfirmationService,
          useValue: modalConfirmationService,
        },
        { provide: Overlay, useValue: mockOverlay },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(RanFilterListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('exposes the configured columns with translated labels', () => {
    const columns = component.columns();

    expect(columns.length).toBe(12);
    expect(columns.map(c => c.key)).toEqual([
      'filterId',
      'filterName',
      'filterDescription',
      'conditionCount',
      'vendor',
      'owner',
      'createdAt',
      'updated',
      'exportStatus',
      'exportPath',
      'exportModifiedTime',
      'actions',
    ]);
    expect(columns.map(c => c.label)).toEqual([
      'ranFilter.list.fields.filterId',
      'ranFilter.list.fields.filterName',
      'ranFilter.list.fields.filterDescription',
      'ranFilter.list.fields.conditionCount',
      'ranFilter.list.fields.vendor',
      'ranFilter.list.fields.owner',
      'ranFilter.list.fields.createdAt',
      'ranFilter.list.fields.updated',
      'ranFilter.list.fields.exportStatus',
      'ranFilter.list.fields.exportPath',
      'ranFilter.list.fields.exportModifiedTime',
      'ranFilter.list.fields.actions',
    ]);
  });

  it('starts in loading state with no data', () => {
    const state = component.ranFilters();
    expect(state.loading).toBeTrue();
    expect(state.data).toBeUndefined();
  });

  it('updates the table state when ranFilters$ emits', () => {
    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();

    const state = component.sortedRanFilters();
    expect(state.loading).toBeFalse();
    expect(state.data).toEqual({
      items: [sampleResponse.items[1], sampleResponse.items[0]],
      totalCount: sampleResponse.totalCount,
    });
  });

  it('reflects loading=true emissions from the facade (e.g. on refresh)', () => {
    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();
    expect(component.sortedRanFilters().loading).toBeFalse();

    ranFiltersSubject.next({ loading: true });
    fixture.detectChanges();

    const state = component.sortedRanFilters();
    expect(state.loading).toBeTrue();
    expect(state.data).toBeUndefined();
  });

  it('updates currentSort and sorts table rows locally by a string column', () => {
    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();

    component.onSortChange({
      parameter: 'filterName',
      direction: SortDirection.DESC,
    });

    expect(component.currentSort()).toEqual({
      parameter: 'filterName',
      direction: SortDirection.DESC,
    });
    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.map(r => r.filterName)).toEqual(['Filter B', 'Filter A']);
  });

  it('sorts table rows locally by date column', () => {
    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();

    component.onSortChange({
      parameter: 'updated',
      direction: SortDirection.ASC,
    });

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.map(r => r.filterId)).toEqual([1, 2]);
  });

  it('sorts table rows locally by numeric filterId', () => {
    ranFiltersSubject.next({
      loading: false,
      data: {
        items: [sampleResponse.items[1], sampleResponse.items[0]],
        totalCount: 2,
      },
    });
    fixture.detectChanges();

    component.onSortChange({
      parameter: 'filterId',
      direction: SortDirection.ASC,
    });

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.map(r => r.filterId)).toEqual([1, 2]);
  });

  it('returns unsorted data when SortDirection.NONE is selected', () => {
    ranFiltersSubject.next({
      loading: false,
      data: {
        items: [sampleResponse.items[1], sampleResponse.items[0]],
        totalCount: 2,
      },
    });
    fixture.detectChanges();

    component.onSortChange({
      parameter: 'filterName',
      direction: SortDirection.NONE,
    });

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.map(r => r.filterName)).toEqual(['Filter B', 'Filter A']);
  });

  it('updates search value on onSearch', () => {
    component.onSearch('filter a');
    expect(component.searchValue()).toBe('filter a');
  });

  it('resets search value on onSearchReset', () => {
    component.onSearch('filter a');
    component.onSearchReset();
    expect(component.searchValue()).toBeUndefined();
  });

  it('filters rows locally by search text', () => {
    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();

    component.onSearch('huawei');

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.length).toBe(1);
    expect(rows[0].vendor).toBe('Huawei');
  });

  it('returns all rows when search is cleared', () => {
    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();

    component.onSearch('huawei');
    expect(component.sortedRanFilters().data?.items?.length).toBe(1);

    component.onSearchReset();
    expect(component.sortedRanFilters().data?.items?.length).toBe(2);
  });

  it('column value accessors return safe values for missing data', () => {
    const columns = component.columns();
    const emptyRow = {} as any;

    for (const column of columns) {
      const value = column.value(emptyRow);
      if (column.key === 'conditionCount') {
        expect(value).toBe('0');
      } else {
        expect(value).toBe('');
      }
    }
  });

  describe('tnap-data-table bindings', () => {
    it('binds static configuration inputs', () => {
      const dataTable = getDataTable();

      expect(dataTable.localStorageKey).toBe('ran-filter-list-table-v2');
      expect(dataTable.showDetailButton).toBeFalse();
      expect(dataTable.showColumnConfig).toBeTrue();
      expect(dataTable.showPagination).toBeFalse();
      expect(dataTable.noDataMessage).toBe('common.filters.noResults');
    });

    it('binds the columns signal value', () => {
      const dataTable = getDataTable();
      expect(dataTable.columns).toEqual(component.columns());
    });

    it('forwards loading state and undefined data on init', () => {
      const dataTable = getDataTable();
      expect(dataTable.isLoading).toBeTrue();
      expect(dataTable.data).toBeUndefined();
    });

    it('forwards the filter response once it arrives', () => {
      ranFiltersSubject.next({ loading: false, data: sampleResponse });
      fixture.detectChanges();

      const dataTable = getDataTable();
      expect(dataTable.isLoading).toBeFalse();
      expect(dataTable.data).toEqual({
        items: [sampleResponse.items[1], sampleResponse.items[0]],
        totalCount: sampleResponse.totalCount,
      });
    });
  });

  it('totalItemCount reflects the totalCount from the response', () => {
    expect(component.totalItemCount()).toBe(0);

    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();

    expect(component.totalItemCount()).toBe(2);
  });

  it('sorts by conditionCount numerically', () => {
    const dataWithConditions: RanFilterResponse = {
      items: [
        {
          ...sampleResponse.items[0],
          conditions: [
            { conditionId: 1 } as any,
            { conditionId: 2 } as any,
            { conditionId: 3 } as any,
          ],
        },
        {
          ...sampleResponse.items[1],
          conditions: [{ conditionId: 1 } as any],
        },
      ],
      totalCount: 2,
    };
    ranFiltersSubject.next({ loading: false, data: dataWithConditions });
    fixture.detectChanges();

    component.onSortChange({
      parameter: 'conditionCount',
      direction: SortDirection.ASC,
    });

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.map(r => r.conditions.length)).toEqual([1, 3]);
  });

  it('sorts by createdAt as date', () => {
    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();

    component.onSortChange({
      parameter: 'createdAt',
      direction: SortDirection.DESC,
    });

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.map(r => r.filterId)).toEqual([2, 1]);
  });

  it('sorts by filterDescription', () => {
    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();

    component.onSortChange({
      parameter: 'filterDescription',
      direction: SortDirection.DESC,
    });

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.map(r => r.filterDescription)).toEqual([
      'Description B',
      'Description A',
    ]);
  });

  it('sorts by vendor', () => {
    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();

    component.onSortChange({
      parameter: 'vendor',
      direction: SortDirection.ASC,
    });

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.map(r => r.vendor)).toEqual(['Ericson', 'Huawei']);
  });

  it('sorts by owner', () => {
    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();

    component.onSortChange({
      parameter: 'owner',
      direction: SortDirection.ASC,
    });

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.map(r => r.owner)).toEqual(['alice', 'bob']);
  });

  it('handles sort by unknown column gracefully (default case)', () => {
    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();

    component.onSortChange({
      parameter: 'unknownColumn',
      direction: SortDirection.ASC,
    });

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.length).toBe(2);
  });

  it('handles rows with missing optional fields during sort', () => {
    const sparseData: RanFilterResponse = {
      items: [
        {
          filterName: 'Z',
          filterDescription: '',
          vendor: '',
          conditions: [],
        } as any,
        {
          filterId: 5,
          filterName: 'A',
          filterDescription: '',
          vendor: '',
          conditions: [],
        },
      ],
      totalCount: 2,
    };
    ranFiltersSubject.next({ loading: false, data: sparseData });
    fixture.detectChanges();

    component.onSortChange({
      parameter: 'filterId',
      direction: SortDirection.ASC,
    });

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows[0].filterId ?? 0).toBe(0);
    expect(rows[1].filterId).toBe(5);
  });

  it('handles toDateNumber with invalid date string', () => {
    const dataWithBadDate: RanFilterResponse = {
      items: [
        { ...sampleResponse.items[0], createdAt: 'not-a-date' },
        { ...sampleResponse.items[1], createdAt: '2026-05-10T12:00:00Z' },
      ],
      totalCount: 2,
    };
    ranFiltersSubject.next({ loading: false, data: dataWithBadDate });
    fixture.detectChanges();

    component.onSortChange({
      parameter: 'createdAt',
      direction: SortDirection.ASC,
    });

    const rows = component.sortedRanFilters().data?.items ?? [];
    // Invalid date should sort as 0 (earliest)
    expect(rows[0].createdAt).toBe('not-a-date');
  });

  it('handles toDateNumber with undefined date during sort', () => {
    const dataWithMissingDate: RanFilterResponse = {
      items: [
        { ...sampleResponse.items[0], updatedAt: undefined },
        { ...sampleResponse.items[1] },
      ],
      totalCount: 2,
    };
    ranFiltersSubject.next({ loading: false, data: dataWithMissingDate });
    fixture.detectChanges();

    component.onSortChange({
      parameter: 'updated',
      direction: SortDirection.ASC,
    });

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows[0].updatedAt).toBeUndefined();
  });

  it('filters by filterId as string', () => {
    const idData: RanFilterResponse = {
      items: [
        {
          filterId: 999,
          filterName: 'Unique',
          filterDescription: 'Desc',
          vendor: 'Nokia',
          owner: 'owner',
          createdAt: '3000-01-01T00:00:00Z',
          updatedAt: '3000-01-01T00:00:00Z',
          conditions: [],
        },
        {
          filterId: 1,
          filterName: 'Other',
          filterDescription: 'Desc',
          vendor: 'Nokia',
          owner: 'owner',
          createdAt: '3000-01-01T00:00:00Z',
          updatedAt: '3000-01-01T00:00:00Z',
          conditions: [],
        },
      ],
      totalCount: 2,
    };
    ranFiltersSubject.next({ loading: false, data: idData });
    fixture.detectChanges();

    component.onSearch('999');

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.length).toBe(1);
    expect(rows[0].filterId).toBe(999);
  });

  it('filters by owner', () => {
    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();

    component.onSearch('alice');

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.length).toBe(1);
    expect(rows[0].owner).toBe('alice');
  });

  it('filters by date string', () => {
    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();

    component.onSearch('2026-05-10');

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.length).toBe(1);
    expect(rows[0].filterId).toBe(2);
  });

  it('search trims whitespace', () => {
    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();

    component.onSearch('  huawei  ');

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.length).toBe(1);
    expect(rows[0].vendor).toBe('Huawei');
  });

  it('search is case-insensitive', () => {
    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();

    component.onSearch('FILTER A');

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.length).toBe(1);
    expect(rows[0].filterName).toBe('Filter A');
  });

  it('returns empty when search matches nothing', () => {
    ranFiltersSubject.next({ loading: false, data: sampleResponse });
    fixture.detectChanges();

    component.onSearch('nonexistent');

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.length).toBe(0);
  });

  it('combines search and sort', () => {
    const data: RanFilterResponse = {
      items: [
        {
          filterId: 1,
          filterName: 'Alpha Filter',
          filterDescription: 'Desc',
          vendor: 'Nokia',
          owner: 'user1',
          createdAt: '2026-01-01T00:00:00Z',
          updatedAt: '2026-01-02T00:00:00Z',
          conditions: [],
        },
        {
          filterId: 2,
          filterName: 'Beta Filter',
          filterDescription: 'Desc',
          vendor: 'Nokia',
          owner: 'user2',
          createdAt: '2026-02-01T00:00:00Z',
          updatedAt: '2026-02-02T00:00:00Z',
          conditions: [],
        },
        {
          filterId: 3,
          filterName: 'Gamma',
          filterDescription: 'Other',
          vendor: 'Ericson',
          owner: 'user3',
          createdAt: '2026-03-01T00:00:00Z',
          updatedAt: '2026-03-02T00:00:00Z',
          conditions: [],
        },
      ],
      totalCount: 3,
    };
    ranFiltersSubject.next({ loading: false, data });
    fixture.detectChanges();

    // Search for "Nokia" vendor, then sort by filterName DESC
    component.onSearch('Nokia');
    component.onSortChange({
      parameter: 'filterName',
      direction: SortDirection.DESC,
    });

    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.length).toBe(2);
    expect(rows.map(r => r.filterName)).toEqual([
      'Beta Filter',
      'Alpha Filter',
    ]);
    expect(component.sortedRanFilters().data?.totalCount).toBe(2);
  });

  it('matchesSearch handles row with missing optional fields', () => {
    const sparseData: RanFilterResponse = {
      items: [
        {
          filterName: 'Sparse',
          filterDescription: '',
          vendor: '',
          conditions: [],
        } as any,
      ],
      totalCount: 1,
    };
    ranFiltersSubject.next({ loading: false, data: sparseData });
    fixture.detectChanges();

    component.onSearch('Sparse');
    const rows = component.sortedRanFilters().data?.items ?? [];
    expect(rows.length).toBe(1);
  });

  it('column value accessors return correct values for populated rows', () => {
    const columns = component.columns();
    const row = sampleResponse.items[0];

    expect(columns[0].value(row)).toBe('1');
    expect(columns[1].value(row)).toBe('Filter A');
    expect(columns[2].value(row)).toBe('Description A');
    expect(columns[3].value(row)).toBe('0');
    expect(columns[4].value(row)).toBe('Ericson');
    expect(columns[5].value(row)).toBe('alice');
    expect(columns[6].value(row)).toBe('2026-05-01T10:00:00Z');
    expect(columns[7].value(row)).toBe('2026-05-03T11:30:00Z');
    expect(columns[8].value(row)).toBe(
      'ranFilter.list.exportStatusValues.completed'
    );
    expect(columns[9].value(row)).toBe(
      'do4/filter-data/filter_1/20260504091500/filter_1_20260504091500.zip'
    );
    expect(columns[10].value(row)).toBe('2026-05-04T09:15:00Z');
    expect(columns[11].value(row)).toBe('');
  });

  it('conditionCount column returns correct count for rows with conditions', () => {
    const columns = component.columns();
    const rowWithConditions = {
      ...sampleResponse.items[0],
      conditions: [{ conditionId: 1 } as any, { conditionId: 2 } as any],
    };
    expect(columns[3].value(rowWithConditions)).toBe('2');
  });

  describe('export columns', () => {
    it('sorts by exportStatus', () => {
      ranFiltersSubject.next({ loading: false, data: sampleResponse });
      fixture.detectChanges();

      component.onSortChange({
        parameter: 'exportStatus',
        direction: SortDirection.ASC,
      });

      const rows = component.sortedRanFilters().data?.items ?? [];
      expect(rows.map(r => r.exportStatus)).toEqual([
        'completed',
        'in_progress',
      ]);
    });

    it('sorts by exportPath', () => {
      ranFiltersSubject.next({ loading: false, data: sampleResponse });
      fixture.detectChanges();

      component.onSortChange({
        parameter: 'exportPath',
        direction: SortDirection.DESC,
      });

      const rows = component.sortedRanFilters().data?.items ?? [];
      expect(rows.map(r => r.exportPath)).toEqual([
        'do4/filter-data/filter_2/20260512142000/filter_2_20260512142000.zip',
        'do4/filter-data/filter_1/20260504091500/filter_1_20260504091500.zip',
      ]);
    });

    it('sorts by exportModifiedTime as date', () => {
      ranFiltersSubject.next({ loading: false, data: sampleResponse });
      fixture.detectChanges();

      component.onSortChange({
        parameter: 'exportModifiedTime',
        direction: SortDirection.DESC,
      });

      const rows = component.sortedRanFilters().data?.items ?? [];
      expect(rows.map(r => r.filterId)).toEqual([2, 1]);
    });

    it('filters by exportPath', () => {
      ranFiltersSubject.next({ loading: false, data: sampleResponse });
      fixture.detectChanges();

      component.onSearch('filter_2_20260512142000');

      const rows = component.sortedRanFilters().data?.items ?? [];
      expect(rows).toHaveSize(1);
      expect(rows[0].filterId).toBe(2);
    });

    it('filters by the translated export status label', () => {
      ranFiltersSubject.next({ loading: false, data: sampleResponse });
      fixture.detectChanges();

      component.onSearch('exportStatusValues.in_progress');

      const rows = component.sortedRanFilters().data?.items ?? [];
      expect(rows).toHaveSize(1);
      expect(rows[0].filterId).toBe(2);
    });

    it('resolves a label for every export status of the API enum', () => {
      expect(component.exportStatusLabels()).toEqual({
        in_progress: 'ranFilter.list.exportStatusValues.in_progress',
        completed: 'ranFilter.list.exportStatusValues.completed',
        error: 'ranFilter.list.exportStatusValues.error',
      });
    });

    it('hides only the S3 key column by default', () => {
      const hiddenKeys = component
        .columns()
        .filter(column => column.visible === false)
        .map(column => column.key);

      expect(hiddenKeys).toEqual(['exportPath']);
    });

    it('returns empty column values for rows without export data', () => {
      const columns = component.columns();

      expect(columns[8].value(rowWithoutExport)).toBe('');
      expect(columns[9].value(rowWithoutExport)).toBe('');
      expect(columns[10].value(rowWithoutExport)).toBe('');
    });

    it('sorts rows without an export timestamp first in ascending order', () => {
      ranFiltersSubject.next({
        loading: false,
        data: {
          items: [...sampleResponse.items, rowWithoutExport],
          totalCount: 3,
        },
      });
      fixture.detectChanges();

      component.onSortChange({
        parameter: 'exportModifiedTime',
        direction: SortDirection.ASC,
      });

      const rows = component.sortedRanFilters().data?.items ?? [];
      expect(rows.map(r => r.filterId)).toEqual([3, 1, 2]);
    });

    it('sorts rows without an export status first in ascending order', () => {
      ranFiltersSubject.next({
        loading: false,
        data: {
          items: [...sampleResponse.items, rowWithoutExport],
          totalCount: 3,
        },
      });
      fixture.detectChanges();

      component.onSortChange({
        parameter: 'exportStatus',
        direction: SortDirection.ASC,
      });

      const rows = component.sortedRanFilters().data?.items ?? [];
      expect(rows.map(r => r.filterId)).toEqual([3, 1, 2]);
    });
  });

  describe('export cell templates', () => {
    it('renders the translated export status as plain text', () => {
      const host = renderCell('exportStatus', sampleResponse.items[0]);

      expect(host.querySelector('.qa_export_status')?.textContent?.trim()).toBe(
        'ranFilter.list.exportStatusValues.completed'
      );
      expect(host.querySelector('tnap-badge')).toBeNull();
    });

    it('falls back to the raw value for statuses without a label', () => {
      const host = renderCell('exportStatus', {
        exportStatus: 'archived' as RanFilter.ExportStatusEnum,
      });

      expect(host.querySelector('.qa_export_status')?.textContent?.trim()).toBe(
        'archived'
      );
    });

    it('renders a dash when the export status is missing', () => {
      const host = renderCell('exportStatus', { filterId: 3 });

      expect(host.querySelector('.qa_export_status')?.textContent?.trim()).toBe(
        '-'
      );
    });

    it('renders the S3 key with the full value as title', () => {
      const host = renderCell('exportPath', sampleResponse.items[0]);
      const path = host.querySelector('.qa_export_path');
      const expected =
        'do4/filter-data/filter_1/20260504091500/filter_1_20260504091500.zip';

      expect(path?.textContent?.trim()).toBe(expected);
      expect(path?.getAttribute('title')).toBe(expected);
    });

    it('renders no S3 key element when the export path is missing', () => {
      const host = renderCell('exportPath', { filterId: 3 });

      expect(host.querySelector('.qa_export_path')).toBeNull();
    });

    it('renders the formatted export timestamp', () => {
      const host = renderCell('exportModifiedTime', sampleResponse.items[0]);

      expect(
        host.querySelector('.qa_export_modified_time')?.textContent?.trim()
      ).toMatch(/^\d{2}\.\d{2}\.\d{4} \d{2}:\d{2}$/);
    });

    it('renders a dash when the export timestamp is missing', () => {
      const host = renderCell('exportModifiedTime', { filterId: 3 });

      expect(
        host.querySelector('.qa_export_modified_time')?.textContent?.trim()
      ).toBe('-');
    });
  });

  describe('actions', () => {
    it('opens confirmation modal and deletes filter on confirm', () => {
      const row = sampleResponse.items[0];
      ranFilterServiceStub.deleteRanFilter$.and.returnValue(of(undefined));

      component.onDelete(row);

      expect(
        modalConfirmationService.openConfirmationModal
      ).toHaveBeenCalledWith(
        'common.buttons.yes',
        'ranFilter.list.modal.delete.title',
        'ranFilter.list.modal.delete.text',
        { name: row.filterName }
      );
      expect(ranFilterServiceStub.deleteRanFilter$).toHaveBeenCalledWith(
        row.filterId
      );
      expect(alertServiceSpy.success).toHaveBeenCalledWith(
        'ranFilter.list.deleteSuccess'
      );
      expect(ranFilterServiceStub.refreshRanFilters).toHaveBeenCalled();
    });

    it('does not delete when modal is dismissed', () => {
      modalConfirmationService.openConfirmationModal.and.returnValue(of(false));
      const row = sampleResponse.items[0];

      component.onDelete(row);

      expect(modalConfirmationService.openConfirmationModal).toHaveBeenCalled();
      expect(ranFilterServiceStub.deleteRanFilter$).not.toHaveBeenCalled();
    });

    it('does not call refreshRanFilters when delete fails', () => {
      ranFilterServiceStub.deleteRanFilter$.and.returnValue(
        throwError(() => new Error('fail'))
      );
      const row = sampleResponse.items[0];

      component.onDelete(row);

      expect(ranFilterServiceStub.refreshRanFilters).not.toHaveBeenCalled();
    });

    it('navigates to edit route on onEdit', () => {
      const routerSpy = TestBed.inject(Router);
      spyOn(routerSpy, 'navigate');
      const row = sampleResponse.items[0];

      component.onEdit(row);

      expect(routerSpy.navigate).toHaveBeenCalledWith([
        '/ran-filter/edit',
        row.filterId,
      ]);
    });

    it('calls executeRanFilter$ with the filter id on execute', () => {
      const executeResponse: ExecuteFilterResponse = { payload: { count: 3 } };
      ranFilterServiceStub.executeRanFilter$.and.returnValue(
        of(executeResponse)
      );
      const row = sampleResponse.items[0];

      component.onExecute(row);

      expect(ranFilterServiceStub.executeRanFilter$).toHaveBeenCalledWith({
        filterId: row.filterId,
        impactOnly: true,
      });
    });

    it('opens overlay with correct filter name and response on success', () => {
      const executeResponse: ExecuteFilterResponse = { payload: { count: 3 } };
      ranFilterServiceStub.executeRanFilter$.and.returnValue(
        of(executeResponse)
      );
      const row = sampleResponse.items[0];

      expect(mockOverlay.create).not.toHaveBeenCalled();

      component.onExecute(row);

      expect(mockOverlay.create).toHaveBeenCalled();
      expect(mockOverlayRef.attach).toHaveBeenCalled();
      expect(mockPanelInstance.filterName).toBe(row.filterName);
      expect(mockPanelInstance.result).toEqual(executeResponse);
    });

    it('disposes overlay on closeExecuteResult', () => {
      const executeResponse: ExecuteFilterResponse = { payload: {} };
      ranFilterServiceStub.executeRanFilter$.and.returnValue(
        of(executeResponse)
      );
      component.onExecute(sampleResponse.items[0]);
      expect(mockOverlayRef.dispose).not.toHaveBeenCalled();

      component.closeExecuteResult();

      expect(mockOverlayRef.dispose).toHaveBeenCalled();
    });

    it('restores focus to the trigger element after closing', () => {
      const executeResponse: ExecuteFilterResponse = { payload: {} };
      ranFilterServiceStub.executeRanFilter$.and.returnValue(
        of(executeResponse)
      );
      const mockButton = jasmine.createSpyObj<HTMLButtonElement>('button', [
        'focus',
      ]);
      const mockEvent = { currentTarget: mockButton } as unknown as MouseEvent;

      component.onExecute(sampleResponse.items[0], mockEvent);
      component.closeExecuteResult();

      expect(mockButton.focus).toHaveBeenCalled();
    });

    describe('show nodes toggle', () => {
      const impactResult: ExecuteFilterResponse = { payload: { count: 3 } };
      const nodesResult: ExecuteFilterResponse = {
        payload: { count: 3, nodeDataList: [{ id: 1 }] },
      };

      const openPanel = (): void => {
        ranFilterServiceStub.executeRanFilter$.and.returnValue(
          of(impactResult)
        );
        component.onExecute(sampleResponse.items[0]);
        ranFilterServiceStub.executeRanFilter$.calls.reset();
      };

      it('fetches the node variant once and mirrors the checkbox', () => {
        openPanel();
        ranFilterServiceStub.executeRanFilter$.and.returnValue(of(nodesResult));

        showNodesSubject.next(true);

        expect(mockPanelInstance.showNodes).toBeTrue();
        expect(mockPanelInstance.result).toEqual(nodesResult);
        expect(ranFilterServiceStub.executeRanFilter$).toHaveBeenCalledOnceWith(
          { filterId: sampleResponse.items[0].filterId, impactOnly: false },
          true
        );
      });

      it('serves the impact variant from cache when switched back off', () => {
        openPanel();
        ranFilterServiceStub.executeRanFilter$.and.returnValue(of(nodesResult));
        showNodesSubject.next(true);
        ranFilterServiceStub.executeRanFilter$.calls.reset();

        showNodesSubject.next(false);

        expect(ranFilterServiceStub.executeRanFilter$).not.toHaveBeenCalled();
        expect(mockPanelInstance.result).toEqual(impactResult);
        expect(mockPanelInstance.showNodes).toBeFalse();
      });

      it('clears the spinner and reverts the checkbox when the fetch fails', () => {
        openPanel();
        ranFilterServiceStub.executeRanFilter$.and.returnValue(
          throwError(() => new Error('fail'))
        );

        showNodesSubject.next(true);

        expect(mockPanelInstance.loadingNodes).toBeFalse();
        expect(mockPanelInstance.showNodes).toBeFalse();
        expect(mockPanelInstance.result).toEqual(impactResult);
      });

      it('caches per execution, so a second filter starts from scratch', () => {
        openPanel();
        ranFilterServiceStub.executeRanFilter$.and.returnValue(of(nodesResult));
        showNodesSubject.next(true);

        ranFilterServiceStub.executeRanFilter$.and.returnValue(
          of(impactResult)
        );
        component.onExecute(sampleResponse.items[1]);
        ranFilterServiceStub.executeRanFilter$.calls.reset();
        ranFilterServiceStub.executeRanFilter$.and.returnValue(of(nodesResult));

        showNodesSubject.next(true);

        expect(ranFilterServiceStub.executeRanFilter$).toHaveBeenCalledTimes(1);
      });

      /* Executing B leaves A's panel on screen until B answers, so a component-wide
         filter id would send A's toggle after B's nodes and show them in A's panel. */
      it('keeps an open panel toggling against the filter it was opened for', () => {
        openPanel();
        const panelA = mockPanelInstance;
        const toggleA = showNodesSubject;

        // B is requested but never answers, so A's panel is still the one on screen.
        ranFilterServiceStub.executeRanFilter$.and.returnValue(NEVER);
        component.onExecute(sampleResponse.items[1]);
        ranFilterServiceStub.executeRanFilter$.calls.reset();
        ranFilterServiceStub.executeRanFilter$.and.returnValue(of(nodesResult));

        toggleA.next(true);

        expect(ranFilterServiceStub.executeRanFilter$).toHaveBeenCalledOnceWith(
          {
            filterId: sampleResponse.items[0].filterId,
            impactOnly: false,
          },
          true
        );
        expect(panelA.result).toEqual(nodesResult);
      });

      it('keeps an open panel serving its own cached impact result', () => {
        openPanel();
        const toggleA = showNodesSubject;
        ranFilterServiceStub.executeRanFilter$.and.returnValue(of(nodesResult));
        toggleA.next(true);

        ranFilterServiceStub.executeRanFilter$.and.returnValue(NEVER);
        component.onExecute(sampleResponse.items[1]);
        ranFilterServiceStub.executeRanFilter$.calls.reset();

        toggleA.next(false);

        expect(ranFilterServiceStub.executeRanFilter$).not.toHaveBeenCalled();
        expect(mockPanelInstances[0].result).toEqual(impactResult);
      });
    });

    it('does not open overlay when execute fails', () => {
      ranFilterServiceStub.executeRanFilter$.and.returnValue(
        throwError(() => new Error('fail'))
      );
      const row = sampleResponse.items[0];

      component.onExecute(row);

      expect(mockOverlay.create).not.toHaveBeenCalled();
    });

    it('navigateToCreate routes to /ran-filter/create', () => {
      const router = TestBed.inject(Router);
      spyOn(router, 'navigate');

      component.navigateToCreate();

      expect(router.navigate).toHaveBeenCalledWith(['/ran-filter/create']);
    });
  });

  describe('export actions', () => {
    it('delegates download to the export service', () => {
      const row = sampleResponse.items[0];

      component.onDownload(row);

      expect(ranFilterExportServiceSpy.downloadExport).toHaveBeenCalledWith(
        row
      );
    });

    it('delegates upload to the export service', () => {
      const row = sampleResponse.items[0];

      component.onUpload(row);

      expect(ranFilterExportServiceSpy.uploadExport).toHaveBeenCalledWith(row);
    });
  });

  describe('actions cell template', () => {
    it('renders edit, execute and upload buttons with the design icons', () => {
      const host = renderCell('actions', sampleResponse.items[0]);

      expect(host.querySelector('.qa_filter_action_edit .bi-pencil-square'))
        .withContext('edit icon')
        .toBeTruthy();
      expect(host.querySelector('.qa_filter_action_execute svg path'))
        .withContext('execute icon')
        .toBeTruthy();
      expect(host.querySelector('.qa_filter_action_upload .bi-cloud-arrow-up'))
        .withContext('upload icon')
        .toBeTruthy();
    });

    it('labels the icon-only buttons with an action tooltip and an aria-label naming the filter', () => {
      const host = renderCell('actions', sampleResponse.items[0]);

      expect(
        host
          .querySelector('.qa_filter_action_edit')
          ?.getAttribute('data-tooltip')
      ).toBe('ranFilter.list.actionLabels.edit');
      expect(
        host.querySelector('.qa_filter_action_edit')?.getAttribute('aria-label')
      ).toBe('ranFilter.list.ariaLabels.edit|{"name":"Filter A"}');

      expect(
        host
          .querySelector('.qa_filter_action_execute')
          ?.getAttribute('data-tooltip')
      ).toBe('ranFilter.list.actionLabels.preview');
      expect(
        host
          .querySelector('.qa_filter_action_execute')
          ?.getAttribute('aria-label')
      ).toBe('ranFilter.list.ariaLabels.preview|{"name":"Filter A"}');

      expect(
        host
          .querySelector('.qa_filter_action_upload')
          ?.getAttribute('data-tooltip')
      ).toBe('ranFilter.list.actionLabels.upload');
      expect(
        host
          .querySelector('.qa_filter_action_upload')
          ?.getAttribute('aria-label')
      ).toBe('ranFilter.list.ariaLabels.upload|{"name":"Filter A"}');

      expect(
        host
          .querySelector('.qa_filter_action_more')
          ?.getAttribute('data-aria-label')
      ).toBe('ranFilter.list.ariaLabels.moreActions|{"name":"Filter A"}');
      expect(
        host
          .querySelector('.qa_filter_action_more')
          ?.parentElement?.getAttribute('data-tooltip')
      ).toBe('common.buttons.moreActions');
    });

    it('explains the disabled upload button through the wrapper tooltip', () => {
      const enabled = renderCell('actions', sampleResponse.items[0]);
      const pending = renderCell('actions', sampleResponse.items[1]);

      expect(
        enabled
          .querySelector('.qa_filter_action_upload')
          ?.parentElement?.getAttribute('data-tooltip')
      ).toBeNull();
      expect(
        pending
          .querySelector('.qa_filter_action_upload')
          ?.parentElement?.getAttribute('data-tooltip')
      ).toBe('ranFilter.list.uploadHints.running');
    });

    it('names the menu entries after the action they perform', () => {
      const host = renderCell('actions', sampleResponse.items[0]);

      expect(
        host.querySelector('.qa_filter_action_download')?.textContent?.trim()
      ).toBe('ranFilter.list.actionLabels.download');
      expect(
        host.querySelector('.qa_filter_action_delete')?.textContent?.trim()
      ).toBe('ranFilter.list.actionLabels.delete');
    });

    it('moves download and delete into the more-actions menu', () => {
      const host = renderCell('actions', sampleResponse.items[0]);

      expect(host.querySelector('.qa_filter_action_more'))
        .withContext('more actions button')
        .toBeTruthy();
      expect(host.querySelector('.qa_filter_action_download .bi-download'))
        .withContext('download item')
        .toBeTruthy();
      expect(host.querySelector('.qa_filter_action_delete .bi-trash3'))
        .withContext('delete item')
        .toBeTruthy();
      expect(host.querySelector('.qa_filter_action_delete')?.classList)
        .withContext('delete item is styled as destructive')
        .toContain('text-danger');
    });

    it('disables the download entry only while the export is pending', () => {
      const host = renderCell('actions', sampleResponse.items[1]);
      const download = host.querySelector('.qa_filter_action_download');

      expect(download?.closest('button')?.getAttribute('aria-disabled')).toBe(
        'true'
      );
      expect(
        host.querySelector('.mock-more-actions-hint')?.textContent?.trim()
      ).toBe('ranFilter.list.downloadHints.inProgress');
    });

    it('keeps the download entry enabled when no export exists', () => {
      const host = renderCell('actions', rowWithoutExport);
      const download = host.querySelector('.qa_filter_action_download');

      expect(download).toBeTruthy();
      expect(
        download?.closest('button')?.getAttribute('aria-disabled')
      ).toBeNull();
      expect(host.querySelector('.mock-more-actions-hint')).toBeNull();
      expect(host.querySelector('.qa_filter_action_delete')).toBeTruthy();
    });

    it('keeps the download entry enabled after a failed export', () => {
      const host = renderCell('actions', {
        ...sampleResponse.items[0],
        exportStatus: RanFilter.ExportStatusEnum.ERROR,
      });

      expect(
        host
          .querySelector('.qa_filter_action_download')
          ?.closest('button')
          ?.getAttribute('aria-disabled')
      ).toBeNull();
      expect(host.querySelector('.mock-more-actions-hint')).toBeNull();
    });

    it('enables the download entry and shows no hint for a completed export', () => {
      const host = renderCell('actions', sampleResponse.items[0]);
      const download = host.querySelector('.qa_filter_action_download');

      expect(
        download?.closest('button')?.getAttribute('aria-disabled')
      ).toBeNull();
      expect(host.querySelector('.mock-more-actions-hint')).toBeNull();
    });

    it('enables the upload button for a completed export', () => {
      const host = renderCell('actions', sampleResponse.items[0]);

      expect(
        host
          .querySelector<HTMLButtonElement>('.qa_filter_action_upload')
          ?.hasAttribute('disabled')
      ).toBeFalse();
    });

    it('disables the upload button while the export status is pending', () => {
      const host = renderCell('actions', sampleResponse.items[1]);

      expect(
        host
          .querySelector<HTMLButtonElement>('.qa_filter_action_upload')
          ?.hasAttribute('disabled')
      ).toBeTrue();
    });

    it('disables the upload button while an export request is still open', () => {
      runningExportIds.set(new Set([sampleResponse.items[0].filterId ?? -1]));

      const host = renderCell('actions', sampleResponse.items[0]);

      expect(
        host
          .querySelector<HTMLButtonElement>('.qa_filter_action_upload')
          ?.hasAttribute('disabled')
      ).toBeTrue();
    });

    it('disables the download entry while a download request is still open', () => {
      runningDownloadKeys.set(
        new Set([sampleResponse.items[0].exportPath ?? ''])
      );

      const host = renderCell('actions', sampleResponse.items[0]);

      expect(
        host
          .querySelector('.qa_filter_action_download')
          ?.closest('button')
          ?.getAttribute('aria-disabled')
      ).toBe('true');
      expect(
        host.querySelector('.mock-more-actions-hint')?.textContent?.trim()
      ).toBe('ranFilter.list.downloadHints.running');
    });

    it('keeps the progress bar mounted and idle while no download is in flight', () => {
      const host = renderCell('actions', sampleResponse.items[0]);

      expect(
        host.querySelector('tnap-progress-bar')?.getAttribute('data-active')
      ).toBe('false');
    });

    it('leaves the live region empty while no download is in flight', () => {
      const host = renderCell('actions', sampleResponse.items[0]);

      expect(
        host.querySelector('.mock-progress-status')?.textContent?.trim()
      ).toBe('');
    });

    it('activates the progress bar without a value before the first progress event', () => {
      const key = sampleResponse.items[0].exportPath ?? '';
      runningDownloadKeys.set(new Set([key]));

      const host = renderCell('actions', sampleResponse.items[0]);
      const progress = host.querySelector('tnap-progress-bar');

      expect(progress?.getAttribute('data-active')).toBe('true');
      expect(progress?.hasAttribute('data-value')).toBeFalse();
    });

    it('names the progress bar after the filter of its row', () => {
      const host = renderCell('actions', sampleResponse.items[0]);

      expect(
        host.querySelector('tnap-progress-bar')?.getAttribute('data-aria-label')
      ).toBe(
        `ranFilter.list.downloadHints.progressLabel|${JSON.stringify({
          name: sampleResponse.items[0].filterName,
        })}`
      );
    });

    it('passes the known percentage to the progress bar', () => {
      const key = sampleResponse.items[0].exportPath ?? '';
      runningDownloadKeys.set(new Set([key]));
      downloadProgressByKey.set(
        new Map([[key, { loaded: 250, total: 1000, percent: 25 }]])
      );

      const host = renderCell('actions', sampleResponse.items[0]);

      expect(
        host.querySelector('tnap-progress-bar')?.getAttribute('data-value')
      ).toBe('25');
    });

    it('keeps the progress bar indeterminate when the total is unknown', () => {
      const key = sampleResponse.items[0].exportPath ?? '';
      runningDownloadKeys.set(new Set([key]));
      downloadProgressByKey.set(new Map([[key, { loaded: 250 }]]));

      const host = renderCell('actions', sampleResponse.items[0]);
      const progress = host.querySelector('tnap-progress-bar');

      expect(progress?.hasAttribute('data-value')).toBeFalse();
      expect(progress?.getAttribute('data-value-text-indeterminate')).toBe(
        'ranFilter.list.downloadHints.running'
      );
    });

    it('does not treat an object prototype member as a running download', () => {
      const host = renderCell('actions', {
        ...sampleResponse.items[0],
        exportPath: 'constructor',
      });

      expect(
        host.querySelector('tnap-progress-bar')?.getAttribute('data-active')
      ).toBe('false');
      expect(
        host
          .querySelector('.qa_filter_action_download')
          ?.closest('button')
          ?.getAttribute('aria-disabled')
      ).toBeNull();
    });

    it('announces the start of a download while the percentage is unknown', () => {
      const key = sampleResponse.items[0].exportPath ?? '';
      runningDownloadKeys.set(new Set([key]));

      const host = renderCell('actions', sampleResponse.items[0]);

      expect(
        host.querySelector('.mock-progress-status')?.textContent?.trim()
      ).toBe(
        `ranFilter.list.downloadHints.startedStatus|${JSON.stringify({
          name: sampleResponse.items[0].filterName,
        })}`
      );
    });

    it('announces the download progress with the percentage of the live region', () => {
      const key = sampleResponse.items[0].exportPath ?? '';
      runningDownloadKeys.set(new Set([key]));
      downloadProgressByKey.set(
        new Map([[key, { loaded: 200, total: 1000, percent: 20 }]])
      );

      const host = renderCell('actions', sampleResponse.items[0]);

      expect(
        host.querySelector('.mock-progress-status')?.textContent?.trim()
      ).toBe(
        `ranFilter.list.downloadHints.progressStatus|${JSON.stringify({
          name: sampleResponse.items[0].filterName,
          percent: 20,
        })}`
      );
    });

    it('announces completion at 100 percent', () => {
      const key = sampleResponse.items[0].exportPath ?? '';
      runningDownloadKeys.set(new Set([key]));
      downloadProgressByKey.set(
        new Map([[key, { loaded: 1000, total: 1000, percent: 100 }]])
      );

      const host = renderCell('actions', sampleResponse.items[0]);

      expect(
        host.querySelector('.mock-progress-status')?.textContent?.trim()
      ).toBe(
        `ranFilter.list.downloadHints.progressStatus|${JSON.stringify({
          name: sampleResponse.items[0].filterName,
          percent: 100,
        })}`
      );
    });

    it('keeps the last percentage available after the transfer ended', () => {
      const key = sampleResponse.items[0].exportPath ?? '';
      downloadProgressByKey.set(
        new Map([[key, { loaded: 1000, total: 1000, percent: 100 }]])
      );

      const host = renderCell('actions', sampleResponse.items[0]);
      const progress = host.querySelector('tnap-progress-bar');

      // The kit holds its status for a grace period, so the final value has to outlive `active`.
      expect(progress?.getAttribute('data-active')).toBe('false');
      expect(progress?.getAttribute('data-value')).toBe('100');
    });
  });
});
