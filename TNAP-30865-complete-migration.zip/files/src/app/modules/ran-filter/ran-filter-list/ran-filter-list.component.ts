/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ChangeDetectionStrategy,
  Component,
  ComponentRef,
  computed,
  DestroyRef,
  inject,
  signal,
  ViewContainerRef,
} from '@angular/core';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { take, filter, switchMap, takeUntil } from 'rxjs';
import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { RanFilterExecuteResultPanelComponent } from '../ran-filter-execute-result-panel/ran-filter-execute-result-panel.component';
import { ColumnDefinition } from '@portal-mfe/tnap-ui-kit/components/data-table';
import { Sort, SortDirection } from '@portal-mfe/tnap-ui-kit/components/sort';
import { ModalConfirmationService } from '../../../services/common-functionalities/modal-confirmation.service';
import { RanFilter } from '../../../../../openapi/output/model/ranFilter.model';
import {
  RanFilterListState,
  RanFilterService,
} from '../../../services/ran-filterservice/ran-filter.service';
import { RanFilterExportService } from '../../../services/ran-filterservice/ran-filter-export.service';
import type { DownloadProgress } from '../../../services/ran-filterservice/ran-filter-export.service';
import {
  ALLOW_RAN_FILTER_CREATE,
  ALLOW_RAN_FILTER_EDIT,
  ALLOW_RAN_FILTER_DELETE,
  ALLOW_RAN_FILTER_EXECUTE,
  ALLOW_RAN_FILTER_UPLOAD,
  ALLOW_RAN_FILTER_DOWNLOAD,
} from '../../../permissions.config';
import { environment } from '../../../../environments/environment';
import { ExecuteFilterResponse } from '../../../../../openapi/output';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

const INITIAL_RAN_FILTER_TABLE_STATE: RanFilterListState = {
  loading: true,
  data: undefined,
};

const EXPORT_STATUS_LABEL_PREFIX = 'ranFilter.list.exportStatusValues.';

/** Builds a prototype-less record so a template index access cannot hit `Object.prototype`. */
function toLookup<K extends PropertyKey, V>(
  entries: readonly (readonly [K, V])[]
): Record<K, V> {
  const lookup = Object.create(null) as Record<K, V>;
  for (const [key, value] of entries) {
    lookup[key] = value;
  }
  return lookup;
}

@Component({
  selector: 'app-ran-filter-list',
  templateUrl: './ran-filter-list.component.html',
  styleUrl: './ran-filter-list.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: false,
})
export class RanFilterListComponent {
  private readonly ranFilterService = inject(RanFilterService);
  private readonly ranFilterExportService = inject(RanFilterExportService);
  private readonly translateService = inject(TranslateService);
  private readonly alertService = inject(TnapAlertService);
  private readonly router = inject(Router);
  private readonly destroyRef = inject(DestroyRef);
  private readonly modalConfirmationService = inject(ModalConfirmationService);
  private readonly overlay = inject(Overlay);
  private readonly viewContainerRef = inject(ViewContainerRef);
  private readonly lang = toSignal(this.translateService.onLangChange);

  private executeOverlayRef: OverlayRef | null = null;
  private executeTriggerElement: HTMLElement | null = null;

  constructor() {
    this.destroyRef.onDestroy(() => {
      if (this.executeOverlayRef) {
        this.executeOverlayRef.dispose();
        this.executeOverlayRef = null;
      }
    });
  }

  readonly createPermission = ALLOW_RAN_FILTER_CREATE;
  readonly editPermission = ALLOW_RAN_FILTER_EDIT;
  readonly deletePermission = ALLOW_RAN_FILTER_DELETE;
  readonly executePermission = ALLOW_RAN_FILTER_EXECUTE;
  readonly uploadPermission = ALLOW_RAN_FILTER_UPLOAD;
  readonly downloadPermission = ALLOW_RAN_FILTER_DOWNLOAD;

  readonly dateTimeFormat = environment.dateTimeFormat;
  readonly inProgressExportStatus = RanFilter.ExportStatusEnum.IN_PROGRESS;
  readonly downloadPendingHint = 'ranFilter.list.downloadHints.inProgress';
  readonly downloadRunningHint = 'ranFilter.list.downloadHints.running';
  readonly downloadProgressLabel = 'ranFilter.list.downloadHints.progressLabel';
  readonly downloadStartedStatus = 'ranFilter.list.downloadHints.startedStatus';
  readonly downloadProgressStatus =
    'ranFilter.list.downloadHints.progressStatus';

  /**
   * Keyed lookups so the row template does not have to call `Set.has()`.
   * Null-prototype records keep an unknown key from resolving to an inherited member.
   */
  readonly runningExports = computed<Record<number, boolean>>(() =>
    toLookup(
      [...this.ranFilterExportService.runningExportIds()].map(
        (id): [number, boolean] => [id, true]
      )
    )
  );

  readonly runningDownloads = computed<Record<string, boolean>>(() =>
    toLookup(
      [...this.ranFilterExportService.runningDownloadKeys()].map(
        (key): [string, boolean] => [key, true]
      )
    )
  );

  readonly downloadProgress = computed<Record<string, DownloadProgress>>(() =>
    toLookup([...this.ranFilterExportService.downloadProgressByKey()])
  );

  readonly currentSort = signal<Sort>({
    parameter: 'createdAt',
    direction: SortDirection.DESC,
  });
  readonly searchValue = signal<string | undefined>(undefined);
  readonly SortDirection = SortDirection;

  /** Resolved once per language so sorting and filtering do not translate per row. */
  readonly exportStatusLabels = computed<Record<string, string | undefined>>(
    () => {
      this.lang();
      return Object.fromEntries(
        Object.values(RanFilter.ExportStatusEnum).map(status => [
          status,
          this.translateService.instant(EXPORT_STATUS_LABEL_PREFIX + status),
        ])
      );
    }
  );

  readonly columns = computed<ColumnDefinition<RanFilter>[]>(() => {
    this.lang();
    return [
      {
        key: 'filterId',
        label: this.translateService.instant('ranFilter.list.fields.filterId'),
        value: row => String(row.filterId ?? ''),
        sorting: { enabled: true, parameter: 'filterId' },
      },
      {
        key: 'filterName',
        label: this.translateService.instant(
          'ranFilter.list.fields.filterName'
        ),
        value: row => row.filterName || '',
        sorting: { enabled: true, parameter: 'filterName' },
      },
      {
        key: 'filterDescription',
        label: this.translateService.instant(
          'ranFilter.list.fields.filterDescription'
        ),
        value: row => row.filterDescription || '',
        sorting: { enabled: true, parameter: 'filterDescription' },
      },
      {
        key: 'conditionCount',
        label: this.translateService.instant(
          'ranFilter.list.fields.conditionCount'
        ),
        value: row => String(row.conditions?.length ?? 0),
        sorting: { enabled: true, parameter: 'conditionCount' },
      },
      {
        key: 'vendor',
        label: this.translateService.instant('ranFilter.list.fields.vendor'),
        value: row => row.vendor || '',
        sorting: { enabled: true, parameter: 'vendor' },
      },
      {
        key: 'owner',
        label: this.translateService.instant('ranFilter.list.fields.owner'),
        value: row => row.owner || '',
        sorting: { enabled: true, parameter: 'owner' },
      },
      {
        key: 'createdAt',
        label: this.translateService.instant('ranFilter.list.fields.createdAt'),
        value: row => row.createdAt || '',
        sorting: { enabled: true, parameter: 'createdAt' },
      },
      {
        key: 'updated',
        label: this.translateService.instant('ranFilter.list.fields.updated'),
        value: row => row.updatedAt || '',
        sorting: { enabled: true, parameter: 'updated' },
      },
      {
        key: 'exportStatus',
        label: this.translateService.instant(
          'ranFilter.list.fields.exportStatus'
        ),
        value: row => this.getExportStatusLabel(row.exportStatus),
        sorting: { enabled: true, parameter: 'exportStatus' },
      },
      {
        key: 'exportPath',
        label: this.translateService.instant(
          'ranFilter.list.fields.exportPath'
        ),
        value: row => row.exportPath || '',
        visible: false,
        sorting: { enabled: true, parameter: 'exportPath' },
      },
      {
        key: 'exportModifiedTime',
        label: this.translateService.instant(
          'ranFilter.list.fields.exportModifiedTime'
        ),
        value: row => row.exportModifiedTime || '',
        sorting: { enabled: true, parameter: 'exportModifiedTime' },
      },
      {
        key: 'actions',
        label: this.translateService.instant('ranFilter.list.fields.actions'),
        value: () => '',
      },
    ];
  });

  readonly ranFilters = toSignal(this.ranFilterService.ranFilters$, {
    initialValue: INITIAL_RAN_FILTER_TABLE_STATE,
  });

  readonly totalItemCount = computed(
    () => this.ranFilters().data?.totalCount ?? 0
  );

  readonly sortedRanFilters = computed<RanFilterListState>(() => {
    const state = this.ranFilters();
    const sort = this.currentSort();
    const data = state.data;
    const items = data?.items;
    const search = this.searchValue()?.trim().toLowerCase();

    if (!items) {
      return state;
    }

    const filteredItems = search
      ? items.filter(item => this.matchesSearch(item, search))
      : items;

    if (sort.direction === SortDirection.NONE) {
      return {
        ...state,
        data: {
          items: filteredItems,
          totalCount: filteredItems.length,
        },
      };
    }

    const sortedItems = [...filteredItems].sort((a, b) =>
      this.compareRows(a, b, sort)
    );

    return {
      ...state,
      data: {
        items: sortedItems,
        totalCount: sortedItems.length,
      },
    };
  });

  onSortChange(sort: Sort): void {
    this.currentSort.set(sort);
  }

  onSearch(value: string | undefined): void {
    this.searchValue.set(value);
  }

  onSearchReset(): void {
    this.searchValue.set(undefined);
  }

  private compareRows(a: RanFilter, b: RanFilter, sort: Sort): number {
    const { parameter, direction } = sort;
    const order = direction === SortDirection.ASC ? 1 : -1;

    const valueA = this.getComparableValue(a, parameter);
    const valueB = this.getComparableValue(b, parameter);

    if (typeof valueA === 'number' && typeof valueB === 'number') {
      return (valueA - valueB) * order;
    }

    return String(valueA).localeCompare(String(valueB)) * order;
  }

  private getComparableValue(
    row: RanFilter,
    parameter: string
  ): string | number {
    switch (parameter) {
      case 'filterId':
        return row.filterId ?? 0;
      case 'filterName':
        return row.filterName ?? '';
      case 'filterDescription':
        return row.filterDescription ?? '';
      case 'vendor':
        return row.vendor ?? '';
      case 'owner':
        return row.owner ?? '';
      case 'createdAt':
        return this.toDateNumber(row.createdAt);
      case 'updated':
        return this.toDateNumber(row.updatedAt);
      case 'exportStatus':
        return this.getExportStatusLabel(row.exportStatus);
      case 'exportPath':
        return row.exportPath ?? '';
      case 'exportModifiedTime':
        return this.toDateNumber(row.exportModifiedTime);
      case 'conditionCount':
        return row.conditions?.length ?? 0;
      default:
        return '';
    }
  }

  private toDateNumber(value: string | undefined): number {
    if (!value) {
      return 0;
    }
    const timestamp = Date.parse(value);
    return Number.isNaN(timestamp) ? 0 : timestamp;
  }

  private matchesSearch(item: RanFilter, search: string): boolean {
    return [
      item.filterId?.toString() ?? '',
      item.filterName ?? '',
      item.filterDescription ?? '',
      item.vendor ?? '',
      item.owner ?? '',
      item.createdAt ?? '',
      item.updatedAt ?? '',
      this.getExportStatusLabel(item.exportStatus),
      item.exportPath ?? '',
      item.exportModifiedTime ?? '',
    ].some(value => value.toLowerCase().includes(search));
  }

  /** Falls back to the raw value for statuses added to the API before the UI knows them. */
  private getExportStatusLabel(
    status: RanFilter.ExportStatusEnum | undefined
  ): string {
    if (!status) {
      return '';
    }
    return this.exportStatusLabels()[status] ?? status;
  }

  onDelete(ranFilter: RanFilter): void {
    this.modalConfirmationService
      .openConfirmationModal(
        'common.buttons.yes',
        'ranFilter.list.modal.delete.title',
        'ranFilter.list.modal.delete.text',
        { name: ranFilter.filterName }
      )
      .pipe(
        take(1),
        filter(confirmed => confirmed === true),
        switchMap(() =>
          this.ranFilterService.deleteRanFilter$(ranFilter.filterId as number)
        ),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: () => {
          this.alertService.success(
            this.translateService.instant('ranFilter.list.deleteSuccess')
          );
          this.ranFilterService.refreshRanFilters();
        },
        error: () => {
          /* handled by HttpErrorInterceptor */
        },
      });
  }

  onEdit(filter: RanFilter): void {
    this.router.navigate(['/ran-filter/edit', filter.filterId]);
  }

  onDownload(ranFilter: RanFilter): void {
    this.ranFilterExportService.downloadExport(ranFilter);
  }

  onUpload(ranFilter: RanFilter): void {
    this.ranFilterExportService.uploadExport(ranFilter);
  }

  onExecute(ranFilter: RanFilter, event?: MouseEvent): void {
    this.executeTriggerElement = (event?.currentTarget as HTMLElement) ?? null;
    const filterId = ranFilter.filterId;
    this.ranFilterService
      .executeRanFilter$({ filterId, impactOnly: true })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: response => {
          this.openExecuteResultPanel(
            filterId,
            ranFilter.filterName ?? '',
            response
          );
        },
        error: () => {
          /* handled by HttpErrorInterceptor */
        },
      });
  }

  private openExecuteResultPanel(
    filterId: number | undefined,
    filterName: string,
    result: ExecuteFilterResponse
  ): void {
    // Close any previously open overlay without restoring focus
    if (this.executeOverlayRef) {
      this.executeOverlayRef.dispose();
      this.executeOverlayRef = null;
    }

    this.executeOverlayRef = this.overlay.create({
      positionStrategy: this.overlay
        .position()
        .global()
        .centerHorizontally()
        .centerVertically(),
      hasBackdrop: true,
      backdropClass: 'execute-result-overlay-backdrop',
      scrollStrategy: this.overlay.scrollStrategies.block(),
      width: '954px',
    });

    const portal = new ComponentPortal(
      RanFilterExecuteResultPanelComponent,
      this.viewContainerRef
    );
    const componentRef = this.executeOverlayRef.attach(portal);
    componentRef.instance.filterName = filterName;
    componentRef.instance.result = result;

    /* Filter id and cache belong to this panel, not to the component: executing a
       second filter leaves this panel on screen until its own response lands, and
       shared state would point its toggle at the newer filter. */
    const resultCache = new Map<boolean, ExecuteFilterResponse>([
      [true, result],
    ]);

    componentRef.instance.closePanel
      .pipe(take(1))
      .subscribe(() => this.closeExecuteResult());

    componentRef.instance.showNodesChange
      .pipe(takeUntil(this.executeOverlayRef.detachments()))
      .subscribe(showNodes =>
        this.onExecuteShowNodesChange(
          componentRef,
          filterId,
          resultCache,
          showNodes
        )
      );

    this.executeOverlayRef
      .backdropClick()
      .pipe(take(1))
      .subscribe(() => this.closeExecuteResult());
  }

  /**
   * Switches the open result between the impact summary and the full node list.
   *
   * Each variant is fetched at most once per execution; the panel shows its own
   * spinner meanwhile, so the page-wide indicator does not grey out its controls.
   */
  private onExecuteShowNodesChange(
    panelRef: ComponentRef<RanFilterExecuteResultPanelComponent>,
    filterId: number | undefined,
    resultCache: Map<boolean, ExecuteFilterResponse>,
    showNodes: boolean
  ): void {
    const panel = panelRef.instance;
    panel.showNodes = showNodes;

    const impactOnly = !showNodes;
    const cached = resultCache.get(impactOnly);
    if (cached) {
      panel.result = cached;
      return;
    }

    panel.loadingNodes = true;
    const openOverlay = this.executeOverlayRef;
    this.ranFilterService
      .executeRanFilter$({ filterId, impactOnly }, true)
      .pipe(
        /* The modal may be gone by the time the nodes arrive; writing to the
           detached panel would resurrect a view the user already dismissed. */
        filter(() => this.executeOverlayRef === openOverlay),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: response => {
          panel.loadingNodes = false;
          resultCache.set(impactOnly, response);
          panel.result = response;
        },
        error: () => {
          /* handled by HttpErrorInterceptor */
          panel.loadingNodes = false;
          panel.showNodes = !showNodes;
        },
      });
  }

  closeExecuteResult(): void {
    if (this.executeOverlayRef) {
      this.executeOverlayRef.dispose();
      this.executeOverlayRef = null;
    }
    this.executeTriggerElement?.focus();
    this.executeTriggerElement = null;
  }

  navigateToCreate(): void {
    this.router.navigate(['/ran-filter/create']);
  }
}
