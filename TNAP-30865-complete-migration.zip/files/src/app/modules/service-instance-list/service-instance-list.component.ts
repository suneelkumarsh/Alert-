/*
 * Copyright (c) 2022. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, inject, OnInit } from '@angular/core';
import {
  BehaviorSubject,
  combineLatest,
  EMPTY,
  merge,
  Observable,
  of,
  Subject,
} from 'rxjs';
import {
  catchError,
  filter,
  map,
  repeatWhen,
  shareReplay,
  switchMap,
  take,
  takeUntil,
  tap,
  withLatestFrom,
} from 'rxjs/operators';
import { Router } from '@angular/router';
import {
  AlarmAggregationService,
  AlarmAggregationTreeResponse,
  CustomersService,
  ServiceInstancesService,
  ServiceSubscriptionsService,
} from 'openapi/output';
import { UnsubscribeService } from 'src/app/services/unsubscribe/unsubscribe.service';
import { isNotNull } from 'src/app/helpers/helpers';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmationModalComponent } from '../../components/shared/confirmation-modal/confirmation-modal.component';
import { TranslateService } from '@ngx-translate/core';
import { VALIDATION_PATTERN } from 'src/app/model/validation-pattern.model';
import { OrchestrationStatus } from '../../model/service-instance.model';
import { UserSettingsService } from 'src/app/services/user-settings.service';
import { UserPreferencesModel } from 'src/app/model/user-preferences.model';
import { HistoryService } from '../../services/history.service';
import {
  ActionType,
  CreateActionModel,
  EntityPnfHistoryActionModel,
  EntityServiceInstanceHistoryActionModel,
  EntityType,
  EntityVnfHistoryActionModel,
} from '../../model/user-last-action.model';
import { KeyboardShortcuts } from '../../services/shortcut.service';
import {
  SERVICE_INSTANCE_DEFAULT_PAGE,
  SERVICE_INSTANCE_DEFAULT_PAGE_SIZE,
} from 'src/app/modules/service-instance-list/configuration';
import { ServiceFormModel } from 'src/app/model/service-model.model';
import { QueryParamService } from '../../services/query-param.service';
import { BaseFilterService } from '../../services/common-functionalities/base-filter.service';
import { PaginationService } from '../../services/common-functionalities/pagination.service';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-service-instance-list',
  templateUrl: './service-instance-list.component.html',
  styleUrls: ['./service-instance-list.component.css'],
  providers: [UnsubscribeService],
  standalone: false,
})
export class ServiceInstanceListComponent implements OnInit {
  VALIDATION_PATTERN = VALIDATION_PATTERN;
  OrchestrationStatus = OrchestrationStatus;
  formData!: ServiceFormModel;
  readonly permissions = inject(PERMISSIONS_TOKEN);
  public isServiceInstanceCollapsed = false;
  public ACCESS_KEY = KeyboardShortcuts;
  public tableDataLoading = false;
  public activeId = 1;
  private selectedServiceId$ = this.queryParamService.getValueOf(
    'selectedServiceInstance'
  );
  private readonly reload$ = new Subject<void>();
  private readonly addNewActionToHistory$ = new Subject<{
    type: ActionType;
    entity: EntityType;
    serviceInstanceValue?: string;
    customerId: string;
    serviceType: string;
    serviceInstanceName: string;
  }>();

  private readonly addNewVnfActionToHistory$ = new Subject<{
    type: ActionType;
    entity: EntityType;
    vnfId: string;
    vnfName: string;
    parentInstanceName?: string;
  }>();

  private readonly alarmsNotAvailable$ = new BehaviorSubject<boolean>(false);

  readonly filter$ = this.queryParamService.getValueOf('filter');
  readonly customerId$ = this.queryParamService.getValueOf('customerId');
  readonly serviceType$ = this.queryParamService.getValueOf('serviceType');
  readonly page$ = this.queryParamService.getQueryParamAsNumber(
    'page',
    SERVICE_INSTANCE_DEFAULT_PAGE
  );
  readonly pageSize$ = this.queryParamService.getQueryParamAsNumber(
    'pageSize',
    SERVICE_INSTANCE_DEFAULT_PAGE_SIZE
  );

  readonly customerOptions$ = this.customerService.listCustomers().pipe(
    map(customers => customers.items),
    map(customers =>
      customers.sort((c1, c2) =>
        c1.subscriberName.localeCompare(c2.subscriberName)
      )
    ),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  readonly serviceTypeOptions$ = this.customerId$.pipe(
    switchMap(customerId =>
      customerId
        ? this.serviceSubscriptionsService
            .listServiceSubscriptions(customerId)
            .pipe(map(serviceTypes => serviceTypes.items))
        : EMPTY
    ),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  readonly serviceInstanceList$ = combineLatest([
    this.page$,
    this.pageSize$,
    this.customerId$,
    this.serviceType$,
    this.filter$,
  ]).pipe(
    switchMap(([page, pageSize, customerId, serviceType, filterValue]) => {
      if (customerId !== null && serviceType !== null) {
        this.tableDataLoading = true;
        return this.serviceInstanceService
          .listServiceInstances(
            customerId,
            serviceType,
            page,
            pageSize,
            filterValue ? filterValue : undefined
          )
          .pipe(repeatWhen(() => this.reload$));
      }
      return of(null);
    }),
    tap(() => (this.tableDataLoading = false)),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  readonly serviceInstance$ = this.selectedServiceId$.pipe(
    withLatestFrom(this.customerId$, this.serviceType$),
    switchMap(([serviceId, customerId, subscription]) => {
      if (serviceId !== null && customerId !== null && subscription !== null) {
        return this.serviceInstanceService.getServiceInstanceDetails(
          customerId,
          subscription,
          serviceId
        );
      }
      return of(null);
    }),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  readonly alarmsForServiceInstances$: Observable<AlarmAggregationTreeResponse> =
    this.serviceInstanceList$.pipe(
      filter(isNotNull),
      map(serviceInstanceList =>
        serviceInstanceList.items.map(serviceInstance => serviceInstance.id)
      ),
      filter(serviceInstanceIds => serviceInstanceIds.length > 0),
      switchMap((serviceInstanceIds: string[]) => {
        const getAlarms = (ids: string[]) =>
          this.alarmsAggregateService.alarmAggregateTree(ids, true, true).pipe(
            tap(() => this.alarmsNotAvailable$.next(false)),
            catchError(() => {
              this.alarmsNotAvailable$.next(true);
              return of({ items: [], totalCount: 0 });
            })
          );
        // Handling the error from the server: 413 - Request Entity Too Large
        if (serviceInstanceIds.length > 99) {
          const partial_arrays: string[][] = [];
          const max_array_size = 50;
          while (serviceInstanceIds.length > 0)
            partial_arrays.push(serviceInstanceIds.splice(0, max_array_size));
          const requests$ = partial_arrays.map(ids => getAlarms(ids));
          return merge(...requests$);
        }
        return getAlarms(serviceInstanceIds);
      }),
      shareReplay({ refCount: true, bufferSize: 1 })
    );

  readonly serviceInstanceAlarms$ = combineLatest([
    this.serviceInstance$.pipe(filter(isNotNull)),
    this.alarmsForServiceInstances$,
  ]).pipe(
    map(([instance, alarms]) => {
      return ServiceInstanceListComponent.findAlarmsByServiceInstanceId(
        alarms,
        instance.serviceInstanceId
      );
    })
  );

  addVnf(serviceInstanceId: string) {
    combineLatest([this.customerId$, this.serviceType$]).subscribe(
      ([customer, serviceType]) => {
        this.router.navigate([
          '/service-model-deployment/add-vnf',
          customer,
          serviceType,
          serviceInstanceId,
        ]);
      }
    );
  }

  constructor(
    private customerService: CustomersService,
    private serviceSubscriptionsService: ServiceSubscriptionsService,
    private serviceInstanceService: ServiceInstancesService,
    private unsubscribeService: UnsubscribeService,
    private userSettingsService: UserSettingsService,
    private readonly modalService: NgbModal,
    private readonly translateService: TranslateService,
    private readonly alertService: TnapAlertService,
    private historyService: HistoryService,
    private alarmsAggregateService: AlarmAggregationService,
    private queryParamService: QueryParamService,
    private filterService: BaseFilterService,
    private paginationService: PaginationService,
    private router: Router
  ) {}

  public preferences$ = this.userSettingsService.getPreferences$().pipe(
    takeUntil(this.unsubscribeService.unsubscribe$),
    map(
      (preferences: UserPreferencesModel) => preferences.serviceInstanceSettings
    )
  );

  ngOnInit(): void {
    combineLatest([this.customerOptions$, this.customerId$])
      .pipe(filter(isNotNull), takeUntil(this.unsubscribeService.unsubscribe$))
      .subscribe(([customers, customerId]) => {
        if (!customerId) {
          if (customers.length > 0) {
            this.changeCustomer(customers[0].customerId);
          }
        }
      });

    this.serviceTypeOptions$
      .pipe(
        withLatestFrom(this.serviceType$),
        filter(isNotNull),
        takeUntil(this.unsubscribeService.unsubscribe$)
      )
      .subscribe(([serviceTypes, serviceType]) => {
        if (!serviceType) {
          if (serviceTypes.length > 0) {
            this.changeServiceType(serviceTypes[0].serviceType);
          }
        }
      });

    this.serviceInstanceList$
      .pipe(
        filter(isNotNull),
        takeUntil(this.unsubscribeService.unsubscribe$),
        withLatestFrom(this.selectedServiceId$)
      )
      .subscribe(([instanceList, selectedServiceId]) => {
        if (selectedServiceId) {
          return;
        }
        if (instanceList.items.length > 0) {
          this.getServiceInstance(instanceList.items[0].id);
        }
      });

    this.addNewActionToHistory$
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap(
          ({
            type,
            entity,
            serviceInstanceValue,
            serviceType,
            customerId,
            serviceInstanceName,
          }) => {
            let entityParams: EntityServiceInstanceHistoryActionModel = {
              serviceInstanceName,
              customerId,
              serviceType,
            };

            if (entity === EntityType.TOPOLOGY) {
              entityParams = {
                ...entityParams,
                serviceInstanceValue,
              };
            }

            return this.historyService.createServiceInstanceHistoryAction({
              type,
              entity,
              entityParams,
            });
          }
        )
      )
      .subscribe();

    this.addNewVnfActionToHistory$
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap(({ type, entity, vnfId, vnfName }) => {
          const entityParams: EntityVnfHistoryActionModel = {
            vnfId,
            vnfName,
          };

          return this.historyService.createVnfHistoryAction({
            type,
            entity,
            entityParams,
          });
        })
      )
      .subscribe();
  }

  static findAlarmsByServiceInstanceId = (
    alarmList: AlarmAggregationTreeResponse,
    serviceInstanceId: string
  ) =>
    alarmList.items.find(alarm => alarm.serviceInstanceId === serviceInstanceId)
      ?.alarmAggregation;

  onChangePage(page: number): void {
    this.paginationService.changePage(page, {
      selectedServiceInstance: undefined,
    });
  }

  onChangePageSize(pageSize: number): void {
    this.paginationService.changePageSize(pageSize);
  }

  changeCustomer(customerId: string): void {
    this.router.navigate([], {
      queryParams: {
        customerId,
        serviceType: null,
        page: 1,
        filter: undefined,
        selectedServiceInstance: undefined,
      },
      queryParamsHandling: 'merge',
    });
  }

  changeServiceType(serviceType: string | null): void {
    this.router.navigate([], {
      queryParams: {
        serviceType,
        page: 1,
        filter: undefined,
        selectedServiceInstance: undefined,
      },
      queryParamsHandling: 'merge',
    });
  }

  onSearchChange(filterValue: string | undefined): void {
    this.addActionToHistory();
    this.filterService.changeFilter(filterValue);
  }

  getServiceInstance(selectedServiceInstance: string, event: any = null): void {
    // set active tab to general
    this.activeId = 1;
    // this is to prevent some default dom events
    if (event) {
      event.preventDefault();
    }
    this.router.navigate([], {
      queryParams: { selectedServiceInstance },
      queryParamsHandling: 'merge',
    });
  }

  openModal(serviceInstanceId: string, serviceInstanceName: string): void {
    // open confirmation modal for service instance deletion
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalRef.componentInstance.okText = this.translateService.instant(
      'common.buttons.delete'
    );
    modalRef.componentInstance.title = this.translateService.instant(
      'serviceInstance.modal.delete.title'
    );
    modalRef.componentInstance.text = this.translateService.instant(
      'serviceInstance.modal.delete.text',
      {
        serviceInstanceName,
      }
    );
    modalRef.closed
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap((confirm: boolean) => {
          if (confirm) {
            return combineLatest([this.customerId$, this.serviceType$]).pipe(
              switchMap(([customerId, serviceType]) => {
                if (customerId && serviceType) {
                  this.addNewActionToHistory$.next({
                    type: ActionType.DELETE,
                    entity: EntityType.SERVICEINSTANCE,
                    serviceInstanceName: serviceInstanceId,
                    customerId,
                    serviceType,
                  });
                  return this.serviceInstanceService.deleteServiceInstance(
                    customerId,
                    serviceType,
                    serviceInstanceId
                  );
                }
                return EMPTY;
              })
            );
          }
          return EMPTY;
        }),
        tap(() => {
          this.successDeleteMessage();
        })
      )
      .subscribe(() => this.reload());
  }

  openDeleteNetworkFunctionConfirmationModal(
    childInstanceId: string,
    childInstanceName: string,
    serviceInstanceId: string,
    serviceInstanceName: string
  ): void {
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalRef.componentInstance.okText = this.translateService.instant(
      'common.buttons.delete'
    );
    modalRef.componentInstance.title = this.translateService.instant(
      'serviceInstance.modal.childDelete.title'
    );
    modalRef.componentInstance.text = this.translateService.instant(
      'serviceInstance.modal.childDelete.text',
      {
        childInstanceName,
      }
    );
    modalRef.closed
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap((confirm: boolean) => {
          if (confirm) {
            return this.deletionOfVnf(childInstanceId, serviceInstanceId);
          }
          return EMPTY;
        }),
        tap(() => {
          this.successChildDeleteMessage();
        })
      )
      .subscribe(() => {
        this.addVnfDeletionToHistory(
          childInstanceName,
          serviceInstanceName,
          childInstanceId
        );
        this.reload();
      });
  }

  private successDeleteMessage(): void {
    this.alertService.success(
      this.translateService.instant('serviceInstance.messages.success.deleted'),
      { keepAfterRouteChange: true }
    );
  }

  private successChildDeleteMessage(): void {
    this.alertService.success(
      this.translateService.instant(
        'serviceInstance.messages.success.childDeleted'
      ),
      { keepAfterRouteChange: true }
    );
  }

  private reload() {
    this.reload$.next();
  }
  redirectFromVnfToTopology(vnfName: string, vnfId: string) {
    this.addVnfTopologyRedirectToHistory(vnfId, vnfName);
    this.router.navigate(['/topology', vnfId], {
      queryParams: { type: 'generic-vnf' },
    });
  }
  redirectFromPnfToTopology(pnfName: string) {
    this.addPnfTopologyRedirectToHistory(pnfName);
    this.router.navigate(['/topology', pnfName], {
      queryParams: { type: 'pnf' },
    });
  }
  redirectToTopology(serviceInstanceId: string, serviceInstanceName: string) {
    combineLatest([this.customerId$, this.serviceType$])
      .pipe(takeUntil(this.unsubscribeService.unsubscribe$))
      .subscribe(([customerId, serviceType]) => {
        if (!customerId) {
          // eslint-disable-next-line no-console
          console.error(
            'Trying to navigate to topology view without customerId'
          );
          return;
        }
        if (!serviceType) {
          // eslint-disable-next-line no-console
          console.error(
            'Trying to navigate to topology view without serviceType'
          );
          return;
        }
        this.addNewActionToHistory$.next({
          type: ActionType.VIEW,
          entity: EntityType.TOPOLOGY,
          serviceInstanceValue: serviceInstanceId,
          serviceType,
          customerId,
          serviceInstanceName,
        });
        this.router.navigate(['/topology', serviceInstanceId], {
          queryParams: {
            customerId,
            serviceType,
            hideDetail: true,
          },
        });
      });
  }

  changePreferences(onlyFilled: boolean) {
    this.userSettingsService
      .updatePreferences({ serviceInstanceSettings: { onlyFilled } })
      .pipe(take(1))
      .subscribe();
  }

  private addActionToHistory() {
    combineLatest([this.customerId$, this.serviceType$, this.filter$])
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap(([customerId, serviceType, filterParams]) => {
          if (customerId && serviceType && filterParams) {
            this.addNewActionToHistory$.next({
              type: ActionType.SEARCH,
              entity: EntityType.SERVICEINSTANCE,
              serviceInstanceName: filterParams,
              serviceType,
              customerId,
            });
          }
          return EMPTY;
        })
      )
      .subscribe();
  }

  private deletionOfVnf(vnfId: string, serviceInstanceId: string) {
    return combineLatest([this.customerId$, this.serviceType$]).pipe(
      switchMap(([customerId, serviceType]) => {
        if (customerId && serviceType) {
          return this.serviceInstanceService.deleteVnf(
            serviceInstanceId,
            vnfId
          );
        }
        return EMPTY;
      })
    );
  }

  public addVnfDeletionToHistory(
    vnfName: string,
    serviceInstanceName: string,
    vnfId: string
  ) {
    const action: CreateActionModel<EntityVnfHistoryActionModel> = {
      type: ActionType.DELETE,
      entity: EntityType.VNF,
      entityParams: {
        vnfName,
        vnfId,
        parentInstanceName: serviceInstanceName,
      },
    };
    this.historyService
      .createVnfHistoryAction(action)
      .pipe(take(1))
      .subscribe();
  }
  public addVnfTopologyRedirectToHistory(vnfId: string, vnfName: string) {
    const action: CreateActionModel<EntityVnfHistoryActionModel> = {
      type: ActionType.TOPOLOGY,
      entity: EntityType.VNF,
      entityParams: {
        vnfName,
        vnfId,
      },
    };
    this.historyService
      .createVnfHistoryAction(action)
      .pipe(take(1))
      .subscribe();
  }
  public addPnfTopologyRedirectToHistory(pnfName: string) {
    const action: CreateActionModel<EntityPnfHistoryActionModel> = {
      type: ActionType.TOPOLOGY,
      entity: EntityType.PNF,
      entityParams: {
        pnfName,
      },
    };
    this.historyService
      .createPnfHistoryAction(action)
      .pipe(take(1))
      .subscribe();
  }
}
