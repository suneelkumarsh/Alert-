/*
 * Copyright (c) 2022. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, computed, inject } from '@angular/core';
import {
  catchError,
  map,
  repeatWhen,
  shareReplay,
  switchMap,
  takeUntil,
  tap,
} from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { UnsubscribeService } from 'src/app/services/unsubscribe/unsubscribe.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmationModalComponent } from 'src/app/components/shared/confirmation-modal/confirmation-modal.component';
import {
  BehaviorSubject,
  combineLatest,
  EMPTY,
  Observable,
  of,
  Subject,
} from 'rxjs';
import {
  ActionsResponse,
  UserListResponse,
  UserResponse,
  UsersService,
} from 'openapi/output';
import { ActionType, EntityType } from '../../../model/user-last-action.model';
import { HistoryService } from '../../../services/history.service';
import { AuthService } from '@portal-mfe/auth';
import {
  USER_MANAGEMENT_DEFAULT_PAGE,
  USER_MANAGEMENT_DEFAULT_PAGE_SIZE,
} from 'src/app/modules/user-administration/configuration';
import { environment } from '../../../../environments/environment';
import { ColumnDefinition } from '@portal-mfe/tnap-ui-kit/components/data-table';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { toSignal } from '@angular/core/rxjs-interop';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';
@Component({
  selector: 'app-user-administration-list',
  templateUrl: './user-administration-list.component.html',
  styleUrls: ['./user-administration-list.component.css'],
  providers: [UnsubscribeService],
  standalone: false,
})
export class UserAdministrationListComponent {
  readonly permissions = inject(PERMISSIONS_TOKEN);
  private readonly translate = inject(TranslateService);
  private readonly lang = toSignal(this.translate.onLangChange);

  readonly userColumns = computed<ColumnDefinition<UserResponse>[]>(() => {
    this.lang();
    return [
      {
        key: 'userName',
        label: this.translateService.instant(
          'userAdministration.fields.userName'
        ),
        classes: '',
        tooltip: '',
        visible: true,
        value: row => row.username,
      },
      {
        key: 'firstName',
        label: this.translateService.instant(
          'userAdministration.fields.firstName'
        ),
        classes: '',
        tooltip: '',
        visible: true,
        value: row => row.firstName,
      },
      {
        key: 'lastName',
        label: this.translateService.instant(
          'userAdministration.fields.lastName'
        ),
        classes: '',
        tooltip: '',
        visible: true,
        value: row => row.lastName,
      },
      {
        key: 'email',
        label: this.translateService.instant('userAdministration.fields.email'),
        classes: '',
        tooltip: '',
        visible: true,
        value: row => row.email,
      },
      {
        key: 'assignedRoles',
        label: this.translateService.instant(
          'userAdministration.fields.assignedRoles'
        ),
        classes: '',
        tooltip: '',
        visible: true,
        value: row => row.realmRoles,
      },
      {
        key: 'actions',
        visible: true,
        label: this.translateService.instant(
          'userAdministration.fields.actions'
        ),
        value: () => '',
      },
    ];
  });
  readonly page$ = new BehaviorSubject<number>(USER_MANAGEMENT_DEFAULT_PAGE);
  readonly pageSize$ = new BehaviorSubject<number>(
    USER_MANAGEMENT_DEFAULT_PAGE_SIZE
  );
  readonly loggedUserId$ = this.authService.loadCachedUserProfile().pipe(
    takeUntil(this.unsubscribeService.unsubscribe$),
    map(userInfo => userInfo?.sub)
  );

  private readonly reload$ = new Subject<void>();
  readonly result$ = combineLatest([this.page$, this.pageSize$]).pipe(
    switchMap(([page, pageSize]) => {
      return this.userAdministrationService.listUsers(page, pageSize).pipe(
        map(response => {
          return {
            ...response,
            items: response.items.map(user => ({
              ...user,
              realmRoles: user.realmRoles?.filter(role =>
                role.startsWith(environment.keycloak.realmRolesPrefix)
              ),
            })),
          } as UserListResponse;
        }),
        repeatWhen(() => this.reload$)
      );
    }),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  constructor(
    private readonly userAdministrationService: UsersService,
    private readonly alertService: TnapAlertService,
    private readonly translateService: TranslateService,
    private readonly modalService: NgbModal,
    private readonly unsubscribeService: UnsubscribeService,
    private readonly authService: AuthService,
    private readonly historyService: HistoryService
  ) {}

  changePage(page: number): void {
    this.page$.next(page);
  }

  changePageSize(pageSize: number): void {
    this.pageSize$.next(pageSize);
  }

  openModal(userId: string, userName: string): void {
    // open confirmation modal for user deletion
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalRef.componentInstance.okText = this.translateService.instant(
      'common.buttons.delete'
    );
    modalRef.componentInstance.title = this.translateService.instant(
      'userAdministration.list.modal.delete.title'
    );
    modalRef.componentInstance.text = this.translateService.instant(
      'userAdministration.list.modal.delete.text',
      {
        userName,
      }
    );
    modalRef.closed
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap((confirm: boolean) => {
          if (confirm) {
            return this.userDeletion(userId).pipe(
              switchMap(() =>
                this.addHistoryAction(ActionType.DELETE, userName, userId)
              )
            );
          }
          return EMPTY;
        }),
        tap(() => {
          this.successDeleteMessage();
        })
      )
      .subscribe(() => this.reload());
  }

  private userDeletion(userId: string) {
    return this.userAdministrationService.deleteUser(userId);
  }

  private addHistoryAction(
    actionType: ActionType,
    userName: string,
    userId: string
  ): Observable<ActionsResponse | null> {
    return this.historyService
      .createUserHistoryAction({
        type: actionType,
        entity: EntityType.USERADMINISTRATION,
        entityParams: { userName, userId },
      })
      .pipe(catchError(() => of(null)));
  }

  private successDeleteMessage(): void {
    this.alertService.success(
      this.translateService.instant(
        'userAdministration.messages.success.deleted'
      ),
      { keepAfterRouteChange: true }
    );
  }

  private reload() {
    this.reload$.next();
  }

  protected readonly USER_MANAGEMENT_DEFAULT_PAGE_SIZE =
    USER_MANAGEMENT_DEFAULT_PAGE_SIZE;
}
