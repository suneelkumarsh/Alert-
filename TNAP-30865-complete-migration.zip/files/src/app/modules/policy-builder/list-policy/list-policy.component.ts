/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  inject,
  OnInit,
} from '@angular/core';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { Observable, of, Subject, merge, forkJoin } from 'rxjs';
import { catchError, map, shareReplay, switchMap, take } from 'rxjs/operators';
import { withLoading } from '../../../helpers/custom-operators';
import { PolicyBuilderService } from '../shared/policy-builder.service';
import { FileTreeNode } from 'openapi/output/model/fileTreeNode.model';
import { QueryParamService } from '../../../services/query-param.service';
import { Draft, OpaPolicyContentResponse } from 'openapi/output';
import { PolicyBuilderDataService } from '../shared/policy-builder-data.service';
import { mapToPolicyJson } from 'src/app/model/OpaBuilderPolicy.model';
import { TranslateService } from '@ngx-translate/core';
import {
  ALLOWED_POLICIES,
  extractPolicyName,
  POLICY_FILE_SUFFIX,
} from '../shared/policy-builder.constants';
import { ColumnDefinition } from '@portal-mfe/tnap-ui-kit/components/data-table';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

export interface PolicyListItem extends FileTreeNode {
  policyVersion?: string;
}

@Component({
  selector: 'app-list-policy',
  templateUrl: './list-policy.component.html',
  styleUrl: './list-policy.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: false,
})
export class ListPolicyComponent implements OnInit {
  private static readonly ALLOWED_FILE_NAMES = new Set(
    ALLOWED_POLICIES.map(policy => `${policy}${POLICY_FILE_SUFFIX}`)
  );

  private readonly destroyRef = inject(DestroyRef);
  protected readonly policyBuilderService = inject(PolicyBuilderService);
  private readonly policyBuilderDataService = inject(PolicyBuilderDataService);
  private readonly queryParamService = inject(QueryParamService);
  private readonly translateService = inject(TranslateService);
  private readonly lang = toSignal(this.translateService.onLangChange);
  private readonly alertService = inject(TnapAlertService);
  readonly filter$ = this.queryParamService.getValueOf('filter');
  private readonly refreshTrigger$ = new Subject<void>();
  private draftName: Draft | undefined = undefined;
  protected deleteRegoResponse = '';
  protected isSuccess = false;
  protected loadingPolicyName: string | null = null;
  protected loadingAction: 'view' | 'edit' | null = null;
  protected deployedPolicyName: string | null = null;

  readonly columns = computed((): ColumnDefinition<PolicyListItem>[] => {
    this.lang();
    return [
      {
        key: 'name',
        label: this.translateService.instant(
          'policyBuilder.listPolicy.fields.name'
        ),
        value: policy => extractPolicyName(policy.name || ''),
      },
      {
        key: 'policyVersion',
        label: this.translateService.instant(
          'policyBuilder.listPolicy.fields.policyVersion'
        ),
        value: policy => policy.policyVersion || '-',
      },
      {
        key: 'status',
        label: this.translateService.instant(
          'policyBuilder.listPolicy.fields.status'
        ),
        value: () => '',
      },
      {
        key: 'actions',
        label: this.translateService.instant(
          'policyBuilder.listPolicy.fields.actions'
        ),
        value: () => '',
      },
    ];
  });

  readonly policies$: Observable<{
    loading: boolean;
    data?: {
      items: PolicyListItem[];
      totalCount: number;
    };
  }> = merge(
    this.filter$,
    this.refreshTrigger$.pipe(switchMap(() => this.filter$))
  ).pipe(
    switchMap(filter =>
      this.policyBuilderService.getPolicyList().pipe(
        map(response => response.items || []),
        map(items => this.filterPolicyFiles(items)),
        map(items => this.applySearchFilter(items, filter)),
        switchMap(filteredItems => this.fetchPolicyMetadata(filteredItems)),
        map(itemsWithVersions => ({
          items: itemsWithVersions,
          totalCount: itemsWithVersions.length,
        }))
      )
    ),
    catchError(() => of({ items: [], totalCount: 0 })),
    withLoading(),
    shareReplay({ refCount: true, bufferSize: 1 }),
    takeUntilDestroyed(this.destroyRef)
  );

  public ngOnInit() {
    this.policyBuilderDataService.activeTab$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(tab => {
        if (tab === 'listPolicy') {
          this.refreshTrigger$.next();
        }
      });

    this.policyBuilderDataService.justDeployed$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(policyName => {
        this.deployedPolicyName = policyName;
      });
  }

  protected resetSearch(): void {
    this.queryParamService.updateQueryParam({ filter: null });
  }

  protected onSearchChange(filter: string): void {
    if (filter?.trim()) {
      this.queryParamService.updateQueryParam({ filter: filter.trim() });
    } else {
      this.resetSearch();
    }
  }

  private filterPolicyFiles(items: FileTreeNode[]): FileTreeNode[] {
    return items.filter(item =>
      ListPolicyComponent.ALLOWED_FILE_NAMES.has(item.name || '')
    );
  }

  private applySearchFilter(
    items: FileTreeNode[],
    filter?: string | null
  ): FileTreeNode[] {
    if (!filter?.trim()) {
      return items;
    }

    const searchTerm = filter.trim().toLowerCase();
    return items.filter(item => item.name?.toLowerCase().includes(searchTerm));
  }

  private fetchPolicyMetadata(
    items: FileTreeNode[]
  ): Observable<PolicyListItem[]> {
    const itemsWithName = items.filter(item => item.name);
    if (itemsWithName.length === 0) {
      return of([]);
    }

    const requests = itemsWithName.map(item =>
      this.policyBuilderService.getPolicyVersionCached(item.name!).pipe(
        map(version => ({
          ...item,
          policyVersion: version,
        })),
        catchError(() => of({ ...item, policyVersion: undefined }))
      )
    );

    return forkJoin(requests);
  }

  editPolicy(row: FileTreeNode) {
    this.loadingAction = 'edit';
    this.queryParamService.updateQueryParam({
      mode: 'edit',
      policyPath: row.name,
    });
    this.openPolicyEditor(row, true);
  }

  viewPolicy(row: FileTreeNode) {
    this.loadingAction = 'view';
    this.queryParamService.updateQueryParam({
      mode: 'view',
      policyPath: row.name,
    });
    this.openPolicyEditor(row, false);
  }

  private openPolicyEditor(row: FileTreeNode, isEdit: boolean): void {
    this.deleteRegoResponse = '';
    const packageName = row.name;
    this.loadingPolicyName = packageName;

    this.policyBuilderService
      .getFreshDraftBranchForPolicy(packageName)
      .pipe(
        take(1),
        switchMap(draftBranch => {
          this.draftName = draftBranch;
          return this.policyBuilderService.getPolicyDetails(
            packageName,
            draftBranch
          );
        }),
        catchError(err => this.handlePolicyLoadError(err)),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: regoData => {
          if (regoData)
            this.handlePolicyLoadSuccess(
              regoData as OpaPolicyContentResponse,
              packageName,
              isEdit
            );
        },
      });
  }

  private handlePolicyLoadSuccess(
    regoData: OpaPolicyContentResponse,
    policyName: string,
    isEdit: boolean
  ): void {
    const scriptEditable = regoData.metadata?.['script-editable'] !== false;
    const finalEditMode = isEdit && scriptEditable;
    const advancedPolicy = mapToPolicyJson(regoData, {
      name: policyName,
      isEdit: finalEditMode,
      draftBranch: this.draftName?.name,
      ui_layout: regoData?.ui_layout as Record<string, unknown> | undefined,
      mode: regoData?.metadata?.mode,
    });
    this.policyBuilderService.setEditPolicyJson(advancedPolicy);
    this.policyBuilderDataService.switchTab('createPolicy');
    this.loadingPolicyName = null;
    this.loadingAction = null;
  }

  private handlePolicyLoadError(err: {
    error?: { message?: string };
  }): Observable<null> {
    this.loadingPolicyName = null;
    this.loadingAction = null;
    this.deleteRegoResponse = err?.error?.message ?? '';
    this.isSuccess = false;
    this.alertService.error(
      this.translateService.instant('policyBuilder.errors.loadPolicyFailed')
    );
    return of(null);
  }
}
