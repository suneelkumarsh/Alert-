/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ComponentFixture,
  TestBed,
  fakeAsync,
  tick,
} from '@angular/core/testing';
import { of, throwError, BehaviorSubject } from 'rxjs';
import { take } from 'rxjs/operators';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { Component, Input } from '@angular/core';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ListPolicyComponent } from './list-policy.component';
import { PolicyBuilderService } from '../shared/policy-builder.service';
import { PolicyBuilderDataService } from '../shared/policy-builder-data.service';
import { QueryParamService } from '../../../services/query-param.service';
import {
  FileTreeNode,
  FileTreeNodeType,
  FileTreeNodeList,
} from 'openapi/output';
import { By } from '@angular/platform-browser';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';
@Component({
  // eslint-disable-next-line @angular-eslint/component-selector -- mocks the real tnap-data-table selector used in the template under test
  selector: 'tnap-data-table',
  template: '',
  standalone: false,
})
class MockDataTableComponent {
  @Input() columns: any;
  @Input() data: any;
  @Input() isLoading: any;
  @Input() showPagination: any;
  @Input() showColumnConfig?: boolean;
}

describe('ListPolicyComponent', () => {
  let component: any;
  let fixture: ComponentFixture<ListPolicyComponent>;
  let mockPolicyBuilderService: jasmine.SpyObj<PolicyBuilderService>;
  let mockPolicyBuilderDataService: jasmine.SpyObj<PolicyBuilderDataService>;
  let mockQueryParamService: jasmine.SpyObj<QueryParamService>;
  const filterSubject = new BehaviorSubject<string | null>(null);
  const activeTabSubject = new BehaviorSubject<string>('listPolicy');
  const justDeployedSubject = new BehaviorSubject<string | null>(null);

  const mockPolicyList: FileTreeNodeList = {
    items: [
      {
        name: 'tnap.resource_groups_opa_policy.yml',
        path: '/policies/tnap.resource_groups_opa_policy.yml',
        type: FileTreeNodeType.FILE,
      },
      {
        name: 'tnap.slice_capacity_check_opa_policy.yml',
        path: '/policies/tnap.slice_capacity_check_opa_policy.yml',
        type: FileTreeNodeType.FILE,
      },
      {
        name: 'regular_policy.yml',
        path: '/policies/regular_policy.yml',
        type: FileTreeNodeType.FILE,
      },
      {
        name: 'folder1',
        path: '/policies/folder1',
        type: FileTreeNodeType.DIRECTORY,
      },
    ],
    totalCount: 4,
  };

  const mockEmptyPolicyList: FileTreeNodeList = {
    items: [],
    totalCount: 0,
  };

  beforeEach(async () => {
    const policyBuilderServiceSpy = jasmine.createSpyObj(
      'PolicyBuilderService',
      {
        getPolicyList: of(mockPolicyList),
        refreshDrafts: jasmine.createSpy('refreshDrafts'),
        getPolicyVersionCached: of('1.0.0'),
        getPolicyStatusCached: of('DEPLOYED'),
        getFreshDraftBranchForPolicy: of({ name: 'main' }),
        getPolicyDetails: of({
          name: 'test-policy.yml',
          path: '/policies/test-policy.yml',
          metadata: { mode: 'basic' },
        }),
        setEditPolicyJson: jasmine.createSpy('setEditPolicyJson'),
        // provide gitLabMainUrl function used by template
        gitLabMainUrl: () => '/main-repo',
      },
      {
        getPolicyDrafts$: of({ items: [] }),
      }
    );

    const policyBuilderDataServiceSpy = jasmine.createSpyObj(
      'PolicyBuilderDataService',
      ['switchTab'],
      {
        activeTab$: activeTabSubject.asObservable(),
        justDeployed$: justDeployedSubject.asObservable(),
      }
    );

    const queryParamServiceSpy = jasmine.createSpyObj('QueryParamService', {
      getValueOf: filterSubject.asObservable(),
      updateQueryParam: jasmine.createSpy(),
    });

    const alertServiceSpy = jasmine.createSpyObj('TnapAlertService', ['error']);

    queryParamServiceSpy.getValueOf.and.callFake((param: string) => {
      if (param === 'filter') return filterSubject.asObservable();
      return of(null);
    });

    await TestBed.configureTestingModule({
      declarations: [ListPolicyComponent, MockDataTableComponent],
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: PolicyBuilderService, useValue: policyBuilderServiceSpy },
        {
          provide: PolicyBuilderDataService,
          useValue: policyBuilderDataServiceSpy,
        },
        { provide: QueryParamService, useValue: queryParamServiceSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(ListPolicyComponent);
    component = fixture.componentInstance;
    mockPolicyBuilderService = TestBed.inject(
      PolicyBuilderService
    ) as jasmine.SpyObj<PolicyBuilderService>;
    mockPolicyBuilderDataService = TestBed.inject(
      PolicyBuilderDataService
    ) as jasmine.SpyObj<PolicyBuilderDataService>;
    mockQueryParamService = TestBed.inject(
      QueryParamService
    ) as jasmine.SpyObj<QueryParamService>;
    const translateService = TestBed.inject(TranslateService);
    translateService.setTranslation('en', {}, true);
    translateService.use('en');
  });

  afterEach(() => {
    filterSubject.next(null);
    activeTabSubject.next('listPolicy');
    justDeployedSubject.next(null);
    mockPolicyBuilderService.getPolicyList.calls.reset();
    mockPolicyBuilderService.getPolicyList.and.returnValue(of(mockPolicyList));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Component Properties', () => {
    it('should initialize columns with translated labels', () => {
      expect(component.columns()).toBeDefined();
      expect(component.columns().length).toBe(4);

      expect(component.columns()[0].key).toBe('name');
      expect(component.columns()[0].label).toBe(
        'policyBuilder.listPolicy.fields.name'
      );

      expect(component.columns()[1].key).toBe('policyVersion');
      expect(component.columns()[1].label).toBe(
        'policyBuilder.listPolicy.fields.policyVersion'
      );

      expect(component.columns()[2].key).toBe('status');
      expect(component.columns()[2].label).toBe(
        'policyBuilder.listPolicy.fields.status'
      );

      expect(component.columns()[3].key).toBe('actions');
      expect(component.columns()[3].label).toBe(
        'policyBuilder.listPolicy.fields.actions'
      );
    });

    it('should have filter$ observable from queryParamService', () => {
      expect(component.filter$).toBeDefined();
    });
    it('should not explicitly bind showColumnConfig and rely on default value', () => {
      fixture.detectChanges();

      const dataTable = fixture.debugElement.query(
        By.directive(MockDataTableComponent)
      ).componentInstance as MockDataTableComponent;

      expect(dataTable.showColumnConfig).toBeUndefined();
    });
  });

  describe('Policy Loading', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    it('should load policies on initialization', fakeAsync(() => {
      tick();
      component.policies$.pipe(take(1)).subscribe({
        next: result => {
          expect(result.loading).toBe(false);
          expect(result.data).toBeDefined();
          expect(result.data!.items.length).toBe(2);
          expect(result.data!.totalCount).toBe(2);
          expect(mockPolicyBuilderService.getPolicyList).toHaveBeenCalled();

          expect(
            result.data!.items.every(item =>
              item.name?.includes('_opa_policy.yml')
            )
          ).toBe(true);
        },
      });
    }));

    it('should handle empty policy list', fakeAsync(() => {
      mockPolicyBuilderService.getPolicyList.and.returnValue(
        of(mockEmptyPolicyList)
      );
      filterSubject.next(null);

      tick();
      component.policies$.pipe(take(1)).subscribe({
        next: result => {
          expect(result.data!.items.length).toBe(0);
          expect(result.data!.totalCount).toBe(0);
        },
      });
    }));

    it('should handle service errors gracefully', fakeAsync(() => {
      mockPolicyBuilderService.getPolicyList.and.returnValue(
        throwError(() => new Error('Service error'))
      );
      filterSubject.next(null);

      tick();
      component.policies$.pipe(take(1)).subscribe({
        next: result => {
          expect(result.loading).toBe(false);
          expect(result.data).toEqual({ items: [], totalCount: 0 });
        },
      });
    }));
  });

  describe('Filtering', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    it('should filter policies by name', done => {
      filterSubject.next('resource_groups');
      fixture.detectChanges();

      component.policies$.pipe(take(1)).subscribe({
        next: result => {
          if (result.data) {
            expect(result.data.items.length).toBe(1);
            expect(result.data.items[0].name).toBe(
              'tnap.resource_groups_opa_policy.yml'
            );
            expect(result.data.totalCount).toBe(1);
            done();
          } else {
            done.fail('No data received');
          }
        },
        error: done.fail,
      });
    });

    it('should be case insensitive when filtering', done => {
      filterSubject.next('RESOURCE_GROUPS');
      fixture.detectChanges();

      component.policies$.pipe(take(1)).subscribe({
        next: result => {
          if (result.data) {
            expect(result.data.items.length).toBe(1);
            expect(result.data.items[0].name).toBe(
              'tnap.resource_groups_opa_policy.yml'
            );
            done();
          } else {
            done.fail('No data received');
          }
        },
        error: done.fail,
      });
    });

    it('should return all OPA policy items when filter is empty', done => {
      filterSubject.next('');
      fixture.detectChanges();

      component.policies$.pipe(take(1)).subscribe({
        next: result => {
          if (result.data) {
            expect(result.data.items.length).toBe(2);
            expect(result.data.totalCount).toBe(2);
            expect(
              result.data.items.every(item =>
                item.name?.includes('_opa_policy.yml')
              )
            ).toBe(true);
            done();
          } else {
            done.fail('No data received');
          }
        },
        error: done.fail,
      });
    });

    it('should return all OPA policy items when filter is null', done => {
      filterSubject.next(null);
      fixture.detectChanges();

      component.policies$.pipe(take(1)).subscribe({
        next: result => {
          if (result.data) {
            expect(result.data.items.length).toBe(2);
            expect(result.data.totalCount).toBe(2);
            expect(
              result.data.items.every(item =>
                item.name?.includes('_opa_policy.yml')
              )
            ).toBe(true);
            done();
          } else {
            done.fail('No data received');
          }
        },
        error: done.fail,
      });
    });

    it('should return empty results when no policies match filter', done => {
      filterSubject.next('nonexistent');
      fixture.detectChanges();

      component.policies$.pipe(take(1)).subscribe({
        next: result => {
          if (result.data) {
            expect(result.data.items.length).toBe(0);
            expect(result.data.totalCount).toBe(0);
            done();
          } else {
            done.fail('No data received');
          }
        },
        error: done.fail,
      });
    });

    it('should trim filter value before applying', done => {
      filterSubject.next('  resource_groups  ');
      fixture.detectChanges();

      component.policies$.pipe(take(1)).subscribe({
        next: result => {
          if (result.data) {
            expect(result.data.items.length).toBe(1);
            expect(result.data.items[0].name).toBe(
              'tnap.resource_groups_opa_policy.yml'
            );
            done();
          } else {
            done.fail('No data received');
          }
        },
        error: done.fail,
      });
    });
  });

  describe('Search Methods', () => {
    it('should update filter when onSearchChange is called with value', () => {
      const testFilter = 'test-filter';
      component.onSearchChange(testFilter);

      expect(mockQueryParamService.updateQueryParam).toHaveBeenCalledWith({
        filter: testFilter,
      });
    });

    it('should reset search when onSearchChange is called with empty string', () => {
      spyOn(component, 'resetSearch');
      component.onSearchChange('');

      expect(component.resetSearch).toHaveBeenCalled();
    });

    it('should reset search when onSearchChange is called with whitespace', () => {
      spyOn(component, 'resetSearch');
      component.onSearchChange('   ');

      expect(component.resetSearch).toHaveBeenCalled();
    });

    it('should trim filter value in onSearchChange', () => {
      const testFilter = '  test-filter  ';
      component.onSearchChange(testFilter);

      expect(mockQueryParamService.updateQueryParam).toHaveBeenCalledWith({
        filter: 'test-filter',
      });
    });

    it('should reset filter when resetSearch is called', () => {
      component.resetSearch();

      expect(mockQueryParamService.updateQueryParam).toHaveBeenCalledWith({
        filter: null,
      });
    });
  });

  describe('Private Methods', () => {
    describe('filterPolicyFiles', () => {
      it('should filter out non-OPA policy files', () => {
        const testItems: FileTreeNode[] = [
          {
            name: 'tnap.resource_groups_opa_policy.yml',
            path: '/policies/tnap.resource_groups_opa_policy.yml',
            type: FileTreeNodeType.FILE,
          },
          {
            name: 'regular_policy.yml',
            path: '/policies/regular_policy.yml',
            type: FileTreeNodeType.FILE,
          },
          {
            name: 'tnap.slice_feasibility_opa_policy.yml',
            path: '/policies/tnap.slice_feasibility_opa_policy.yml',
            type: FileTreeNodeType.FILE,
          },
          {
            name: 'folder1',
            path: '/policies/folder1',
            type: FileTreeNodeType.DIRECTORY,
          },
        ];

        const result = (component as any).filterPolicyFiles(testItems);
        expect(result.length).toBe(2);
        expect(
          result.every(item => item.name?.includes('_opa_policy.yml'))
        ).toBe(true);
      });

      it('should return empty array when no OPA policy files exist', () => {
        const testItems: FileTreeNode[] = [
          {
            name: 'regular_policy.yml',
            path: '/policies/regular_policy.yml',
            type: FileTreeNodeType.FILE,
          },
          {
            name: 'another_file.txt',
            path: '/policies/another_file.txt',
            type: FileTreeNodeType.FILE,
          },
        ];

        const result = (component as any).filterPolicyFiles(testItems);
        expect(result.length).toBe(0);
      });

      it('should handle empty name gracefully', () => {
        const testItems: FileTreeNode[] = [
          {
            name: '',
            path: '/policies/empty_name',
            type: FileTreeNodeType.FILE,
          },
          {
            name: 'tnap.tmap_offset_opa_policy.yml',
            path: '/policies/tnap.tmap_offset_opa_policy.yml',
            type: FileTreeNodeType.FILE,
          },
        ];

        const result = (component as any).filterPolicyFiles(testItems);
        expect(result.length).toBe(1);
        expect(result[0].name).toBe('tnap.tmap_offset_opa_policy.yml');
      });
    });

    describe('applySearchFilter', () => {
      it('should apply search filter correctly', () => {
        const testItems: FileTreeNode[] = [
          {
            name: 'policy1_opa_policy.yml',
            path: '/policies/policy1_opa_policy.yml',
            type: FileTreeNodeType.FILE,
          },
          {
            name: 'policy2_opa_policy.yml',
            path: '/policies/policy2_opa_policy.yml',
            type: FileTreeNodeType.FILE,
          },
        ];

        const result = (component as any).applySearchFilter(
          testItems,
          'policy1'
        );
        expect(result.length).toBe(1);
        expect(result[0].name).toBe('policy1_opa_policy.yml');
      });

      it('should return all items when search filter is empty', () => {
        const testItems: FileTreeNode[] = [
          {
            name: 'policy1_opa_policy.yml',
            path: '/policies/policy1_opa_policy.yml',
            type: FileTreeNodeType.FILE,
          },
          {
            name: 'policy2_opa_policy.yml',
            path: '/policies/policy2_opa_policy.yml',
            type: FileTreeNodeType.FILE,
          },
        ];

        const result = (component as any).applySearchFilter(testItems, '');
        expect(result.length).toBe(2);
      });

      it('should return all items when search filter is null', () => {
        const testItems: FileTreeNode[] = [
          {
            name: 'policy1_opa_policy.yml',
            path: '/policies/policy1_opa_policy.yml',
            type: FileTreeNodeType.FILE,
          },
          {
            name: 'policy2_opa_policy.yml',
            path: '/policies/policy2_opa_policy.yml',
            type: FileTreeNodeType.FILE,
          },
        ];

        const result = (component as any).applySearchFilter(testItems, null);
        expect(result.length).toBe(2);
      });

      it('should handle items with undefined names in search filter', () => {
        const testItems: FileTreeNode[] = [
          {
            name: undefined as any,
            path: '/policies/unnamed',
            type: FileTreeNodeType.FILE,
          },
          {
            name: 'policy1_opa_policy.yml',
            path: '/policies/policy1_opa_policy.yml',
            type: FileTreeNodeType.FILE,
          },
        ];

        const result = (component as any).applySearchFilter(
          testItems,
          'policy1'
        );
        expect(result.length).toBe(1);
        expect(result[0].name).toBe('policy1_opa_policy.yml');
      });

      it('should be case insensitive', () => {
        const testItems: FileTreeNode[] = [
          {
            name: 'policy1_opa_policy.yml',
            path: '/policies/policy1_opa_policy.yml',
            type: FileTreeNodeType.FILE,
          },
        ];

        const result = (component as any).applySearchFilter(
          testItems,
          'POLICY1'
        );
        expect(result.length).toBe(1);
        expect(result[0].name).toBe('policy1_opa_policy.yml');
      });

      it('should trim search filter', () => {
        const testItems: FileTreeNode[] = [
          {
            name: 'policy1_opa_policy.yml',
            path: '/policies/policy1_opa_policy.yml',
            type: FileTreeNodeType.FILE,
          },
        ];

        const result = (component as any).applySearchFilter(
          testItems,
          '  policy1  '
        );
        expect(result.length).toBe(1);
        expect(result[0].name).toBe('policy1_opa_policy.yml');
      });
    });
  });

  describe('Observable Streams', () => {
    it('should react to filter changes', done => {
      let callCount = 0;
      component.policies$.subscribe(() => {
        callCount++;
        if (callCount === 2) {
          done();
        }
      });

      fixture.detectChanges();
      filterSubject.next('policy1');
    });

    it('should share replay the latest policy data', fakeAsync(() => {
      let subscriptionCount = 0;

      const subscription1 = component.policies$.subscribe(() => {
        subscriptionCount++;
      });

      const subscription2 = component.policies$.subscribe(() => {
        subscriptionCount++;
      });

      tick(10);
      expect(subscriptionCount).toBeGreaterThan(0);
      subscription1.unsubscribe();
      subscription2.unsubscribe();
    }));
  });

  describe('Integration Tests', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    it('should load policies and apply filter together', done => {
      filterSubject.next('slice_capacity_check');
      fixture.detectChanges();

      component.policies$.pipe(take(1)).subscribe({
        next: result => {
          if (result.data) {
            expect(result.data.items.length).toBe(1);
            expect(result.data.items[0].name).toBe(
              'tnap.slice_capacity_check_opa_policy.yml'
            );
            expect(mockPolicyBuilderService.getPolicyList).toHaveBeenCalled();
            done();
          } else {
            done.fail('No data received');
          }
        },
        error: done.fail,
      });
    });

    it('should handle search change and filter update flow', () => {
      const testFilter = 'test-search';
      component.onSearchChange(testFilter);

      expect(mockQueryParamService.updateQueryParam).toHaveBeenCalledWith({
        filter: testFilter,
      });
    });

    it('should handle empty search input correctly', () => {
      spyOn(component, 'resetSearch');
      component.onSearchChange('');

      expect(component.resetSearch).toHaveBeenCalled();
    });

    it('should handle whitespace-only search input correctly', () => {
      spyOn(component, 'resetSearch');
      component.onSearchChange('   ');

      expect(component.resetSearch).toHaveBeenCalled();
    });
  });

  describe('Edit and View Policy', () => {
    const mockRow: FileTreeNode = {
      name: 'tnap.resource_groups_opa_policy.yml',
      path: '/policies/tnap.resource_groups_opa_policy.yml',
      type: FileTreeNodeType.FILE,
    };

    it('should update query params with edit mode when editPolicy is called', () => {
      component.editPolicy(mockRow);

      expect(mockQueryParamService.updateQueryParam).toHaveBeenCalledWith({
        mode: 'edit',
        policyPath: mockRow.name,
      });
    });

    it('should update query params with view mode when viewPolicy is called', () => {
      component.viewPolicy(mockRow);

      expect(mockQueryParamService.updateQueryParam).toHaveBeenCalledWith({
        mode: 'view',
        policyPath: mockRow.name,
      });
    });

    it('should call getFreshDraftBranchForPolicy when opening policy editor', () => {
      component.editPolicy(mockRow);

      expect(
        mockPolicyBuilderService.getFreshDraftBranchForPolicy
      ).toHaveBeenCalledWith(mockRow.name);
    });

    it('should switch to createPolicy tab on successful policy load', fakeAsync(() => {
      component.editPolicy(mockRow);

      tick(100);
      expect(mockPolicyBuilderDataService.switchTab).toHaveBeenCalledWith(
        'createPolicy'
      );
    }));
  });
});
