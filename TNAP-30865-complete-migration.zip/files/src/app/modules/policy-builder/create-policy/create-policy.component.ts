/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  OnInit,
  AfterViewInit,
  OnDestroy,
  Component,
  viewChild,
  viewChildren,
  inject,
  DestroyRef,
  input,
  output,
  signal,
  computed,
  ElementRef,
  HostListener,
  effect,
} from '@angular/core';
import {
  FormGroup,
  Validators,
  FormBuilder,
  ValidationErrors,
  AbstractControl,
} from '@angular/forms';
import {
  take,
  switchMap,
  of,
  catchError,
  filter,
  Observable,
  EMPTY,
  tap,
  combineLatest,
} from 'rxjs';
import { RanPolicyService } from 'src/app/services/ran-policyservice/ran-policy.service';
import { TranslateService } from '@ngx-translate/core';
import { ModalConfirmationService } from 'src/app/services/common-functionalities/modal-confirmation.service';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { CodeEditorService } from 'src/app/services/common-functionalities/code-editor.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import {
  createPolicyApiRequest,
  GlobalVar,
  OpaBuilderPolicyValidationResponse,
  OpaBuilderPolicyValidationSuccessResponse,
  PACKAGE_MATCH,
  PACKAGE_REGEX,
  PolicyFormData,
  Rule,
  ConditionParseParams,
  ParseRuleParams,
  FunctionBlockDefinition,
  AddRuleParams,
  ParseRuleBlockParams,
  EveryBlockParams,
  PushEveryBlockParams,
  CreateRuleHeadParams,
  RegoRule,
  ParseFlags,
  RuleHead,
  RuleBody,
  PolicyJson,
  AstNode,
  Condition,
  FunctionArg,
  TemplateFolder,
} from 'src/app/model/OpaBuilderPolicy.model';
import { PolicyBuilderService } from '../shared/policy-builder.service';
import { PolicyBuilderDataService } from '../shared/policy-builder-data.service';
import { RuleBlockComponent } from '../rule-block/rule-block.component';
import { HelperFunctionsCreatePolicyService } from '../shared/helper-function-create-policy.service';
import * as CONST from 'src/app/model/OpaBuilderPolicy.model';
import { GlobalVarsComponent } from '../global-vars/global-vars.component';
import { HelperFunctionsConditionRowService } from '../shared/helper-functions-condition-row.service';
import {
  ValidateRegoRequest,
  Draft,
  OpaPolicyContentResponse,
} from 'openapi/output';
import { FullscreenService } from 'src/app/services/fullscreen.service';
import { RanTemplateService } from 'src/app/services/ran-templateservice/ran-template.service';
import { ValidateOutputComponent } from '../validate-output/validate-output.component';

import { updateWasEditorLastFocused } from '../shared/code-mirror-focus-helper';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-create-policy',
  standalone: false,
  templateUrl: './create-policy.component.html',
  styleUrls: ['./create-policy.component.css'],
})
export class CreatePolicyComponent implements OnInit, AfterViewInit, OnDestroy {
  readonly codeEditor = viewChild<{
    codeMirror?: {
      refresh: () => void;
      getCursor: () => { line: number; ch: number };
      replaceRange: (
        text: string,
        from: { line: number; ch: number },
        to?: { line: number; ch: number }
      ) => void;
      focus: () => void;
      setOption: (option: string, value: boolean) => void;
      hasFocus: () => boolean;
      getValue: () => string;
    };
  }>('codeEditor');
  readonly validateOutputRef =
    viewChild<ValidateOutputComponent>('validateOutputRef');
  private readonly ranPolicyService = inject(RanPolicyService);
  private readonly codeEditorService = inject(CodeEditorService);
  protected readonly policyBuilderService = inject(PolicyBuilderService);
  private readonly policyBuilderDataService = inject(PolicyBuilderDataService);
  private readonly formBuilder = inject(FormBuilder);
  private readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);
  private readonly confirmationService = inject(ModalConfirmationService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly fullscreenService = inject(FullscreenService);
  readonly permissions = inject(PERMISSIONS_TOKEN);
  readonly editorTheme = this.codeEditorService.getEditorTheme();
  protected draftName: string | undefined = undefined;
  private readonly elementRef = inject(ElementRef);
  private readonly ranTemplateService = inject(RanTemplateService);
  protected path: string = '';
  protected policyId: string = '';
  protected readonly templateFolders = signal<TemplateFolder[]>([]);
  private defaultBranch = 'main';
  protected readonly copiedFile = signal<string | null>(null);
  private clipboardTimeoutId: ReturnType<typeof setTimeout> | null = null;
  protected codeChanged: boolean = false;
  protected deployChanged: boolean = false;
  protected hasDraftBranch: boolean = false;
  protected draftBranchUrl: string | undefined = undefined;
  protected draftBranchName: string | undefined = undefined;
  protected draftBranchFileUrl: string | undefined = undefined;
  protected mainBranchFileUrl: string | undefined = undefined;
  protected isDeployEnabled: boolean = false;
  protected justSaved: boolean = false;
  private originalCode = '';
  protected output: string = '';
  protected submitted = false;
  protected isShrunk = false;
  protected isFormVisible = true;
  protected createPolicyForm!: FormGroup;
  protected isValidate = false;
  protected regoInputSchema: Record<string, unknown> | null = null;
  protected schemaTreeVisible = true;
  protected policyType = signal<string>('');
  protected saveRegoResponse = '';
  protected isSuccess = false;
  protected selectedRoot: string | null = null;
  protected isScriptEditable = true;
  protected isScriptVisible = true;
  protected isDataEditable = true;
  protected isDataVisible = true;
  protected policyName = '';
  protected isBasicMode = true;
  protected isAdvanced = false;
  protected isEditMode = false;
  protected isLoading = false;
  protected readonly edit = signal(false);
  protected isApiAdvancedMode = false;
  protected isHelpVisible = false;
  protected isHelpMaximized = false;
  protected isVisualMode = true;
  protected isRegoFullScreen = false;
  protected leftPane = 70;
  protected rightPane = 20;
  protected unit: '%' | 'px' = '%';
  protected minWidth = 20;
  protected maxWidth = 85;
  protected step = 2;
  protected rules: Rule[] = [
    {
      name: { value: 'allow' },
      category: 'DEFAULT',
      value: true,
      conditions: [],
    },
  ];
  protected globalVars: {
    key: string;
    value: string;
    type: string;
    default: boolean;
    isTypeDisabled: boolean;
  }[] = [];

  readonly toggleSchemaTreeFromEdit = output<boolean>();
  protected ui_layout: Record<string, unknown> = {};
  private readonly helperFunctionsCreatePolicyService = inject(
    HelperFunctionsCreatePolicyService
  );
  private readonly helperFunctionsService = inject(
    HelperFunctionsConditionRowService
  );
  readonly previewOnly = input(false);
  protected readonly isPreviewMode = computed(
    () => this.previewOnly() || !this.edit()
  );
  private readonly ruleBlockComponents = viewChildren(RuleBlockComponent);
  private readonly globalVarsComponent = viewChild(GlobalVarsComponent);
  protected rightOperands: string[] = [];
  private dollarIndex = 0;
  private everyIndex = 0;
  protected ruleNameErrors: { [index: number]: string } = {};
  protected get ruleNames(): string[] {
    return this.rules.map(r => r.name.value).filter(name => name.trim() !== '');
  }
  protected get customFunctions() {
    return this.rules
      .filter(r => r.isFunction)
      .map(r => ({
        name: r.name.value,
        args: r.args ?? [],
        returnVar: r.returnVar ?? '',
        returnType: r.returnType ?? '',
      }));
  }
  constructor() {
    effect(() => this.updateReadOnly());
  }
  public ngOnInit(): void {
    this.createPolicyForm = this.formBuilder.group({
      name: ['', [Validators.required, this.policyNameValidator()]],
      description: ['', Validators.required],
      mode: [this.isBasicMode ? 'basic' : 'advanced', Validators.required],
    });

    this.policyBuilderService.checkIsBasicMode(this.isBasicMode);

    this.policyBuilderService.editPolicyJson$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(policyJson => {
        if (policyJson) {
          this.usePolicyJson(policyJson);
        } else {
          this.isEditMode = false;
          this.selectedRoot = this.policyName || '';
          this.clearAll();
        }
      });
    if (this.previewOnly()) {
      this.policyBuilderService.previewPolicyJson$
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe(policyJson => {
          if (policyJson) {
            this.isEditMode = false;
            this.usePolicyJson(policyJson);
          }
        });
    }
    if (this.isEditMode) {
      this.createPolicyForm.get('name')?.disable();
    } else {
      this.createPolicyForm.get('name')?.enable();
    }
    if (this.previewOnly()) {
      this.createPolicyForm.disable();
    }

    this.policyBuilderService.insertPath$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(path => {
        const cm = this.codeEditor()?.codeMirror;
        if (cm && this.wasEditorLastFocused) {
          const cursor = cm.getCursor();
          cm.replaceRange(path, cursor);
          cm.focus();
          this.output = cm.getValue();
        }
      });
  }

  private wasEditorLastFocused = false;
  @HostListener('document:mousedown', ['$event'])
  protected onDocumentMouseDown(event: MouseEvent): void {
    updateWasEditorLastFocused({
      target: event.target as HTMLElement | null,
      setWasEditorLastFocused: v => (this.wasEditorLastFocused = v),
    });
  }

  private usePolicyJson(policyJson: PolicyJson) {
    if (!policyJson || !policyJson.name || !policyJson.metadata) {
      return;
    }
    this.isEditMode = true;
    this.clearPolicyData();
    this.edit.set(policyJson.edit || false);
    this.isValidate = !!(policyJson.data && policyJson.data.trim().length > 0);
    const parsedInput = this.parseApiPayload(policyJson.input);
    const parsedData = this.parseApiPayloadToObject(policyJson.data);
    const parsedSchema = this.parseApiPayloadToObject(policyJson.schema);
    this.regoInputSchema =
      Object.keys(parsedSchema).length > 0 ? parsedSchema : null;
    this.policyBuilderService.setInput(parsedInput);
    this.policyBuilderService.setData(parsedData);
    this.policyBuilderService.setJson(this.regoInputSchema);
    this.isBasicMode = policyJson.mode == 'basic';
    this.isAdvanced = policyJson.mode == 'advanced';
    this.isApiAdvancedMode = policyJson.mode == 'advanced';
    this.isShrunk = policyJson.mode != 'basic';
    this.isFormVisible = true;
    this.policyName = policyJson.name;
    this.policyType.set(
      policyJson.name.replace(/^[^.]*\./, '').replace(/\.yml$/i, '')
    );
    const rawUiLayout = policyJson.ui_layout;
    this.ui_layout =
      typeof rawUiLayout === 'string'
        ? JSON.parse(rawUiLayout)
        : rawUiLayout || {};
    this.policyId = (policyJson.metadata.policyId as string) || '';
    this.path = policyJson.path || '';
    this.isScriptEditable = policyJson.metadata['script-editable'] !== false;
    this.isScriptVisible = policyJson.metadata['script-visible'] !== false;
    this.isDataEditable = policyJson.metadata['data-editable'] !== false;
    this.isDataVisible = policyJson.metadata['data-visible'] !== false;
    this.policyBuilderService.checkIsBasicMode(this.isBasicMode);

    if (policyJson.edit) {
      this.policyBuilderService
        .getDraftBranchForPolicy(this.policyName)
        .pipe(take(1))
        .subscribe(draftBranch => {
          this.hasDraftBranch = !!draftBranch;
          this.draftBranchUrl = draftBranch?.url;
          this.draftBranchName = draftBranch?.name;
          this.isDeployEnabled = !!draftBranch;
          this.justSaved = false;
        });
    }

    if (this.policyId === 'tnap.slice_ran_template') {
      combineLatest([
        this.ranTemplateService.getDefaultBranch$,
        this.ranTemplateService.getTemplatesMainBranchStructure.pipe(
          filter(data => !data.loading)
        ),
      ])
        .pipe(take(1))
        .subscribe(([branch, data]) => {
          this.defaultBranch = branch;
          this.templateFolders.set(
            this.mapToTemplateFolders(data.data?.items || [])
          );
        });
    }

    this.createPolicyForm.setValue({
      name: policyJson.name,
      description: this.isBasicMode
        ? (this.ui_layout['description'] as string)
        : (policyJson.metadata['policy-description'] as string),
      mode: policyJson.mode,
    });

    if (this.isAdvanced) {
      const script = policyJson.script || '';
      const packageMatch = script.match(PACKAGE_MATCH);
      this.selectedRoot = packageMatch ? packageMatch[1] : '';
      this.output = script;
      this.policyBuilderService.setErrorMsg(
        this.output?.includes('decision')
          ? ''
          : this.translateService.instant(
              'policyBuilder.validation.mandatoryDecisionFieldMissing'
            )
      );

      this.originalCode = script;
      this.codeChanged = false;

      if (!this.isValidate) {
        this.refreshCodeEditor();
      }
    }
    if (this.isBasicMode) {
      this.output = policyJson.script || '';
      this.loadPolicy(policyJson);
    }

    if (this.isValidate) {
      this.validateRego();
    }
  }

  private parseApiPayload(
    payload: unknown
  ): Record<string, unknown> | unknown[] {
    if (!payload) return {};
    if (typeof payload === 'object') {
      return payload as Record<string, unknown> | unknown[];
    }
    if (typeof payload !== 'string' || !payload.trim()) return {};

    try {
      const parsed = JSON.parse(payload) as unknown;
      return typeof parsed === 'string'
        ? this.parseApiPayload(parsed)
        : parsed && typeof parsed === 'object'
          ? (parsed as Record<string, unknown> | unknown[])
          : {};
    } catch {
      return {};
    }
  }

  private parseApiPayloadToObject(payload: unknown): Record<string, unknown> {
    if (!payload) {
      return {};
    }

    if (typeof payload === 'object' && !Array.isArray(payload)) {
      return payload as Record<string, unknown>;
    }

    if (typeof payload !== 'string') {
      return {};
    }
    const trimmedPayload = payload.trim();
    if (!trimmedPayload) {
      return {};
    }
    try {
      const parsed = JSON.parse(trimmedPayload) as unknown;
      if (
        typeof parsed === 'object' &&
        parsed !== null &&
        !Array.isArray(parsed)
      ) {
        return parsed as Record<string, unknown>;
      }
      if (typeof parsed === 'string') {
        return this.parseApiPayloadToObject(parsed);
      }
      return {};
    } catch {
      return {};
    }
  }

  loadPolicy(policyJson: PolicyJson) {
    const rawLayout = policyJson.ui_layout;
    const layout =
      typeof rawLayout === 'string' ? JSON.parse(rawLayout) : rawLayout || {};
    this.selectedRoot = layout.package || '';
    this.globalVars = ((layout.globalVars as GlobalVar[]) || []).map(
      (v: GlobalVar) => ({
        key: v.key || '',
        value: v.value || '',
        type: v.type || '',
        default: v.default ?? false,
        isTypeDisabled: v.isTypeDisabled ?? false,
      })
    );
    this.policyName = layout.name || '';
    this.rules = (layout.rules || []).map((rule: Rule) => ({
      ...rule,
      conditions: (rule.conditions || []).map(condition => ({
        ...condition,
        leftFunctionArgs: condition.leftFunctionArgs || [],
        functionArgs: condition.functionArgs || [],
        everyRuleBlocks: condition.everyRuleBlocks || [],
        subRules: condition.subRules || [],
      })),
    }));
  }

  ngAfterViewInit() {
    if (this.codeEditor()?.codeMirror) {
      this.refreshCodeEditor();
    }
    if (this.previewOnly()) {
      const elem = this.elementRef.nativeElement as HTMLElement;
      elem
        .querySelectorAll(
          'input, textarea, select, button, nz-select, nz-switch'
        )
        .forEach(el => (el as HTMLElement).setAttribute('disabled', 'true'));
      elem
        .querySelectorAll('nz-select')
        .forEach(el => el.setAttribute('nzDisabled', 'true'));
      elem
        .querySelectorAll('nz-switch')
        .forEach(el => el.setAttribute('nzDisabled', 'true'));
      elem
        .querySelectorAll('mat-select')
        .forEach(el => el.setAttribute('disabled', 'true'));
      elem.querySelectorAll('[tabindex], [click], [keydown]').forEach(el => {
        const htmlEl = el as HTMLElement;
        htmlEl.removeAttribute('tabindex');
        htmlEl.style.pointerEvents = 'none';
      });
    }
  }

  getRegoPackage(code: string): string | null {
    const match = PACKAGE_REGEX.exec(code);
    return match ? match[1] : null;
  }

  toggleViewMode() {
    this.isVisualMode = !this.isVisualMode;
    this.isShrunk = !this.isVisualMode;

    if (this.isShrunk) {
      const valid = this.generateAST().length > 0;
      if (!valid) {
        this.isShrunk = false;
        this.isVisualMode = true;
        this.scrollToFirstError();
        return;
      }
      this.generateRego();
    }
  }

  private scrollToFirstError(): boolean {
    const errorElement =
      this.elementRef.nativeElement.querySelector('.invalid-feedback');
    if (errorElement) {
      errorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      const input = errorElement
        .closest('.input-with-error')
        ?.querySelector('input') as HTMLInputElement;
      if (input) {
        input.focus();
      }
      return true;
    }
    return false;
  }

  toggleMode() {
    if (this.scrollToFirstError()) {
      return;
    }
    if (!this.validatePolicy()) {
      return;
    }
    if (this.isBasicMode) {
      this.confirmationService
        .openConfirmationModal(
          'common.buttons.yes',
          'ranTemplate.modal.mode.title',
          'ranTemplate.modal.mode.text'
        )
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe(confirmed => {
          if (confirmed) {
            this.generateRego();
            this.switchToAdvancedMode();
          }
        });
    } else {
      this.switchToBasicMode();
    }
  }

  private switchToAdvancedMode() {
    this.isBasicMode = false;
    this.isAdvanced = true;
    this.isShrunk = true;
    this.isFormVisible = false;
    this.policyBuilderService.checkIsBasicMode(false);
  }

  private switchToBasicMode() {
    this.isBasicMode = true;
    this.isAdvanced = false;
    this.isVisualMode = true;
    this.isShrunk = false;
    this.isFormVisible = false;
    this.policyBuilderService.checkIsBasicMode(true);
  }

  showForm() {
    this.saveRegoResponse = '';

    if (this.isBasicMode) {
      const data = this.generateAST();
      if (data.length > 0) {
        this.generateRego();
        this.isFormVisible = true;
        this.isShrunk = true;
        this.isVisualMode = false;
      } else {
        this.isFormVisible = false;
        this.isShrunk = false;
      }
    } else {
      this.isFormVisible = true;
    }
  }

  protected onPathSelected(path: string): void {
    if (this.edit()) {
      this.policyBuilderService.insertPath(path);
    }
  }

  private validateSaveResponse(
    response: OpaBuilderPolicyValidationResponse | null
  ) {
    if (!response) {
      this.alertService.error(
        this.translateService.instant('ranTemplate.message.error.save')
      );
      return;
    }

    if (this.isSuccessResponse(response)) {
      if (response?.name == undefined) {
        this.alertService.warn(
          this.translateService.instant(
            'ranTemplate.message.error.constrainViolation'
          )
        );
      } else {
        this.alertService.success(
          this.translateService.instant('ranTemplate.message.success.save')
        );
        this.ranPolicyService.updateDraftBranches(response.name);
      }
    }
  }

  private isSuccessResponse(
    response: OpaBuilderPolicyValidationResponse | undefined
  ): response is OpaBuilderPolicyValidationSuccessResponse {
    if (!response) {
      return false;
    }
    return 'name' in response && response.name !== undefined;
  }

  deploy(): void {
    if (!this.policyName) {
      this.alertService.error(
        this.translateService.instant('policyBuilder.error.policyNameNotSet')
      );
      return;
    }
    const hadDraftBranch = this.hasDraftBranch;

    this.policyBuilderService
      .getFreshDraftBranchForPolicy(this.policyName)
      .pipe(
        take(1),
        switchMap(draftBranch => {
          return this.policyBuilderService.deployPolicy(
            this.policyName,
            draftBranch?.name
          );
        })
      )
      .subscribe({
        next: response => {
          if (!response?.name) {
            this.alertService.warn(
              this.translateService.instant(
                'ranTemplate.message.error.constrainViolation'
              )
            );
          } else {
            this.alertService.success(
              this.translateService.instant(
                'ranTemplate.message.success.deploy'
              )
            );
            this.deployChanged = false;
            this.hasDraftBranch = false;

            this.policyBuilderService.setEditPolicyJson(null);

            if (hadDraftBranch) {
              this.policyBuilderDataService.setJustDeployed(this.policyName);
            }
            setTimeout(() => {
              this.policyBuilderService.refreshDrafts();
              this.policyBuilderDataService.switchTab('listPolicy');
            }, 100);
          }
        },
        error: () => {
          this.alertService.error(
            this.translateService.instant('ranTemplate.message.error.deploy')
          );
        },
      });
  }

  private setPackageNameError(): void {
    this.saveRegoResponse = this.translateService.instant(
      'policyBuilder.validation.packageNameCannotBeChanged',
      { packageName: this.selectedRoot }
    );
    this.isSuccess = false;
    this.isFormVisible = false;
    this.policyBuilderService.checkIsSaveFormVisible(this.isFormVisible);
  }

  private clearValidationMessages(): void {
    this.saveRegoResponse = '';
    this.isSuccess = true;
  }

  private validatePackageName(regoText: string): void {
    const packageName = this.getRegoPackage(regoText);
    if (packageName != null && packageName !== this.selectedRoot) {
      this.setPackageNameError();
    } else {
      this.clearValidationMessages();
    }
  }

  isValidPackageName(rego: string): boolean {
    const packageName = this.getRegoPackage(rego);
    if (packageName == null) {
      this.output = 'package ' + this.selectedRoot + '\n\n' + rego;
      this.clearValidationMessages();
      return true;
    } else if (packageName != this.selectedRoot) {
      this.setPackageNameError();
      return false;
    }
    this.clearValidationMessages();
    return true;
  }

  hideForm() {
    this.isFormVisible = false;
    this.policyBuilderService.checkIsSaveFormVisible(this.isFormVisible);
    this.submitted = false;
  }

  cancelForm() {
    this.saveRegoResponse = '';
    const modeVal = this.createPolicyForm.controls['mode']?.value;
    if (!this.isEditMode) {
      this.createPolicyForm.reset({
        name: '',
        description: '',
        mode: modeVal,
      });
    }
    this.hideForm();
    this.isSuccess = false;
  }

  policyNameValidator() {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = control.value;
      if (!value) return null;
      if (value.length > 50) {
        return {
          policyName: this.translateService.instant(
            'policyBuilder.validation.policyNameLength'
          ),
        };
      }
      if (!/^[A-Za-z]/.test(value)) {
        return {
          policyName: this.translateService.instant(
            'policyBuilder.validation.policyNameStart'
          ),
        };
      }
      if (!/^[A-Za-z0-9._-]+$/.test(value)) {
        return {
          policyName: this.translateService.instant(
            'policyBuilder.validation.policyName'
          ),
        };
      }
      return null;
    };
  }

  onSubmit() {
    this.submitted = true;
    if (!this.createPolicyForm.controls['mode']?.value) {
      this.createPolicyForm.controls['mode']?.setValue(
        this.isBasicMode ? 'basic' : 'advanced'
      );
    }

    if (this.createPolicyForm.invalid) {
      return;
    }

    const formData: PolicyFormData = {
      name: this.createPolicyForm.controls['name']?.value,
      description: this.createPolicyForm.controls['description']?.value,
      mode: this.createPolicyForm.controls['mode']?.value,
    };
    this.savePolicy(formData);
  }

  protected format(): Observable<boolean> {
    return this.policyBuilderService.formatRegoCode(this.output).pipe(
      tap(success => {
        if (success) {
          this.output = this.policyBuilderService.regoCode$() || this.output;
        }
      })
    );
  }

  private savePolicy(formData: PolicyFormData): void {
    this.submitted = true;

    this.createPolicyForm
      .get('mode')
      ?.setValue(this.isBasicMode ? 'basic' : 'advanced');

    if (this.createPolicyForm.invalid) {
      return;
    }

    const regoData$ = this.isValidate
      ? this.policyBuilderService.regoData.pipe(
          take(1),
          tap(rego => {
            this.output = rego || '';
          })
        )
      : of(null);

    regoData$
      .pipe(
        switchMap(() => this.format()),
        filter(success => success),
        switchMap(() => this.proceedWithSave(formData)),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: data =>
          this.handleSaveSuccess(
            formData,
            data as OpaBuilderPolicyValidationResponse
          ),
        error: error => this.handleSaveError(error),
      });
  }

  private proceedWithSave(
    formData: PolicyFormData
  ): Observable<Draft | OpaPolicyContentResponse> {
    const description = formData.description;

    if (this.isBasicMode) {
      this.ui_layout.description = formData.description;
      this.ui_layout.name = formData.name;
      this.ui_layout.package = this.selectedRoot;
      this.ui_layout.globalVars = this.globalVars;
      this.ui_layout.rules = this.rules;
    }

    const currentMode = this.isBasicMode ? 'basic' : 'advanced';
    const uiLayoutPayload = this.isBasicMode
      ? JSON.stringify(this.ui_layout)
      : undefined;
    const apiRequest = createPolicyApiRequest(
      formData.name,
      description,
      currentMode,
      this.path,
      this.output,
      uiLayoutPayload
    );

    if (!this.isBasicMode) {
      const validateRequest: ValidateRegoRequest = {
        regoCode: this.output,
        mode: currentMode,
      };
      return this.policyBuilderService.validateRegoData(validateRequest).pipe(
        switchMap(res => {
          const isCompileError =
            res.status === 'failure' &&
            'errorType' in res &&
            (res.errorType === 'parse' || res.errorType === 'format');

          if (isCompileError) {
            this.alertService.error(res.message);
            this.isSuccess = false;
            return EMPTY;
          }
          return this.callSaveApi(apiRequest);
        }),
        catchError(err => {
          this.saveRegoResponse = err;
          this.isSuccess = false;
          return EMPTY;
        })
      );
    }

    return this.callSaveApi(apiRequest);
  }

  private callSaveApi(
    apiRequest: ReturnType<typeof createPolicyApiRequest>
  ): Observable<Draft | OpaPolicyContentResponse> {
    return this.policyBuilderService.savePolicy(apiRequest);
  }

  closeNotificationDiv() {
    this.saveRegoResponse = '';
    this.isSuccess = false;
  }

  private refreshCodeEditor(): void {
    setTimeout(() => {
      if (this.codeEditor()?.codeMirror) {
        this.codeEditor()!.codeMirror!.refresh();
      }
    }, 300);
  }

  private handleSaveError(error: { error: string }): void {
    try {
      const errorResponse = JSON.parse(error.error);
      this.saveRegoResponse = errorResponse.message;
    } catch {
      this.saveRegoResponse = this.translateService.instant(
        'policyBuilder.validation.savePolicyError'
      );
    }
    this.isSuccess = false;
  }

  private handleSaveSuccess(
    formData: PolicyFormData,
    data: OpaBuilderPolicyValidationResponse | null
  ): void {
    this.validateSaveResponse(data);
    this.codeChanged = false;
    this.policyName = formData.name;
    this.hasDraftBranch = true;
    this.isDeployEnabled = false;
    this.justSaved = true;
    setTimeout(() => {
      this.isDeployEnabled = true;
      this.justSaved = false;
    }, 10000);
    this.cancelForm();
    this.policyBuilderService.refreshDrafts();
  }

  clearAll(): void {
    this.clearPolicyData();
    this.output = '';
    this.selectedRoot = this.policyName || '';
    this.isShrunk = false;
    this.hideForm();
  }

  private clearPolicyData(): void {
    this.isValidate = false;
    this.regoInputSchema = null;
    this.policyBuilderService.setRegoData(null);
    this.policyBuilderService.setInput({});
    this.policyBuilderService.setData({});
    this.policyBuilderService.setJson(null);
    this.policyBuilderService.updateOutput({});
    this.policyBuilderService.updateLint({});
  }

  onCodeChange(): void {
    const hasDecision = /\bdecision\b/.test(this.output);
    this.codeChanged = this.output !== this.originalCode;
    this.policyBuilderService.setErrorMsg(
      hasDecision
        ? null
        : this.translateService.instant(
            'policyBuilder.validation.mandatoryDecisionFieldMissing'
          )
    );
    this.isShrunk = true;
    const isValid = this.isBasicMode && hasDecision;
    this.policyBuilderService.setDecisionValue(isValid);
    if (!isValid) {
      this.validatePackageName(this.output ?? '');
    }
  }

  onGlobalVarsChange(vars: GlobalVar[]) {
    vars.forEach((v, i) => {
      if (this.globalVars[i]) {
        Object.assign(this.globalVars[i], {
          ...v,
          default: v.default ?? false,
        });
      } else {
        this.globalVars.push({
          ...v,
          default: v.default ?? false,
        });
      }
    });

    if (this.globalVars.length > vars.length) {
      this.globalVars.length = vars.length;
    }
    this.forceUpdateAllRows(this.globalVars);
  }

  onRuleChange(updatedRule: Rule, index: number): void {
    Object.assign(this.rules[index], updatedRule);
  }

  forceUpdateAllRows(newVars: GlobalVar[]) {
    const normalizedVars = newVars.map(v => ({
      ...v,
      default: v.default ?? false,
    }));
    this.ruleBlockComponents().forEach(block => {
      block
        .conditionRows()
        .forEach(row => row.updateFromGlobalVars(normalizedVars));
    });
  }

  addNewFunctionBlock(fn: FunctionBlockDefinition) {
    this.rules.push({
      name: { value: fn.name },
      category: 'FUNCTION_BLOCK',
      args: fn.args,
      isFunction: true,
      isOr: false,
      isOtherwise: false,
      conditions: [],
      value: null,
      returnVar: fn.returnVar ?? '',
      returnType: fn.returnType,
    });
  }

  addNewRule(ruleName: string, insertAfterIndex?: number): void {
    const isOr = ruleName?.startsWith('OR:') ?? false;
    const isOtherwise = ruleName?.startsWith('Otherwise:') ?? false;
    const actualName = isOr
      ? ruleName.substring(3)
      : isOtherwise
        ? ruleName.substring(10)
        : ruleName;

    if ((isOr || isOtherwise) && actualName === 'undefined') return;

    const exists = this.rules.find(r => r.name.value === actualName);

    if ((isOr || isOtherwise) && exists) {
      this.addRule({ isOr, isOtherwise, exists, insertAfterIndex });
    } else if (!exists) {
      this.rules.push({
        name: { value: actualName },
        category: 'RULE_BLOCK',
        value: true,
        conditions: [],
        isOr: false,
      });
    } else {
      let counter = 1;
      let uniqueName = `${actualName}_${counter}`;
      while (this.rules.find(r => r.name.value === uniqueName)) {
        counter++;
        uniqueName = `${actualName}_${counter}`;
      }
      this.rules.push({
        name: { value: uniqueName },
        category: 'RULE_BLOCK',
        value: true,
        conditions: [],
        isOr: false,
      });
    }
  }

  removeRule(index: number): void {
    const rule = this.rules.splice(index, 1);
    const ruleName = rule[0].name.value;
    const isRootRule =
      rule[0].isOtherwise == undefined &&
      (rule[0].isOr == undefined || !rule[0].isOr);
    if (isRootRule) {
      this.rules = this.rules.filter(r => r.name.value !== ruleName);
    }

    const hasBaseRule = this.rules.some(r => !r.isOr);
    if (!hasBaseRule && this.rules.length > 0) {
      this.rules[0].isOr = false;
    }
  }

  onClearParentRuleNameErrors() {
    this.ruleNameErrors = [];
  }

  addRule(params: AddRuleParams) {
    const { isOr, isOtherwise, exists, insertAfterIndex } = params;
    const newRule: Rule = {
      name: exists.name,
      category: '',
      value: '',
      conditions: [],
      isOr,
      isOtherwise,
      returnVar: '',
    };
    if (typeof insertAfterIndex === 'number') {
      let offset = 1;
      if (isOr || isOtherwise) {
        while (this.rules[insertAfterIndex + offset]?.isOtherwise) {
          offset++;
        }
      }
      this.rules.splice(insertAfterIndex + offset, 0, newRule);
    } else {
      this.rules.push(newRule);
    }
  }

  generateAST(): string {
    if (!this.helperFunctionsCreatePolicyService.checkForRules(this.rules)) {
      return '';
    }
    for (const block of this.ruleBlockComponents()) {
      if (
        !this.helperFunctionsCreatePolicyService.validateEveryBlock(
          block.rule().everyRuleBlocks
        )
      ) {
        return '';
      }
      if (!this.helperFunctionsCreatePolicyService.isValidCondition(block))
        return '';
    }
    if (!this.validatePolicy()) return '';
    const globalVarsComp = this.globalVarsComponent();
    if (globalVarsComp?.hasValidationErrors()) {
      return '';
    }

    this.helperFunctionsCreatePolicyService.validateOtherwiseConditions(
      this.rules
    );

    const rules: RegoRule[] = [];
    const flags = {
      needsInImport: false,
      indexInc: 0,
      arrayIndex: 1,
      arrayCounter: 0,
    };

    this.parseRuleBlock({ rules, flags });
    const ast: Record<string, unknown> = {};
    if (this.selectedRoot) {
      ast.package = this.customPackageTemplate();
    } else {
      ast.package = CONST.PACKAGE_TEMPLATE;
    }
    ast.imports = CONST.DEFAULT_IMPORTS;
    ast.rules = rules;
    if (rules.length == 0) {
      return '';
    }
    return JSON.stringify(ast, null, 2);
  }

  validatePolicy(): boolean {
    let isValid = true;

    if (!this.validateRuleNames()) {
      isValid = false;
    }
    const globalVarsComp = this.globalVarsComponent();
    if (globalVarsComp) {
      if (!globalVarsComp.validateAllGlobalVars()) {
        isValid = false;
      }

      if (!globalVarsComp.validateAllArguments()) {
        isValid = false;
      }
    }
    this.ruleBlockComponents().forEach(ruleBlock => {
      if (!ruleBlock.validateRuleBlock(ruleBlock.rule())) {
        isValid = false;
      }
    });

    return isValid;
  }

  parseRuleBlock(params: ParseRuleBlockParams): void {
    const { rules, flags } = params;
    this.globalVars.forEach(v => {
      const base = {
        body: [
          {
            index: 0,
            terms:
              this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.boolean(
                true
              ),
          },
        ],
      };
      const defaultPart = v.default ? { default: true } : {};

      const headPart =
        this.helperFunctionsCreatePolicyService.createHeadPartFromTemplate(
          v.key,
          this.helperFunctionsCreatePolicyService.getValueForGlobalVar(
            v,
            this.dollarIndex
          )
        );
      rules.push({ ...base, ...defaultPart, ...headPart });
    });
    let lastNormalRule: RegoRule | null = null;

    this.rules.forEach(rule => {
      this.dollarIndex = 0;
      this.everyIndex = 0;
      const head = this.createRuleHeadPartFromTemplate({
        key: rule.name.value,
        value: this.getValueForUnknownInput(rule.value),
        isOtherwise: !!rule.isOtherwise,
        isContains: !!rule.isContains,
        isFunction: !!rule.isFunction,
        returnVar: rule.returnVar,
        functionArgs: rule.args,
        actualValue: rule.value as string,
      });
      const body: RuleBody[] = [];
      this.parseEveryAndAppendToBody({
        everyRuleBlocks: rule.everyRuleBlocks,
        body,
        idx: this.everyIndex,
        flags,
      });
      this.everyIndex++;

      this.parseRegoblock(rule.conditions, flags, body);
      this.parseRegoblockForOtherwise(rule, body);
      if (body.length > 0) {
        if (rule.isOtherwise) {
          if (lastNormalRule) {
            this.helperFunctionsCreatePolicyService.getLastNormalRule(
              lastNormalRule,
              body,
              head,
              rules
            );
          }
        } else {
          const normal: RegoRule = {
            body: body,
            head: head,
            else: undefined,
          };
          rules.push(normal);
          lastNormalRule = normal;
        }
      }
    });
  }

  createRuleHeadPartFromTemplate(params: CreateRuleHeadParams): RuleHead {
    const {
      key,
      value,
      isOtherwise,
      isContains,
      isFunction,
      returnVar,
      functionArgs,
      actualValue,
    } = params;
    let template;

    const isRefPath = (
      val: { value?: string } | null | undefined,
      actual: string
    ): boolean =>
      typeof val?.value === 'string' &&
      val.value.includes('.') &&
      typeof actual === 'string' &&
      !actual.startsWith('"');

    const buildRef = (path: string) => {
      const parts = path.split('.');
      return {
        type: 'ref',
        value: parts.map((part: string, index: number) =>
          index === 0 ? { type: 'var', value: part } : buildStringTerm(part)
        ),
      };
    };

    const buildStringTerm = (part: string) =>
      isQuotedString(part)
        ? { type: 'string', value: part.slice(1, -1) }
        : { type: 'string', value: part };

    const isQuotedString = (val: string): boolean =>
      typeof val === 'string' &&
      ((val.startsWith('"') && val.endsWith('"')) ||
        (val.startsWith("'") && val.endsWith("'")));

    const isArrayLiteral = (val: string): boolean =>
      typeof val === 'string' && val.startsWith('[') && val.endsWith(']');

    const isObjectOrSetLiteral = (val: string): boolean =>
      typeof val === 'string' && val.startsWith('{') && val.endsWith('}');

    const parseObjectOrSet = (actual: string) => {
      if (this.helperFunctionsCreatePolicyService.isObjectLiteral(actual)) {
        return {
          type: 'object',
          value:
            this.helperFunctionsCreatePolicyService.parseObjectLiteral(actual),
        };
      }

      return {
        type: 'set',
        value: this.helperFunctionsCreatePolicyService.parseSetLiteral(actual),
      };
    };

    const buildPrimitiveOrVar = (val: { value: unknown }, actual: string) => {
      const inferred = this.helperFunctionsService.inferType(actual);
      return {
        type:
          typeof val.value === 'boolean'
            ? 'boolean'
            : inferred === 'json'
              ? 'object'
              : inferred === '' || inferred === 'empty'
                ? 'var'
                : inferred,
        value: val.value,
      };
    };

    const normalizeValue = (
      val: { value?: unknown } | null | undefined,
      actual: string
    ): object | null => {
      if (!val) return null;
      const strVal =
        typeof val.value === 'string' ? val.value : String(val.value ?? '');
      if (isRefPath(val as { value?: string }, actual)) {
        return buildRef(strVal);
      }

      if (isQuotedString(actual)) {
        return { type: 'string', value: strVal };
      }

      if (isArrayLiteral(actual)) {
        return { type: 'array', value: val.value };
      }

      if (isObjectOrSetLiteral(actual)) {
        return parseObjectOrSet(actual);
      }

      return buildPrimitiveOrVar(val as { value: unknown }, actual);
    };

    template = this.helperFunctionsCreatePolicyService.setTemplateVal(
      template,
      value as AstNode,
      isOtherwise
    );

    if (isContains) {
      template = structuredClone(CONST.TEMPLATE_CONTAINS);
      if (isObjectOrSetLiteral(actualValue)) {
        template.key = parseObjectOrSet(actualValue as string);
      } else {
        template.key = normalizeValue(
          value as { value?: unknown },
          actualValue as string
        );
      }
      this.setTemplateRefAndName(template, key);
    } else {
      template = isFunction
        ? structuredClone(CONST.TEMPLATE_FUNCTION)
        : structuredClone(CONST.TEMPLATE_ASSIGN);
      template.assign = true;

      if (isFunction) {
        template.value =
          this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.var(returnVar);
        template.args = (functionArgs ?? []).map(arg => ({
          type: 'var',
          value: arg,
        }));
      } else {
        template.value = normalizeValue(
          value as { value?: unknown },
          actualValue as string
        );
      }

      this.setTemplateRefAndName(template, key);
    }

    return template;
  }

  getValueForUnknownInput(val: unknown): object | null {
    if (val == null) {
      return null;
    }

    if (typeof val === 'boolean') {
      return this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.boolean(
        val
      );
    }

    if (typeof val === 'number') {
      return this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.number(val);
    }

    if (
      Array.isArray(val) ||
      (typeof val === 'string' && (val.startsWith('[') || val.endsWith(']')))
    ) {
      return this.helperFunctionsCreatePolicyService.parseOperandAndAppendAST({
        expr: val as string,
        flags: { indexInc: 0, arrayCounter: 0 },
        isArray: false,
        operator: '',
        dollarIndex: this.dollarIndex,
      });
    }

    if (typeof val === 'object' && val !== null) {
      return this.helperFunctionsCreatePolicyService.getValueForGlobalVarJSON(
        {
          value: JSON.stringify(val),
          type: 'JSON',
          key: '',
          default: false,
          isTypeDisabled: false,
        },
        this.dollarIndex
      );
    }

    if (typeof val === 'string') {
      const v = val.trim();

      const value = this.getValueForStringType(v);
      if (value) return value;

      if (/^[a-zA-Z_][a-zA-Z0-9_.]*$/.test(v)) {
        if (v.indexOf('.')) {
          this.helperFunctionsCreatePolicyService.parseOperandAndAppendAST({
            expr: val,
            flags: { indexInc: 0, arrayCounter: 0 },
            isArray: false,
            operator: '',
            dollarIndex: this.dollarIndex,
          });
        } else {
          return this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.var(v);
        }
      }

      return this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.string(v);
    }

    return this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.string(
      String(val)
    );
  }

  validateRuleNames(): boolean {
    this.ruleNameErrors = {};
    const nameCount: { [name: string]: number } = {};
    let isValid = true;

    this.rules.forEach((rule, index) => {
      if (rule.isOr || rule.isOtherwise || rule.isContains) {
        return;
      }
      const name = rule.name.value?.trim();
      if (!name) return;

      nameCount[name] = (nameCount[name] || 0) + 1;
      if (nameCount[name] > 1) {
        this.ruleNameErrors[index] = '*duplicate';
        isValid = false;
      }
    });

    return isValid;
  }

  customPackageTemplate() {
    return {
      path: [
        {
          type: 'var',
          value: 'data',
        },
        {
          type: 'string',
          value: this.selectedRoot,
        },
      ],
    };
  }

  private parseEveryAndAppendToBody(params: EveryBlockParams) {
    const { everyRuleBlocks, body, idx, flags } = params;
    const blocks: Rule[] = Array.isArray(everyRuleBlocks)
      ? everyRuleBlocks
      : everyRuleBlocks
        ? [everyRuleBlocks]
        : [];
    blocks?.forEach(subRule => {
      this.pushEveryBlockToBody({
        subBody: body,
        idx,
        subRule,
        flags,
      });
    });
  }

  private pushEveryBlockToBody(params: PushEveryBlockParams) {
    const { subBody, idx, subRule, flags } = params;
    let keyAst: object | null = null;
    let valueAst: object | null =
      this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.var(
        subRule.name.value
      );
    if (
      typeof subRule.name?.value === 'string' &&
      subRule.name.value.includes(',')
    ) {
      const parts = subRule.name.value.split(',').map((p: string) => p.trim());
      if (parts.length === 2) {
        keyAst = this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.var(
          parts[0]
        );
        valueAst = this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.var(
          parts[1]
        );
      }
    }
    const nestedBody = this.parseEverySubRule(subRule, flags);
    subBody.push({
      index: idx,
      terms: {
        body: nestedBody,
        domain:
          this.helperFunctionsCreatePolicyService.parseOperandAndAppendAST({
            expr: subRule.value as string,
            flags: { indexInc: 0, arrayCounter: 0 },
            isArray: false,
            operator: null,
            dollarIndex: this.dollarIndex,
          }),
        key: keyAst,
        value: valueAst,
      },
    });
  }

  private parseEverySubRule(subRule: Rule, flags: ParseFlags): object[] {
    const subBody: object[] = [];
    this.parseRegoblock(subRule.conditions, flags, subBody);
    const nestedBlocks: Rule[] = Array.isArray(subRule.everyRuleBlocks)
      ? subRule.everyRuleBlocks
      : subRule.everyRuleBlocks
        ? [subRule.everyRuleBlocks]
        : [];

    nestedBlocks.forEach((nested, idx) => {
      this.pushEveryBlockToBody({
        subBody,
        idx,
        subRule: nested,
        flags,
      });
    });
    return subBody;
  }

  parseRegoblock(
    conditions: Condition[],
    flags: ParseFlags,
    body: object[]
  ): void {
    conditions.forEach((cond, idx) => {
      this.parseRule({ cond, idx, flags, body });
      this.parseEveryAndAppendToBody({
        everyRuleBlocks: cond.everyRuleBlocks,
        body,
        idx: this.everyIndex,
        flags,
      });
      this.everyIndex++;
    });
  }

  parseRule(params: ParseRuleParams): void {
    const { cond, idx, flags, body } = params;
    let { leftOperand, rightOperand } = cond;
    const { operator } = cond;
    const bodyIndex = idx + flags.indexInc + flags.arrayCounter;

    rightOperand = this.processIterOperands(rightOperand as string);
    const opFunc = this.parseConditionAndAppendAST({
      op: operator,
      flags,
      leftOperand,
      rightOperand: rightOperand as string,
      body,
      idx,
      cond,
    });

    if (this.isArray(rightOperand as string) && operator === 'in1') {
      [leftOperand, rightOperand] = [rightOperand as string, leftOperand];
    }

    const leftOper = cond.leftFunctionArgs?.length
      ? this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.call([
          this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.refVar([
            this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.var(
              cond.leftOperand
            ),
          ]),
          ...cond.leftFunctionArgs.map((arg: FunctionArg) =>
            this.helperFunctionsCreatePolicyService.generateBuiltInAST(arg)
          ),
        ])
      : this.helperFunctionsCreatePolicyService.parseOperandAndAppendAST({
          expr: leftOperand,
          flags,
          isArray: this.isArray(leftOperand),
          operator,
          dollarIndex: this.dollarIndex,
        });

    const rightOper = cond.functionArgs?.length
      ? this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.call([
          this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.refVar([
            this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.var(
              cond.rightOperand as string
            ),
          ]),
          ...cond.functionArgs.map((arg: FunctionArg) =>
            this.helperFunctionsCreatePolicyService.generateBuiltInAST(arg)
          ),
        ])
      : this.helperFunctionsCreatePolicyService.parseOperandAndAppendAST({
          expr: rightOperand as string,
          flags,
          isArray: this.isArray(rightOperand as string),
          operator,
          dollarIndex: this.dollarIndex,
        });

    const isSpecialListType =
      operator === CONST.NOT_IN_LIST_TYPE || operator === CONST.IN_LIST_TYPE;
    const finalCond = isSpecialListType
      ? CONST.NOT_IN_REF
      : this.OPER_FUNC_REF(opFunc);
    const terms = [finalCond, leftOper, rightOper];

    if (operator === CONST.IN_TYPE) {
      return;
    }

    const finalBody =
      operator === CONST.NOT_IN_LIST_TYPE
        ? { index: bodyIndex, negated: true, terms }
        : { index: bodyIndex, terms };

    body.push(finalBody);
    if (flags.indexInc === 1) {
      flags.arrayCounter++;
    }
  }

  parseRegoblockForOtherwise(rule: Rule, body: RuleBody[]): void {
    if (rule.conditions.length == 0 && rule.isOtherwise) {
      body.push(structuredClone(CONST.ELSE_TEMPLATE));
    }
  }

  parseConditionAndAppendAST(params: ConditionParseParams): string {
    const { op, flags, leftOperand, rightOperand, body, idx, cond } = params;
    const REF_PATH_PATTERN = /^[a-zA-Z_]\w*(\.\w+)+$/;
    const OPERAND_INDEX = 1;
    const VALUE_INDEX = 2;
    if (!op) {
      return 'equal';
    }

    const opFunc = CONST.OPERATOR_FUNCTION_MAP[op] ?? 'equal';

    if (op === CONST.IN_TYPE) {
      const template = structuredClone(CONST.IN_ARRAY_TEMPLATE_2);

      template.value[OPERAND_INDEX].value = leftOperand;
      if (cond.functionArgs?.length) {
        (template.value as unknown[])[VALUE_INDEX] =
          this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.call([
            this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.refVar(
              this.parseRefString(rightOperand)
            ),
            ...cond.functionArgs.map((a: FunctionArg) =>
              this.helperFunctionsCreatePolicyService.generateBuiltInAST(a)
            ),
          ]);
      } else if (REF_PATH_PATTERN.test(rightOperand)) {
        (template.value as unknown[])[VALUE_INDEX] = {
          type: 'ref',
          value: this.parseRefString(rightOperand),
        };
      } else {
        template.value[VALUE_INDEX].value = rightOperand;
      }

      body.push({
        index: idx + flags.indexInc + flags.arrayCounter,
        terms: { symbols: [template] },
      });
    }
    return opFunc;
  }

  processIterOperands(expression: string): string {
    if (!expression) return expression;

    expression = expression.replaceAll(
      /\$iter_2D\(([^)]+)\)/g,
      (_, content) => {
        return `${content}[_][_]`;
      }
    );

    expression = expression.replaceAll(/\$iter\(([^)]+)\)/g, (_, content) => {
      return `${content}[_]`;
    });

    return expression;
  }

  isArray(str: string): boolean {
    if (typeof str !== 'string') return false;
    return str.startsWith('[');
  }

  OPER_FUNC_REF = (opFunc: string) => ({
    type: 'ref',
    value: [{ type: 'var', value: opFunc }],
  });

  parseRefString(expr: string): AstNode[] {
    const parts = expr.split('.');
    return parts.map((part, idx) => {
      if (idx === 0) {
        return this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.var(part);
      }
      return this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.string(
        part
      );
    });
  }

  setTemplateRefAndName(
    template: Record<string, unknown> | RuleHead,
    key: string
  ): void {
    template.ref = this.helperFunctionsCreatePolicyService.buildRefFromKey(key);

    if (!key.includes('.') && !key.includes('[')) {
      template.name = key;
    } else {
      delete template.name;
    }
  }

  getValueForStringType(v: string): object | null {
    if (v.toLowerCase() === 'true') {
      return this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.boolean(
        true
      );
    }
    if (v.toLowerCase() === 'false') {
      return this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.boolean(
        false
      );
    }

    if (!isNaN(Number(v)) && v !== '') {
      return this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.number(
        Number(v)
      );
    }

    if (/^".*"$/.test(v)) {
      return this.helperFunctionsCreatePolicyService.NODE_TEMPLATES.string(
        v.slice(1, -1)
      );
    }

    try {
      const parsed = JSON.parse(v);

      if (Array.isArray(parsed)) {
        return this.helperFunctionsCreatePolicyService.getValueForGlobalVarArray(
          {
            value: v,
            type: 'Array',
            key: '',
            default: false,
            isTypeDisabled: false,
          },
          this.dollarIndex
        );
      }

      if (typeof parsed === 'object' && parsed !== null) {
        return this.helperFunctionsCreatePolicyService.getValueForGlobalVarJSON(
          {
            value: v,
            type: 'JSON',
            key: '',
            default: false,
            isTypeDisabled: false,
          },
          this.dollarIndex
        );
      }
    } catch {
      this.alertService.warn(
        this.translateService.instant(
          'policyBuilder.validation.invalidJsonValue'
        )
      );
    }

    return null;
  }

  generateRego(): void {
    this.cancelForm();
    const ast: Record<string, object> = {};
    try {
      ast.ast = JSON.parse(this.generateAST());
    } catch {
      this.alertService.error(
        this.translateService.instant('policyBuilder.error.invalidAST')
      );
      return;
    }
    const data: string = JSON.stringify(ast);
    if (data.length > 0) {
      this.isLoading = true;
      const requestData = { ast: ast.ast };
      const observable = this.policyBuilderService.getRegoData(requestData);
      observable.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
        next: (regoCode: Blob | string | unknown) => {
          this.isLoading = false;
          if (regoCode instanceof Blob) {
            regoCode.text().then(t => this.processRegoResponse(t));
          } else {
            this.processRegoResponse(
              typeof regoCode === 'string' ? regoCode : String(regoCode)
            );
          }
        },
        error: error => {
          this.isLoading = false;
          if (!this.isBasicMode) {
            this.output = '';
          } else {
            if (error.status === 400) {
              this.output = this.translateService.instant(
                'policyBuilder.error.regoGenerationBadRequest'
              );
            } else if (error.status === 500) {
              this.output = this.translateService.instant(
                'policyBuilder.error.regoGenerationServerError'
              );
            } else {
              this.output = 'Error generating rego:\n' + error.message;
            }
          }
        },
      });
    } else {
      this.output = '';
      this.isFormVisible = false;
      this.policyBuilderService.checkIsSaveFormVisible(this.isFormVisible);
      setTimeout(() => {
        this.isShrunk = false;
      });
      if (this.isValidate) {
        this.validateRego();
      }
    }
  }

  validateRego(): void {
    this.schemaTreeVisible = true;
    if (this.isValidate) {
      this.toggleSchemaTreeFromEdit.emit(true);
      const regoText = this.output || '';
      const packageName =
        this.helperFunctionsCreatePolicyService.getRegoPackage(regoText);
      if (!packageName) {
        this.output = 'package ' + this.selectedRoot + '\n\n' + regoText;
        this.policyBuilderService.setRegoData(this.output);
      } else {
        if (this.isValidPackageName(regoText)) {
          this.isShrunk = true;
        }
        this.policyBuilderService.setRegoData(regoText);
      }
    } else {
      this.toggleSchemaTreeFromEdit.emit(false);
      this.policyBuilderService.regoData
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe(rego => {
          const cleaned =
            this.helperFunctionsCreatePolicyService.stripPackageLine(
              rego || ''
            );
          this.output = cleaned;
        });
    }
  }

  toggleRegoFullScreen(): void {
    this.isRegoFullScreen = this.fullscreenService.toggleElementFullScreen(
      this.isRegoFullScreen,
      {
        hideSelector: '.policy-create-container-section',
        expandSelector: '.regoDiv',
        resizerSelector: '.vertical-resizer',
      }
    );
  }

  private processRegoResponse(regoText: string): void {
    const cleaned =
      this.helperFunctionsCreatePolicyService.stripPackageLine(regoText);
    if (this.isBasicMode || this.isValidate) {
      this.output = regoText;
    } else {
      this.output = cleaned;
    }
    if (this.isValidate) {
      this.validateRego();
    }
  }

  toggleHelpMaximize(): void {
    this.isHelpMaximized = !this.isHelpMaximized;
  }

  closeRego(): void {
    if (this.isRegoFullScreen) this.toggleRegoFullScreen();
    this.isVisualMode = true;
    if (this.isBasicMode) {
      this.isShrunk = false;
    }
  }

  protected copyToClipboard(filePath: string): void {
    const formatted =
      encodeURIComponent(filePath) + '?ref=' + this.defaultBranch;
    navigator.clipboard
      .writeText(formatted)
      .then(() => {
        this.copiedFile.set(filePath);
        if (this.clipboardTimeoutId) {
          clearTimeout(this.clipboardTimeoutId);
        }
        this.clipboardTimeoutId = setTimeout(
          () => this.copiedFile.set(null),
          2000
        );
      })
      .catch(() => {
        this.alertService.error(
          this.translateService.instant(
            'policyBuilder.error.clipboardCopyFailed'
          )
        );
      });
  }
  private makeFileUrl(
    repoUrl: string | undefined,
    branchName: string | undefined,
    filePath: string
  ): string | undefined {
    if (!repoUrl || !branchName || !filePath) return undefined;
    try {
      const repoBase = repoUrl.split('/-/')[0];
      const encodedPath = filePath
        .split('/')
        .map(p => encodeURIComponent(p))
        .join('/');
      return `${repoBase}/-/blob/${encodeURIComponent(branchName)}/${encodedPath}`;
    } catch {
      return undefined;
    }
  }

  protected openTemplateFile(filePath: string): void {
    if (!filePath) return;
    this.policyBuilderService.getDefaultBranch$
      .pipe(take(1))
      .subscribe(defaultBranchName => {
        const branchName = defaultBranchName || this.defaultBranch || 'main';
        const mainRepoUrl = this.policyBuilderService.gitLabMainUrl();
        const mainFileUrl = this.makeFileUrl(mainRepoUrl, branchName, filePath);

        const urlToOpen = mainFileUrl || mainRepoUrl;
        if (urlToOpen) {
          window.open(urlToOpen, '_blank', 'noopener,noreferrer');
        }
      });
  }
  protected openMainBranch(event?: MouseEvent): void {
    if (event && event.button !== 0) {
      return;
    }

    if (event) {
      event.preventDefault();
    }
    let url = this.mainBranchFileUrl;
    if (!url && this.path) {
      const branchName = this.defaultBranch || 'main';
      const mainRepoUrl = this.policyBuilderService.gitLabMainUrl();
      url = this.makeFileUrl(mainRepoUrl, branchName, this.path) || mainRepoUrl;
    }

    if (!url) {
      url = this.policyBuilderService.gitLabMainUrl();
    }

    if (url) {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  }

  private mapToTemplateFolders(
    items: {
      name: string;
      path: string;
      items?: { name: string; path: string }[];
    }[]
  ): TemplateFolder[] {
    return items.map(item => ({
      name: item.name,
      path: item.path,
      files: item.items ?? [],
    }));
  }

  ngOnDestroy(): void {
    if (this.clipboardTimeoutId) {
      clearTimeout(this.clipboardTimeoutId);
    }
  }

  protected editorOptions = {
    lineNumbers: true,
    mode: 'go',
    lineWrapping: true,
    indentWithTabs: true,
    smartIndent: true,
    matchBrackets: true,
    autoCloseBrackets: true,
    readOnly: false,
    extraKeys: {
      Tab: (cm: { getInputField: () => HTMLInputElement }) =>
        cm.getInputField().blur(),
    },
  };

  protected updateReadOnly() {
    const readOnly = !this.edit() || this.isBasicMode || !this.isScriptEditable;
    this.editorOptions.readOnly = readOnly;
    const cm = this.codeEditor()?.codeMirror;
    if (cm) {
      cm.setOption('readOnly', readOnly);
    }
  }
}
