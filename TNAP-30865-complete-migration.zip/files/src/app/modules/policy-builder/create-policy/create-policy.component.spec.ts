/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ComponentFixture,
  TestBed,
  fakeAsync,
  tick,
} from '@angular/core/testing';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { of, BehaviorSubject } from 'rxjs';
import { NO_ERRORS_SCHEMA } from '@angular/core';

import { CreatePolicyComponent } from './create-policy.component';
import { PolicyBuilderService } from '../shared/policy-builder.service';
import { PolicyBuilderDataService } from '../shared/policy-builder-data.service';
import { RanPolicyService } from 'src/app/services/ran-policyservice/ran-policy.service';
import { ModalConfirmationService } from 'src/app/services/common-functionalities/modal-confirmation.service';
import { CodeEditorService } from 'src/app/services/common-functionalities/code-editor.service';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import {
  Rule,
  GlobalVar,
  TemplateFolder,
} from 'src/app/model/OpaBuilderPolicy.model';
import { RanTemplateService } from 'src/app/services/ran-templateservice/ran-template.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('CreatePolicyComponent', () => {
  let component: CreatePolicyComponent;
  let fixture: ComponentFixture<CreatePolicyComponent>;
  let editPolicyJsonSubject: BehaviorSubject<any>;
  let policyBuilderServiceSpy: jasmine.SpyObj<PolicyBuilderService>;
  let policyBuilderDataServiceSpy: jasmine.SpyObj<PolicyBuilderDataService>;
  let alertServiceSpy: jasmine.SpyObj<TnapAlertService>;
  let modalConfirmationServiceSpy: jasmine.SpyObj<ModalConfirmationService>;
  let ranTemplateServiceSpy: jasmine.SpyObj<RanTemplateService>;

  const mockPermissions = {
    ALLOW_RAN_TEMPLATE_POLICIES_EDIT: 'policies.edit',
  };

  const createMockRule = (name: string, options: Partial<Rule> = {}): Rule => ({
    name: { value: name },
    category: 'RULE_BLOCK',
    value: true,
    conditions: [],
    ...options,
  });

  const createMockGlobalVar = (
    key: string,
    value: string,
    options: Partial<GlobalVar> = {}
  ): GlobalVar => ({
    key,
    value,
    type: 'string',
    default: false,
    isTypeDisabled: false,
    ...options,
  });

  beforeEach(async () => {
    editPolicyJsonSubject = new BehaviorSubject<any>(null);

    policyBuilderServiceSpy = jasmine.createSpyObj(
      'PolicyBuilderService',
      [
        'setEditPolicyJson',
        'savePolicyDraft',
        'deployPolicy',
        'checkIsSaveFormVisible',
        'refreshDrafts',
        'getBranch',
        'savePolicy',
        'checkIsBasicMode',
        'getDraftBranchForPolicy',
        'getFreshDraftBranchForPolicy',
        'validateRegoData',
        'getRegoData',
        'setRegoData',
        'updateOutput',
        'updateLint',
        'setInput',
        'setData',
        'setJson',
        'lintCheckRegoData',
        'formatRegoData',
        'formatRegoCode',
        'regoCode$',
        'setErrorMsg',
        'setDecisionValue',
        'insertPath',
      ],
      {
        editPolicyJson$: editPolicyJsonSubject.asObservable(),
        getPolicyDrafts$: of({ items: [] }),
        regoData: of(''),
        previewPolicyJson$: of(null),
        insertPath$: of(null),
      }
    );
    policyBuilderServiceSpy.getDraftBranchForPolicy.and.returnValue(
      of({ name: 'draft-123', url: '/drafts/draft-123', isDefault: false })
    );
    policyBuilderServiceSpy.getFreshDraftBranchForPolicy.and.returnValue(
      of(undefined)
    );
    policyBuilderServiceSpy.lintCheckRegoData.and.returnValue(
      of({
        ignore_directives: [],
        violations: [],
        notices: [],
        summary: {} as any,
      })
    );
    policyBuilderServiceSpy.formatRegoCode.and.returnValue(of(true));
    policyBuilderServiceSpy.regoCode$.and.returnValue('formatted code');
    policyBuilderServiceSpy.savePolicy.and.returnValue(
      of({ name: 'test_policy' })
    );
    policyBuilderServiceSpy.validateRegoData.and.returnValue(
      of({ status: 'success', message: '' })
    );

    policyBuilderDataServiceSpy = jasmine.createSpyObj(
      'PolicyBuilderDataService',
      ['switchTab', 'setJustDeployed']
    );

    const ranPolicyServiceSpy = jasmine.createSpyObj('RanPolicyService', {
      getRanPolicyPageData: of({}),
      policyIsValid: true,
      updateDraftBranches: undefined,
    });

    alertServiceSpy = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
      'warn',
    ]);

    modalConfirmationServiceSpy = jasmine.createSpyObj(
      'ModalConfirmationService',
      ['confirm', 'openConfirmationModal']
    );
    modalConfirmationServiceSpy.openConfirmationModal.and.returnValue(of(true));

    const codeEditorServiceSpy = jasmine.createSpyObj('CodeEditorService', {
      getEditorTheme: 'vs-dark',
      getSupportedLanguages: ['javascript', 'typescript'],
    });

    ranTemplateServiceSpy = jasmine.createSpyObj(
      'RanTemplateService',
      ['refreshTemplates'],
      {
        getDefaultBranch$: of('main'),
        getTemplatesMainBranchStructure: of({
          loading: false,
          data: {
            items: [
              {
                name: 'Ericsson_2024_Q1',
                path: 'Ericsson_2024_Q1',
                items: [
                  {
                    name: 'BaseTemplate.jinja',
                    path: 'Ericsson_2024_Q1/activation/BaseTemplate.jinja',
                  },
                  {
                    name: 'node_config.jinja',
                    path: 'Ericsson_2024_Q1/activation/node_config.jinja',
                  },
                ],
              },
            ],
            totalCount: 1,
          },
        }),
      }
    );

    await TestBed.configureTestingModule({
      declarations: [CreatePolicyComponent],
      imports: [ReactiveFormsModule, TranslateModule.forRoot()],
      providers: [
        FormBuilder,
        { provide: PolicyBuilderService, useValue: policyBuilderServiceSpy },
        {
          provide: PolicyBuilderDataService,
          useValue: policyBuilderDataServiceSpy,
        },
        { provide: RanPolicyService, useValue: ranPolicyServiceSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
        {
          provide: ModalConfirmationService,
          useValue: modalConfirmationServiceSpy,
        },
        { provide: CodeEditorService, useValue: codeEditorServiceSpy },
        { provide: RanTemplateService, useValue: ranTemplateServiceSpy },
        { provide: PERMISSIONS_TOKEN, useValue: mockPermissions },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(CreatePolicyComponent);
    component = fixture.componentInstance;
  });

  afterEach(() => {
    editPolicyJsonSubject.complete();
  });

  describe('Component Creation', () => {
    it('should create the component', () => {
      expect(component).toBeTruthy();
    });

    it('should have correct default initial values', () => {
      expect((component as any).isBasicMode).toBeTrue();
      expect((component as any).isAdvanced).toBeFalse();
      expect((component as any).isEditMode).toBeFalse();
      expect((component as any).isFormVisible).toBeTrue();
    });
  });

  describe('Form Initialization', () => {
    beforeEach(() => {
      component.ngOnInit();
    });

    it('should initialize form with default values', () => {
      const form = (component as any).createPolicyForm;
      expect(form).toBeDefined();
      expect(form.get('name')?.value).toBe('');
      expect(form.get('description')?.value).toBe('');
      expect(form.get('mode')?.value).toBe('basic');
    });

    it('should mark name as required', () => {
      const nameControl = (component as any).createPolicyForm.get('name');
      expect(nameControl?.hasError('required')).toBeTrue();
    });

    it('should mark description as required', () => {
      const descControl = (component as any).createPolicyForm.get(
        'description'
      );
      expect(descControl?.hasError('required')).toBeTrue();
    });

    it('should validate form when all fields are filled correctly', () => {
      const form = (component as any).createPolicyForm;
      form.patchValue({
        name: 'valid_policy',
        description: 'Test description',
        mode: 'basic',
      });
      expect(form.valid).toBeTrue();
    });
  });

  describe('Policy Name Validation', () => {
    beforeEach(() => {
      component.ngOnInit();
    });

    it('should accept valid policy name starting with letter', () => {
      const validator = (component as any).policyNameValidator();
      expect(validator({ value: 'validName' })).toBeNull();
    });

    it('should accept valid policy name with dots and underscores', () => {
      const validator = (component as any).policyNameValidator();
      expect(validator({ value: 'valid_name.v1' })).toBeNull();
    });

    it('should accept valid policy name with hyphens', () => {
      const validator = (component as any).policyNameValidator();
      expect(validator({ value: 'valid-name-v1' })).toBeNull();
    });

    it('should reject policy name starting with number', () => {
      const validator = (component as any).policyNameValidator();
      expect(validator({ value: '1invalidName' })).toBeTruthy();
    });

    it('should reject policy name with spaces', () => {
      const validator = (component as any).policyNameValidator();
      expect(validator({ value: 'invalid name' })).toBeTruthy();
    });

    it('should reject policy name with special characters', () => {
      const validator = (component as any).policyNameValidator();
      expect(validator({ value: 'invalid@name!' })).toBeTruthy();
    });

    it('should reject policy name exceeding 50 characters', () => {
      const validator = (component as any).policyNameValidator();
      const longName = 'a'.repeat(51);
      expect(validator({ value: longName })).toBeTruthy();
    });

    it('should accept empty value (handled by required validator)', () => {
      const validator = (component as any).policyNameValidator();
      expect(validator({ value: '' })).toBeNull();
    });
  });

  describe('Edit Mode', () => {
    const mockAdvancedPolicy = {
      name: 'test_policy',
      mode: 'advanced',
      edit: true,
      metadata: {
        policyId: 'policy-123',
        'policy-description': 'Test policy description',
      },
      script: 'package test.policy\n\nallow = true',
      draftBranch: 'draft-123',
      path: '/policies/test',
    };

    const mockBasicPolicy = {
      name: 'basic_policy',
      mode: 'basic',
      edit: true,
      metadata: {
        policyId: 'policy-456',
        'policy-description': 'Basic policy',
      },
      script: '',
      ui_layout: {
        package: 'test.pkg',
        description: 'Basic description',
        globalVars: [],
        rules: [],
        name: 'basic_policy',
      },
    };

    it('should load policy in edit mode', fakeAsync(() => {
      component.ngOnInit();
      editPolicyJsonSubject.next(mockAdvancedPolicy);
      tick();

      expect((component as any).isEditMode).toBeTrue();
      expect((component as any).edit()).toBeTrue();
      expect((component as any).policyName).toBe('test_policy');
    }));

    it('should set advanced mode flags when loading advanced policy', fakeAsync(() => {
      component.ngOnInit();
      editPolicyJsonSubject.next(mockAdvancedPolicy);
      tick();

      expect((component as any).isAdvanced).toBeTrue();
      expect((component as any).isBasicMode).toBeFalse();
      expect((component as any).isShrunk).toBeTrue();
    }));

    it('should set basic mode flags when loading basic policy', fakeAsync(() => {
      component.ngOnInit();
      editPolicyJsonSubject.next(mockBasicPolicy);
      tick();

      expect((component as any).isBasicMode).toBeTrue();
      expect((component as any).isAdvanced).toBeFalse();
    }));

    it('should disable name field in edit mode', fakeAsync(() => {
      editPolicyJsonSubject.next(mockAdvancedPolicy);
      component.ngOnInit();
      tick();

      expect(
        (component as any).createPolicyForm.get('name')?.disabled
      ).toBeTrue();
    }));

    it('should load policy in view mode when edit is false', fakeAsync(() => {
      const viewPolicy = { ...mockAdvancedPolicy, edit: false };
      component.ngOnInit();
      editPolicyJsonSubject.next(viewPolicy);
      tick();

      expect((component as any).isEditMode).toBeTrue();
      expect((component as any).edit()).toBeFalse();
    }));

    it('should check for draft branch when editing', fakeAsync(() => {
      component.ngOnInit();
      editPolicyJsonSubject.next(mockAdvancedPolicy);
      tick();

      expect(
        policyBuilderServiceSpy.getDraftBranchForPolicy
      ).toHaveBeenCalledWith('test_policy');
    }));

    it('should set hasDraftBranch when draft exists', fakeAsync(() => {
      component.ngOnInit();
      editPolicyJsonSubject.next(mockAdvancedPolicy);
      tick();

      expect((component as any).hasDraftBranch).toBeTrue();
      expect((component as any).isDeployEnabled).toBeTrue();
    }));

    it('should clear data when receiving null policy', fakeAsync(() => {
      component.ngOnInit();
      editPolicyJsonSubject.next(mockAdvancedPolicy);
      tick();

      editPolicyJsonSubject.next(null);
      tick();

      expect((component as any).isEditMode).toBeFalse();
    }));

    it('should extract package name from script', fakeAsync(() => {
      component.ngOnInit();
      editPolicyJsonSubject.next(mockAdvancedPolicy);
      tick();

      expect((component as any).selectedRoot).toBe('test.policy');
    }));
  });

  describe('loadPolicy', () => {
    it('should map globalVars from ui_layout', () => {
      (component as any).loadPolicy({
        ui_layout: {
          package: 'test.pkg',
          globalVars: [createMockGlobalVar('k1', 'v1')],
          rules: [],
          name: 'my_policy',
        },
      });

      expect((component as any).selectedRoot).toBe('test.pkg');
      expect((component as any).globalVars.length).toBe(1);
      expect((component as any).globalVars[0].key).toBe('k1');
      expect((component as any).policyName).toBe('my_policy');
    });

    it('should handle empty ui_layout', () => {
      (component as any).loadPolicy({ ui_layout: {} });

      expect((component as any).selectedRoot).toBe('');
      expect((component as any).globalVars).toEqual([]);
      expect((component as any).rules).toEqual([]);
    });

    it('should handle string ui_layout', () => {
      (component as any).loadPolicy({
        ui_layout: JSON.stringify({
          package: 'test.pkg',
          globalVars: [],
          rules: [],
          name: 'string_policy',
        }),
      });

      expect((component as any).selectedRoot).toBe('test.pkg');
      expect((component as any).policyName).toBe('string_policy');
    });

    it('should map rules with conditions', () => {
      (component as any).loadPolicy({
        ui_layout: {
          package: 'pkg',
          globalVars: [],
          rules: [
            {
              ...createMockRule('r1'),
              conditions: [
                {
                  leftOperand: 'x',
                  operator: '==',
                  rightOperand: '1',
                },
              ],
            },
          ],
          name: 'p',
        },
      });

      expect((component as any).rules[0].conditions[0].functionArgs).toEqual(
        []
      );
      expect(
        (component as any).rules[0].conditions[0].leftFunctionArgs
      ).toEqual([]);
    });
  });

  describe('Rule Management', () => {
    describe('addNewRule', () => {
      beforeEach(() => {
        (component as any).rules = [];
      });

      it('should add a new rule', () => {
        (component as any).addNewRule('new_rule');

        expect((component as any).rules.length).toBe(1);
        expect((component as any).rules[0].name.value).toBe('new_rule');
        expect((component as any).rules[0].isOr).toBeFalse();
      });

      it('should generate unique name for duplicate rule', () => {
        (component as any).rules = [createMockRule('allow')];
        (component as any).addNewRule('allow');

        expect((component as any).rules.length).toBe(2);
        expect((component as any).rules[1].name.value).toBe('allow_1');
      });

      it('should increment suffix for multiple duplicates', () => {
        (component as any).rules = [
          createMockRule('allow'),
          createMockRule('allow_1'),
        ];
        (component as any).addNewRule('allow');

        expect((component as any).rules[2].name.value).toBe('allow_2');
      });

      it('should add OR rule for existing rule', () => {
        (component as any).rules = [createMockRule('allow')];
        (component as any).addNewRule('OR:allow');

        expect((component as any).rules.length).toBe(2);
        expect((component as any).rules[1].isOr).toBeTrue();
        expect((component as any).rules[1].name.value).toBe('allow');
      });

      it('should add Otherwise rule for existing rule', () => {
        (component as any).rules = [createMockRule('deny', { value: false })];
        (component as any).addNewRule('Otherwise:deny');

        expect((component as any).rules.length).toBe(2);
        expect((component as any).rules[1].isOtherwise).toBeTrue();
      });

      it('should skip OR:undefined rule', () => {
        (component as any).addNewRule('OR:undefined');
        expect((component as any).rules.length).toBe(0);
      });

      it('should skip Otherwise:undefined rule', () => {
        (component as any).addNewRule('Otherwise:undefined');
        expect((component as any).rules.length).toBe(0);
      });

      it('should insert rule at specific index with insertAfterIndex', () => {
        (component as any).rules = [
          createMockRule('first'),
          createMockRule('second'),
        ];
        (component as any).addNewRule('OR:first', 0);

        expect((component as any).rules[1].name.value).toBe('first');
        expect((component as any).rules[1].isOr).toBeTrue();
      });
    });

    describe('removeRule', () => {
      it('should remove rule at specified index', () => {
        (component as any).rules = [
          createMockRule('allow'),
          createMockRule('deny'),
        ];
        (component as any).removeRule(1);

        expect((component as any).rules.length).toBe(1);
        expect((component as any).rules[0].name.value).toBe('allow');
      });

      it('should remove all rules with same name when removing root rule', () => {
        (component as any).rules = [
          createMockRule('allow'),
          createMockRule('allow', { isOr: true }),
        ];
        (component as any).removeRule(0);

        expect((component as any).rules.length).toBe(0);
      });

      it('should not remove other rules when removing OR rule', () => {
        (component as any).rules = [
          createMockRule('allow'),
          createMockRule('allow', { isOr: true }),
        ];
        (component as any).removeRule(1);

        expect((component as any).rules.length).toBe(1);
        expect((component as any).rules[0].name.value).toBe('allow');
      });

      it('should set first remaining rule isOr to false when no base rule remains', () => {
        (component as any).rules = [
          createMockRule('allow', { isOr: true }),
          createMockRule('deny', { isOr: true }),
        ];
        (component as any).removeRule(0);

        expect((component as any).rules[0].isOr).toBeFalse();
      });
    });

    describe('addRule', () => {
      it('should insert rule with insertAfterIndex', () => {
        const existingRule = createMockRule('allow');
        (component as any).rules = [existingRule];

        (component as any).addRule({
          isOr: true,
          isOtherwise: false,
          exists: existingRule,
          insertAfterIndex: 0,
        });

        expect((component as any).rules.length).toBe(2);
        expect((component as any).rules[1].isOr).toBeTrue();
      });

      it('should push rule without insertAfterIndex', () => {
        const existingRule = createMockRule('allow');
        (component as any).rules = [existingRule];

        (component as any).addRule({
          isOr: false,
          isOtherwise: true,
          exists: existingRule,
        });

        expect((component as any).rules.length).toBe(2);
        expect((component as any).rules[1].isOtherwise).toBeTrue();
      });
    });

    describe('onRuleChange', () => {
      it('should update rule at specified index', () => {
        (component as any).rules = [createMockRule('allow')];
        (component as any).onRuleChange(
          createMockRule('allow', { value: false }),
          0
        );

        expect((component as any).rules[0].value).toBeFalse();
      });
    });

    describe('addNewFunctionBlock', () => {
      it('should add function block rule', () => {
        (component as any).rules = [];
        (component as any).addNewFunctionBlock({
          name: 'myFunc',
          args: ['x', 'y'],
          returnVar: 'result',
          returnType: 'string',
        });

        expect((component as any).rules.length).toBe(1);
        expect((component as any).rules[0].name.value).toBe('myFunc');
        expect((component as any).rules[0].isFunction).toBeTrue();
        expect((component as any).rules[0].args).toEqual(['x', 'y']);
        expect((component as any).rules[0].returnVar).toBe('result');
      });
    });
  });

  describe('Global Variables Management', () => {
    describe('onGlobalVarsChange', () => {
      it('should add new global vars', () => {
        (component as any).globalVars = [];
        (component as any).onGlobalVarsChange([
          createMockGlobalVar('k1', 'v1'),
        ]);

        expect((component as any).globalVars.length).toBe(1);
        expect((component as any).globalVars[0].key).toBe('k1');
      });

      it('should update existing global var', () => {
        (component as any).globalVars = [createMockGlobalVar('k1', 'v1')];
        (component as any).onGlobalVarsChange([
          createMockGlobalVar('k1', 'v2', { default: true }),
        ]);

        expect((component as any).globalVars[0].value).toBe('v2');
        expect((component as any).globalVars[0].default).toBeTrue();
      });

      it('should truncate globalVars when update array is shorter', () => {
        (component as any).globalVars = [
          createMockGlobalVar('k1', 'v1'),
          createMockGlobalVar('k2', 'v2'),
        ];
        (component as any).onGlobalVarsChange([
          createMockGlobalVar('k1', 'v1'),
        ]);

        expect((component as any).globalVars.length).toBe(1);
      });

      it('should set default to false when not provided', () => {
        (component as any).globalVars = [];
        (component as any).onGlobalVarsChange([
          { key: 'k1', value: 'v1', type: 'string', isTypeDisabled: false },
        ]);

        expect((component as any).globalVars[0].default).toBeFalse();
      });
    });
  });

  describe('Code Change Tracking', () => {
    it('should detect no changes when output matches original', () => {
      (component as any).originalCode = 'original code';
      (component as any).output = 'original code';
      (component as any).onCodeChange();

      expect((component as any).codeChanged).toBeFalse();
    });

    it('should detect changes when output differs from original', () => {
      (component as any).originalCode = 'original code';
      (component as any).output = 'modified code';
      (component as any).onCodeChange();

      expect((component as any).codeChanged).toBeTrue();
    });

    it('should set isShrunk to true on code change', () => {
      (component as any).isShrunk = false;
      (component as any).output = 'code';
      (component as any).onCodeChange();

      expect((component as any).isShrunk).toBeTrue();
    });
  });

  describe('Form Actions', () => {
    beforeEach(() => {
      component.ngOnInit();
    });

    describe('showForm', () => {
      it('should show form in advanced mode', () => {
        (component as any).isBasicMode = false;
        (component as any).output = 'test';
        (component as any).isFormVisible = false;

        (component as any).showForm();

        expect((component as any).isFormVisible).toBeTrue();
      });

      it('should clear saveRegoResponse when showing form', () => {
        (component as any).saveRegoResponse = 'previous response';
        (component as any).isBasicMode = false;

        (component as any).showForm();

        expect((component as any).saveRegoResponse).toBe('');
      });
    });

    describe('cancelForm', () => {
      it('should hide form', () => {
        (component as any).isFormVisible = false;
        (component as any).cancelForm();

        expect((component as any).isFormVisible).toBeFalse();
      });

      it('should clear saveRegoResponse', () => {
        (component as any).saveRegoResponse = 'response';
        (component as any).cancelForm();

        expect((component as any).saveRegoResponse).toBe('');
      });

      it('should reset isSuccess', () => {
        (component as any).isSuccess = true;
        (component as any).cancelForm();

        expect((component as any).isSuccess).toBeFalse();
      });
    });

    describe('hideForm', () => {
      it('should set isFormVisible to false', () => {
        (component as any).isFormVisible = false;
        (component as any).hideForm();

        expect((component as any).isFormVisible).toBeFalse();
      });

      it('should reset submitted flag', () => {
        (component as any).submitted = true;
        (component as any).hideForm();

        expect((component as any).submitted).toBeFalse();
      });
    });

    describe('clearAll', () => {
      it('should clear output', () => {
        (component as any).output = 'some code';
        (component as any).clearAll();

        expect((component as any).output).toBe('');
      });

      it('should reset isShrunk to false', () => {
        (component as any).isShrunk = true;
        (component as any).clearAll();

        expect((component as any).isShrunk).toBeFalse();
      });
    });
  });

  describe('Mode Toggle', () => {
    beforeEach(() => {
      component.ngOnInit();
    });

    it('should initialize in basic mode by default', () => {
      expect((component as any).isBasicMode).toBeTrue();
      expect((component as any).isAdvanced).toBeFalse();
    });

    describe('toggleMode', () => {
      it('should return early when scrollToFirstError finds an error', () => {
        spyOn(component as any, 'scrollToFirstError').and.returnValue(true);
        spyOn(component as any, 'validatePolicy');

        (component as any).toggleMode();

        expect((component as any).validatePolicy).not.toHaveBeenCalled();
      });

      it('should return early when validatePolicy fails', () => {
        spyOn(component as any, 'scrollToFirstError').and.returnValue(false);
        spyOn(component as any, 'validatePolicy').and.returnValue(false);
        spyOn(component as any, 'switchToBasicMode');

        (component as any).isBasicMode = false;
        (component as any).toggleMode();

        expect((component as any).switchToBasicMode).not.toHaveBeenCalled();
      });

      it('should open confirmation modal when in basic mode', () => {
        spyOn(component as any, 'scrollToFirstError').and.returnValue(false);
        spyOn(component as any, 'validatePolicy').and.returnValue(true);
        (component as any).isBasicMode = true;

        (component as any).toggleMode();

        expect(
          modalConfirmationServiceSpy.openConfirmationModal
        ).toHaveBeenCalled();
      });

      it('should switch to advanced mode when confirmed', () => {
        spyOn(component as any, 'scrollToFirstError').and.returnValue(false);
        spyOn(component as any, 'validatePolicy').and.returnValue(true);
        spyOn(component as any, 'generateRego');
        modalConfirmationServiceSpy.openConfirmationModal.and.returnValue(
          of(true)
        );
        (component as any).isBasicMode = true;

        (component as any).toggleMode();

        expect((component as any).isBasicMode).toBeFalse();
        expect((component as any).isAdvanced).toBeTrue();
      });

      it('should not switch when confirmation is declined', () => {
        spyOn(component as any, 'scrollToFirstError').and.returnValue(false);
        spyOn(component as any, 'validatePolicy').and.returnValue(true);
        modalConfirmationServiceSpy.openConfirmationModal.and.returnValue(
          of(false)
        );
        (component as any).isBasicMode = true;

        (component as any).toggleMode();

        expect((component as any).isBasicMode).toBeTrue();
      });

      it('should switch to basic mode when in advanced mode', () => {
        spyOn(component as any, 'scrollToFirstError').and.returnValue(false);
        spyOn(component as any, 'validatePolicy').and.returnValue(true);
        (component as any).isBasicMode = false;
        (component as any).isAdvanced = true;

        (component as any).toggleMode();

        expect((component as any).isBasicMode).toBeTrue();
        expect((component as any).isAdvanced).toBeFalse();
      });
    });

    describe('toggleViewMode', () => {
      it('should toggle isShrunk', () => {
        spyOn(component as any, 'generateAST').and.returnValue('[{}]');
        spyOn(component as any, 'generateRego');
        (component as any).isVisualMode = true;
        const initialIsShrunk = (component as any).isShrunk;

        (component as any).toggleViewMode();

        expect((component as any).isShrunk).toBe(!initialIsShrunk);
      });

      it('should revert when AST generation fails', () => {
        spyOn(component as any, 'generateAST').and.returnValue('');
        (component as any).isVisualMode = true;
        (component as any).isShrunk = false;

        (component as any).toggleViewMode();

        expect((component as any).isVisualMode).toBeTrue();
        expect((component as any).isShrunk).toBeFalse();
      });
    });
  });

  describe('Toggle Functions', () => {
    describe('toggleRegoFullScreen', () => {
      it('should toggle isRegoFullScreen', () => {
        const initialValue = (component as any).isRegoFullScreen;
        (component as any).toggleRegoFullScreen();

        expect((component as any).isRegoFullScreen).toBe(!initialValue);
      });
    });

    describe('closeRego', () => {
      it('should set isVisualMode to true', () => {
        (component as any).isVisualMode = false;
        (component as any).closeRego();

        expect((component as any).isVisualMode).toBeTrue();
      });
    });

    describe('closeNotificationDiv', () => {
      it('should clear saveRegoResponse', () => {
        (component as any).saveRegoResponse = 'Some response';
        (component as any).closeNotificationDiv();

        expect((component as any).saveRegoResponse).toBe('');
      });

      it('should set isSuccess to false', () => {
        (component as any).isSuccess = true;
        (component as any).closeNotificationDiv();

        expect((component as any).isSuccess).toBeFalse();
      });
    });

    describe('toggleHelpMaximize', () => {
      it('should toggle isHelpMaximized', () => {
        (component as any).isHelpMaximized = false;
        (component as any).toggleHelpMaximize();
        expect((component as any).isHelpMaximized).toBeTrue();

        (component as any).toggleHelpMaximize();
        expect((component as any).isHelpMaximized).toBeFalse();
      });
    });
  });

  describe('Validation Functions', () => {
    beforeEach(() => {
      component.ngOnInit();
    });

    describe('validateRuleNames', () => {
      it('should return true when no duplicate rule names', () => {
        (component as any).rules = [
          createMockRule('allow'),
          createMockRule('deny'),
        ];

        expect((component as any).validateRuleNames()).toBeTrue();
      });

      it('should detect duplicate rule names', () => {
        (component as any).rules = [
          createMockRule('allow'),
          createMockRule('allow'),
        ];

        expect((component as any).validateRuleNames()).toBeFalse();
        expect((component as any).ruleNameErrors[1]).toBe('*duplicate');
      });

      it('should skip OR rules when checking for duplicates', () => {
        (component as any).rules = [
          createMockRule('allow', { isOr: false }),
          createMockRule('allow', { isOr: true }),
        ];

        expect((component as any).validateRuleNames()).toBeTrue();
      });

      it('should skip Otherwise rules when checking for duplicates', () => {
        (component as any).rules = [
          createMockRule('allow'),
          createMockRule('allow', { isOtherwise: true }),
        ];

        expect((component as any).validateRuleNames()).toBeTrue();
      });

      it('should skip contains rules when checking for duplicates', () => {
        (component as any).rules = [
          createMockRule('items'),
          createMockRule('items', { isContains: true } as any),
        ];

        expect((component as any).validateRuleNames()).toBeTrue();
      });
    });

    describe('validatePolicy', () => {
      it('should return true when all validations pass', () => {
        spyOn(component as any, 'validateRuleNames').and.returnValue(true);

        expect((component as any).validatePolicy()).toBeTrue();
      });

      it('should return false when validateRuleNames fails', () => {
        spyOn(component as any, 'validateRuleNames').and.returnValue(false);

        expect((component as any).validatePolicy()).toBeFalse();
      });

      it('should check globalVars validation', () => {
        spyOn(component as any, 'validateRuleNames').and.returnValue(true);
        const mockGlobalVars = {
          validateAllGlobalVars: jasmine.createSpy().and.returnValue(false),
          validateAllArguments: jasmine.createSpy().and.returnValue(true),
        };
        spyOn(component as any, 'globalVarsComponent').and.returnValue(
          mockGlobalVars
        );

        expect((component as any).validatePolicy()).toBeFalse();
      });

      it('should check ruleBlock validation', () => {
        spyOn(component as any, 'validateRuleNames').and.returnValue(true);
        const mockRuleBlock = {
          validateRuleBlock: jasmine.createSpy().and.returnValue(false),
          rule: () => createMockRule('test'),
        };
        spyOn(component as any, 'ruleBlockComponents').and.returnValue([
          mockRuleBlock,
        ]);

        expect((component as any).validatePolicy()).toBeFalse();
      });
    });

    describe('isValidPackageName', () => {
      it('should return true and prepend package when no package in rego', () => {
        (component as any).selectedRoot = 'test.pkg';

        expect(
          (component as any).isValidPackageName('allow = true')
        ).toBeTrue();
        expect((component as any).output).toContain('package test.pkg');
      });

      it('should return false for wrong package name', () => {
        (component as any).selectedRoot = 'test.pkg';

        expect(
          (component as any).isValidPackageName('package wrong.pkg\nallow=true')
        ).toBeFalse();
      });

      it('should return true for matching package name', () => {
        (component as any).selectedRoot = 'test.pkg';

        expect(
          (component as any).isValidPackageName('package test.pkg\nallow=true')
        ).toBeTrue();
      });
    });
  });

  describe('Utility Methods', () => {
    describe('getRegoPackage', () => {
      it('should extract package name from rego code', () => {
        expect(
          (component as any).getRegoPackage('package test.policy\nallow = true')
        ).toBe('test.policy');
      });

      it('should return null when no package in rego code', () => {
        expect((component as any).getRegoPackage('allow = true')).toBeNull();
      });
    });

    describe('isArray', () => {
      it('should return true for array string', () => {
        expect((component as any).isArray('[1,2,3]')).toBeTrue();
      });

      it('should return false for non-array string', () => {
        expect((component as any).isArray('not_array')).toBeFalse();
      });

      it('should return false for null', () => {
        expect((component as any).isArray(null as any)).toBeFalse();
      });

      it('should return false for undefined', () => {
        expect((component as any).isArray(undefined as any)).toBeFalse();
      });
    });

    describe('processIterOperands', () => {
      it('should process $iter operand', () => {
        expect((component as any).processIterOperands('$iter(arr)')).toBe(
          'arr[_]'
        );
      });

      it('should process $iter_2D operand', () => {
        expect((component as any).processIterOperands('$iter_2D(arr)')).toBe(
          'arr[_][_]'
        );
      });

      it('should return empty string for empty input', () => {
        expect((component as any).processIterOperands('')).toBe('');
      });

      it('should return unchanged string with no iter tokens', () => {
        expect((component as any).processIterOperands('simple.value')).toBe(
          'simple.value'
        );
      });

      it('should process multiple iter tokens', () => {
        expect(
          (component as any).processIterOperands('$iter(a) && $iter(b)')
        ).toBe('a[_] && b[_]');
      });
    });

    describe('OPER_FUNC_REF', () => {
      it('should return ref object for operator function', () => {
        const result = (component as any).OPER_FUNC_REF('equal');

        expect(result.type).toBe('ref');
        expect(result.value[0].value).toBe('equal');
      });
    });

    describe('customPackageTemplate', () => {
      it('should return package template with selectedRoot', () => {
        (component as any).selectedRoot = 'my.package';
        const result = (component as any).customPackageTemplate();

        expect(result.path[0].type).toBe('var');
        expect(result.path[0].value).toBe('data');
        expect(result.path[1].value).toBe('my.package');
      });
    });

    describe('parseRefString', () => {
      it('should parse ref string into AST nodes', () => {
        const result = (component as any).parseRefString('input.user.name');

        expect(result.length).toBe(3);
        expect(result[0].type).toBe('var');
        expect(result[0].value).toBe('input');
        expect(result[1].type).toBe('string');
        expect(result[1].value).toBe('user');
      });
    });

    describe('setTemplateRefAndName', () => {
      it('should set name for simple key', () => {
        const template: Record<string, unknown> = {};
        (component as any).setTemplateRefAndName(template, 'allow');

        expect(template.name).toBe('allow');
        expect(template.ref).toBeDefined();
      });

      it('should not set name for dotted key', () => {
        const template: Record<string, unknown> = { name: 'old' };
        (component as any).setTemplateRefAndName(template, 'input.user');

        expect(template.name).toBeUndefined();
      });
    });

    describe('onClearParentRuleNameErrors', () => {
      it('should clear ruleNameErrors', () => {
        (component as any).ruleNameErrors = { 0: 'error', 1: 'another error' };
        (component as any).onClearParentRuleNameErrors();

        expect(Object.keys((component as any).ruleNameErrors).length).toBe(0);
      });
    });

    describe('makeFileUrl', () => {
      it('should return undefined when repoUrl is undefined', () => {
        const result = (component as any).makeFileUrl(
          undefined,
          'main',
          'path/to/file.rego'
        );
        expect(result).toBeUndefined();
      });

      it('should return undefined when branchName is undefined', () => {
        const result = (component as any).makeFileUrl(
          'https://gitlab.example.com/group/project',
          undefined,
          'path/to/file.rego'
        );
        expect(result).toBeUndefined();
      });

      it('should return undefined when filePath is empty', () => {
        const result = (component as any).makeFileUrl(
          'https://gitlab.example.com/group/project',
          'main',
          ''
        );
        expect(result).toBeUndefined();
      });

      it('should build correct URL when repoUrl contains /-/ segment', () => {
        const repoUrl = 'https://gitlab.example.com/group/project/-/tree/main';
        const branch = 'feature/my-branch';
        const filePath = 'folder/sub folder/file name.rego';

        const result = (component as any).makeFileUrl(
          repoUrl,
          branch,
          filePath
        );

        expect(result).toBe(
          'https://gitlab.example.com/group/project/-/blob/feature%2Fmy-branch/folder/sub%20folder/file%20name.rego'
        );
      });

      it('should build correct URL when repoUrl does not contain /-/', () => {
        const repoUrl = 'https://gitlab.example.com/group/project';
        const branch = 'main';
        const filePath = 'policies/allow.rego';

        const result = (component as any).makeFileUrl(
          repoUrl,
          branch,
          filePath
        );

        expect(result).toBe(
          'https://gitlab.example.com/group/project/-/blob/main/policies/allow.rego'
        );
      });

      it('should encode special characters in branch name', () => {
        const result = (component as any).makeFileUrl(
          'https://gitlab.example.com/group/project',
          'feature/special branch',
          'file.rego'
        );

        expect(result).toBe(
          'https://gitlab.example.com/group/project/-/blob/feature%2Fspecial%20branch/file.rego'
        );
      });

      it('should encode special characters in file path segments', () => {
        const result = (component as any).makeFileUrl(
          'https://gitlab.example.com/group/project',
          'main',
          'path/file with spaces.rego'
        );

        expect(result).toBe(
          'https://gitlab.example.com/group/project/-/blob/main/path/file%20with%20spaces.rego'
        );
      });
    });
  });

  describe('Value Parsing Methods', () => {
    describe('getValueForStringType', () => {
      it('should return boolean node for "true"', () => {
        const result = (component as any).getValueForStringType('true');
        expect(result).not.toBeNull();
      });

      it('should return boolean node for "false"', () => {
        const result = (component as any).getValueForStringType('false');
        expect(result).not.toBeNull();
      });

      it('should return number node for numeric string', () => {
        const result = (component as any).getValueForStringType('42');
        expect(result).not.toBeNull();
      });

      it('should return string node for quoted string', () => {
        const result = (component as any).getValueForStringType('"hello"');
        expect(result).not.toBeNull();
      });
    });

    describe('getValueForUnknownInput', () => {
      it('should return null for null input', () => {
        expect((component as any).getValueForUnknownInput(null)).toBeNull();
      });

      it('should return boolean node for boolean input', () => {
        expect((component as any).getValueForUnknownInput(true)).not.toBeNull();
        expect(
          (component as any).getValueForUnknownInput(false)
        ).not.toBeNull();
      });

      it('should return number node for number input', () => {
        expect((component as any).getValueForUnknownInput(42)).not.toBeNull();
      });
    });
  });

  describe('AST Generation', () => {
    beforeEach(() => {
      component.ngOnInit();
    });

    describe('generateAST', () => {
      it('should return string result', () => {
        const result = (component as any).generateAST();
        expect(typeof result).toBe('string');
      });
    });

    describe('parseRegoblockForOtherwise', () => {
      it('should push to body for otherwise rule with no conditions', () => {
        const body: unknown[] = [];
        (component as any).parseRegoblockForOtherwise(
          createMockRule('allow', { isOtherwise: true }),
          body
        );

        expect(body.length).toBe(1);
      });

      it('should not push to body when conditions exist', () => {
        const body: unknown[] = [];
        (component as any).parseRegoblockForOtherwise(
          createMockRule('allow', {
            isOtherwise: true,
            conditions: [{ leftOperand: 'x' }] as any,
          }),
          body
        );

        expect(body.length).toBe(0);
      });
    });
  });

  describe('Save and Error Handling', () => {
    beforeEach(() => {
      component.ngOnInit();
    });

    describe('onSubmit', () => {
      it('should set submitted to true', () => {
        (component as any).onSubmit();
        expect((component as any).submitted).toBeTrue();
      });

      it('should return early when form is invalid', () => {
        (component as any).onSubmit();
        expect(policyBuilderServiceSpy.savePolicy).not.toHaveBeenCalled();
      });

      it('should call save for valid form', () => {
        (component as any).createPolicyForm.patchValue({
          name: 'test_policy',
          description: 'Test description',
          mode: 'basic',
        });
        (component as any).isBasicMode = true;
        (component as any).output = 'package test\nallow = true';

        (component as any).onSubmit();

        expect(policyBuilderServiceSpy.formatRegoCode).toHaveBeenCalled();
      });
    });

    describe('proceedWithSave', () => {
      const mockFormData = {
        name: 'test_policy',
        description: 'Test description',
        mode: 'basic',
      };

      it('should call savePolicy directly in basic mode', done => {
        (component as any).isBasicMode = true;
        (component as any).output = 'package test\nallow = true';

        (component as any)['proceedWithSave'](mockFormData).subscribe({
          next: () => {
            expect(policyBuilderServiceSpy.savePolicy).toHaveBeenCalled();
            expect(
              policyBuilderServiceSpy.validateRegoData
            ).not.toHaveBeenCalled();
            done();
          },
          error: done.fail,
        });
      });

      it('should call validateRegoData first in advanced mode', done => {
        (component as any).isBasicMode = false;
        (component as any).output = 'package test\nallow = true';
        policyBuilderServiceSpy.validateRegoData.and.returnValue(
          of({ status: 'success', message: '' })
        );

        (component as any)['proceedWithSave'](mockFormData).subscribe({
          next: () => {
            expect(policyBuilderServiceSpy.validateRegoData).toHaveBeenCalled();
            expect(policyBuilderServiceSpy.savePolicy).toHaveBeenCalled();
            done();
          },
          error: done.fail,
        });
      });

      it('should call savePolicy even when lint validation fails in advanced mode', done => {
        (component as any).isBasicMode = false;
        (component as any).output = 'package test\nallow = true';
        policyBuilderServiceSpy.validateRegoData.and.returnValue(
          of({
            status: 'failure',
            message: 'Validation failed',
            errorType: 'lint',
            errorDetails: { violations: [], notices: [] },
          } as any)
        );
        policyBuilderServiceSpy.savePolicy.calls.reset();

        (component as any)['proceedWithSave'](mockFormData).subscribe({
          complete: () => {
            expect(policyBuilderServiceSpy.validateRegoData).toHaveBeenCalled();
            expect(policyBuilderServiceSpy.savePolicy).toHaveBeenCalled();
            done();
          },
          error: done.fail,
        });
      });

      it('should populate ui_layout in basic mode', done => {
        (component as any).isBasicMode = true;
        (component as any).output = 'package test\nallow = true';
        (component as any).selectedRoot = 'test_package';
        (component as any).globalVars = [];
        (component as any).rules = [];

        (component as any)['proceedWithSave'](mockFormData).subscribe({
          next: () => {
            expect((component as any).ui_layout.name).toBe('test_policy');
            expect((component as any).ui_layout.description).toBe(
              'Test description'
            );
            expect((component as any).ui_layout.package).toBe('test_package');
            done();
          },
          error: done.fail,
        });
      });
    });

    describe('callSaveApi', () => {
      it('should return observable from policyBuilderService.savePolicy', done => {
        const mockApiRequest = {
          name: 'test_policy',
          path: '',
          script: {},
          mode: 'basic' as const,
          policy_description: 'Test',
        };

        (component as any)['callSaveApi'](mockApiRequest).subscribe({
          next: result => {
            expect(policyBuilderServiceSpy.savePolicy).toHaveBeenCalled();
            expect(result).toEqual({ name: 'test_policy' });
            done();
          },
          error: done.fail,
        });
      });
    });

    describe('handleSaveError', () => {
      it('should parse JSON error message', () => {
        (component as any)['handleSaveError']({
          error: '{"message":"json error msg"}',
        });

        expect((component as any).saveRegoResponse).toBe('json error msg');
        expect((component as any).isSuccess).toBeFalse();
      });

      it('should handle non-JSON error', () => {
        (component as any)['handleSaveError']({ error: 'not-json' });

        expect((component as any).isSuccess).toBeFalse();
      });
    });

    describe('handleSaveSuccess', () => {
      it('should update state on successful save', () => {
        (component as any)['handleSaveSuccess'](
          { name: 'test_policy', description: 'desc', mode: 'basic' },
          { name: 'test_policy' }
        );

        expect((component as any).codeChanged).toBeFalse();
        expect((component as any).policyName).toBe('test_policy');
        expect((component as any).hasDraftBranch).toBeTrue();
        expect((component as any).justSaved).toBeTrue();
      });

      it('should still call cancelForm with null response', () => {
        (component as any).isFormVisible = false;
        (component as any)['handleSaveSuccess'](
          { name: 'test_policy', description: 'desc', mode: 'basic' },
          null
        );

        expect((component as any).isFormVisible).toBeFalse();
      });
    });

    describe('validateSaveResponse', () => {
      it('should show error alert for null response', () => {
        (component as any)['validateSaveResponse'](null);

        expect(alertServiceSpy.error).toHaveBeenCalled();
      });

      it('should show success alert for valid response with name', () => {
        (component as any)['validateSaveResponse']({ name: 'test_policy' });

        expect(alertServiceSpy.success).toHaveBeenCalled();
      });

      it('should not call warn or success for response without name property', () => {
        (component as any)['validateSaveResponse']({});

        expect(alertServiceSpy.warn).not.toHaveBeenCalled();
        expect(alertServiceSpy.success).not.toHaveBeenCalled();
        expect(alertServiceSpy.error).not.toHaveBeenCalled();
      });
    });
  });

  describe('Lifecycle Hooks', () => {
    describe('ngAfterViewInit', () => {
      it('should not throw when previewOnly is false', () => {
        fixture.componentRef.setInput('previewOnly', false);
        expect(() => component.ngAfterViewInit()).not.toThrow();
      });

      it('should not throw when previewOnly is true', () => {
        fixture.componentRef.setInput('previewOnly', true);
        expect(() => component.ngAfterViewInit()).not.toThrow();
      });
    });
  });

  describe('Computed Properties', () => {
    it('should return rule names array', () => {
      (component as any).rules = [
        createMockRule('allow'),
        createMockRule('deny'),
        createMockRule(''),
      ];

      const names = (component as any).ruleNames;

      expect(names).toContain('allow');
      expect(names).toContain('deny');
      expect(names).not.toContain('');
    });

    it('should return custom functions', () => {
      (component as any).rules = [
        createMockRule('allow'),
        {
          ...createMockRule('myFunc'),
          isFunction: true,
          args: ['x'],
          returnVar: 'result',
          returnType: 'string',
        },
      ];

      const funcs = (component as any).customFunctions;

      expect(funcs.length).toBe(1);
      expect(funcs[0].name).toBe('myFunc');
      expect(funcs[0].args).toEqual(['x']);
    });
  });

  describe('OPA Data Functionality', () => {
    beforeEach(() => {
      component.ngOnInit();
    });

    it('should parse and set input when policy contains input field', fakeAsync(() => {
      const policyBuilderSpy = TestBed.inject(PolicyBuilderService) as any;
      const testInput = { region: 'eu', enabled: true };

      const policyWithInput = {
        name: 'test_policy',
        mode: 'advanced',
        edit: true,
        metadata: {
          policyId: 'policy-123',
          'policy-description': 'Test policy',
        },
        script: 'package test',
        input: JSON.stringify(testInput),
      };

      editPolicyJsonSubject.next(policyWithInput);
      tick();

      expect(policyBuilderSpy.setInput).toHaveBeenCalledWith(testInput);
    }));

    it('should set empty input when policy input field is empty', fakeAsync(() => {
      const policyBuilderSpy = TestBed.inject(PolicyBuilderService) as any;

      const policyWithoutInput = {
        name: 'test_policy',
        mode: 'advanced',
        edit: true,
        metadata: {
          policyId: 'policy-123',
          'policy-description': 'Test policy',
        },
        script: 'package test',
      };

      editPolicyJsonSubject.next(policyWithoutInput);
      tick();

      expect(policyBuilderSpy.setInput).toHaveBeenCalledWith({});
    }));

    it('should handle invalid JSON in input field gracefully', fakeAsync(() => {
      const policyBuilderSpy = TestBed.inject(PolicyBuilderService) as any;

      const policyWithInvalidInput = {
        name: 'test_policy',
        mode: 'advanced',
        edit: true,
        metadata: {
          policyId: 'policy-123',
          'policy-description': 'Test policy',
        },
        script: 'package test',
        input: '{invalid json}',
      };

      editPolicyJsonSubject.next(policyWithInvalidInput);
      tick();

      expect(policyBuilderSpy.setInput).toHaveBeenCalledWith({});
    }));

    it('should set isValidate to true when loading policy with data', fakeAsync(() => {
      const policyWithData = {
        name: 'test_policy',
        mode: 'advanced',
        edit: true,
        metadata: {
          policyId: 'policy-123',
          'policy-description': 'Test policy',
        },
        script: 'package test\n\nallow = true',
        draftBranch: 'draft-123',
        data: '{"key": "value"}',
      };

      editPolicyJsonSubject.next(policyWithData);
      tick();

      expect((component as any).isValidate).toBe(true);
    }));

    it('should parse and set data when policy contains data field', fakeAsync(() => {
      const policyBuilderSpy = TestBed.inject(PolicyBuilderService) as any;
      const testData = { test: 'data', nested: { value: 123 } };

      const policyWithData = {
        name: 'test_policy',
        mode: 'advanced',
        edit: true,
        metadata: {
          policyId: 'policy-123',
          'policy-description': 'Test policy',
        },
        script: 'package test',
        data: JSON.stringify(testData),
      };

      editPolicyJsonSubject.next(policyWithData);
      tick();

      expect(policyBuilderSpy.setData).toHaveBeenCalledWith(testData);
    }));

    it('should set empty data when policy data field is empty', fakeAsync(() => {
      const policyBuilderSpy = TestBed.inject(PolicyBuilderService) as any;

      const policyWithoutData = {
        name: 'test_policy',
        mode: 'advanced',
        edit: true,
        metadata: {
          policyId: 'policy-123',
          'policy-description': 'Test policy',
        },
        script: 'package test',
      };

      editPolicyJsonSubject.next(policyWithoutData);
      tick();

      expect(policyBuilderSpy.setData).toHaveBeenCalledWith({});
    }));

    it('should handle invalid JSON in data field gracefully', fakeAsync(() => {
      const policyBuilderSpy = TestBed.inject(PolicyBuilderService) as any;

      const policyWithInvalidData = {
        name: 'test_policy',
        mode: 'advanced',
        edit: true,
        metadata: {
          policyId: 'policy-123',
          'policy-description': 'Test policy',
        },
        script: 'package test',
        data: '{invalid json}',
      };

      editPolicyJsonSubject.next(policyWithInvalidData);
      tick();

      expect(policyBuilderSpy.setData).toHaveBeenCalledWith({});
    }));

    it('should clear data when clearing policy', () => {
      const policyBuilderSpy = TestBed.inject(PolicyBuilderService) as any;

      component.clearAll();

      expect(policyBuilderSpy.setData).toHaveBeenCalledWith({});
    });

    it('should clear input when clearing policy', () => {
      const policyBuilderSpy = TestBed.inject(PolicyBuilderService) as any;

      component.clearAll();

      expect(policyBuilderSpy.setInput).toHaveBeenCalledWith({});
    });
  });

  describe('Metadata Flags', () => {
    it('should default all metadata flags to true', () => {
      expect((component as any).isScriptEditable).toBe(true);
      expect((component as any).isScriptVisible).toBe(true);
      expect((component as any).isDataEditable).toBe(true);
      expect((component as any).isDataVisible).toBe(true);
    });

    it('should set isScriptEditable to false when metadata has script-editable false', () => {
      component.ngOnInit();
      editPolicyJsonSubject.next({
        name: 'test',
        mode: 'advanced',
        edit: false,
        metadata: {
          policyId: 'test.policy',
          'policy-description': 'test desc',
          'script-editable': false,
        },
        script: 'package test',
      });
      expect((component as any).isScriptEditable).toBe(false);
    });

    it('should set isScriptVisible to false when metadata has script-visible false', () => {
      component.ngOnInit();
      editPolicyJsonSubject.next({
        name: 'test',
        mode: 'advanced',
        edit: false,
        metadata: {
          policyId: 'test.policy',
          'policy-description': 'test desc',
          'script-visible': false,
        },
        script: 'package test',
      });
      expect((component as any).isScriptVisible).toBe(false);
    });

    it('should set isDataEditable to false when metadata has data-editable false', () => {
      component.ngOnInit();
      editPolicyJsonSubject.next({
        name: 'test',
        mode: 'advanced',
        edit: false,
        metadata: {
          policyId: 'test.policy',
          'policy-description': 'test desc',
          'data-editable': false,
        },
        script: 'package test',
      });
      expect((component as any).isDataEditable).toBe(false);
    });

    it('should set isDataVisible to false when metadata has data-visible false', () => {
      component.ngOnInit();
      editPolicyJsonSubject.next({
        name: 'test',
        mode: 'advanced',
        edit: false,
        metadata: {
          policyId: 'test.policy',
          'policy-description': 'test desc',
          'data-visible': false,
        },
        script: 'package test',
      });
      expect((component as any).isDataVisible).toBe(false);
    });

    it('should keep flags true when metadata does not specify them', () => {
      component.ngOnInit();
      editPolicyJsonSubject.next({
        name: 'test',
        mode: 'advanced',
        edit: false,
        metadata: {
          policyId: 'test.policy',
          'policy-description': 'test desc',
        },
        script: 'package test',
      });
      expect((component as any).isScriptEditable).toBe(true);
      expect((component as any).isScriptVisible).toBe(true);
      expect((component as any).isDataEditable).toBe(true);
      expect((component as any).isDataVisible).toBe(true);
    });

    it('should hide script section when script-visible is false', () => {
      component.ngOnInit();
      editPolicyJsonSubject.next({
        name: 'test',
        mode: 'advanced',
        edit: true,
        metadata: {
          policyId: 'test.policy',
          'policy-description': 'test desc',
          'script-visible': false,
        },
        script: 'package test',
      });

      expect((component as any).isScriptVisible).toBe(false);
      // Template uses @if (isScriptVisible && ...) to conditionally render script section
    });

    it('should show script section when script-visible is true', () => {
      component.ngOnInit();
      (component as any).isBasicMode = false;
      (component as any).isShrunk = true;
      editPolicyJsonSubject.next({
        name: 'test',
        mode: 'advanced',
        edit: true,
        metadata: {
          policyId: 'test.policy',
          'policy-description': 'test desc',
          'script-visible': true,
        },
        script: 'package test',
      });

      expect((component as any).isScriptVisible).toBe(true);
    });

    it('should make rego editor readOnly when script-editable is false and edit is true', () => {
      component.ngOnInit();
      (component as any).isBasicMode = false;
      (component as any).isShrunk = true;
      (component as any).isValidate = false;
      editPolicyJsonSubject.next({
        name: 'test',
        mode: 'advanced',
        edit: true,
        metadata: {
          policyId: 'test.policy',
          'policy-description': 'test desc',
          'script-editable': false,
        },
        script: 'package test',
      });

      expect((component as any).isScriptEditable).toBe(false);
      expect((component as any).edit()).toBe(true);
    });

    it('should pass isDataEditable false to validate-output when data-editable is false', () => {
      component.ngOnInit();
      (component as any).isBasicMode = false;
      (component as any).isShrunk = true;
      editPolicyJsonSubject.next({
        name: 'test',
        mode: 'advanced',
        edit: true,
        metadata: {
          policyId: 'test.policy',
          'policy-description': 'test desc',
          'data-editable': false,
        },
        script: 'package test',
        data: '{"key": "value"}',
      });

      expect((component as any).isDataEditable).toBe(false);
      expect((component as any).isValidate).toBe(true);
    });

    it('should pass isDataEditable true to validate-output when data-editable is not false', () => {
      component.ngOnInit();
      (component as any).isBasicMode = false;
      (component as any).isShrunk = true;
      editPolicyJsonSubject.next({
        name: 'test',
        mode: 'advanced',
        edit: true,
        metadata: {
          policyId: 'test.policy',
          'policy-description': 'test desc',
        },
        script: 'package test',
        data: '{"key": "value"}',
      });

      expect((component as any).isDataEditable).toBe(true);
      expect((component as any).isValidate).toBe(true);
    });
  });

  describe('RAN Template Dropdown', () => {
    it('should initialize templateFolders as empty array', () => {
      expect((component as any).templateFolders()).toEqual([]);
    });

    it('should initialize defaultBranch as main', () => {
      expect((component as any).defaultBranch).toBe('main');
    });

    it('should initialize copiedFile as null', () => {
      expect((component as any).copiedFile()).toBeNull();
    });

    it('should load template folders when policyId is tnap.slice_ran_template', fakeAsync(() => {
      component.ngOnInit();

      const policyJson = {
        name: 'test_policy',
        mode: 'basic',
        edit: true,
        metadata: {
          policyId: 'tnap.slice_ran_template',
          'policy-description': 'Test',
          'script-editable': true,
        },
        script: 'package test',
        ui_layout: JSON.stringify({
          description: 'Test',
          name: 'test_policy',
          package: 'test',
          globalVars: [],
          rules: [
            {
              name: { value: 'allow' },
              category: 'DEFAULT',
              value: true,
              conditions: [],
            },
          ],
        }),
        path: '/test',
      };

      editPolicyJsonSubject.next(policyJson);
      tick();

      expect((component as any).templateFolders().length).toBe(1);
      expect((component as any).templateFolders()[0].name).toBe(
        'Ericsson_2024_Q1'
      );
      expect((component as any).templateFolders()[0].files.length).toBe(2);
      expect((component as any).defaultBranch).toBe('main');
    }));

    it('should NOT load template folders when policyId is different', fakeAsync(() => {
      const policyJson = {
        name: 'test_policy',
        mode: 'basic',
        edit: true,
        metadata: {
          policyId: 'some.other_policy',
          'policy-description': 'Test',
          'script-editable': true,
        },
        script: 'package test',
        ui_layout: JSON.stringify({
          description: 'Test',
          name: 'test_policy',
          package: 'test',
          globalVars: [],
          rules: [
            {
              name: { value: 'allow' },
              category: 'DEFAULT',
              value: true,
              conditions: [],
            },
          ],
        }),
        path: '/test',
      };

      editPolicyJsonSubject.next(policyJson);
      tick();

      expect((component as any).templateFolders()).toEqual([]);
    }));

    it('should map items correctly via mapToTemplateFolders', () => {
      const mockItems = [
        {
          name: 'FolderA',
          path: 'FolderA',
          items: [
            { name: 'file1.jinja', path: 'FolderA/file1.jinja' },
            { name: 'file2.jinja', path: 'FolderA/file2.jinja' },
          ],
        },
        {
          name: 'FolderB',
          path: 'FolderB',
          items: [],
        },
      ];

      const result: TemplateFolder[] = (component as any).mapToTemplateFolders(
        mockItems
      );

      expect(result.length).toBe(2);
      expect(result[0].name).toBe('FolderA');
      expect(result[0].files.length).toBe(2);
      expect(result[0].files[0]).toEqual({
        name: 'file1.jinja',
        path: 'FolderA/file1.jinja',
      });
      expect(result[1].name).toBe('FolderB');
      expect(result[1].files.length).toBe(0);
    });

    it('should handle items with no sub-items in mapToTemplateFolders', () => {
      const mockItems = [{ name: 'EmptyFolder', path: 'EmptyFolder' }];

      const result: TemplateFolder[] = (component as any).mapToTemplateFolders(
        mockItems
      );

      expect(result.length).toBe(1);
      expect(result[0].files).toEqual([]);
    });

    it('should copy file path to clipboard with encoded format', fakeAsync(() => {
      spyOn(navigator.clipboard, 'writeText').and.returnValue(
        Promise.resolve()
      );
      (component as any).defaultBranch = 'main';

      (component as any).copyToClipboard(
        'Ericsson_2024_Q1/activation/BaseTemplate.jinja'
      );
      tick();

      expect(navigator.clipboard.writeText).toHaveBeenCalledWith(
        'Ericsson_2024_Q1%2Factivation%2FBaseTemplate.jinja?ref=main'
      );
      expect((component as any).copiedFile()).toBe(
        'Ericsson_2024_Q1/activation/BaseTemplate.jinja'
      );
    }));

    it('should reset copiedFile after 2 seconds', fakeAsync(() => {
      spyOn(navigator.clipboard, 'writeText').and.returnValue(
        Promise.resolve()
      );

      (component as any).copyToClipboard('test/file.jinja');
      tick();

      expect((component as any).copiedFile()).toBe('test/file.jinja');

      tick(2000);

      expect((component as any).copiedFile()).toBeNull();
    }));

    it('should use custom defaultBranch in clipboard format', fakeAsync(() => {
      spyOn(navigator.clipboard, 'writeText').and.returnValue(
        Promise.resolve()
      );
      (component as any).defaultBranch = 'develop';

      (component as any).copyToClipboard('folder/file.jinja');
      tick();

      expect(navigator.clipboard.writeText).toHaveBeenCalledWith(
        'folder%2Ffile.jinja?ref=develop'
      );
    }));

    it('should handle clipboard write failure', fakeAsync(() => {
      spyOn(navigator.clipboard, 'writeText').and.returnValue(
        Promise.reject(new Error('Clipboard denied'))
      );

      (component as any).copyToClipboard('folder/file.jinja');
      tick();

      expect(alertServiceSpy.error).toHaveBeenCalledWith(
        'policyBuilder.error.clipboardCopyFailed'
      );
    }));

    it('should clear existing timeout when copying again', fakeAsync(() => {
      spyOn(navigator.clipboard, 'writeText').and.returnValue(
        Promise.resolve()
      );

      (component as any).copyToClipboard('file1.jinja');
      tick();
      expect((component as any).copiedFile()).toBe('file1.jinja');

      (component as any).copyToClipboard('file2.jinja');
      tick();
      expect((component as any).copiedFile()).toBe('file2.jinja');

      tick(2000);
      expect((component as any).copiedFile()).toBeNull();
    }));

    it('should clear clipboard timeout on destroy', fakeAsync(() => {
      spyOn(navigator.clipboard, 'writeText').and.returnValue(
        Promise.resolve()
      );

      (component as any).copyToClipboard('file.jinja');
      tick();

      component.ngOnDestroy();

      tick(2000);
      expect((component as any).copiedFile()).toBe('file.jinja');
    }));
  });

  describe('parseApiPayloadToObject', () => {
    describe('Null and Undefined Handling', () => {
      it('should return empty object for null payload', () => {
        const result = (component as any).parseApiPayloadToObject(null);
        expect(result).toEqual({});
      });

      it('should return empty object for undefined payload', () => {
        const result = (component as any).parseApiPayloadToObject(undefined);
        expect(result).toEqual({});
      });
    });

    describe('Object Input', () => {
      it('should return object as-is when input is already an object', () => {
        const testObj = { name: 'test', value: 123 };
        const result = (component as any).parseApiPayloadToObject(testObj);
        expect(result).toEqual(testObj);
        expect(result).toBe(testObj);
      });

      it('should return empty object when input is an array', () => {
        const result = (component as any).parseApiPayloadToObject([1, 2, 3]);
        expect(result).toEqual({});
      });

      it('should handle nested objects', () => {
        const testObj = {
          user: { name: 'John', age: 30 },
          settings: { theme: 'dark' },
        };
        const result = (component as any).parseApiPayloadToObject(testObj);
        expect(result).toEqual(testObj);
        expect(result.user.name).toBe('John');
      });
    });

    describe('String Input (Valid JSON)', () => {
      it('should parse valid JSON string to object', () => {
        const jsonString = JSON.stringify({ name: 'test', value: 123 });
        const result = (component as any).parseApiPayloadToObject(jsonString);
        expect(result).toEqual({ name: 'test', value: 123 });
      });

      it('should parse JSON string with nested objects', () => {
        const jsonString = JSON.stringify({
          user: { name: 'John', roles: ['admin', 'user'] },
        });
        const result = (component as any).parseApiPayloadToObject(jsonString);
        expect(result.user.name).toBe('John');
        expect(result.user.roles).toEqual(['admin', 'user']);
      });

      it('should handle JSON string with extra whitespace', () => {
        const jsonString = '  { "key": "value" }  ';
        const result = (component as any).parseApiPayloadToObject(jsonString);
        expect(result).toEqual({ key: 'value' });
      });

      it('should handle double-encoded JSON strings (recursive parsing)', () => {
        const innerObj = { data: 'nested' };
        const middleStr = JSON.stringify(innerObj);
        const outerStr = JSON.stringify(middleStr);
        const result = (component as any).parseApiPayloadToObject(outerStr);
        expect(result).toEqual(innerObj);
      });

      it('should handle multiple levels of JSON encoding', () => {
        const level0 = { value: 'data' };
        const level1 = JSON.stringify(level0);
        const level2 = JSON.stringify(level1);
        const level3 = JSON.stringify(level2);

        const result = (component as any).parseApiPayloadToObject(level3);
        expect(result).toEqual(level0);
      });
    });

    describe('String Input (Empty/Whitespace)', () => {
      it('should return empty object for empty string', () => {
        const result = (component as any).parseApiPayloadToObject('');
        expect(result).toEqual({});
      });

      it('should return empty object for string with only spaces', () => {
        const result = (component as any).parseApiPayloadToObject('   ');
        expect(result).toEqual({});
      });

      it('should return empty object for string with only tabs and newlines', () => {
        const result = (component as any).parseApiPayloadToObject('\n\t  \n');
        expect(result).toEqual({});
      });
    });

    describe('String Input (Invalid JSON)', () => {
      it('should return empty object for malformed JSON string', () => {
        const result = (component as any).parseApiPayloadToObject(
          '{invalid json}'
        );
        expect(result).toEqual({});
      });

      it('should return empty object for incomplete JSON string', () => {
        const result = (component as any).parseApiPayloadToObject(
          '{"name": "test"'
        );
        expect(result).toEqual({});
      });

      it('should return empty object when JSON parses to non-object value', () => {
        const result1 = (component as any).parseApiPayloadToObject(
          '"just a string"'
        );
        expect(result1).toEqual({});

        const result2 = (component as any).parseApiPayloadToObject('123');
        expect(result2).toEqual({});

        const result3 = (component as any).parseApiPayloadToObject('true');
        expect(result3).toEqual({});

        const result4 = (component as any).parseApiPayloadToObject('null');
        expect(result4).toEqual({});
      });

      it('should return empty object when JSON parses to array', () => {
        const result = (component as any).parseApiPayloadToObject('[1, 2, 3]');
        expect(result).toEqual({});
      });
    });

    describe('String Input (Nested JSON Strings)', () => {
      it('should recursively parse string value that contains JSON', () => {
        const innerObj = { nested: true };
        const outerStr = JSON.stringify(JSON.stringify(innerObj));
        const result = (component as any).parseApiPayloadToObject(outerStr);
        expect(result).toEqual(innerObj);
      });

      it('should stop recursion when parsed value is not a string', () => {
        const obj = { value: 123 };
        const str = JSON.stringify(obj);
        const result = (component as any).parseApiPayloadToObject(str);
        expect(result).toEqual(obj);
        expect(result.value).toBe(123);
      });
    });

    describe('Non-String, Non-Object Input', () => {
      it('should return empty object for number input', () => {
        const result = (component as any).parseApiPayloadToObject(123);
        expect(result).toEqual({});
      });

      it('should return empty object for boolean input', () => {
        const result1 = (component as any).parseApiPayloadToObject(true);
        expect(result1).toEqual({});

        const result2 = (component as any).parseApiPayloadToObject(false);
        expect(result2).toEqual({});
      });

      it('should return empty object for array input', () => {
        const result = (component as any).parseApiPayloadToObject([1, 2, 3]);
        expect(result).toEqual({});
      });
    });

    describe('parseApiPayload', () => {
      it('should return object as-is', () => {
        const obj = { name: 'test' };

        expect((component as any).parseApiPayload(obj)).toEqual(obj);
      });

      it('should return array as-is', () => {
        const arr = [1, 2, 3];

        expect((component as any).parseApiPayload(arr)).toEqual(arr);
      });

      it('should parse JSON object string', () => {
        expect(
          (component as any).parseApiPayload('{"status":"OK","errors":[]}')
        ).toEqual({
          status: 'OK',
          errors: [],
        });
      });

      it('should parse JSON array string', () => {
        expect((component as any).parseApiPayload('[{"name":"test"}]')).toEqual(
          [{ name: 'test' }]
        );
      });

      it('should parse double encoded JSON', () => {
        const payload = '"{\\"status\\":\\"OK\\",\\"errors\\":[]}"';

        expect((component as any).parseApiPayload(payload)).toEqual({
          status: 'OK',
          errors: [],
        });
      });

      it('should return empty object for invalid JSON', () => {
        expect((component as any).parseApiPayload('{invalid json}')).toEqual(
          {}
        );
      });

      it('should return empty object for empty string', () => {
        expect((component as any).parseApiPayload('')).toEqual({});
      });

      it('should return empty object for primitive JSON values', () => {
        expect((component as any).parseApiPayload('"test"')).toEqual({});

        expect((component as any).parseApiPayload('123')).toEqual({});

        expect((component as any).parseApiPayload('true')).toEqual({});
      });
    });

    describe('Edge Cases', () => {
      it('should handle JSON with special characters', () => {
        const obj = { message: 'Hello "World"' };
        const jsonStr = JSON.stringify(obj);
        const result = (component as any).parseApiPayloadToObject(jsonStr);
        expect(result.message).toBe('Hello "World"');
      });

      it('should handle JSON with unicode characters', () => {
        const obj = { greeting: '你好世界' };
        const jsonStr = JSON.stringify(obj);
        const result = (component as any).parseApiPayloadToObject(jsonStr);
        expect(result.greeting).toBe('你好世界');
      });

      it('should handle JSON with escaped characters', () => {
        const obj = { text: 'Line 1\nLine 2\tTabbed' };
        const jsonStr = JSON.stringify(obj);
        const result = (component as any).parseApiPayloadToObject(jsonStr);
        expect(result.text).toContain('Line 1');
        expect(result.text).toContain('Line 2');
      });

      it('should preserve numeric precision from JSON', () => {
        const obj = { decimal: 3.14159, integer: 42 };
        const jsonStr = JSON.stringify(obj);
        const result = (component as any).parseApiPayloadToObject(jsonStr);
        expect(result.decimal).toBe(3.14159);
        expect(result.integer).toBe(42);
      });

      it('should preserve boolean values in nested structures', () => {
        const obj = { flags: { enabled: true, disabled: false } };
        const jsonStr = JSON.stringify(obj);
        const result = (component as any).parseApiPayloadToObject(jsonStr);
        expect(result.flags.enabled).toBe(true);
        expect(result.flags.disabled).toBe(false);
      });

      it('should handle empty object in JSON', () => {
        const result = (component as any).parseApiPayloadToObject('{}');
        expect(result).toEqual({});
      });

      it('should handle large objects', () => {
        const largeObj: Record<string, unknown> = {};
        for (let i = 0; i < 1000; i++) {
          largeObj[`key_${i}`] = `value_${i}`;
        }
        const jsonStr = JSON.stringify(largeObj);
        const result = (component as any).parseApiPayloadToObject(jsonStr);
        expect(Object.keys(result).length).toBe(1000);
        expect(result['key_999']).toBe('value_999');
      });
    });

    describe('Integration with usePolicyJson', () => {
      it('should correctly parse input field when loading policy', () => {
        const policy = {
          name: 'test',
          mode: 'advanced' as const,
          edit: true,
          metadata: {
            policyId: 'test',
            'policy-description': 'test',
          },
          script: 'package test',
          input: JSON.stringify({ region: 'eu', enabled: true }),
        };
        component.ngOnInit();
        (component as any).usePolicyJson(policy);

        expect((component as any).regoInputSchema).toBeNull();
        expect(policyBuilderServiceSpy.setInput).toHaveBeenCalledWith({
          region: 'eu',
          enabled: true,
        });
      });

      it('should correctly parse data field when loading policy', () => {
        const policy = {
          name: 'test',
          mode: 'advanced' as const,
          edit: true,
          metadata: {
            policyId: 'test',
            'policy-description': 'test',
          },
          script: 'package test',
          data: JSON.stringify({ resources: ['res1', 'res2'] }),
        };
        component.ngOnInit();
        (component as any).usePolicyJson(policy);

        expect(policyBuilderServiceSpy.setData).toHaveBeenCalledWith({
          resources: ['res1', 'res2'],
        });
      });

      it('should correctly parse schema field when loading policy', () => {
        const schema = {
          type: 'object',
          properties: { name: { type: 'string' } },
        };
        const policy = {
          name: 'test',
          mode: 'advanced' as const,
          edit: true,
          metadata: {
            policyId: 'test',
            'policy-description': 'test',
          },
          script: 'package test',
          schema: JSON.stringify(schema),
        };
        component.ngOnInit();
        (component as any).usePolicyJson(policy);

        expect((component as any).regoInputSchema).toEqual(schema);
        expect(policyBuilderServiceSpy.setJson).toHaveBeenCalledWith(schema);
      });

      it('should set regoInputSchema to null when schema is empty', () => {
        const policy = {
          name: 'test',
          mode: 'advanced' as const,
          edit: true,
          metadata: {
            policyId: 'test',
            'policy-description': 'test',
          },
          script: 'package test',
          schema: '{}',
        };
        component.ngOnInit();
        (component as any).usePolicyJson(policy);

        expect((component as any).regoInputSchema).toBeNull();
        expect(policyBuilderServiceSpy.setJson).toHaveBeenCalledWith(null);
      });

      it('should handle malformed JSON in schema gracefully', () => {
        const policy = {
          name: 'test',
          mode: 'advanced' as const,
          edit: true,
          metadata: {
            policyId: 'test',
            'policy-description': 'test',
          },
          script: 'package test',
          schema: 'not valid json',
        };
        component.ngOnInit();
        (component as any).usePolicyJson(policy);

        expect((component as any).regoInputSchema).toBeNull();
        expect(policyBuilderServiceSpy.setJson).toHaveBeenCalledWith(null);
      });
    });

    describe('Performance and Safety', () => {
      it('should not throw error on very long string input', () => {
        const longString = 'a'.repeat(100000);
        expect(() => {
          (component as any).parseApiPayloadToObject(longString);
        }).not.toThrow();
      });

      it('should not mutate input object', () => {
        const original = { name: 'test', nested: { value: 123 } };
        const input = { ...original };
        (component as any).parseApiPayloadToObject(input);
        expect(input).toEqual(original);
      });
    });
  });

  describe('Dynamic Schema Integration', () => {
    beforeEach(() => {
      component.ngOnInit();
    });

    it('should flow schema from API payload through policyBuilderService', fakeAsync(() => {
      const schemaPayload = {
        type: 'object',
        properties: {
          userId: { type: 'string' },
          permissions: { type: 'array' },
        },
      };

      const policy = {
        name: 'test_policy',
        mode: 'basic' as const,
        edit: true,
        metadata: {
          policyId: 'test',
          'policy-description': 'test',
        },
        script: 'package test',
        schema: JSON.stringify(schemaPayload),
        ui_layout: { description: 'test description' },
      };

      editPolicyJsonSubject.next(policy);
      tick();

      expect(policyBuilderServiceSpy.setJson).toHaveBeenCalledWith(
        schemaPayload
      );
      expect((component as any).regoInputSchema).toEqual(schemaPayload);
    }));

    it('should update validate-output component with parsed schema', fakeAsync(() => {
      const schema = { type: 'object', title: 'Test Schema' };
      const policy = {
        name: 'test',
        mode: 'advanced' as const,
        edit: true,
        metadata: {
          policyId: 'test',
          'policy-description': 'test',
        },
        script: 'package test',
        schema: JSON.stringify(schema),
      };

      editPolicyJsonSubject.next(policy);
      tick();

      expect((component as any).regoInputSchema).toEqual(schema);
      expect(policyBuilderServiceSpy.setJson).toHaveBeenCalledWith(schema);
    }));

    it('should handle policy updates with different schemas', fakeAsync(() => {
      const schema1 = { type: 'object', properties: { a: { type: 'string' } } };
      const schema2 = { type: 'object', properties: { b: { type: 'number' } } };

      const policy1 = {
        name: 'test1',
        mode: 'advanced' as const,
        edit: true,
        metadata: {
          policyId: 'test1',
          'policy-description': 'test1',
        },
        script: 'package test',
        schema: JSON.stringify(schema1),
      };

      editPolicyJsonSubject.next(policy1);
      tick();
      expect(policyBuilderServiceSpy.setJson).toHaveBeenCalledWith(schema1);

      const policy2 = {
        name: 'test2',
        mode: 'advanced' as const,
        edit: true,
        metadata: {
          policyId: 'test2',
          'policy-description': 'test2',
        },
        script: 'package test',
        schema: JSON.stringify(schema2),
      };

      editPolicyJsonSubject.next(policy2);
      tick();
      expect(policyBuilderServiceSpy.setJson).toHaveBeenCalledWith(schema2);
    }));
  });

  describe('updateReadOnly', () => {
    let setOptionSpy: jasmine.Spy;

    beforeEach(() => {
      setOptionSpy = jasmine.createSpy('setOption');

      (component as any).editorOptions = { readOnly: false };

      (component as any).codeEditor = () => ({
        codeMirror: {
          setOption: setOptionSpy,
        },
      });
    });

    it('should set readOnly = true when edit() returns false', () => {
      spyOn(component as any, 'edit').and.returnValue(false);
      (component as any).isBasicMode = false;
      (component as any).isScriptEditable = true;

      (component as any).updateReadOnly();

      expect((component as any).editorOptions.readOnly).toBeTrue();
      expect(setOptionSpy).toHaveBeenCalledWith('readOnly', true);
    });

    it('should set readOnly = false when all conditions allow editing', () => {
      spyOn(component as any, 'edit').and.returnValue(true);
      (component as any).isBasicMode = false;
      (component as any).isScriptEditable = true;

      (component as any).updateReadOnly();

      expect((component as any).editorOptions.readOnly).toBeFalse();
      expect(setOptionSpy).toHaveBeenCalledWith('readOnly', false);
    });
  });

  describe('onPathSelected', () => {
    beforeEach(() => {
      spyOn(component as any, 'edit');
    });

    it('should call insertPath when edit() returns true', () => {
      (component as any).edit.and.returnValue(true);

      (component as any).onPathSelected('test/path');

      expect(policyBuilderServiceSpy.insertPath).toHaveBeenCalledWith(
        'test/path'
      );
    });

    it('should NOT call insertPath when edit() returns false', () => {
      (component as any).edit.and.returnValue(false);

      (component as any).onPathSelected('test/path');

      expect(policyBuilderServiceSpy.insertPath).not.toHaveBeenCalled();
    });
  });
});
