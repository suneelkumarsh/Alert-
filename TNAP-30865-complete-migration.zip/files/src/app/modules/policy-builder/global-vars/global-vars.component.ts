﻿/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Component,
  DestroyRef,
  ElementRef,
  OnInit,
  effect,
  inject,
  input,
  model,
  output,
  viewChild,
  viewChildren,
} from '@angular/core';
import { NgModel } from '@angular/forms';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as CONST from 'src/app/model/OpaBuilderPolicy.model';
import { TranslateService } from '@ngx-translate/core';
import { PolicyBuilderService } from '../shared/policy-builder.service';
import {
  BuiltinFunctionDef,
  AttrData,
  GlobalVar,
  RawFunctionInput,
  SchemaNode,
  createDefaultGlobalVar,
} from 'src/app/model/OpaBuilderPolicy.model';
import { HelperFunctionsConditionRowService } from '../shared/helper-functions-condition-row.service';
import { CommonService } from '../shared/common.service';
import { LoadSchemaDataService } from '../shared/load-schema-data.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-global-vars',
  standalone: false,
  templateUrl: './global-vars.component.html',
  styleUrl: './global-vars.component.css',
})
export class GlobalVarsComponent implements OnInit {
  readonly globalVars = model<GlobalVar[]>([]);
  readonly previewOnly = input(false);
  readonly isRightPanelVisible = input(false);
  readonly ruleNames = input<string[]>([]);
  readonly customFunctions = input<
    { name: string; args: string[]; returnVar: string; returnType: string }[]
  >([]);
  readonly rightOperands = input<string[]>([]);

  readonly newRuleRequested = output<string>();
  readonly rightPanelToggled = output<void>();
  readonly newFunctionRequested = output<{
    name: string;
    args: string[];
    returnVar: string;
    returnType: string;
  }>();

  protected isCollapsed = false;
  protected showCollapse = true;
  protected showFunctionModal = false;
  protected readonly options = CONST.TYPE_OPTIONS;

  protected leftOperandOptions: AttrData[] = [];
  protected rightOperandOptions: AttrData[] = [];
  protected filteredLeftOperands: AttrData[] = [];
  protected filteredRightOperands: AttrData[] = [];
  protected builtinAttrs: AttrData[] = [];
  private json: SchemaNode | null = null;
  private builtinFunctions: (BuiltinFunctionDef & { type?: string })[] = [];
  leftOperandWidth = 170;
  rightOperandWidth = 170;
  readonly leftOperandMeasure = viewChild<ElementRef>('leftOperandMeasure');
  readonly rightOperandMeasure = viewChild<ElementRef>('rightOperandMeasure');
  readonly jsonTextareas =
    viewChildren<ElementRef<HTMLTextAreaElement>>('jsonTextarea');

  private readonly literals = ['true', 'false'];
  readonly allowedRoots = ['input', 'data'];

  private readonly isBooleanLiteral = (token: string): boolean =>
    this.literals.includes(token.toLowerCase());

  private readonly getVarType = (token: string): string | null => {
    const root = token.split('.')[0];
    return this.allowedRoots.includes(root)
      ? 'boolean'
      : (this.gv.find(v => v.key === root)?.type ?? null);
  };

  private readonly reservedKeywords = new Set([
    'as',
    'contains',
    'data',
    'default',
    'else',
    'every',
    'function',
    'if',
    'import',
    'in',
    'is',
    'not',
    'null',
    'package',
    'return',
    'some',
    'true',
    'false',
    'with',
  ]);

  private readonly alertService = inject(TnapAlertService);
  private readonly commonService = inject(CommonService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly helperFunctionsConditionRowService = inject(
    HelperFunctionsConditionRowService
  );
  private readonly loadSchemaDataService = inject(LoadSchemaDataService);
  private readonly policyBuilderService = inject(PolicyBuilderService);
  private readonly translateService = inject(TranslateService);

  private get gv(): GlobalVar[] {
    return this.globalVars();
  }
  private get cf() {
    return this.customFunctions();
  }
  private get rn(): string[] {
    return this.ruleNames();
  }

  constructor() {
    effect(() => {
      const textareas = this.jsonTextareas();
      textareas.forEach(ta => {
        const el = ta.nativeElement;
        el.style.resize = 'both';
        el.style.overflow = 'auto';
        el.style.minHeight = '60px';
        el.style.minWidth = '120px';
      });
    });

    effect(() => {
      this.showCollapse = this.gv.length === 0;
    });
  }

  ngOnInit(): void {
    this.getBuiltInFunctions();
    this.policyBuilderService.json$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: jsonData => {
          this.json = jsonData;
          [this.leftOperandOptions, this.rightOperandOptions] =
            this.loadSchemaDataService.loadOperandOptions(
              this.json,
              this.leftOperandOptions,
              this.rightOperandOptions,
              false
            );
        },
        error: (err: Error) => this.alertService.error(err.message),
      });

    this.updateLeftOperandWidth();
  }

  getBuiltInFunctions() {
    this.policyBuilderService
      .loadBuiltInFunctions()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (data: BuiltinFunctionDef[]) => {
          this.builtinFunctions = data;
          this.builtinAttrs = this.policyBuilderService.getBuiltInAttr();
          this.rightOperandOptions = Array.from(
            new Set([...this.builtinAttrs, ...this.rightOperandOptions])
          );
        },
        error: (err: Error) => this.alertService.error(err.message),
      });
  }

  addVariable(): void {
    this.globalVars.update(v => [...v, createDefaultGlobalVar()]);
    this.emitChange();
    this.showCollapse = this.gv.length === 0;
    if (this.gv.length) this.isCollapsed = false;
  }

  removeVariable(index: number): void {
    this.globalVars.update(v => v.filter((_, i) => i !== index));
    this.emitChange();
    this.showCollapse = this.gv.length === 0;
  }

  filterLeftOperands(value: string, index?: number): void {
    void index;
    const all = this.buildLeftOperandsList();
    const query = (value || '').toLowerCase();
    this.filteredLeftOperands = this.commonService
      .getUniqueData(all)
      .filter(opt => opt.data.toLowerCase().includes(query));
    this.updateLeftOperandWidth();
  }

  onLeftOperandInputFocus(index?: number): void {
    void index;
    this.filteredLeftOperands = this.commonService.getUniqueData(
      this.buildLeftOperandsList()
    );
  }

  filterRightOperands(value: string) {
    const all = this.buildRightOperandsList();
    const query = (value || '').toLowerCase();
    this.filteredRightOperands = this.commonService
      .getUniqueData(all)
      .filter(opt => opt.data.toLowerCase().includes(query));
  }

  onRightOperandInputFocus(type?: string, index?: number): void {
    void type;
    void index;
    if (this.rightOperandOptions.length <= 0) {
      this.rightOperandOptions = Array.from(
        new Set(this.policyBuilderService.getBuiltInAttr())
      );
    }
    this.filteredRightOperands = this.commonService.getUniqueData(
      this.buildRightOperandsList()
    );
  }

  private buildCommonOperands(): AttrData[] {
    const fromGlobalVars = this.gv.map(v => ({
      data: v.key,
      type: v.type,
    }));
    const fromRuleNames = this.rn.map(v => ({
      data: v,
      type: typeof v,
    }));
    return [...fromGlobalVars, ...fromRuleNames];
  }

  private buildLeftOperandsList(): AttrData[] {
    return this.leftOperandOptions.concat(...this.buildCommonOperands());
  }

  private buildRightOperandsList(): AttrData[] {
    const fromCustomFunctions = this.cf.map(
      f => ({ data: f.name, type: f.returnType }) as AttrData
    );
    return this.rightOperandOptions.concat(
      ...this.buildCommonOperands(),
      ...fromCustomFunctions
    );
  }

  emitChange(): void {
    for (const item of this.gv) {
      item.valueError = '';

      const valueKey = (item.value ?? '').trim();

      if (!valueKey) continue;

      const matchedVar = this.gv.find(v => v.key === valueKey);

      if (
        matchedVar &&
        matchedVar.type !== item.type &&
        matchedVar.type !== 'null'
      ) {
        item.valueError = this.translateService.instant(
          'policyBuilder.error.cannotReferenceVariable',
          { variable: valueKey, type: matchedVar.type, fieldType: item.type }
        );
      }
    }
    const cloned = this.gv.map(v => ({ ...v }));
    this.globalVars.set(cloned);
  }

  getBuiltinArgName(fnName: string, argIndex: number): string | null {
    return (
      this.builtinFunctions.find(f => f.name === fnName)?.argNames?.[
        argIndex
      ] ?? null
    );
  }

  isJSON(input: unknown): boolean {
    if (typeof input !== 'string') return false;
    try {
      const parsed = JSON.parse(input);
      return (
        typeof parsed === 'object' && parsed !== null && !Array.isArray(parsed)
      );
    } catch {
      return false;
    }
  }

  onTypeChange(index: number, newType: string) {
    const item = this.gv[index];
    const type = newType.toLowerCase();
    item.type = type;

    if (type === 'null') {
      item.value = '';
      item.args = [];
    } else if (type === 'string' && !item.value.startsWith('"')) {
      item.value = '""';
    } else if (type === 'array' && !item.value.startsWith('[')) {
      item.value = '[]';
    } else if (type === 'json' && !item.value.startsWith('{')) {
      item.value = '{}';
    } else if (type === 'boolean') {
      item.value = 'false';
    } else if (type === 'object' && !this.isJSON(item.value)) {
      item.value = '{}';
    }
    this.emitChange();
  }

  onRightOperandSelected(option: AttrData | string, item: GlobalVar): void {
    const selectedValue = typeof option === 'string' ? option : option.data;
    item.value = selectedValue;

    const trimmed = selectedValue.trim();
    const argCount = this.isFunction(trimmed)
      ? this.builtinArgCount(trimmed) || this.customFunctionArgCount(trimmed)
      : 0;

    item.args = argCount
      ? Array.from({ length: argCount }, () => ({ value: '' }))
      : [];
  }

  getBuiltInFunction(value: string) {
    return value?.trim()
      ? this.builtinFunctions.find(f => f.name === value.trim())
      : undefined;
  }

  getCustomFunctionName(name: string) {
    return this.cf.find(f => f.name === name);
  }

  private normalize(str: string): string {
    let result = '';
    let skipping = false;

    for (const ch of str) {
      if (ch === '[' && !skipping) {
        skipping = true;
        result += '[]';
        continue;
      }
      if (ch === ']' && skipping) {
        skipping = false;
        continue;
      }
      if (!skipping) result += ch;
    }
    return result;
  }

  setDataType(item: GlobalVar): void {
    if (!item.value) return;
    const match = this.rightOperandOptions.find(
      opt => this.normalize(opt.data) === this.normalize(item.value)
    );
    if (match) {
      item.type = match.type;
      this.emitChange();
    } else {
      if (this.helperFunctionsConditionRowService.inferType(item.value) != '') {
        item.type = this.helperFunctionsConditionRowService.inferType(
          item.value
        );
        this.emitChange();
      }
    }
  }

  onValueChange(item: GlobalVar) {
    const input = item.value?.trim();
    if (input.startsWith('input.') || input.includes('input.')) {
      item.isTypeDisabled = true;
    } else if (this.isBuiltinName(input)) {
      const builtindata = this.getBuiltInFunction(input);
      if (builtindata?.type) {
        item.type = builtindata.type;
      }
      item.isTypeDisabled = true;
    } else if (this.isCustomFunctionName(input)) {
      const customFunc = this.getCustomFunctionName(input);
      if (customFunc?.returnType) {
        item.type = customFunc.returnType;
      }
      item.isTypeDisabled = true;
    } else {
      item.isTypeDisabled = false;
    }
  }

  onValueChangeArray(item: GlobalVar): void {
    if (item?.type?.toLowerCase() !== 'array' || this.isFunction(item?.value))
      return;

    const val = item.value?.trim();
    if (!val) {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.arrayCannotBeEmpty'
      );
      return;
    }

    if (!(val.startsWith('[') && val.endsWith(']'))) {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.invalidArrayFormat'
      );
      return;
    }

    const inner = val.slice(1, -1).trim();
    if (!inner) {
      item.valueError = undefined;
      return;
    }

    const parts = inner.split(',').map(p => p.trim());
    for (const p of parts) {
      if (!this.isValidArrayElement(p)) {
        item.valueError = this.translateService.instant(
          'policyBuilder.error.invalidArrayElement',
          { element: p }
        );
        return;
      }
    }

    item.valueError = '';
  }

  private isValidArrayElement(element: string): boolean {
    return (
      /^-?\d+(\.\d+)?$/.test(element) ||
      /^(true|false)$/i.test(element) ||
      /^["'].*["']$/.test(element) ||
      /^[a-zA-Z_]\w*(\[.*\])?$/.test(element) ||
      /^[a-zA-Z_]\w*\s*[+\-*/]\s*\w+$/.test(element) ||
      /^\{[^}]+\}$/.test(element)
    );
  }

  onValueChangeString(item: GlobalVar): void {
    if (item?.type?.toLowerCase() !== 'string' || this.isFunction(item?.value))
      return;

    item.valueError = '';
    const trimmed = (item.value ?? '').trim();
    const normalized = trimmed.replace(/\(\)$/, '');

    if (this.isFunction(normalized)) {
      this.handleFunctionArgs(item, normalized);
      return;
    }

    item.args = [];
    if (!trimmed) {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.valueCannotBeEmpty'
      );
      return;
    }

    if ((trimmed.match(/"/g) || []).length % 2 !== 0) {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.unmatchedQuotes'
      );
      return;
    }

    this.validateStringParts(item, trimmed);
  }

  private handleFunctionArgs(item: GlobalVar, fnName: string): void {
    const argCount =
      this.builtinArgCount(fnName) || this.customFunctionArgCount(fnName);
    if (!item.args || item.args.length !== argCount) {
      item.args = Array(argCount).fill('');
    }
  }

  private validateStringParts(item: GlobalVar, trimmed: string): void {
    const parts = trimmed.split('+').map(p => p.trim());
    for (const part of parts) {
      if (!part) {
        item.valueError = this.translateService.instant(
          'policyBuilder.error.invalidUseOfPlusOperator'
        );
        return;
      }

      if (/^["'].*["']$/.test(part)) continue;

      const root = part.split('.')[0];
      if (this.isInvalidStringLiteral(part, item)) {
        item.valueError = this.translateService.instant(
          'policyBuilder.error.isNotString',
          { root }
        );
        return;
      }

      const definedGlobal = this.findStringVariable(root, item);
      if (!this.isAllowedRoot(root) && !definedGlobal) {
        item.valueError = this.translateService.instant(
          'policyBuilder.error.variableNotDefined',
          { root }
        );
        return;
      }

      if (
        definedGlobal &&
        definedGlobal.type !== 'string' &&
        definedGlobal.type !== 'null'
      ) {
        item.valueError = this.translateService.instant(
          'policyBuilder.error.variableTypeExpected',
          {
            variable: root,
            actualType: definedGlobal.type,
            expectedType: 'String',
          }
        );
        return;
      }
    }
  }

  private isInvalidStringLiteral(part: string, item: GlobalVar): boolean {
    return (
      item.type === 'string' &&
      (/^-?\d+(\.\d+)?$/.test(part) ||
        /^(true|false)$/i.test(part) ||
        /^null$/i.test(part) ||
        !/^[A-Za-z_]\w*(\.[A-Za-z_]\w*)*$/.test(part))
    );
  }

  private findStringVariable(
    root: string,
    item: GlobalVar
  ): GlobalVar | undefined {
    return this.gv.find(
      v =>
        v.key === root &&
        v !== item &&
        (v.type === 'string' || v.type === 'null')
    );
  }

  private isAllowedRoot(root: string): boolean {
    return this.allowedRoots.includes(root);
  }

  onValueChangeJson(item: GlobalVar): void {
    if (item?.type?.toLowerCase() !== 'json' || this.isFunction(item?.value)) {
      return;
    }

    const val = item.value?.trim();
    if (!val) {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.jsonCannotBeEmpty'
      );
      return;
    }

    if (!(val.startsWith('{') && val.endsWith('}'))) {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.invalidJsonFormat'
      );
      return;
    }

    this.validateJsonValue(item, val);
  }

  private validateJsonValue(item: GlobalVar, val: string): void {
    try {
      const normalized = this.normalizeJsonValue(val);
      const parsed: unknown = JSON.parse(normalized);

      if (
        typeof parsed !== 'object' ||
        parsed === null ||
        Array.isArray(parsed)
      ) {
        item.valueError = this.translateService.instant(
          'policyBuilder.error.jsonObjectRequired'
        );
        return;
      }

      item.valueError = undefined;
    } catch (err) {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.invalidJsonWithError',
        {
          error: (err as Error).message,
        }
      );
    }
  }

  private normalizeJsonValue(val: string): string {
    return val
      .replace(/([{,]\s*)([a-zA-Z_]\w*)(\s*:)/g, '$1"$2"$3')
      .replace(/:\s*([a-zA-Z_]\w*)/g, ': "$1"');
  }

  normalizeObjectLiteral(raw: string): string {
    return raw
      .replace(/([{,]\s*)([a-zA-Z_]\w*)\s*:/g, '$1"$2":')
      .replace(/([{,]\s*)(\d+)\s*:/g, '$1"$2":')
      .replace(/'/g, '"')
      .replace(
        /(:|\[|,)\s*([a-zA-Z_]\w*)(?=\s*[,\]]}])/g,
        (_m, prefix, value) => {
          if (value === 'true' || value === 'false' || value === 'null') {
            return `${prefix} ${value}`;
          }
          return `${prefix} "${value}"`;
        }
      );
  }

  onValueChangeObject(item: GlobalVar): void {
    if (item?.type?.toLowerCase() !== 'object') return;

    const val = item.value?.trim();

    if (!val) {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.objectCannotBeEmpty'
      );
      return;
    }

    if (!(val.startsWith('{') && val.endsWith('}'))) {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.invalidObjectFormat'
      );
      return;
    }

    this.validateObjectLiteral(item, val);
  }

  private validateObjectLiteral(item: GlobalVar, val: string): void {
    try {
      const normalized = this.normalizeObjectLiteral(val);
      const parsed = JSON.parse(normalized);

      if (
        typeof parsed !== 'object' ||
        parsed === null ||
        Array.isArray(parsed)
      ) {
        item.valueError = this.translateService.instant(
          'policyBuilder.error.objectNotLiteral'
        );
      } else {
        item.valueError = undefined;
      }
    } catch {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.invalidObjectLiteral'
      );
    }
  }

  onValueChangeSet(item: GlobalVar): void {
    if (item?.type?.toLowerCase() !== 'set') return;

    const val = item.value?.trim();
    if (!(val?.startsWith('{') && val?.endsWith('}'))) {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.invalidSetFormat'
      );
      return;
    }

    this.validateSetValues(item, val);
  }

  private validateSetValues(item: GlobalVar, val: string): void {
    const inner = val.slice(1, -1).trim();
    const parts = inner.split(',').map(p => p.trim());
    const parsedValues: (string | number | boolean)[] = [];

    for (const part of parts) {
      if (
        (part.startsWith('"') && part.endsWith('"')) ||
        (part.startsWith("'") && part.endsWith("'"))
      ) {
        parsedValues.push(part.slice(1, -1));
        continue;
      }

      if (!isNaN(Number(part))) {
        parsedValues.push(Number(part));
        continue;
      }

      if (/^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*$/.test(part)) {
        parsedValues.push(part);
        continue;
      }

      item.valueError = this.translateService.instant(
        'policyBuilder.error.invalidValueInSet',
        { value: part }
      );
      return;
    }

    try {
      new Set(parsedValues);
      item.valueError = undefined;
    } catch {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.invalidObjectLiteral'
      );
    }
  }

  private basicNumericCheck(item: GlobalVar): boolean {
    if (item?.type?.toLowerCase() !== 'number' || this.isFunction(item?.value))
      return false;

    item.valueError = '';
    const trimmed = item.value?.trim() ?? '';

    if (!trimmed) {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.valueCannotBeEmpty'
      );
      return false;
    }

    if (/^["'].*["']$/.test(trimmed)) {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.quotedStringsNotAllowedForNumber'
      );
      return false;
    }
    return true;
  }

  onValueChangeNumber(item: GlobalVar): void {
    if (!this.basicNumericCheck(item)) return;

    const trimmed = item.value?.trim() ?? '';
    const tokens = trimmed.match(
      /[a-zA-Z_]\w*(?:\.\w+)*|\d+(\.\d+)?|[+\-*/()]/g
    );

    if (!tokens) {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.invalidNumericExpression'
      );
      return;
    }

    for (const token of tokens) {
      if (/^[+\-*/()]$/.test(token) || /^\d+(\.\d+)?$/.test(token)) continue;

      const root = token.split('.')[0];
      if (this.isAllowedRoot(root)) continue;

      const definedGlobal = this.gv.find(v => v.key === root && v !== item);
      if (
        !definedGlobal ||
        (definedGlobal.type !== 'number' && definedGlobal.type !== 'null')
      ) {
        item.valueError = this.translateService.instant(
          'policyBuilder.error.variableTypeExpected',
          {
            variable: root,
            actualType: definedGlobal?.type || 'undefined',
            expectedType: 'number',
          }
        );
        return;
      }
    }

    if (!this.validateNumericExpression(item, trimmed)) {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.invalidNumericExpression'
      );
    }
  }

  private validateNumericExpression(item: GlobalVar, trimmed: string): boolean {
    try {
      let evalExpression = trimmed;
      for (const gv of this.gv.filter(
        v => v !== item && (v.type === 'number' || v.type === 'null')
      )) {
        evalExpression = this.replaceWholeWord(
          evalExpression,
          String(gv.key),
          String(gv.value)
        );
      }
      evalExpression = evalExpression.replace(
        /\b(input|data)(?:\.[a-zA-Z0-9_]+|\[\d+\])+\b/g,
        '1'
      );
      return !isNaN(this.safeEvaluate(evalExpression));
    } catch {
      return false;
    }
  }

  private replaceWholeWord(
    text: string,
    word: string,
    replacement: string
  ): string {
    if (!word) return text;
    return text
      .split(/\b/)
      .map(part => (part === word ? replacement : part))
      .join('');
  }

  private safeEvaluate(expr: string): number {
    expr = expr.replace(/\s+/g, '');

    if (!/^[0-9+\-*/.()]+$/.test(expr)) {
      throw new Error('Invalid characters in expression');
    }

    return this.evaluateMathExpression(expr);
  }

  private evaluateMathExpression(expr: string): number {
    let pos = 0;

    const parseExpr = (): number => {
      let value = parseTerm();
      while (pos < expr.length && (expr[pos] === '+' || expr[pos] === '-')) {
        const op = expr[pos++];
        const term = parseTerm();
        value = op === '+' ? value + term : value - term;
      }
      return value;
    };

    const parseTerm = (): number => {
      let value = parseFactor();
      while (pos < expr.length && (expr[pos] === '*' || expr[pos] === '/')) {
        const op = expr[pos++];
        const factor = parseFactor();
        value = op === '*' ? value * factor : value / factor;
      }
      return value;
    };

    const parseFactor = (): number => {
      if (expr[pos] === '(') {
        pos++;
        const value = parseExpr();
        if (expr[pos] !== ')') {
          throw new Error('Missing closing parenthesis');
        }
        pos++;
        return value;
      }
      if (expr[pos] === '-') {
        pos++;
        return -parseFactor();
      }
      const start = pos;
      while (pos < expr.length && /[0-9.]/.test(expr[pos])) {
        pos++;
      }
      if (pos === start) {
        throw new Error(
          `Unexpected character at position ${pos}: ${expr[pos]}`
        );
      }
      return parseFloat(expr.slice(start, pos));
    };

    const result = parseExpr();
    if (pos !== expr.length) {
      throw new Error(`Unexpected character at position ${pos}: ${expr[pos]}`);
    }
    if (typeof result !== 'number' || isNaN(result)) {
      throw new Error('Result must be a number');
    }
    return result;
  }

  onValueChangeBoolean(item: GlobalVar): void {
    if (item?.type?.toLowerCase() !== 'boolean' || this.isFunction(item?.value))
      return;

    item.valueError = '';
    const trimmed = item.value?.trim() ?? '';

    if (!trimmed) {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.booleanExpressionEmpty'
      );
      return;
    }

    if (this.isBooleanLiteral(trimmed)) return;

    if (/^[a-zA-Z_]\w*(\.\w+)*$/.test(trimmed)) {
      const refType = this.getVarType(trimmed);
      if (refType !== 'boolean') {
        item.valueError = `Variable "${trimmed.split('.')[0]}" must be of type "boolean".`;
      }
      return;
    }

    const comparisonRegex =
      /^\s*([A-Za-z_][A-Za-z0-9_.]*|\d+(?:\.\d+)?|"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')\s*(==|!=|>=|<=|>|<)\s*([A-Za-z_][A-Za-z0-9_.]*|\d+(?:\.\d+)?|"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')\s*$/;
    if (!trimmed.match(comparisonRegex)) {
      item.valueError = this.translateService.instant(
        'policyBuilder.error.invalidBooleanExpression'
      );
    }
  }

  isAttrData(obj: unknown): obj is AttrData {
    return (
      !!obj &&
      typeof obj === 'object' &&
      'type' in obj &&
      typeof (obj as Record<string, unknown>).type === 'string' &&
      'data' in obj
    );
  }

  onKeyChange(
    selected: AttrData | string,
    item: GlobalVar,
    keyModel: AttrData | string | NgModel
  ): void {
    let type: string = '';
    if (this.isAttrData(selected)) {
      type = selected.type.toLowerCase();
      item.type = type === 'integer' ? 'number' : type;
      item.key = selected.data;
    } else {
      item.key = selected;
    }
    const trimmedKey = item.key?.trim().toLowerCase();

    if (this.reservedKeywords.has(trimmedKey)) {
      item.keyError = this.translateService.instant(
        'policyBuilder.error.keywordCannotBeVariable',
        { keyword: trimmedKey }
      );

      if (keyModel && typeof keyModel === 'object' && 'control' in keyModel) {
        (keyModel as NgModel).control.setErrors({ custom: true });
      }
    } else {
      item.keyError = '';
      if (keyModel && typeof keyModel === 'object' && 'control' in keyModel) {
        (keyModel as NgModel).control.setErrors(null);
      }
    }
  }

  toggleGlobalVarComponent(): void {
    this.isCollapsed = !this.isCollapsed;
  }

  hasValidationErrors(): boolean {
    let hasError = false;

    for (const item of this.gv) {
      const value = item.value?.trim() || '';

      if (!this.validateLeftOperand(item)) hasError = true;

      if (!value && item.type.toLowerCase() !== 'null') {
        item.valueError = '*required.';
        hasError = true;
        continue;
      }

      if (this.isFunction(value)) continue;

      this.callValidationByType(item, item.type.toLowerCase());

      if (!this.helperFunctionsConditionRowService.isValidRegex(item.key)) {
        item.keyError = this.translateService.instant(
          'policyBuilder.error.invalidVariableName'
        );
      }
      if (
        !this.helperFunctionsConditionRowService.isValidRegexValue(value) &&
        item.valueError === ''
      ) {
        item.valueError = this.translateService.instant(
          'policyBuilder.error.invalidValueFormat'
        );
      }

      if (item.keyError || item.valueError) hasError = true;
    }
    return hasError;
  }

  validateLeftOperand(item: GlobalVar): boolean {
    const key = item.key?.trim();

    if (!key) {
      item.keyError = '*required';
      return false;
    }

    if (!this.helperFunctionsConditionRowService.isValidRegex(key)) {
      item.keyError = this.translateService.instant(
        'policyBuilder.error.invalidVariableName'
      );
      return false;
    }

    if (this.reservedKeywords.has(key.toLowerCase())) {
      item.keyError = this.translateService.instant(
        'policyBuilder.error.keywordCannotBeVariable',
        { keyword: key }
      );
      return false;
    }

    if (this.looksLikeFunction(key)) {
      item.keyError = this.translateService.instant(
        'policyBuilder.error.functionCallNotAllowed'
      );
      return false;
    }

    if (this.isBuiltinFunctionName(key)) {
      item.keyError = this.translateService.instant(
        'policyBuilder.error.builtinFunctionName',
        { name: key }
      );
      return false;
    }

    if (this.isCustomFunctionNameStrict(key)) {
      item.keyError = this.translateService.instant(
        'policyBuilder.error.customFunctionName',
        { name: key }
      );
      return false;
    }

    if (this.isSchemaAttribute(key)) {
      item.keyError = this.translateService.instant(
        'policyBuilder.error.schemaAttributeName',
        { name: key }
      );
      return false;
    }

    if (this.isOtherGlobalVar(key, item)) {
      item.keyError = this.translateService.instant(
        'policyBuilder.error.globalVarAlreadyDefined',
        { name: key }
      );
      return false;
    }

    item.keyError = '';
    return true;
  }

  private isBuiltinFunctionName(name: string): boolean {
    return this.builtinFunctions.some(
      fn => fn.name.toLowerCase() === name.toLowerCase()
    );
  }

  private isCustomFunctionNameStrict(name: string): boolean {
    return this.cf.some(fn => fn.name.toLowerCase() === name.toLowerCase());
  }

  private isOtherGlobalVar(name: string, self: GlobalVar): boolean {
    return this.gv.some(
      v => v !== self && v.key?.toLowerCase() === name.toLowerCase()
    );
  }

  private looksLikeFunction(name: string): boolean {
    const match = name.match(/^[a-zA-Z0-9_]+/);
    if (!match || match[0].length === 0) return false;

    let i = match[0].length;
    while (i < name.length && /\s/.test(name[i])) i++;

    return i < name.length && name[i] === '(' && name.lastIndexOf(')') > i;
  }

  private normalizeSchemaKey(value: string): string {
    return this.normalize(value);
  }

  private isSchemaAttribute(name: string): boolean {
    const normalized = this.normalizeSchemaKey(name);

    return this.leftOperandOptions.some(
      opt => this.normalizeSchemaKey(opt.data) === normalized
    );
  }

  private readonly typeValidators: Record<string, (item: GlobalVar) => void> = {
    string: item => this.onValueChangeString(item),
    number: item => this.onValueChangeNumber(item),
    boolean: item => this.onValueChangeBoolean(item),
    array: item => this.onValueChangeArray(item),
    json: item => this.onValueChangeJson(item),
    object: item => this.onValueChangeObject(item),
    set: item => this.onValueChangeSet(item),
  };

  callValidationByType(item: GlobalVar, type: string) {
    this.typeValidators[type]?.(item);
  }

  validateAllGlobalVars(): boolean {
    let isValid = true;
    for (const item of this.gv) {
      const key = item.key?.trim();
      const value =
        item.type.toLowerCase() !== 'null' ? item.value?.trim() : ' ';
      item.keyError = key ? '' : '*required';
      item.valueError =
        value || item.type.toLowerCase() === 'null' ? '' : '*required';
      if (!key || !value) isValid = false;
    }
    return this.checkDuplicate(this.getSeenKeys(), isValid);
  }

  getSeenKeys(): Map<string, GlobalVar[]> {
    const seenKeys = new Map<string, GlobalVar[]>();
    for (const item of this.gv) {
      if (item.default) continue;
      const key = item.key?.trim();
      if (key) {
        if (!seenKeys.has(key)) {
          seenKeys.set(key, []);
        }
        seenKeys.get(key)!.push(item);
      }
    }
    return seenKeys;
  }

  checkDuplicate(seenKeys: Map<string, GlobalVar[]>, isValid: boolean) {
    for (const [, items] of seenKeys.entries()) {
      if (items.length > 1) {
        for (const item of items) {
          item.keyError = this.translateService.instant(
            'policyBuilder.error.duplicateVariable'
          );
          isValid = false;
        }
      }
    }
    return isValid;
  }

  validateAllArguments(): boolean {
    let isValid = true;

    const validateArgs = (
      args: RawFunctionInput[],
      parentFnName: string
    ): boolean => {
      for (let i = 0; i < args.length; i++) {
        const arg = args[i];
        const trimmed = arg.value?.trim() || '';
        if (!trimmed) {
          isValid = false;
          continue;
        }
        if (
          !this.helperFunctionsConditionRowService.isValidRegexValue(trimmed)
        ) {
          isValid = false;
          continue;
        }
        const builtin = this.builtinFunctions.find(
          fn => fn.name === parentFnName
        );
        if (builtin) {
          isValid = this.validateArgBuiltin(builtin, trimmed, i, isValid);
          if (!isValid) continue;
        }

        if (arg.subArgs?.length) {
          validateArgs(arg.subArgs, trimmed);
        }
      }
      return isValid;
    };

    for (const gv of this.gv) {
      if (gv.args?.length) {
        validateArgs(gv.args, gv.value?.trim());
      }
    }
    return isValid;
  }

  validateArgBuiltin(
    builtin: BuiltinFunctionDef,
    trimmed: string,
    i: number,
    isValid: boolean
  ): boolean {
    this.onRightOperandInputFocus('', 0);
    const attrMatch = this.filteredRightOperands.find(
      op => op.data === trimmed
    );
    const expectedType = builtin.argTypes[i];
    const expectedTypes = expectedType
      ? [...expectedType.split('|').map((t: string) => t.trim()), 'null']
      : ['null'];

    if (
      attrMatch &&
      attrMatch.type != '' &&
      !expectedTypes.includes(attrMatch.type) &&
      expectedType != ''
    ) {
      isValid = false;
    } else if (
      expectedType &&
      attrMatch?.type == undefined &&
      this.helperFunctionsConditionRowService.inferType(trimmed) != '' &&
      !expectedTypes.includes(
        this.helperFunctionsConditionRowService.inferType(trimmed)
      )
    ) {
      isValid = false;
    }
    return isValid;
  }

  onKeyInput(item: GlobalVar, event: Event): void {
    if (this.isAttrData(item.key)) {
      item.key = item.key.data;
    }
    const input = (event.target as HTMLInputElement).value;
    item.key = input;
    if (item.keyError && input.trim() !== '') {
      item.keyError = '';
    }
  }

  onValueInput(item: GlobalVar, event?: Event): void {
    let input = item.value;

    if (event) {
      input = (event.target as HTMLInputElement).value;
      item.value = input;
    }

    if (item.valueError && input.trim() !== '') {
      item.valueError = '';
    }

    const trimmed = input.trim();

    if (this.isFunction(trimmed)) {
      const argCount =
        this.builtinArgCount(trimmed) || this.customFunctionArgCount(trimmed);
      if (!item.args) {
        item.args = Array.from({ length: argCount }, () => ({ value: '' }));
      } else if (item.args.length < argCount) {
        while (item.args.length < argCount) {
          item.args.push({ value: '' });
        }
      } else if (item.args.length > argCount) {
        item.args = item.args.slice(0, argCount);
      }
    } else {
      item.args = [];
    }
  }

  private builtinArgCount(fnName: string): number {
    const fn = this.builtinFunctions.find(fn => fn.name === fnName);
    return fn ? fn.argCount : 0;
  }

  private customFunctionArgCount(fnName: string): number {
    const fn = this.cf.find(fn => fn.name === fnName);
    return fn ? fn.args.length : 0;
  }

  isFunction(fnName: string): boolean {
    return (
      this.builtinFunctions.some(fn => fn.name === fnName) ||
      this.cf.some(fn => fn.name === fnName)
    );
  }

  updateLeftOperandWidth(): void {
    setTimeout(() => {
      const measure = this.leftOperandMeasure();
      if (!measure) return;
      const el = measure.nativeElement;
      el.style.display = 'inline';
      const width = el.offsetWidth;
      el.style.display = 'none';
      this.leftOperandWidth = Math.max(170, Math.min(width - 5, 600));
    });
  }

  isBuiltinName(value: string): boolean {
    return !!this.getBuiltInFunction(value);
  }

  isCustomFunctionName(name: string): boolean {
    return !!this.getCustomFunctionName(name);
  }

  builtinUsageTooltip(item: GlobalVar): string | undefined {
    return this.builtinFunctions.find(f => f.name === item.value)?.usage;
  }

  builtinUsagePopup(item: GlobalVar): string | undefined {
    return this.builtinFunctions
      .find(f => f.name === item.value)
      ?.usageFull?.replace(/\n/g, '<br>');
  }

  openFunctionModal(): void {
    this.showFunctionModal = true;
  }

  closeFunctionModal(): void {
    this.showFunctionModal = false;
  }

  onFunctionModalClose(
    result: {
      functionName: string;
      args: string[];
      returnVar: string;
      returnType: string;
    } | null
  ) {
    if (result) {
      const { functionName, args, returnVar, returnType } = result;

      this.newFunctionRequested.emit({
        name: functionName,
        args,
        returnVar,
        returnType,
      });
    }
    this.closeFunctionModal();
  }
}
