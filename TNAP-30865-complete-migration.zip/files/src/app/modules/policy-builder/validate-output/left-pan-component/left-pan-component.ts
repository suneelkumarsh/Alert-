/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Component,
  OnInit,
  DestroyRef,
  input,
  output,
  viewChild,
  inject,
  HostListener,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { CodemirrorModule } from '@ctrl/ngx-codemirror';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { PolicyBuilderService } from '../../shared/policy-builder.service';
import { CommonService } from '../../shared/common.service';
import {
  CodeMirrorEditor,
  BackendError,
} from 'src/app/model/OpaBuilderPolicy.model';
import { updateWasEditorLastFocused } from '../../shared/code-mirror-focus-helper';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-left-pan-component',
  standalone: true,
  imports: [FormsModule, CodemirrorModule, TranslateModule],
  templateUrl: './left-pan-component.html',
  styleUrls: ['./left-pan-component.css'],
})
export class LeftPanComponent implements OnInit {
  protected readonly codeEditor = viewChild<CodeMirrorEditor>('codeEditor');
  protected readonly codeChanged = output<string>();
  protected readonly isEditMode = input(true);

  private readonly policyService = inject(PolicyBuilderService);
  private readonly commonService = inject(CommonService);
  private readonly alertService = inject(TnapAlertService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly translate = inject(TranslateService);

  protected generatedRego = '';
  protected isBasic = false;
  protected isSaveFormVisible = false;
  private wasEditorLastFocused = false;
  protected errorMessage = '';

  ngOnInit(): void {
    this.subscribeToRegoData();
    this.subscribeToBasicMode();
    this.subscribeToSaveFormVisibility();
    this.subscribeToHighlightLine();
    this.subscribeToInsertPath();
  }

  protected onCodeChange(newCode: string): void {
    this.generatedRego = newCode;
    this.policyService.setRegoData(newCode);

    const isValid = /\bdecision\b/.test(newCode);
    this.policyService.setErrorMsg(
      isValid
        ? null
        : this.translate.instant(
            'policyBuilder.validation.mandatoryDecisionFieldMissing'
          )
    );
    this.policyService.setDecisionValue(isValid);

    if (!newCode?.trim()) {
      this.policyService.updateLint({
        error: this.translate.instant('policyBuilder.error.regoCodeEmpty'),
      });
      return;
    }

    this.performLintCheck(newCode);
  }

  protected onEditorCodeChange(value: string): void {
    this.codeChanged.emit(value || '');
  }

  private subscribeToRegoData(): void {
    this.policyService.regoData
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: rego => {
          this.generatedRego = rego || '';
        },
        error: (err: Error) =>
          this.alertService.error('Error loading rego data: ' + err.message),
      });
  }

  private subscribeToBasicMode(): void {
    this.policyService.isBasicMode
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: isBasic => (this.isBasic = isBasic ?? false),
        error: (err: Error) =>
          this.alertService.error('Error loading basic mode: ' + err.message),
      });
  }

  private subscribeToSaveFormVisibility(): void {
    this.policyService.isSaveFormVisible
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: isVisible => (this.isSaveFormVisible = isVisible),
        error: (err: Error) =>
          this.alertService.error(
            'Error loading save form visibility: ' + err.message
          ),
      });
  }

  private subscribeToHighlightLine(): void {
    this.policyService.highlightLine$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: lineNumber => {
          const editor = this.codeEditor();
          if (lineNumber !== null && editor?.codeMirror) {
            this.highlightLine(lineNumber);
          }
        },
        error: (err: Error) =>
          this.alertService.error('Error highlighting line: ' + err.message),
      });
  }

  private performLintCheck(code: string): void {
    this.policyService
      .lintCheckRegoData({ source: code })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: response => {
          this.policyService.updateLint({ message: JSON.stringify(response) });
        },
        error: err => {
          this.extractErrorMessage(err).then(msg => {
            this.policyService.updateLint({ error: msg });
          });
        },
      });
  }

  private highlightLine(lineNumber: number): void {
    const cm = this.codeEditor()?.codeMirror;
    if (!cm) return;

    this.clearPreviousMarks(cm);
    const line = lineNumber - 1;
    this.applyHighlight(cm, line);
  }

  private clearPreviousMarks(
    cm: NonNullable<CodeMirrorEditor['codeMirror']>
  ): void {
    cm.getAllMarks().forEach(mark => mark.clear());
  }

  private applyHighlight(
    cm: NonNullable<CodeMirrorEditor['codeMirror']>,
    line: number
  ): void {
    cm.scrollIntoView({ line, ch: 0 }, 100);
    cm.addLineClass(line, 'background', 'highlighted-line');

    setTimeout(
      () => cm.removeLineClass(line, 'background', 'highlighted-line'),
      3000
    );
  }

  private async extractErrorMessage(err: {
    error?: Blob | string | BackendError;
  }): Promise<string> {
    try {
      const errorText =
        err.error instanceof Blob ? await err.error.text() : err.error;
      const backendError = this.commonService.safeParse(errorText);

      return (
        this.getErrorDetails(backendError) ||
        this.translate.instant('policyBuilder.error.unableToConnect')
      );
    } catch {
      return this.translate.instant('policyBuilder.error.unableToConnect');
    }
  }

  private getErrorDetails(backendError: BackendError | null): string | null {
    if (typeof backendError?.detail === 'string') {
      const detailParsed = this.commonService.safeParse(backendError.detail);
      const errorDetails = detailParsed?.errorDetails as
        | Record<string, unknown>
        | undefined;
      if (errorDetails?.['violations']) {
        return JSON.stringify(errorDetails);
      }
      const errorMsg = detailParsed?.error as string;
      if (errorMsg) return errorMsg;
      return backendError.detail;
    }
    if ((backendError as Record<string, unknown>)?.['violations']) {
      return JSON.stringify(backendError);
    }
    const errorMsg = backendError?.error as string;
    return errorMsg || null;
  }

  private subscribeToInsertPath(): void {
    this.policyService.insertPath$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: path => {
          const cm = this.codeEditor()?.codeMirror;
          if (cm && this.wasEditorLastFocused) {
            const cursor = cm.getCursor();
            cm.replaceRange(path, cursor);
            cm.focus();
            this.generatedRego = cm.getValue();
            this.policyService.setRegoData(this.generatedRego);
          }
        },
      });
  }

  @HostListener('document:mousedown', ['$event'])
  protected onDocumentMouseDown(event: MouseEvent): void {
    updateWasEditorLastFocused({
      target: event.target as HTMLElement | null,
      setWasEditorLastFocused: v => (this.wasEditorLastFocused = v),
    });
  }
}
