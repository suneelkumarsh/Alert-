/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LeftPanComponent } from './left-pan-component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of, throwError } from 'rxjs';
import { TranslateModule } from '@ngx-translate/core';
import { PolicyBuilderService } from '../../shared/policy-builder.service';
import { CommonService } from '../../shared/common.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('LeftPanComponentComponent', () => {
  let component: LeftPanComponent;
  let fixture: ComponentFixture<LeftPanComponent>;
  let policyService: jasmine.SpyObj<PolicyBuilderService>;
  let commonService: jasmine.SpyObj<CommonService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;

  beforeEach(async () => {
    policyService = jasmine.createSpyObj('PolicyBuilderService', [
      'updateMessage',
      'setRegoData',
      'updateLint',
      'lintCheckRegoData',
      'setErrorMsg',
    ]);

    (policyService as any).setErrorMsg = jasmine.createSpy('setErrorMsg');
    (policyService as any).setDecisionValue =
      jasmine.createSpy('setDecisionValue');
    commonService = jasmine.createSpyObj('CommonService', [
      'safeParse',
      'formatLintViolations',
    ]);
    alertService = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
    ]);

    (policyService as any).regoData = of('initial rego');
    (policyService as any).isBasicMode = of(true);
    (policyService as any).isSaveFormVisible = of(false);
    (policyService as any).highlightLine$ = of(null);
    (policyService as any).insertPath$ = of();
    (policyService.lintCheckRegoData as any).and.returnValue(of(null));

    await TestBed.configureTestingModule({
      imports: [
        LeftPanComponent,
        HttpClientTestingModule,
        TranslateModule.forRoot(),
      ],
      providers: [
        { provide: PolicyBuilderService, useValue: policyService },
        { provide: CommonService, useValue: commonService },
        { provide: TnapAlertService, useValue: alertService },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(LeftPanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should update generatedRego and call setRegoData', () => {
    const newCode = 'valid rego code';
    (policyService.lintCheckRegoData as any).and.returnValue(
      of('raw-response')
    );
    commonService.safeParse.and.returnValue({ Result: 'parsed-result' } as any);
    commonService.formatLintViolations.and.returnValue('No linter violations');

    (component as any).onCodeChange(newCode);

    expect((component as any).generatedRego).toBe(newCode);
    expect(policyService.setRegoData).toHaveBeenCalledWith(newCode);
    expect(policyService.updateLint).toHaveBeenCalledWith({
      message: '"raw-response"',
    });
  });

  it('should show error if code is empty', () => {
    (component as any).onCodeChange('   ');

    expect(policyService.updateLint).toHaveBeenCalledWith({
      error: 'policyBuilder.error.regoCodeEmpty',
    });
  });

  it('should handle parsed error in response as lint message', () => {
    const newCode = 'rego with error';
    (policyService.lintCheckRegoData as any).and.returnValue(
      of('raw-response')
    );
    commonService.safeParse.and.returnValue({ error: 'Lint error found' });
    commonService.formatLintViolations.and.returnValue('Lint error found');

    (component as any).onCodeChange(newCode);
    expect(policyService.updateLint).toHaveBeenCalledWith({
      message: '"raw-response"',
    });
  });

  it('should handle unexpected response', () => {
    const newCode = 'rego unexpected';
    (policyService.lintCheckRegoData as any).and.returnValue(
      of('raw-response')
    );
    commonService.safeParse.and.returnValue({});
    commonService.formatLintViolations.and.returnValue('No linter violations');

    (component as any).onCodeChange(newCode);

    expect(policyService.updateLint).toHaveBeenCalledWith({
      message: '"raw-response"',
    });
  });

  it('should handle backend error and update lint with error message', () => {
    const newCode = 'invalid rego code';
    (policyService.lintCheckRegoData as any).and.returnValue(
      throwError(() => ({ error: { Error: 'Backend error' } }))
    );
    commonService.safeParse.and.returnValue({
      error: 'Lint error from backend',
    });

    expect(() => (component as any).onCodeChange(newCode)).not.toThrow();
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });

  it('should handle empty code change', () => {
    (policyService.lintCheckRegoData as any).and.returnValue(of([]));
    commonService.safeParse.and.returnValue({ result: null });

    expect(() => (component as any).onCodeChange('')).not.toThrow();
  });

  it('should update rego data on code change', () => {
    const code = 'package test\n\nallow = true';
    (policyService.lintCheckRegoData as any).and.returnValue(of([]));
    commonService.safeParse.and.returnValue({ result: null });

    (component as any).onCodeChange(code);

    expect(policyService.setRegoData).toHaveBeenCalledWith(code);
  });

  describe('onEditorCodeChange', () => {
    it('should emit codeChanged with the provided value', () => {
      const emitted: string[] = [];
      (component as any).codeChanged.subscribe((v: string) => emitted.push(v));
      (component as any).onEditorCodeChange('some code');
      expect(emitted).toEqual(['some code']);
    });

    it('should emit empty string when value is falsy', () => {
      const emitted: string[] = [];
      (component as any).codeChanged.subscribe((v: string) => emitted.push(v));
      (component as any).onEditorCodeChange('');
      expect(emitted).toEqual(['']);
    });
  });

  describe('subscribeToRegoData', () => {
    it('should set generatedRego from service observable', () => {
      (policyService as any).regoData = of('updated rego');
      (component as any).subscribeToRegoData();
      expect((component as any).generatedRego).toBe('updated rego');
    });

    it('should set generatedRego to empty string when null emitted', () => {
      (policyService as any).regoData = of(null);
      (component as any).subscribeToRegoData();
      expect((component as any).generatedRego).toBe('');
    });
  });

  describe('subscribeToBasicMode', () => {
    it('should set isBasic to false when null emitted', () => {
      (policyService as any).isBasicMode = of(null);
      (component as any).subscribeToBasicMode();
      expect((component as any).isBasic).toBe(false);
    });

    it('should set isBasic to true when true emitted', () => {
      (policyService as any).isBasicMode = of(true);
      (component as any).subscribeToBasicMode();
      expect((component as any).isBasic).toBe(true);
    });
  });

  describe('subscribeToSaveFormVisibility', () => {
    it('should set isSaveFormVisible from service', () => {
      (policyService as any).isSaveFormVisible = of(true);
      (component as any).subscribeToSaveFormVisibility();
      expect((component as any).isSaveFormVisible).toBe(true);
    });
  });

  describe('getErrorDetails (private)', () => {
    it('should return JSON of violations when detail is parseable with errorDetails', () => {
      const detail = JSON.stringify({
        errorDetails: { violations: [{ title: 'v1' }] },
      });
      commonService.safeParse.and.returnValue({
        errorDetails: { violations: [{ title: 'v1' }] },
      } as any);
      const result = (component as any).getErrorDetails({ detail });
      expect(result).toContain('violations');
    });

    it('should return error string from parsed detail', () => {
      commonService.safeParse.and.returnValue({ error: 'parsed error' } as any);
      const result = (component as any).getErrorDetails({
        detail: '{"error":"parsed error"}',
      });
      expect(result).toBe('parsed error');
    });

    it('should return raw detail string when safeParse returns no error/violations', () => {
      commonService.safeParse.and.returnValue({} as any);
      const result = (component as any).getErrorDetails({
        detail: 'raw detail',
      });
      expect(result).toBe('raw detail');
    });

    it('should return JSON of top-level violations', () => {
      const backendError = { violations: [{ title: 'v1' }] };
      const result = (component as any).getErrorDetails(backendError);
      expect(result).toContain('violations');
    });

    it('should return error string from top-level error field', () => {
      const result = (component as any).getErrorDetails({
        error: 'top-level error',
      });
      expect(result).toBe('top-level error');
    });

    it('should return null when backendError is null', () => {
      const result = (component as any).getErrorDetails(null);
      expect(result).toBeNull();
    });
  });

  describe('extractErrorMessage (private)', () => {
    it('should parse string error and return detail', async () => {
      commonService.safeParse.and.returnValue({
        detail: 'string detail',
      } as any);
      const result = await (component as any).extractErrorMessage({
        error: '{"detail":"string detail"}',
      });
      expect(typeof result).toBe('string');
    });

    it('should return translated error when parsing throws', async () => {
      commonService.safeParse.and.throwError('parse error');
      const result = await (component as any).extractErrorMessage({
        error: 'bad',
      });
      expect(typeof result).toBe('string');
    });

    it('should handle Blob error', async () => {
      const blob = new Blob(['{"error":"blob error"}'], {
        type: 'application/json',
      });
      commonService.safeParse.and.returnValue({ error: 'blob error' } as any);
      const result = await (component as any).extractErrorMessage({
        error: blob,
      });
      expect(typeof result).toBe('string');
    });
  });

  describe('performLintCheck error handling', () => {
    it('should update lint with error message on failure', async () => {
      const code = 'bad rego';
      (policyService.lintCheckRegoData as any).and.returnValue(
        throwError(() => ({ error: '{"error":"lint backend error"}' }))
      );
      commonService.safeParse.and.returnValue({
        error: 'lint backend error',
      } as any);

      (component as any).onCodeChange(code);

      await new Promise(resolve => setTimeout(resolve, 10));

      expect(policyService.updateLint).toHaveBeenCalledWith(
        jasmine.objectContaining({ error: jasmine.any(String) })
      );
    });
  });
});
