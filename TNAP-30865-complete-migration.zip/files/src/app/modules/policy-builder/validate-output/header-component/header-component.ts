/*
 * Copyright (c) 2025. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, OnInit, DestroyRef, input, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { PolicyBuilderService } from '../../shared/policy-builder.service';
import { CommonService } from '../../shared/common.service';
import { EvaluateRego200Response } from 'openapi/output';
import {
  EvalResult,
  ParsedResponse,
} from 'src/app/model/OpaBuilderPolicy.model';
import { SharedModule } from 'src/app/shared.module';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-header-component',
  standalone: true,
  imports: [CommonModule, TranslateModule, SharedModule],
  templateUrl: './header-component.html',
  styleUrl: './header-component.css',
})
export class HeaderComponent implements OnInit {
  private readonly policyService = inject(PolicyBuilderService);
  private readonly commonService = inject(CommonService);
  private readonly alertService = inject(TnapAlertService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly translate = inject(TranslateService);

  protected readonly isEditMode = input(true);
  readonly showHeader = input(true);
  protected isBasic = false;

  ngOnInit(): void {
    this.policyService.isBasicMode
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: isBasic => (this.isBasic = isBasic ?? false),
        error: (err: Error) =>
          this.alertService.error(
            this.translate.instant('policyBuilder.error.loadBasicMode') +
              err.message
          ),
      });
  }

  private formatErrors(parsed: ParsedResponse): string {
    if (parsed?.errors?.length) {
      return parsed.errors
        .map(
          e =>
            `${e.code || 'ERROR'}: ${e.message || 'No message'}\nLine: ${e.location?.row || '-'}, Column: ${e.location?.col || '-'}`
        )
        .join('\n\n');
    }
    return (
      parsed?.error ||
      this.translate.instant('policyBuilder.error.unknownError')
    );
  }

  private extractErrorMessage(err: HttpErrorResponse): string {
    const backendError = this.commonService.safeParse(err.error);
    const detail = backendError?.detail
      ? this.commonService.safeParse(backendError.detail)
      : null;
    return (
      detail?.error ||
      backendError?.detail ||
      backendError?.error ||
      err.message ||
      this.translate.instant('policyBuilder.error.operationFailed')
    );
  }

  private handleError(
    err: HttpErrorResponse,
    updateFn: (msg: EvalResult) => void
  ): void {
    updateFn({ error: this.extractErrorMessage(err) });
  }

  public format(): void {
    this.policyService
      .formatRegoCode()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe();
  }

  protected lintCheck(): void {
    const code = this.policyService.regoCode$();
    if (!code?.trim()) return;
    this.policyService
      .lintCheckRegoData({ source: code })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: res => {
          this.policyService.updateLint({ message: JSON.stringify(res) });
        },
        error: (err: HttpErrorResponse) => {
          const parsed = this.commonService.safeParse(err.error) as Record<
            string,
            unknown
          >;
          const errorDetails = parsed?.['errorDetails'] as
            | Record<string, unknown>
            | undefined;
          if (errorDetails?.['violations']) {
            this.policyService.updateLint({
              message: JSON.stringify(errorDetails),
            });
          } else if (parsed?.['violations']) {
            this.policyService.updateLint({ message: JSON.stringify(parsed) });
          } else {
            this.handleError(err, msg => this.policyService.updateLint(msg));
          }
        },
      });
  }

  public evaluate(): void {
    const code = this.policyService.regoCode$();
    if (!code?.trim()) {
      this.policyService.updateOutput({
        error: this.translate.instant('policyBuilder.error.regoCodeEmpty'),
      });
      return;
    }

    const payload = {
      regoCode: code,
      input: JSON.stringify(this.policyService.getCurrentInput() || {}),
      data: JSON.stringify(this.policyService.getCurrentData() || {}),
    };

    this.policyService
      .evaluatePolicyData(payload)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (res: EvaluateRego200Response) => {
          const parsed = this.commonService.safeParse(res);
          if (parsed?.error || parsed?.errors) {
            this.policyService.updateOutput({
              error: this.formatErrors(parsed),
            });
          } else {
            const value = parsed?.result?.[0]?.expressions?.[0]?.value;
            this.policyService.updateOutput({
              message:
                value !== undefined
                  ? JSON.stringify(value, null, 2)
                  : this.translate.instant('policyBuilder.message.noResult'),
            });
          }
        },
        error: (err: HttpErrorResponse) => {
          this.handleError(err, msg => this.policyService.updateOutput(msg));
        },
      });
  }
}
