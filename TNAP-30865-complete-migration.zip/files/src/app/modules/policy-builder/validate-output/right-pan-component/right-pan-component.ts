/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { CommonModule } from '@angular/common';
import {
  AfterViewInit,
  Component,
  ElementRef,
  OnInit,
  DestroyRef,
  computed,
  inject,
  input,
  signal,
  viewChild,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { CodemirrorModule } from '@ctrl/ngx-codemirror';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { PolicyBuilderService } from '../../shared/policy-builder.service';
import {
  EvalResult,
  LintViolation,
  CodeMirrorEditor,
} from 'src/app/model/OpaBuilderPolicy.model';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-right-pan-component',
  standalone: true,
  imports: [CommonModule, FormsModule, CodemirrorModule, TranslateModule],
  templateUrl: './right-pan-component.html',
  styleUrl: './right-pan-component.css',
})
export class RightPanComponent implements AfterViewInit, OnInit {
  private readonly policyService = inject(PolicyBuilderService);
  private readonly alertService = inject(TnapAlertService);
  private readonly elRef = inject(ElementRef);
  private readonly destroyRef = inject(DestroyRef);
  private readonly translate = inject(TranslateService);
  private _listenersInitialized = false;
  protected inputError: string | undefined;
  readonly isEditMode = input(true);
  readonly isDataEditable = input(true);

  protected readonly editorOptions = {
    lineNumbers: true,
    mode: 'application/json',
    indentWithTabs: false,
    indentUnit: 2,
    tabSize: 2,
    smartIndent: true,
    matchBrackets: true,
    autoCloseBrackets: true,
    lineWrapping: true,
    readOnly: false,
  };

  protected readonly dynamicEditorOptions = computed(() => ({
    ...this.editorOptions,
    readOnly: !this.isEditMode() || !this.isDataEditable(),
  }));

  protected readonly outputEditorOptions = {
    mode: 'application/json',
    lineNumbers: true,
    theme: 'default',
    tabSize: 2,
    readOnly: true,
  };

  protected inputText = '';
  protected dataText = '';
  protected output: string | undefined;
  protected lint: string | undefined;
  protected lintViolations = signal<LintViolation[]>([]);
  protected lintHeader = '';
  protected isLintError = false;
  protected isBasic = false;

  protected readonly dataEditor = viewChild<CodeMirrorEditor>('dataEditor');

  ngOnInit(): void {
    this.subscribeToOutput();
    this.subscribeToLint();
    this.subscribeToBasicMode();
    this.subscribeToInput();
    this.subscribeToData();
  }

  ngAfterViewInit(): void {
    this.initializeResizers();
  }

  protected onInputChange(value: string): void {
    try {
      const parsed = JSON.parse(value || '{}');
      this.policyService.setInput(parsed as Record<string, unknown>);
      this.inputError = undefined;
    } catch {
      this.inputError = this.translate.instant(
        'policyBuilder.error.invalidJsonInput'
      );
    }
  }

  protected onDataChange(value: string): void {
    try {
      const parsed = JSON.parse(value || '{}');
      this.policyService.setData(parsed as Record<string, unknown>);
    } catch (err) {
      console.warn('Invalid JSON data provided:', err);
      this.policyService.setData({});
    }
  }

  protected formatData(): void {
    const parsed = JSON.parse(this.dataText || '{}');
    this.dataText = JSON.stringify(parsed, null, 2);
    const editor = this.dataEditor()?.codeMirror;
    if (editor) {
      editor.refresh();
    }
  }

  protected onLineClick(lineNumber: number): void {
    this.policyService.setHighlightLine(lineNumber);
  }

  private subscribeToOutput(): void {
    this.policyService.output$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: result => {
          this.output =
            result?.error ||
            (typeof result?.message === 'object'
              ? JSON.stringify(result.message, null, 2)
              : result?.message);
        },
        error: (err: Error) => {
          this.alertService.error(
            'Error in output subscription: ' + err.message
          );
          this.output = this.translate.instant(
            'policyBuilder.error.errorRetrievingOutput'
          );
        },
      });
  }

  private subscribeToLint(): void {
    this.policyService.lint$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: result => this.parseLintData(result),
        error: (err: Error) => {
          this.alertService.error('Error in lint subscription: ' + err.message);
          this.resetLintState();
          this.lintHeader = this.translate.instant(
            'policyBuilder.error.errorRetrievingLint'
          );
        },
      });
  }

  private subscribeToBasicMode(): void {
    this.policyService.isBasicMode
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: isBasic => (this.isBasic = isBasic ?? false),
        error: (err: Error) =>
          this.alertService.error(
            'Error in basic mode subscription: ' + err.message
          ),
      });
  }

  private subscribeToData(): void {
    this.policyService.data$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: data => {
          this.dataText = this.formatJson(data);
          const editor = this.dataEditor()?.codeMirror;
          if (editor) {
            editor.refresh();
          }
        },
        error: (err: Error) => {
          this.alertService.error('Error in data subscription: ' + err.message);
          this.dataText = '';
        },
      });
  }

  private subscribeToInput(): void {
    this.policyService.input$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: input => (this.inputText = this.formatJson(input)),
        error: (err: Error) => {
          this.alertService.error(
            this.translate.instant(
              'policyBuilder.error.errorInInputSubscription'
            ) +
              ': ' +
              err.message
          );
          this.inputText = '';
        },
      });
  }

  private formatJson(value: unknown): string {
    if (!value) return '';
    try {
      const parsed = typeof value === 'string' ? JSON.parse(value) : value;
      return JSON.stringify(parsed, null, 2);
    } catch {
      return typeof value === 'string' ? value : '';
    }
  }

  private initializeResizers(): void {
    if (this._listenersInitialized) {
      return;
    }

    (this.elRef.nativeElement as HTMLElement)
      .querySelectorAll('.resizer')
      .forEach(resizer => {
        resizer.addEventListener('mousedown', (e: Event) =>
          this.handleResize(e as MouseEvent, resizer)
        );
      });

    this._listenersInitialized = true;
  }

  private handleResize(e: MouseEvent, resizer: Element): void {
    e.preventDefault();

    const currentSection = resizer.parentElement as HTMLElement;
    const nextSection = currentSection.nextElementSibling as HTMLElement | null;
    if (!nextSection) return;

    const MIN_HEIGHT = 50;
    const startY = e.clientY;
    const startHeightCurrent = currentSection.offsetHeight;
    const startHeightNext = nextSection.offsetHeight;

    const onMouseMove = (moveEvent: MouseEvent) => {
      const deltaY = moveEvent.clientY - startY;
      const newHeightCurrent = startHeightCurrent + deltaY;
      const newHeightNext = startHeightNext - deltaY;

      if (newHeightCurrent > MIN_HEIGHT && newHeightNext > MIN_HEIGHT) {
        currentSection.style.flex = 'none';
        currentSection.style.height = `${newHeightCurrent}px`;
        nextSection.style.flex = 'none';
        nextSection.style.height = `${newHeightNext}px`;
      }
    };

    const onMouseUp = () => {
      globalThis.removeEventListener('mousemove', onMouseMove);
      globalThis.removeEventListener('mouseup', onMouseUp);
    };

    globalThis.addEventListener('mousemove', onMouseMove);
    globalThis.addEventListener('mouseup', onMouseUp);
  }

  private parseLintData(result: EvalResult | null): void {
    this.resetLintState();

    const lintText = result?.error || result?.message || '';
    this.isLintError = !!result?.error;
    this.lint = lintText;

    if (!lintText) return;

    // Try to parse as JSON (both Lint API and Validate API formats)
    try {
      const parsed = JSON.parse(lintText);
      if (typeof parsed === 'object' && parsed !== null) {
        let violations = (parsed as Record<string, unknown>)['violations'];
        if (!Array.isArray(violations)) {
          const errorDetails = (parsed as Record<string, unknown>)[
            'errorDetails'
          ] as Record<string, unknown> | undefined;
          violations = errorDetails?.['violations'];
        }
        if (Array.isArray(violations)) {
          this.parseLintViolationsFromArray(violations);
        } else {
          this.lintHeader = this.translate.instant(
            'policyBuilder.labels.noLintViolations'
          );
        }
        return;
      }
    } catch {
      this.lintHeader = lintText;
    }
  }

  private resetLintState(): void {
    this.lintViolations.set([]);
    this.lintHeader = '';
    this.isLintError = false;
  }

  private parseLintViolationsFromArray(violations: unknown[]): void {
    if (!Array.isArray(violations)) return;

    const parsed = violations
      .filter(v => typeof v === 'object' && v !== null)
      .map(v => this.mapToLintViolation(v as Record<string, unknown>));

    this.lintViolations.set(parsed);
    this.lintHeader = this.buildLintHeader(parsed.length);
  }

  private mapToLintViolation(
    violation: Record<string, unknown>
  ): LintViolation {
    const location = violation['location'] as
      | Record<string, unknown>
      | undefined;
    const category =
      typeof violation['category'] === 'string'
        ? violation['category']
        : 'violation';
    const titleVal =
      typeof violation['title'] === 'string' ? violation['title'] : '';
    const desc =
      typeof violation['description'] === 'string'
        ? violation['description']
        : '';
    const line =
      typeof location?.['row'] === 'number' ? location['row'] : undefined;

    return { title: `${category}/${titleVal}`, description: desc, line };
  }

  private buildLintHeader(count: number): string {
    if (count === 0) {
      return this.translate.instant('policyBuilder.labels.noLintViolations');
    }
    const key =
      count === 1
        ? 'policyBuilder.labels.lintViolation'
        : 'policyBuilder.labels.lintViolations';
    return `${count} ${this.translate.instant(key)}`;
  }
}
