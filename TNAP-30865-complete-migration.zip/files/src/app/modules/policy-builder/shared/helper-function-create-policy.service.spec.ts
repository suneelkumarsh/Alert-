/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { TestBed } from '@angular/core/testing';
import { FormControl } from '@angular/forms';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { HelperFunctionsCreatePolicyService } from './helper-function-create-policy.service';
import {
  Rule,
  GlobalVar,
  Builtin,
  FunctionArg,
  RawFunctionInput,
} from 'src/app/model/OpaBuilderPolicy.model';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('HelperFunctionsCreatePolicyService', () => {
  let service: HelperFunctionsCreatePolicyService;
  let mockAlertService: jasmine.SpyObj<TnapAlertService>;
  let mockTranslateService: jasmine.SpyObj<TranslateService>;

  beforeEach(() => {
    mockAlertService = jasmine.createSpyObj('TnapAlertService', [
      'error',
      'success',
      'warn',
    ]);
    mockTranslateService = jasmine.createSpyObj('TranslateService', [
      'instant',
    ]);
    mockTranslateService.instant.and.callFake((key: string) => key);

    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      providers: [
        HelperFunctionsCreatePolicyService,
        { provide: TnapAlertService, useValue: mockAlertService },
        { provide: TranslateService, useValue: mockTranslateService },
      ],
    });
    service = TestBed.inject(HelperFunctionsCreatePolicyService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('makeNode', () => {
    it('should create a node with given type and value', () => {
      const result = service.makeNode('string', 'test');
      expect(result).toEqual({ type: 'string', value: 'test' });
    });

    it('should handle null value', () => {
      const result = service.makeNode('null', 'null');
      expect(result).toEqual({ type: 'null', value: {} });
    });

    it('should strip surrounding double quotes from string values', () => {
      const result = service.makeNode('string', '"hello"');
      expect(result).toEqual({ type: 'string', value: 'hello' });
    });

    it('should keep value as is when no surrounding quotes', () => {
      const result = service.makeNode('var', 'myVar');
      expect(result).toEqual({ type: 'var', value: 'myVar' });
    });
  });

  describe('getNonLeafNodes', () => {
    it('should return empty array for node without children', () => {
      const node = { hierarchy: 'root', children: [] };
      const result = service.getNonLeafNodes(node);
      expect(result).toEqual([]);
    });

    it('should return non-leaf nodes for tree with children', () => {
      const node = {
        hierarchy: 'root',
        children: [
          { hierarchy: 'child1', children: [] },
          {
            hierarchy: 'child2',
            children: [{ hierarchy: 'grandchild', children: [] }],
          },
        ],
      };
      const result = service.getNonLeafNodes(node);
      expect(result).toContain('root');
      expect(result).toContain('child2');
    });

    it('should handle hierarchy with brackets by stripping them', () => {
      const node = {
        hierarchy: '[root]',
        children: [{ hierarchy: '[child]' }],
      };
      const result = service.getNonLeafNodes(node);
      expect(result).toContain('root');
    });
  });

  describe('getRegoPackage', () => {
    it('should extract package name from valid Rego code', () => {
      const code = 'package mypackage.policy\n\ndefault allow = false';
      const result = service.getRegoPackage(code);
      expect(result).toBe('mypackage.policy');
    });

    it('should return null for code without package declaration', () => {
      const code = 'default allow = false';
      const result = service.getRegoPackage(code);
      expect(result).toBeNull();
    });

    it('should handle package name with underscores', () => {
      const code = 'package my_package_name';
      const result = service.getRegoPackage(code);
      expect(result).toBe('my_package_name');
    });
  });

  describe('policyNameValidator', () => {
    let validator: ReturnType<typeof service.policyNameValidator>;

    beforeEach(() => {
      validator = service.policyNameValidator();
    });

    it('should return null for valid policy name', () => {
      const control = new FormControl('ValidPolicyName');
      const result = validator(control);
      expect(result).toBeNull();
    });

    it('should return null for empty value', () => {
      const control = new FormControl('');
      const result = validator(control);
      expect(result).toBeNull();
    });

    it('should return error when name exceeds 50 characters', () => {
      const control = new FormControl('a'.repeat(51));
      const result = validator(control);
      expect(result).toEqual({
        policyName: 'policyBuilder.error.policyNameLength',
      });
    });

    it('should return error when name does not start with a letter', () => {
      const control = new FormControl('1invalidName');
      const result = validator(control);
      expect(result).toEqual({
        policyName: 'policyBuilder.error.policyNameStart',
      });
    });

    it('should return error for name with invalid characters', () => {
      const control = new FormControl('invalid name!');
      const result = validator(control);
      expect(result).toEqual({ policyName: 'policyBuilder.error.policyName' });
    });

    it('should accept name with dots, underscores, and hyphens', () => {
      const control = new FormControl('valid_policy.name-v1');
      const result = validator(control);
      expect(result).toBeNull();
    });
  });

  describe('validateRightOperandString', () => {
    it('should return true for string with even number of quotes', () => {
      expect(service.validateRightOperandString('"test"')).toBe(true);
      expect(service.validateRightOperandString('"a" and "b"')).toBe(true);
    });

    it('should return false for string with odd number of quotes', () => {
      expect(service.validateRightOperandString('"test')).toBe(false);
      expect(service.validateRightOperandString('"a" and "b')).toBe(false);
    });

    it('should return true for empty string', () => {
      expect(service.validateRightOperandString('')).toBe(true);
    });

    it('should return true for string without quotes', () => {
      expect(service.validateRightOperandString('test')).toBe(true);
    });
  });

  describe('validateEveryBlock', () => {
    it('should return true when everyRuleBlocks is undefined', () => {
      const result = service.validateEveryBlock(undefined);
      expect(result).toBe(true);
    });

    it('should return true when no blocks have isEvery set', () => {
      const rules: Rule[] = [
        {
          name: { type: 'var', value: 'rule1' },
          isEvery: false,
          conditions: [],
        } as unknown as Rule,
      ];
      const result = service.validateEveryBlock(rules);
      expect(result).toBe(true);
    });

    it('should return false for every block without conditions', () => {
      const rules: Rule[] = [
        {
          name: { type: 'var', value: 'everyRule' },
          isEvery: true,
          conditions: [],
          everyRuleBlocks: null,
        } as unknown as Rule,
      ];
      const result = service.validateEveryBlock(rules);
      expect(result).toBe(false);
      expect(mockAlertService.error).toHaveBeenCalled();
    });

    it('should not show alert when silent flag is true', () => {
      const rules: Rule[] = [
        {
          name: { type: 'var', value: 'everyRule' },
          isEvery: true,
          conditions: [],
          everyRuleBlocks: null,
        } as unknown as Rule,
      ];
      service.validateEveryBlock(rules, true);
      expect(mockAlertService.error).not.toHaveBeenCalled();
    });
  });

  describe('checkForRules', () => {
    it('should return true for rules without errors', () => {
      const rules: Rule[] = [
        { isFunction: true, valueError: '', error: '' } as unknown as Rule,
        { isFunction: false, valueError: '', error: '' } as unknown as Rule,
      ];
      const result = service.checkForRules(rules);
      expect(result).toBe(true);
    });

    it('should return false for function rule with valueError', () => {
      const rules: Rule[] = [
        {
          isFunction: true,
          valueError: 'some error',
          error: '',
        } as unknown as Rule,
      ];
      const result = service.checkForRules(rules);
      expect(result).toBe(false);
    });

    it('should return false for function rule with error', () => {
      const rules: Rule[] = [
        {
          isFunction: true,
          valueError: '',
          error: 'another error',
        } as unknown as Rule,
      ];
      const result = service.checkForRules(rules);
      expect(result).toBe(false);
    });
  });

  describe('isObjectLiteral', () => {
    it('should return true for object literal with colon', () => {
      expect(service.isObjectLiteral('{key: value}')).toBe(true);
      expect(service.isObjectLiteral('{"name": "test"}')).toBe(true);
    });

    it('should return false for set literal without colon', () => {
      expect(service.isObjectLiteral('{1, 2, 3}')).toBe(false);
    });

    it('should return true for empty braces', () => {
      expect(service.isObjectLiteral('{}')).toBe(true);
    });

    it('should handle nested structures', () => {
      expect(service.isObjectLiteral('{outer: {inner: val}}')).toBe(true);
    });
  });

  describe('parseObjectLiteral', () => {
    it('should parse simple key-value pairs', () => {
      const result = service.parseObjectLiteral('{key: value}');
      expect(result.length).toBe(1);
      expect(result[0][0]).toEqual({ type: 'var', value: 'key' });
    });

    it('should parse quoted keys as strings', () => {
      const result = service.parseObjectLiteral('{"key": value}');
      expect(result[0][0]).toEqual({ type: 'string', value: 'key' });
    });

    it('should return empty array for empty object', () => {
      const result = service.parseObjectLiteral('{}');
      expect(result).toEqual([]);
    });
  });

  describe('normalizeInlineValue', () => {
    it('should return number node for numeric string', () => {
      const result = service.normalizeInlineValue('42');
      expect(result).toEqual({ type: 'number', value: 42 });
    });

    it('should return string node for quoted string', () => {
      const result = service.normalizeInlineValue('"hello"');
      expect(result).toEqual({ type: 'string', value: 'hello' });
    });

    it('should handle single-quoted strings', () => {
      const result = service.normalizeInlineValue("'world'");
      expect(result).toEqual({ type: 'string', value: 'world' });
    });

    it('should return var node for identifier', () => {
      const result = service.normalizeInlineValue('myVar');
      expect(result).toEqual({ type: 'var', value: 'myVar' });
    });
  });

  describe('parseSetLiteral', () => {
    it('should parse numeric set elements', () => {
      const result = service.parseSetLiteral('{1, 2, 3}');
      expect(result.length).toBe(3);
      expect(result[0]).toEqual({ type: 'number', value: 1 });
    });

    it('should parse string set elements', () => {
      const result = service.parseSetLiteral('{"a", "b"}');
      expect(result.length).toBe(2);
      expect(result[0]).toEqual({ type: 'string', value: 'a' });
    });

    it('should return empty array for empty set', () => {
      const result = service.parseSetLiteral('{}');
      expect(result).toEqual([]);
    });
  });

  describe('extractBracketValues', () => {
    it('should extract values from single bracket', () => {
      const result = service.extractBracketValues('array[0]');
      expect(result).toEqual(['0']);
    });

    it('should extract values from multiple brackets', () => {
      const result = service.extractBracketValues('data[0][key]');
      expect(result).toEqual(['0', 'key']);
    });

    it('should return empty array when no brackets', () => {
      const result = service.extractBracketValues('simple');
      expect(result).toEqual([]);
    });
  });

  describe('buildRefFromKey', () => {
    it('should build ref from simple key', () => {
      const result = service.buildRefFromKey('input.data');
      expect(result.length).toBe(2);
      expect(result[0]).toEqual({ type: 'var', value: 'input' });
      expect(result[1]).toEqual({ type: 'string', value: 'data' });
    });

    it('should handle brackets in key', () => {
      const result = service.buildRefFromKey('array[idx]');
      expect(result.length).toBe(2);
      expect(result[0]).toEqual({ type: 'var', value: 'array' });
      expect(result[1]).toEqual({ type: 'var', value: 'idx' });
    });
  });

  describe('toFunctionArg', () => {
    it('should convert raw input to function arg', () => {
      const input: RawFunctionInput = { value: ' test ', subArgs: [] };
      const result = service.toFunctionArg(input);
      expect(result.value).toBe('test');
      expect(result.error).toBe('');
    });

    it('should handle nested subArgs', () => {
      const input: RawFunctionInput = {
        value: 'outer',
        subArgs: [{ value: 'inner', subArgs: [] }],
      };
      const result = service.toFunctionArg(input);
      expect(result.args?.length).toBe(1);
      expect(result.args?.[0].value).toBe('inner');
    });
  });

  describe('toBuiltinFunction', () => {
    it('should return FunctionArg for input without subArgs', () => {
      const input: RawFunctionInput = { value: 'simple', subArgs: [] };
      const result = service.toBuiltinFunction(input);
      expect(result.length).toBe(1);
      expect((result[0] as FunctionArg).value).toBe('simple');
    });

    it('should return Builtin for input with subArgs', () => {
      const input: RawFunctionInput = {
        value: 'count',
        subArgs: [{ value: 'arr', subArgs: [] }],
      };
      const result = service.toBuiltinFunction(input);
      expect(result.length).toBe(1);
      expect((result[0] as Builtin).name).toBe('count');
      expect((result[0] as Builtin).type).toBe('builtin');
    });
  });

  describe('enclosesWholeExpression', () => {
    it('should return true for fully enclosed expression', () => {
      expect(service.enclosesWholeExpression('(a + b)')).toBe(true);
      expect(service.enclosesWholeExpression('((a))')).toBe(true);
    });

    it('should return false for partially enclosed expression', () => {
      expect(service.enclosesWholeExpression('(a) + (b)')).toBe(false);
    });

    it('should return false for expression not starting with paren', () => {
      expect(service.enclosesWholeExpression('a + b')).toBe(false);
    });
  });

  describe('scanOperatorfromRightToLeft', () => {
    it('should find lowest precedence operator at correct position', () => {
      const ctx = {
        bestPos: -1,
        bestOp: '',
        val: '1 + 2 * 3',
        precedence: { '+': 1, '-': 1, '*': 2, '/': 2 },
        bestPrec: Infinity,
      };
      const [, op] = service.scanOperatorfromRightToLeft(ctx);
      expect(op).toBe('+');
    });

    it('should ignore operators inside parentheses', () => {
      const ctx = {
        bestPos: -1,
        bestOp: '',
        val: '(1 + 2) * 3',
        precedence: { '+': 1, '-': 1, '*': 2, '/': 2 },
        bestPrec: Infinity,
      };
      const [, op] = service.scanOperatorfromRightToLeft(ctx);
      expect(op).toBe('*');
    });
  });

  describe('stripPackageLine', () => {
    it('should preserve text and trim', () => {
      const input = '  package test  ';
      const result = service.stripPackageLine(input);
      expect(result).toBe('package test');
    });

    it('should handle multiline text', () => {
      const input = 'line1\nline2\nline3';
      const result = service.stripPackageLine(input);
      expect(result).toBe('line1\nline2\nline3');
    });
  });

  describe('generateBuiltInAST', () => {
    it('should generate call node for builtin function', () => {
      const builtin: Builtin = {
        name: 'count',
        args: [{ value: 'arr', error: '' }],
        argNames: ['value1'],
        type: 'builtin',
        error: '',
      };
      const result = service.generateBuiltInAST(builtin);
      expect(result.type).toBe('call');
    });

    it('should generate string node for quoted value', () => {
      const arg: FunctionArg = { value: '"hello"', error: '' };
      const result = service.generateBuiltInAST(arg);
      expect(result).toEqual({ type: 'string', value: 'hello' });
    });

    it('should generate number node for numeric value', () => {
      const arg: FunctionArg = { value: '42', error: '' };
      const result = service.generateBuiltInAST(arg);
      expect(result).toEqual({ type: 'number', value: 42 });
    });

    it('should generate boolean node for boolean value', () => {
      const argTrue: FunctionArg = { value: 'true', error: '' };
      const argFalse: FunctionArg = { value: 'false', error: '' };
      expect(service.generateBuiltInAST(argTrue)).toEqual({
        type: 'boolean',
        value: true,
      });
      expect(service.generateBuiltInAST(argFalse)).toEqual({
        type: 'boolean',
        value: false,
      });
    });
  });

  describe('splitTopLevel', () => {
    it('should split on delimiter at top level', () => {
      const result = service.splitTopLevel('a,b,c', ',');
      expect(result).toEqual(['a', 'b', 'c']);
    });

    it('should not split inside brackets', () => {
      const result = service.splitTopLevel('[a,b],c', ',');
      expect(result).toEqual(['[a,b]', 'c']);
    });

    it('should not split inside braces', () => {
      const result = service.splitTopLevel('{a,b},c', ',');
      expect(result).toEqual(['{a,b}', 'c']);
    });

    it('should handle parentheses', () => {
      const result = service.splitTopLevel('(a,b),c', ',');
      expect(result).toEqual(['(a,b)', 'c']);
    });
  });

  describe('getType', () => {
    it('should return "null" for null value', () => {
      expect(service.getType('null')).toBe('null');
    });

    it('should return "number" for numeric value', () => {
      expect(service.getType('42')).toBe('number');
    });

    it('should return "boolean" for boolean value', () => {
      expect(service.getType('true')).toBe('boolean');
    });

    it('should return "string" for string value', () => {
      expect(service.getType('"test"')).toBe('string');
    });

    it('should return "array" for array value', () => {
      expect(service.getType('[1,2,3]')).toBe('array');
    });

    it('should return "var" for non-JSON value', () => {
      expect(service.getType('someVar')).toBe('var');
    });
  });

  describe('getValue', () => {
    it('should return parsed value for valid JSON', () => {
      expect(service.getValue('42')).toBe(42 as unknown as string);
      expect(service.getValue('"test"')).toBe('test');
    });

    it('should return "null" string for null', () => {
      expect(service.getValue('null')).toBe('null');
    });

    it('should return original value for non-JSON', () => {
      expect(service.getValue('myVar')).toBe('myVar');
    });
  });

  describe('splitKeyValue', () => {
    it('should split key and value correctly', () => {
      const [key, value] = service.splitKeyValue('name: "test"');
      expect(key).toBe('name');
      expect(value).toBe('"test"');
    });

    it('should handle nested structures in value', () => {
      const [key, value] = service.splitKeyValue('data: {inner: val}');
      expect(key).toBe('data');
      expect(value).toBe('{inner: val}');
    });

    it('should throw error for invalid entry without colon', () => {
      expect(() => service.splitKeyValue('invalidEntry')).toThrowError();
    });
  });

  describe('isWrappedInBrackets', () => {
    it('should return true for bracketed string', () => {
      expect(service.isWrappedInBrackets('[test]')).toBe(true);
    });

    it('should return false for non-bracketed string', () => {
      expect(service.isWrappedInBrackets('test')).toBe(false);
    });

    it('should return false for string with only opening bracket', () => {
      expect(service.isWrappedInBrackets('[test')).toBe(false);
    });

    it('should return false for short strings', () => {
      expect(service.isWrappedInBrackets('[')).toBe(false);
    });
  });

  describe('isValidIdentifier', () => {
    it('should return true for valid identifiers', () => {
      expect(service.isValidIdentifier('myVar')).toBe(true);
      expect(service.isValidIdentifier('_private')).toBe(true);
      expect(service.isValidIdentifier('var123')).toBe(true);
    });

    it('should return false for identifier starting with number', () => {
      expect(service.isValidIdentifier('123var')).toBe(false);
    });

    it('should return false for empty string', () => {
      expect(service.isValidIdentifier('')).toBe(false);
    });

    it('should return false for identifier with special characters', () => {
      expect(service.isValidIdentifier('my-var')).toBe(false);
      expect(service.isValidIdentifier('my.var')).toBe(false);
    });
  });

  describe('containsOperator', () => {
    it('should return true for strings containing arithmetic operators', () => {
      expect(service.containsOperator('a + b')).toBe(true);
      expect(service.containsOperator('a - b')).toBe(true);
      expect(service.containsOperator('a * b')).toBe(true);
      expect(service.containsOperator('a / b')).toBe(true);
    });

    it('should return true for strings containing parentheses', () => {
      expect(service.containsOperator('(a)')).toBe(true);
    });

    it('should return false for strings without operators', () => {
      expect(service.containsOperator('simple')).toBe(false);
    });
  });

  describe('getValueForGlobalVarArray', () => {
    it('should return empty array for non-array value', () => {
      const variable: GlobalVar = {
        key: 'test',
        value: 'notAnArray',
        type: 'array',
        isTypeDisabled: false,
      };
      const result = service.getValueForGlobalVarArray(variable, 0);
      expect(result.type).toBe('array');
      expect(result.value).toEqual([]);
    });

    it('should return empty array for empty array literal', () => {
      const variable: GlobalVar = {
        key: 'test',
        value: '[]',
        type: 'array',
        isTypeDisabled: false,
      };
      const result = service.getValueForGlobalVarArray(variable, 0);
      expect(result.type).toBe('array');
      expect(result.value).toEqual([]);
    });

    it('should parse array with elements', () => {
      const variable: GlobalVar = {
        key: 'test',
        value: '[1, 2, 3]',
        type: 'array',
        isTypeDisabled: false,
      };
      const result = service.getValueForGlobalVarArray(variable, 0);
      expect(result.type).toBe('array');
      expect((result.value as unknown[]).length).toBe(3);
    });
  });

  describe('getValueForGlobalVarSet', () => {
    it('should return empty set for invalid format', () => {
      const variable: GlobalVar = {
        key: 'test',
        value: 'notASet',
        type: 'set',
        isTypeDisabled: false,
      };
      const result = service.getValueForGlobalVarSet(variable, 0);
      expect(result.type).toBe('set');
      expect(result.value).toEqual([]);
    });

    it('should return empty set for empty braces', () => {
      const variable: GlobalVar = {
        key: 'test',
        value: '{}',
        type: 'set',
        isTypeDisabled: false,
      };
      const result = service.getValueForGlobalVarSet(variable, 0);
      expect(result.type).toBe('set');
      expect(result.value).toEqual([]);
    });

    it('should parse set with elements', () => {
      const variable: GlobalVar = {
        key: 'test',
        value: '{1, 2, 3}',
        type: 'set',
        isTypeDisabled: false,
      };
      const result = service.getValueForGlobalVarSet(variable, 0);
      expect(result.type).toBe('set');
    });
  });

  describe('createHeadPartFromTemplate', () => {
    it('should create head part with given key and value', () => {
      const value = { type: 'string', value: 'test' };
      const result = service.createHeadPartFromTemplate('myKey', value);
      expect(result.head.name).toBe('myKey');
      expect(result.head.value).toEqual(value);
      expect(result.head.ref[0].value).toBe('myKey');
    });
  });

  describe('setTemplateVal', () => {
    it('should return modified template when value is false and not isOtherwise', () => {
      const template: Record<string, unknown> = {};
      const value = { type: 'boolean', value: false };
      const result = service.setTemplateVal(template, value, false);
      expect(result.assign).toBe(true);
    });

    it('should return original template when value is not false', () => {
      const template: Record<string, unknown> = { original: true };
      const value = { type: 'boolean', value: true };
      const result = service.setTemplateVal(template, value, false);
      expect(result.original).toBe(true);
    });

    it('should return original template when isOtherwise is true', () => {
      const template: Record<string, unknown> = { original: true };
      const value = { type: 'boolean', value: false };
      const result = service.setTemplateVal(template, value, true);
      expect(result.original).toBe(true);
    });
  });

  describe('parseOperandAndAppendAST', () => {
    it('should handle underscore placeholder', () => {
      const ctx = {
        expr: '_',
        flags: { indexInc: 0, arrayCounter: 0 },
        isArray: false,
        operator: '',
        dollarIndex: 5,
      };
      const result = service.parseOperandAndAppendAST(ctx);
      expect(result.type).toBe('var');
      expect(result.value).toBe('$5');
    });

    it('should parse array expression', () => {
      const ctx = {
        expr: '[1, 2]',
        flags: { indexInc: 0, arrayCounter: 0 },
        isArray: false,
        operator: '',
        dollarIndex: 0,
      };
      const result = service.parseOperandAndAppendAST(ctx);
      expect(result.type).toBe('array');
    });

    it('should parse quoted string', () => {
      const ctx = {
        expr: '"hello"',
        flags: { indexInc: 0, arrayCounter: 0 },
        isArray: false,
        operator: '',
        dollarIndex: 0,
      };
      const result = service.parseOperandAndAppendAST(ctx);
      expect(result).toEqual({ type: 'string', value: 'hello' });
    });

    it('should parse boolean true', () => {
      const ctx = {
        expr: 'true',
        flags: { indexInc: 0, arrayCounter: 0 },
        isArray: false,
        operator: '',
        dollarIndex: 0,
      };
      const result = service.parseOperandAndAppendAST(ctx);
      expect(result).toEqual({ type: 'boolean', value: true });
    });

    it('should parse number', () => {
      const ctx = {
        expr: '42',
        flags: { indexInc: 0, arrayCounter: 0 },
        isArray: false,
        operator: '',
        dollarIndex: 0,
      };
      const result = service.parseOperandAndAppendAST(ctx);
      expect(result).toEqual({ type: 'number', value: 42 });
    });
  });

  describe('NODE_TEMPLATES', () => {
    it('should have NODE_TEMPLATES defined', () => {
      expect(service.NODE_TEMPLATES).toBeDefined();
    });
  });

  describe('getValueForGlobalVar', () => {
    it('should return string node for string type', () => {
      const variable: GlobalVar = {
        key: 'k',
        value: '"hello"',
        type: 'string',
        default: false,
        isTypeDisabled: false,
      };
      const result = service.getValueForGlobalVar(variable, 0);
      expect(result).toBeDefined();
    });

    it('should return boolean node for boolean type true', () => {
      const variable: GlobalVar = {
        key: 'k',
        value: 'true',
        type: 'boolean',
        default: false,
        isTypeDisabled: false,
      };
      const result = service.getValueForGlobalVar(variable, 0);
      expect(result.type).toBe('boolean');
    });

    it('should return boolean node for boolean type false', () => {
      const variable: GlobalVar = {
        key: 'k',
        value: 'false',
        type: 'boolean',
        default: false,
        isTypeDisabled: false,
      };
      const result = service.getValueForGlobalVar(variable, 0);
      expect(result.type).toBe('boolean');
    });

    it('should return null node for null type', () => {
      const variable: GlobalVar = {
        key: 'k',
        value: 'null',
        type: 'null',
        default: false,
        isTypeDisabled: false,
      };
      const result = service.getValueForGlobalVar(variable, 0);
      expect(result.type).toBe('null');
    });

    it('should return array node for array type', () => {
      const variable: GlobalVar = {
        key: 'k',
        value: '[1,2,3]',
        type: 'array',
        default: false,
        isTypeDisabled: false,
      };
      const result = service.getValueForGlobalVar(variable, 0);
      expect(result.type).toBe('array');
    });

    it('should return set node for set type', () => {
      const variable: GlobalVar = {
        key: 'k',
        value: '{1, 2}',
        type: 'set',
        default: false,
        isTypeDisabled: false,
      };
      const result = service.getValueForGlobalVar(variable, 0);
      expect(result.type).toBe('set');
    });

    it('should return number node for number type', () => {
      const variable: GlobalVar = {
        key: 'k',
        value: '42',
        type: 'number',
        default: false,
        isTypeDisabled: false,
      };
      const result = service.getValueForGlobalVar(variable, 0);
      expect(result.type).toBe('number');
    });

    it('should handle unknown type as string fallback', () => {
      const variable: GlobalVar = {
        key: 'k',
        value: 'someVal',
        type: 'other',
        default: false,
        isTypeDisabled: false,
      };
      const result = service.getValueForGlobalVar(variable, 0);
      expect(result).toBeDefined();
    });
  });

  describe('getValueForGlobalVarNumeric', () => {
    it('should return number node for simple numeric value', () => {
      const variable: GlobalVar = {
        key: 'k',
        value: '99',
        type: 'number',
        default: false,
        isTypeDisabled: false,
      };
      const result = service.getValueForGlobalVarNumeric(variable, 0);
      expect(result.type).toBe('number');
      expect(result.value as unknown as number).toBe(99);
    });
  });

  describe('getValueForVarNumeric', () => {
    it('should return number node for plain integer string', () => {
      const result = service.getValueForVarNumeric('42', 0);
      expect(result.type).toBe('number');
      expect(result.value as unknown as number).toBe(42);
    });

    it('should return number node for float string', () => {
      const result = service.getValueForVarNumeric('3.14', 0);
      expect(result.type).toBe('number');
    });

    it('should handle simple arithmetic expression', () => {
      const result = service.getValueForVarNumeric('1 + 2', 0);
      expect(result.type).toBe('call');
    });

    it('should handle parenthesized expression', () => {
      const result = service.getValueForVarNumeric('(42)', 0);
      expect(result.type).toBe('number');
    });
  });

  describe('getValueForGlobalVarJSON', () => {
    it('should return object node for valid JSON object string', () => {
      const variable: GlobalVar = {
        key: 'k',
        value: '{"a":"b"}',
        type: 'JSON',
        default: false,
        isTypeDisabled: false,
      };
      const result = service.getValueForGlobalVarJSON(variable, 0);
      expect(result.type).toBe('object');
    });

    it('should throw error for invalid JSON format (not braces)', () => {
      const variable: GlobalVar = {
        key: 'k',
        value: 'notJson',
        type: 'JSON',
        default: false,
        isTypeDisabled: false,
      };
      expect(() => service.getValueForGlobalVarJSON(variable, 0)).toThrow();
    });
  });

  describe('getTempBasedOnPos', () => {
    it('should return call node for arithmetic context', () => {
      const precedence: Record<string, number> = {
        '+': 1,
        '-': 1,
        '*': 2,
        '/': 2,
        '%': 2,
      };
      const ctx = {
        bestPos: 2,
        bestOp: '+',
        val: '1 + 2',
        precedence,
        bestPrec: 1,
      };
      const result = service.getTempBasedOnPos(ctx);
      expect(result?.type).toBe('call');
    });

    it('should return undefined when bestPos is -1', () => {
      const precedence: Record<string, number> = { '+': 1 };
      const ctx = {
        bestPos: -1,
        bestOp: '',
        val: 'noOp',
        precedence,
        bestPrec: Infinity,
      };
      const result = service.getTempBasedOnPos(ctx);
      expect(result).toBeUndefined();
    });
  });

  describe('parseOperandAndAppendAST - additional branches', () => {
    const makeCtx = (expr: string, operator = '') => ({
      expr,
      flags: { indexInc: 0, arrayCounter: 0 },
      isArray: false,
      operator,
      dollarIndex: 0,
    });

    it('should parse boolean false', () => {
      const result = service.parseOperandAndAppendAST(makeCtx('false'));
      expect(result).toEqual({ type: 'boolean', value: false });
    });

    it('should parse arithmetic expression', () => {
      const result = service.parseOperandAndAppendAST(makeCtx('1 + 2'));
      expect(result.type).toBe('call');
    });

    it('should parse simple identifier as var', () => {
      const result = service.parseOperandAndAppendAST(makeCtx('myVar'));
      expect(result.type).toBe('var');
      expect(result.value).toBe('myVar');
    });

    it('should parse dotted path as ref', () => {
      const result = service.parseOperandAndAppendAST(makeCtx('input.user'));
      expect(result.type).toBe('ref');
    });

    it('should parse object expression as object', () => {
      const result = service.parseOperandAndAppendAST(makeCtx('{"key":"val"}'));
      expect(result.type).toBe('object');
    });

    it('should parse set expression as set', () => {
      const result = service.parseOperandAndAppendAST(makeCtx('{1, 2}'));
      expect(result.type).toBe('set');
    });
  });

  describe('getTemplateForSortedOper', () => {
    it('should return template for expression with in operator', () => {
      const ctx = {
        expr: 'x in {1, 2}',
        flags: { indexInc: 0, arrayCounter: 0 },
        operator: 'in',
        dollarIndex: 0,
      };
      const result = service.getTemplateForSortedOper(ctx);
      expect(result).not.toBeNull();
    });

    it('should return null for expression without operators', () => {
      const ctx = {
        expr: 'simpleExpr',
        flags: { indexInc: 0, arrayCounter: 0 },
        operator: '',
        dollarIndex: 0,
      };
      const result = service.getTemplateForSortedOper(ctx);
      expect(result).toBeNull();
    });
  });

  describe('parseRef', () => {
    it('should parse simple variable name', () => {
      const ctx = {
        str: 'myVar',
        counterFlag: { i: 0 },
        flags: { indexInc: 0, arrayCounter: 0 },
        isArray: false,
        operator: '',
        dollarIndex: 0,
      };
      const result = service.parseRef(ctx);
      expect(result).toBeDefined();
    });

    it('should parse dotted path into ref', () => {
      const ctx = {
        str: 'input.user.name',
        counterFlag: { i: 0 },
        flags: { indexInc: 0, arrayCounter: 0 },
        isArray: false,
        operator: '',
        dollarIndex: 0,
      };
      const result = service.parseRef(ctx);
      expect(result.type).toBe('ref');
    });

    it('should parse bracket access', () => {
      const ctx = {
        str: 'arr[0]',
        counterFlag: { i: 0 },
        flags: { indexInc: 0, arrayCounter: 0 },
        isArray: false,
        operator: '',
        dollarIndex: 0,
      };
      const result = service.parseRef(ctx);
      expect(result).toBeDefined();
    });
  });

  describe('generateBuiltInAST - additional', () => {
    it('should return empty string node for empty value', () => {
      const arg: FunctionArg = { value: '', error: '' };
      const result = service.generateBuiltInAST(arg);
      expect(result).toEqual({ type: 'string', value: '' });
    });
  });
});
