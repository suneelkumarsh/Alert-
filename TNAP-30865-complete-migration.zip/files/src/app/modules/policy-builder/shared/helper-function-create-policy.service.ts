/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Injectable, inject } from '@angular/core';
import * as CONST from 'src/app/model/OpaBuilderPolicy.model';
import { AbstractControl, ValidationErrors } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { RuleBlockComponent } from '../rule-block/rule-block.component';
import {
  AstNode,
  Builtin,
  ExprParseContext,
  FunctionArg,
  GlobalVar,
  NumericParseContext,
  ObjectTypeParseContext,
  ParseContext,
  RawFunctionInput,
  RefParseContext,
  RegoRule,
  RuleBody,
  RuleHead,
  Rule,
} from 'src/app/model/OpaBuilderPolicy.model';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Injectable({
  providedIn: 'root',
})
export class HelperFunctionsCreatePolicyService {
  private readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);
  readonly NODE_TEMPLATES = CONST.createNodeTemplates(this.makeNode.bind(this));

  makeNode(type: string, value: unknown): AstNode {
    if (value === 'null') {
      return { type: 'null', value: {} };
    }
    const normalizedValue =
      typeof value === 'string' && value.startsWith('"') && value.endsWith('"')
        ? value.slice(1, -1)
        : value;
    return { type, value: normalizedValue };
  }

  getNonLeafNodes(node: { hierarchy: string; children?: unknown[] }): string[] {
    let nodes: string[] = [];
    if (node?.children && node.children.length > 0) {
      nodes.push(node.hierarchy.replace(/\[|\]/g, ''));
      node.children.forEach((child: unknown) => {
        nodes = nodes.concat(
          this.getNonLeafNodes(
            child as { hierarchy: string; children?: unknown[] }
          )
        );
      });
    }
    return nodes;
  }

  getRegoPackage(code: string): string | null {
    const match = code.match(CONST.PACKAGE_REGEX);
    return match ? match[1] : null;
  }

  /**
   * Validates policy name format and length
   * @returns Validation errors or null if valid
   */
  policyNameValidator() {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = control.value;
      if (!value) return null;
      if (value.length > 50) {
        return {
          policyName: this.translateService.instant(
            'policyBuilder.error.policyNameLength'
          ),
        };
      }
      if (!/^[A-Za-z]/.test(value)) {
        return {
          policyName: this.translateService.instant(
            'policyBuilder.error.policyNameStart'
          ),
        };
      }
      if (!CONST.POLICY_NAME_REGEX.test(value)) {
        return {
          policyName: this.translateService.instant(
            'policyBuilder.error.policyName'
          ),
        };
      }
      return null;
    };
  }

  validateRightOperandString(value: string): boolean {
    const trimmed = value.trim();
    const quoteCount = (trimmed.match(/"/g) || []).length;
    if (quoteCount % 2 !== 0) {
      return false;
    }
    return true;
  }

  validateEveryBlock(
    everyRuleBlocks?: Rule[],
    silent?: boolean | false
  ): boolean {
    if (everyRuleBlocks && everyRuleBlocks.some(b => b.isEvery)) {
      for (const everyBlock of everyRuleBlocks || []) {
        if (
          everyBlock.conditions === null ||
          everyBlock.conditions.length === 0 ||
          (everyBlock.everyRuleBlocks != null &&
            everyBlock.everyRuleBlocks.length > 0)
        ) {
          if (!silent) {
            this.alertService.error(
              this.translateService.instant(
                'policyBuilder.error.everyBlockNeedsCondition',
                { name: everyBlock.name.value }
              )
            );
          }
          return false;
        }
      }
    }
    return true;
  }

  checkForRules(rules: Rule[]): boolean {
    for (const rule of rules) {
      if (
        rule.isFunction &&
        ((rule.valueError && rule.valueError.trim() !== '') ||
          (rule.error && rule.error.trim() !== ''))
      ) {
        return false;
      }
    }
    return true;
  }

  isValidCondition(block: RuleBlockComponent): boolean {
    let result = true;
    const conditionRows = block.conditionRows();
    if (!conditionRows || conditionRows.length === 0) {
      return true;
    }
    for (const row of conditionRows) {
      if (!this.validateRightOperandString(row.condition().rightOperand)) {
        result = false;
      }
      if (!this.validateEveryBlock(row.condition().everyRuleBlocks)) {
        result = false;
      }
    }
    return result;
  }

  validateOtherwiseConditions(rules: Rule[]): void {
    let lastNormalRuleIndex = -1;
    for (let i = rules.length - 1; i >= 0; i--) {
      if (!rules[i].isOtherwise) {
        lastNormalRuleIndex = i;
        break;
      }
    }
    if (lastNormalRuleIndex === -1) {
      return;
    }
    for (let i = 0; i < rules.length; i++) {
      const rule = rules[i];
      if (rule.isOtherwise) {
        const nextIsAlsoOtherwise =
          i + 1 < rules.length && rules[i + 1].isOtherwise;
        const isLastOtherwise = !nextIsAlsoOtherwise || i === rules.length - 1;

        if (!isLastOtherwise && rule.conditions.length === 0) {
          this.alertService.error(
            this.translateService.instant(
              'policyBuilder.error.otherwiseNeedsCondition',
              { ruleName: rule.name.value }
            )
          );
          throw new Error(
            this.translateService.instant(
              'policyBuilder.error.invalidOtherwiseRule',
              { index: i }
            )
          );
        }
      }
    }
  }

  getLastNormalRule(
    lastNormalRule: RegoRule,
    body: RuleBody[],
    head: RuleHead,
    rules: RegoRule[]
  ) {
    let target = lastNormalRule;
    let parent: RegoRule | null = null;
    while (target.else) {
      parent = target;
      target = target.else;
    }
    const newElse: RegoRule = {
      body: body,
      else: undefined,
      head: head,
    };
    const rebuilt: RegoRule = {
      body: target.body,
      else: newElse,
      head: target.head,
    };
    if (parent) {
      parent.else = rebuilt;
    } else {
      rules[rules.indexOf(lastNormalRule)] = rebuilt;
      lastNormalRule = rebuilt;
    }
  }

  createHeadPartFromTemplate(key: string, value: AstNode): { head: RuleHead } {
    const template = JSON.parse(JSON.stringify(CONST.HEAD_PART_TEMPLATE));
    template.head.name = key;
    template.head.value = value;
    template.head.ref[0].value = key;
    return template;
  }

  setTemplateVal(
    template: Record<string, unknown>,
    value: AstNode,
    isOtherwise: boolean
  ): Record<string, unknown> {
    if (value?.value === false && !isOtherwise) {
      template = JSON.parse(JSON.stringify(CONST.TEMPLATE_ASSIGN));
      template.assign = true;
    }
    return template;
  }

  isObjectLiteral(str: string): boolean {
    const inner = str.slice(1, -1).trim();
    if (!inner) return true;

    let depth = 0;
    for (let i = 0; i < inner.length; i++) {
      const ch = inner[i];
      if (ch === CONST.OPEN_BRACE || ch === '[' || ch === '(') depth++;
      if (ch === CONST.CLOSE_BRACE || ch === ']' || ch === ')') depth--;
      if (ch === ':' && depth === 0) {
        return true;
      }
    }
    return false;
  }

  parseObjectLiteral(objStr: string): [AstNode, AstNode][] {
    const inner = objStr.slice(1, -1).trim();
    if (!inner) return [];

    const pairs: string[] = [];
    let depth = 0;
    let last = 0;

    for (let i = 0; i < inner.length; i++) {
      const c = inner.charCodeAt(i);

      if (c === 123) depth++;
      else if (c === 125) depth--;
      else if (c === 44 && depth === 0) {
        pairs.push(inner.slice(last, i).trim());
        last = i + 1;
      }
    }

    pairs.push(inner.slice(last).trim());

    return pairs.map(pair => {
      const idx = pair.indexOf(':');
      const parts =
        idx === -1
          ? [pair.trim()]
          : [pair.slice(0, idx).trim(), pair.slice(idx + 1).trim()];

      const [rawKey, rawVal] = parts;

      const key = rawKey.trim();
      const value = rawVal.trim();

      const keyTerm =
        (key.startsWith('"') && key.endsWith('"')) ||
        (key.startsWith("'") && key.endsWith("'"))
          ? { type: 'string', value: key.slice(1, -1) }
          : { type: 'var', value: key };

      return [keyTerm, this.normalizeInlineValue(value)];
    });
  }

  normalizeInlineValue(val: string): AstNode {
    const v = val.trim();

    if (!isNaN(Number(v))) {
      return { type: 'number', value: Number(v) };
    }

    if (
      (v.startsWith('"') && v.endsWith('"')) ||
      (v.startsWith("'") && v.endsWith("'"))
    ) {
      return { type: 'string', value: v.slice(1, -1) };
    }

    if (v.startsWith(CONST.OPEN_BRACE) && v.endsWith(CONST.CLOSE_BRACE)) {
      return this.isObjectLiteral(v)
        ? { type: 'object', value: this.parseObjectLiteral(v) }
        : { type: 'set', value: this.parseSetLiteral(v) };
    }

    return { type: 'var', value: v };
  }

  parseSetLiteral(setStr: string): AstNode[] {
    const inner = setStr.slice(1, -1).trim();
    if (!inner) return [];

    return inner.split(',').map(item => {
      const v = item.trim();

      if (!isNaN(Number(v))) {
        return { type: 'number', value: Number(v) };
      }
      if (
        (v.startsWith('"') && v.endsWith('"')) ||
        (v.startsWith("'") && v.endsWith("'"))
      ) {
        return { type: 'string', value: v.slice(1, -1) };
      }
      return { type: 'var', value: v };
    });
  }

  extractBracketValues(key: string): string[] {
    const result: string[] = [];
    let start = 0;

    while ((start = key.indexOf('[', start)) !== -1) {
      const end = key.indexOf(']', start + 1);
      if (end === -1) break;
      result.push(key.slice(start + 1, end));
      start = end + 1;
    }

    return result;
  }

  buildRefFromKey(key: string): AstNode[] {
    const base = key.split('[')[0];
    const indexes = this.extractBracketValues(key);
    const parts = base.split('.');

    const ref: AstNode[] = parts.map((part, idx) => {
      if (idx === 0) {
        return { type: 'var', value: part };
      }
      return { type: 'string', value: part };
    });
    ref.push(...indexes.map(idx => ({ type: 'var', value: idx })));
    return ref;
  }

  toFunctionArg(input: RawFunctionInput): FunctionArg {
    const trimmed = input.value.trim();
    return {
      value: trimmed,
      error: '',
      args: (input.subArgs || []).map(sub => this.toFunctionArg(sub)),
    };
  }

  toBuiltinFunction(input: RawFunctionInput): (Builtin | FunctionArg)[] {
    if (!input.subArgs?.length) {
      return [{ value: input.value, error: '' } as FunctionArg];
    }

    const args = input.subArgs.map(sub =>
      sub.subArgs?.length
        ? this.toBuiltinFunction(sub)[0]
        : this.toFunctionArg(sub)
    );

    return [
      {
        error: '',
        name: input.value,
        args,
        argNames: args.map((_, i) => `value${i + 1}`),
        type: 'builtin',
      } as Builtin,
    ];
  }

  getValueForGlobalVar(variable: GlobalVar, dollarIndex: number): AstNode {
    if (variable.args && variable.args.length > 0) {
      const fixedArgs: (Builtin | FunctionArg)[] = variable.args.flatMap(arg =>
        this.toBuiltinFunction(arg)
      );
      return this.NODE_TEMPLATES.call([
        this.NODE_TEMPLATES.refVar([this.NODE_TEMPLATES.var(variable.value)]),
        ...fixedArgs.map(arg => this.generateBuiltInAST(arg)),
      ]);
    }

    const type = variable.type.toLocaleLowerCase();
    const handler = this.getGlobalVarHandler(type);
    return handler(variable, dollarIndex);
  }

  private getGlobalVarHandler(
    type: string
  ): (variable: GlobalVar, dollarIndex: number) => AstNode {
    const handlers: Record<
      string,
      (variable: GlobalVar, dollarIndex: number) => AstNode
    > = {
      boolean: (variable: GlobalVar) =>
        this.NODE_TEMPLATES.boolean(variable.value.toLowerCase() === 'true'),
      string: (variable: GlobalVar, dollarIndex: number) =>
        /^".*"$/.test(variable.value)
          ? this.NODE_TEMPLATES.string(variable.value.replace(/^"(.*)"$/, '$1'))
          : this.parseOperandAndAppendAST({
              expr: variable.value,
              flags: { indexInc: 0, arrayCounter: 0 },
              isArray: false,
              operator: '',
              dollarIndex,
            }),
      number: (variable: GlobalVar, dollarIndex: number) =>
        this.getValueForGlobalVarNumeric(variable, dollarIndex),
      array: (variable: GlobalVar, dollarIndex: number) =>
        this.getValueForGlobalVarArray(variable, dollarIndex),
      json: (variable: GlobalVar, dollarIndex: number) =>
        this.parseOperandAndAppendAST({
          expr: variable.value,
          flags: { indexInc: 0, arrayCounter: 0 },
          isArray: false,
          operator: '',
          dollarIndex,
        }),
      null: () => this.NODE_TEMPLATES.null(),
      reference: (variable: GlobalVar, dollarIndex: number) =>
        this.parseOperandAndAppendAST({
          expr: variable.value,
          flags: { indexInc: 0, arrayCounter: 0 },
          isArray: false,
          operator: variable.type,
          dollarIndex,
        }),
      other: (variable: GlobalVar, dollarIndex: number) =>
        this.parseOperandAndAppendAST({
          expr: variable.value,
          flags: { indexInc: 0, arrayCounter: 0 },
          isArray: false,
          operator: '',
          dollarIndex,
        }),
      set: (variable: GlobalVar, dollarIndex: number) =>
        this.getValueForGlobalVarSet(variable, dollarIndex),
      object: (variable: GlobalVar, dollarIndex: number) =>
        this.parseOperandAndAppendAST({
          expr: variable.value,
          flags: { indexInc: 0, arrayCounter: 0 },
          isArray: false,
          operator: '',
          dollarIndex,
        }),
    };

    return (
      handlers[type] ||
      ((variable: GlobalVar) => this.NODE_TEMPLATES.string(variable.value))
    );
  }

  getValueForGlobalVarNumeric(
    variable: GlobalVar,
    dollarIndex: number
  ): AstNode {
    const val = variable.value;
    return this.getValueForVarNumeric(val, dollarIndex);
  }

  getValueForVarNumeric(val: string, dollarIndex: number): AstNode {
    val = val.trim();

    if (
      val.startsWith('(') &&
      val.endsWith(')') &&
      this.enclosesWholeExpression(val)
    ) {
      return this.getValueForVarNumeric(val.slice(1, -1).trim(), dollarIndex);
    }

    if (!isNaN(Number(val))) {
      return this.NODE_TEMPLATES.number(parseFloat(val));
    }

    const precedence: Record<string, number> = {
      '+': 1,
      '-': 1,
      '*': 2,
      '/': 2,
      '%': 2,
    };
    const ctx: NumericParseContext = {
      bestPos: -1,
      bestOp: '',
      val,
      precedence,
      bestPrec: Infinity,
    };

    [ctx.bestPos, ctx.bestOp] = this.scanOperatorfromRightToLeft(ctx);
    const temp = this.getTempBasedOnPos(ctx);

    return (
      temp ||
      this.parseOperandAndAppendAST({
        expr: val,
        flags: { indexInc: 0, arrayCounter: 0 },
        isArray: false,
        operator: '',
        dollarIndex,
      })
    );
  }

  getValueForGlobalVarArray(variable: GlobalVar, dollarIndex: number): AstNode {
    const val = variable.value.trim();
    if (!val.startsWith('[') || !val.endsWith(']')) {
      return this.NODE_TEMPLATES.array([]);
    }

    const arrayContent = val.slice(1, -1).trim();
    if (!arrayContent) {
      return this.NODE_TEMPLATES.array([]);
    }

    const items = this.splitTopLevel(arrayContent, ',').map(x => x.trim());
    const parsedItems = items.map(item =>
      this.parseOperandAndAppendAST({
        expr: item,
        flags: { indexInc: 0, arrayCounter: 0 },
        isArray: false,
        operator: '',
        dollarIndex,
      })
    );

    return this.NODE_TEMPLATES.array(parsedItems);
  }

  splitTopLevel(str: string, delimiter: string): string[] {
    const result: string[] = [];
    let current = '';
    let depth = 0;

    for (const s of str) {
      const c = s;
      if (c === '[' || c === CONST.OPEN_BRACE || c === '(') depth++;
      if (c === ']' || c === CONST.CLOSE_BRACE || c === ')') depth--;
      if (c === delimiter && depth === 0) {
        result.push(current);
        current = '';
      } else {
        current += c;
      }
    }
    if (current) result.push(current);
    return result;
  }

  getValueForGlobalVarJSON(variable: GlobalVar, dollarIndex: number): AstNode {
    const val = variable.value;
    if (!val.startsWith(CONST.OPEN_BRACE) || !val.endsWith(CONST.CLOSE_BRACE)) {
      throw new Error(
        this.translateService.instant('policyBuilder.error.invalidObjectFormat')
      );
    }

    const inner = val.slice(1, -1).trim();
    const entries = this.splitTopLevel(inner, ',');

    const props = entries.map((entry, idx) => {
      if (!entry.includes(':')) {
        throw new Error(
          this.translateService.instant(
            'policyBuilder.error.invalidObjectEntry',
            { idx }
          )
        );
      }
      const [keyPart, valuePart] = entry.split(':').map(s => s.trim());

      const key = keyPart.replace(/^"(.*)"$/, '$1');
      const keyNode = /^\d+$/.test(key)
        ? this.NODE_TEMPLATES.number(Number(key))
        : this.NODE_TEMPLATES.string(key);

      const value = this.parseOperandAndAppendAST({
        expr: valuePart,
        flags: { indexInc: 0, arrayCounter: 0 },
        isArray: false,
        operator: '',
        dollarIndex,
      });

      return [keyNode, value];
    });

    return {
      type: 'object',
      value: props,
    };
  }

  getValueForGlobalVarSet(variable: GlobalVar, dollarIndex: number): AstNode {
    const val = variable.value.trim();

    if (!this.isValidBraceEnclosure(val)) {
      return this.NODE_TEMPLATES.set([]);
    }

    const inner = val.slice(1, -1).trim();
    if (!inner) return this.NODE_TEMPLATES.set([]);

    const setItems = this.splitTopLevel(inner, ',').map(item =>
      this.parseSetItemValue(item.trim(), dollarIndex)
    );

    return this.NODE_TEMPLATES.set(setItems);
  }

  private isValidBraceEnclosure(val: string): boolean {
    return val.startsWith(CONST.OPEN_BRACE) && val.endsWith(CONST.CLOSE_BRACE);
  }

  private parseSetItemValue(item: string, dollarIndex: number): AstNode {
    if (/^".*"$/.test(item))
      return this.NODE_TEMPLATES.string(item.slice(1, -1));
    if (!isNaN(Number(item)))
      return this.NODE_TEMPLATES.number(parseFloat(item));
    if (/[+\-*/]/.test(item))
      return this.getValueForVarNumeric(item, dollarIndex);
    return this.NODE_TEMPLATES.var(item);
  }

  enclosesWholeExpression(expr: string): boolean {
    if (!(expr.startsWith('(') && expr.endsWith(')'))) return false;
    let depth = 0;
    for (let i = 0; i < expr.length; i++) {
      if (expr[i] === '(') depth++;
      else if (expr[i] === ')') {
        depth--;
        if (depth === 0 && i < expr.length - 1) {
          return false;
        }
      }
    }
    return depth === 0;
  }

  scanOperatorfromRightToLeft(ctx: NumericParseContext): [number, string] {
    let depth = 0;
    let bestPrec = ctx.bestPrec ?? Infinity;

    for (let i = ctx.val.length - 1; i >= 0; i--) {
      const char = ctx.val[i];
      if (char === ')') depth++;
      else if (char === '(') depth--;
      else if (depth === 0 && Object.keys(ctx.precedence).includes(char)) {
        const prec = ctx.precedence[char];
        if (prec <= bestPrec) {
          bestPrec = prec;
          ctx.bestPos = i;
          ctx.bestOp = char;
        }
      }
    }
    return [ctx.bestPos, ctx.bestOp];
  }

  getTempBasedOnPos(ctx: NumericParseContext): AstNode | undefined {
    if (ctx.bestPos >= 0) {
      const left = ctx.val.slice(0, ctx.bestPos).trim();
      const right = ctx.val.slice(ctx.bestPos + 1).trim();

      if (left && right && left !== ctx.val && right !== ctx.val) {
        return this.NODE_TEMPLATES.call([
          this.NODE_TEMPLATES.refVar([
            this.NODE_TEMPLATES.var(CONST.opMap[ctx.bestOp] || ctx.bestOp),
          ]),
          this.getValueForVarNumeric(left, 0),
          this.getValueForVarNumeric(right, 0),
        ]);
      }
    }
    return undefined;
  }

  stripPackageLine(text: string): string {
    return text?.split('\n').join('\n').trim();
  }

  generateBuiltInAST(arg: Builtin | FunctionArg): AstNode {
    if (
      (arg.type === 'builtin' || arg.type === 'custom') &&
      'args' in arg &&
      arg.args
    ) {
      return this.NODE_TEMPLATES.call([
        this.NODE_TEMPLATES.refVar([
          this.NODE_TEMPLATES.var((arg as Builtin).name),
        ]),
        ...(arg.args?.map(inner => this.generateBuiltInAST(inner)) || []),
      ]);
    }

    const raw = (arg as FunctionArg).value?.trim();
    if (!raw) return this.NODE_TEMPLATES.string('');
    if (/^".*"$/.test(raw)) return this.NODE_TEMPLATES.string(raw.slice(1, -1));
    if (!isNaN(Number(raw))) return this.NODE_TEMPLATES.number(Number(raw));
    if (raw === 'true' || raw === 'false')
      return this.NODE_TEMPLATES.boolean(raw === 'true');

    if (!/^[a-zA-Z_]\w*(\.\w+)*$/.test(raw)) {
      return this.NODE_TEMPLATES.refVar([{ type: 'var', value: raw }]);
    }

    const refParts = raw
      .split('.')
      .map((part, idx) =>
        idx === 0
          ? this.NODE_TEMPLATES.var(part)
          : this.NODE_TEMPLATES.string(part)
      );
    return this.NODE_TEMPLATES.refVar(refParts);
  }

  parseOperandAndAppendAST(ctx: ParseContext): AstNode {
    const trimmed = ctx.expr.trim();

    if (trimmed === '_') {
      return this.NODE_TEMPLATES.var('$' + ctx.dollarIndex++);
    }

    const objTemp = this.getTempForObject({
      expr: trimmed,
      flags: ctx.flags,
      operator: ctx.operator,
      dollarIndex: ctx.dollarIndex,
    });
    if (objTemp) return objTemp;

    if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
      return this.parseArrayExpr(trimmed, ctx);
    }

    const exprTemp = this.getTempBasedOnExpr({
      expr: trimmed,
      flags: ctx.flags,
      operator: ctx.operator,
      dollarIndex: ctx.dollarIndex,
    });
    if (exprTemp) return exprTemp;

    const sortedOperTemp = this.getTemplateForSortedOper({
      expr: trimmed,
      flags: ctx.flags,
      operator: ctx.operator,
      dollarIndex: ctx.dollarIndex,
    });
    if (sortedOperTemp) return sortedOperTemp;

    if (
      trimmed.startsWith(CONST.OPEN_BRACE) &&
      trimmed.endsWith(CONST.CLOSE_BRACE)
    ) {
      return this.parseBraceExpr(trimmed, ctx);
    }

    return this.parseRef({
      str: trimmed,
      counterFlag: { i: 0 },
      flags: ctx.flags,
      isArray: ctx.isArray,
      operator: ctx.operator,
      dollarIndex: ctx.dollarIndex,
    });
  }

  private parseArrayExpr(expr: string, ctx: ParseContext): AstNode {
    const arrayContent = expr.slice(1, -1).trim();
    if (!arrayContent) {
      return this.NODE_TEMPLATES.array([]);
    }
    const items = this.splitTopLevel(arrayContent, ',').map(x => x.trim());
    return {
      type: 'array',
      value: items.map(item =>
        this.parseOperandAndAppendAST({
          ...ctx,
          expr: item,
          isArray: true,
          operator: '',
        })
      ),
    };
  }

  private parseBraceExpr(expr: string, ctx: ParseContext): AstNode {
    const inner = expr.slice(1, -1).trim();
    const entries = this.splitTopLevel(inner, ',');
    const isObject = entries.some(e => e.includes(':')) || expr === '{}';
    if (isObject) {
      const props = entries.map(entry => {
        const [keyPart, valuePart] = this.splitKeyValue(entry);
        const key = keyPart.replace(/^"(.*)"$/, '$1');
        const val = this.parseOperandAndAppendAST({
          ...ctx,
          expr: valuePart,
          isArray: false,
          operator: '',
        });
        return [this.NODE_TEMPLATES.string(key), val];
      });
      return { type: 'object', value: props };
    }
    const items = entries.map(item =>
      this.parseOperandAndAppendAST({
        ...ctx,
        expr: item,
        isArray: false,
        operator: '',
      })
    );
    return { type: 'set', value: items };
  }

  parseRef(ctx: RefParseContext): AstNode {
    const parts: AstNode[] = [];
    let token = '';
    let i = 0;

    while (i < ctx.str.length) {
      const c = ctx.str[i];

      if (c === '.') {
        if (token) {
          parts.push(this.NODE_TEMPLATES.var(token));
          token = '';
        }
        i++;
      } else if (c === '[') {
        if (token) {
          parts.push(this.NODE_TEMPLATES.var(token));
          token = '';
        }
        i++; // skip '['
        let depth = 1;
        const start = i;
        while (i < ctx.str.length && depth > 0) {
          if (ctx.str[i] === '[') depth++;
          else if (ctx.str[i] === ']') depth--;
          i++;
        }
        const inner = ctx.str.slice(start, i - 1).trim();
        this.splitTopLevel(inner, ',').forEach(item => {
          const trimmed = item.trim();
          if (/^".*"$/.test(trimmed)) {
            parts.push(this.NODE_TEMPLATES.string(trimmed.slice(1, -1)));
          } else if (!isNaN(Number(trimmed))) {
            parts.push(this.NODE_TEMPLATES.number(parseFloat(trimmed)));
          } else {
            const nested = this.parseRef({
              str: trimmed,
              counterFlag: { i: 0 },
              flags: ctx.flags,
              isArray: false,
              operator: ctx.operator,
              dollarIndex: ctx.dollarIndex,
            });
            const nestedValue = nested.value as AstNode[];
            parts.push(
              nested.type === 'ref' && nestedValue.length === 1
                ? nestedValue[0]
                : nested
            );
          }
        });
      } else {
        token += c;
        i++;
      }
    }

    if (token) parts.push(this.NODE_TEMPLATES.var(token));

    if (parts.length === 1 && parts[0].type === 'string') {
      return { type: this.getType(token), value: this.getValue(token) };
    }
    if (parts.length === 0) {
      return this.NODE_TEMPLATES.var('_');
    }
    return this.NODE_TEMPLATES.refVar(parts);
  }

  getTempBasedOnExpr(ctx: ExprParseContext): AstNode | null {
    if (ctx.expr.startsWith('"') && ctx.expr.endsWith('"')) {
      return this.NODE_TEMPLATES.string(ctx.expr.slice(1, -1));
    }
    if (ctx.expr === 'true') {
      return this.NODE_TEMPLATES.boolean(true);
    }
    if (ctx.expr === 'false') {
      return this.NODE_TEMPLATES.boolean(false);
    }
    if (typeof ctx.expr === 'boolean') {
      return this.NODE_TEMPLATES.boolean(ctx.expr);
    }

    if (!isNaN(Number(ctx.expr))) {
      return this.NODE_TEMPLATES.number(parseFloat(ctx.expr));
    }

    if (this.containsOperator(ctx.expr) && ctx.operator != 'reference') {
      return this.getValueForVarNumeric(ctx.expr, ctx.dollarIndex);
    }
    if (ctx.operator === 'reference') {
      ctx.operator = '';
    }
    if (ctx.operator === CONST.IN_TYPE && this.isWrappedInBrackets(ctx.expr)) {
      return this.NODE_TEMPLATES.var('u' + ((ctx.flags.arrayIndex ?? 1) - 1));
    }
    if (this.isValidIdentifier(ctx.expr)) {
      return this.NODE_TEMPLATES.var(ctx.expr);
    }
    return null;
  }

  containsOperator(str: string): boolean {
    return ['+', '-', '*', '/', '(', ')'].some(op => str.includes(op));
  }

  getTempForObject(ctx: ExprParseContext): AstNode | null {
    let template: AstNode | null = null;
    if (
      ctx.expr.startsWith(CONST.OPEN_BRACE) &&
      ctx.expr.endsWith(CONST.CLOSE_BRACE)
    ) {
      const inner = ctx.expr.slice(1, -1).trim();
      const entries = this.splitTopLevel(inner, ',');
      const isObject = entries.some(e => e.includes(':'));

      if (isObject) {
        const props = entries.map(entry => {
          const [keyPart, valuePart] = this.splitKeyValue(entry);
          const key = keyPart.replace(/^"(.*)"$/, '$1');
          const val = this.parseOperandAndAppendAST({
            expr: valuePart,
            flags: ctx.flags,
            isArray: false,
            operator: '',
            dollarIndex: ctx.dollarIndex,
          });
          const numKey = Number(key);
          return [
            !isNaN(numKey)
              ? this.NODE_TEMPLATES.number(numKey)
              : this.NODE_TEMPLATES.string(key),
            val,
          ];
        });
        template = { type: 'object', value: props };
      } else {
        const items = entries.map(item =>
          this.parseOperandAndAppendAST({
            expr: item,
            flags: ctx.flags,
            isArray: false,
            operator: '',
            dollarIndex: ctx.dollarIndex,
          })
        );
        template = { type: 'set', value: items };
      }
    }
    return template;
  }

  getTemplateForSortedOper(ctx: ExprParseContext): AstNode | null {
    let template: AstNode | null = null;
    const operatorsSorted = Object.keys(CONST.opMap).sort(
      (a, b) => b.length - a.length
    );
    for (const sym of operatorsSorted) {
      const op = ` ${sym} `;
      const idx = ctx.expr.indexOf(op);
      if (idx > -1) {
        const left = ctx.expr.slice(0, idx).trim();
        const right = ctx.expr.slice(idx + op.length).trim();
        const mapped = CONST.opMap[sym];
        const ref =
          sym === CONST.IN_TYPE
            ? this.NODE_TEMPLATES.refVar([
                this.NODE_TEMPLATES.var('internal'),
                this.NODE_TEMPLATES.string(mapped),
              ])
            : this.NODE_TEMPLATES.refVar([this.NODE_TEMPLATES.var(mapped)]);

        let parsedRight: AstNode | null = null;
        if (
          sym === CONST.IN_TYPE &&
          right.startsWith(CONST.OPEN_BRACE) &&
          right.endsWith(CONST.CLOSE_BRACE)
        ) {
          const inner = right.slice(1, -1).trim();
          const entries = this.splitTopLevel(inner, ',');
          const isObject = entries.some(e => e.includes(':'));
          parsedRight = this.getParsedRightForObjType({
            isObject,
            entries,
            flags: ctx.flags,
            dollarIndex: ctx.dollarIndex,
          });
        } else {
          parsedRight = this.parseOperandAndAppendAST({
            expr: right,
            flags: ctx.flags,
            isArray: false,
            operator: sym,
            dollarIndex: ctx.dollarIndex,
          });
        }

        template = {
          type: 'call',
          value: [
            ref,
            this.parseOperandAndAppendAST({
              expr: left,
              flags: ctx.flags,
              isArray: false,
              operator: sym,
              dollarIndex: ctx.dollarIndex,
            }),
            parsedRight,
          ],
        };
      }
    }
    return template;
  }

  getType(value: string): string {
    try {
      const parsed = JSON.parse(value);
      if (parsed === null) return 'null';
      if (typeof parsed === 'object') {
        return Array.isArray(parsed) ? 'array' : 'json';
      }
      return typeof parsed;
    } catch {
      return 'var';
    }
  }

  getValue(value: string): string {
    try {
      const parsed = JSON.parse(value);
      if (parsed === null) return 'null';
      return parsed;
    } catch {
      return value;
    }
  }

  splitKeyValue(str: string): [string, string] {
    let depth = 0;
    for (let i = 0; i < str.length; i++) {
      const c = str[i];
      if (c === CONST.OPEN_BRACE || c === '[') depth++;
      else if (c === CONST.CLOSE_BRACE || c === ']') depth--;
      else if (c === ':' && depth === 0) {
        const key = str.slice(0, i).trim();
        const value = str.slice(i + 1).trim();
        return [key, value];
      }
    }
    throw new Error(
      this.translateService.instant(
        'policyBuilder.error.invalidKeyValueEntry',
        { entry: str }
      )
    );
  }

  isWrappedInBrackets(expr: string): boolean {
    if (typeof expr !== 'string') return false;
    if (expr.length < 2) return false;
    return expr[0] === '[' && expr[expr.length - 1] === ']';
  }

  isValidIdentifier(expr: string): boolean {
    if (!expr) return false;

    return (
      CONST.VALID_IDENTIFIER_START_CHAR.test(expr[0]) &&
      [...expr.slice(1)].every(ch => CONST.VALID_IDENTIFIER_REST_CHAR.test(ch))
    );
  }

  getParsedRightForObjType(ctx: ObjectTypeParseContext): AstNode {
    let parsedRight: AstNode | null = null;
    if (ctx.isObject) {
      parsedRight = {
        type: 'object',
        value: ctx.entries.map(entry => {
          const [keyPart, valuePart] = this.splitKeyValue(entry);
          const key = keyPart.replace(/^"(.*)"$/, '$1');
          const val = this.parseOperandAndAppendAST({
            expr: valuePart,
            flags: ctx.flags,
            isArray: false,
            operator: '',
            dollarIndex: ctx.dollarIndex,
          });
          return [this.NODE_TEMPLATES.string(key), val];
        }),
      };
    } else {
      parsedRight = {
        type: 'set',
        value: ctx.entries.map(item =>
          this.parseOperandAndAppendAST({
            expr: item,
            flags: ctx.flags,
            isArray: false,
            operator: '',
            dollarIndex: ctx.dollarIndex,
          })
        ),
      };
    }
    return parsedRight;
  }
}
