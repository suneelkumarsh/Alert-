/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { TestBed } from '@angular/core/testing';
import { of, throwError, combineLatest, take } from 'rxjs';
import { TranslateModule } from '@ngx-translate/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { PolicyBuilderService } from './policy-builder.service';
import {
  PoliciesService,
  FileTreeNodeList,
  OpaPolicyContentResponse,
  OpaPoliciesService,
  FileTreeNodeType,
  Draft,
  RegoService,
} from '../../../../../openapi/output';
import { ModalConfirmationService } from 'src/app/services/common-functionalities/modal-confirmation.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('PolicyBuilderService', () => {
  let service: PolicyBuilderService;
  let mockPoliciesService: jasmine.SpyObj<PoliciesService>;
  let mockOpaPoliciesService: jasmine.SpyObj<OpaPoliciesService>;
  let mockConfirmationService: jasmine.SpyObj<ModalConfirmationService>;
  let mockRegoService: jasmine.SpyObj<RegoService>;
  let mockAlertService: jasmine.SpyObj<TnapAlertService>;

  const mockFileTreeNodeList: FileTreeNodeList = {
    items: [
      {
        name: 'test-policy.yaml',
        path: '/policies/test-policy.yaml',
        type: FileTreeNodeType.FILE,
      },
      {
        name: 'folder1',
        path: '/policies/folder1',
        type: FileTreeNodeType.DIRECTORY,
      },
    ],
    totalCount: 2,
  };

  const mockPolicyContent: OpaPolicyContentResponse = {
    name: 'test-policy.rego',
    path: '/policies/test-policy.rego',
    script: { test: 'policy content' },
    metadata: {
      policyId: 'test-policy',
      policyVersion: '1.0',
      policy_description: 'Test OPA policy',
      mode: 'basic',
    },
  };

  const mockDraftsList: Draft[] = [
    { name: 'draft_test-policy', url: '/drafts/test-policy', isDefault: false },
    {
      name: 'draft_another-policy',
      url: '/drafts/another-policy',
      isDefault: false,
    },
  ];

  beforeEach(() => {
    mockPoliciesService = jasmine.createSpyObj('PoliciesService', [
      'listPolicies',
      'getPoliciesSourceDraft',
      'listPolicyDrafts',
    ]);

    mockOpaPoliciesService = jasmine.createSpyObj('OpaPoliciesService', [
      'getOPAPolicy',
      'saveOPAPolicy',
      'deployOpaPolicies',
    ]);

    mockConfirmationService = jasmine.createSpyObj('ModalConfirmationService', [
      'openConfirmationModal',
    ]);

    mockRegoService = jasmine.createSpyObj('RegoService', [
      'generateRego',
      'validateRego',
      'evaluateRego',
      'formatRego',
      'lintCheckRego',
    ]);

    mockAlertService = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
      'warn',
    ]);

    // Set default return values (OpenAPI services return body directly by default with observe='body')
    // Cast to any to avoid TypeScript overload resolution issues with spies
    (mockPoliciesService.listPolicies as jasmine.Spy).and.returnValue(
      of(mockFileTreeNodeList)
    );
    (mockPoliciesService.getPoliciesSourceDraft as jasmine.Spy).and.returnValue(
      of({ name: 'main' } as Draft)
    );
    (mockPoliciesService.listPolicyDrafts as jasmine.Spy).and.returnValue(
      of({ items: mockDraftsList, totalCount: mockDraftsList.length })
    );
    (mockOpaPoliciesService.getOPAPolicy as jasmine.Spy).and.returnValue(
      of(mockPolicyContent)
    );
    (
      mockConfirmationService.openConfirmationModal as jasmine.Spy
    ).and.returnValue(of(true));

    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), HttpClientTestingModule],
      providers: [
        PolicyBuilderService,
        { provide: PoliciesService, useValue: mockPoliciesService },
        { provide: OpaPoliciesService, useValue: mockOpaPoliciesService },
        {
          provide: ModalConfirmationService,
          useValue: mockConfirmationService,
        },
        { provide: RegoService, useValue: mockRegoService },
        { provide: TnapAlertService, useValue: mockAlertService },
      ],
    });

    service = TestBed.inject(PolicyBuilderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getPolicyList', () => {
    it('should call listPolicies with "main" branch and return FileTreeNodeList', done => {
      service.getPolicyList().subscribe(result => {
        expect(result).toEqual(mockFileTreeNodeList);
        expect(result.items).toBeDefined();
        expect(result.items.length).toBe(2);
        expect(result.totalCount).toBe(2);
        expect(mockPoliciesService.listPolicies).toHaveBeenCalledWith('main');
        done();
      });
    });

    it('should handle errors from listPolicies', done => {
      const errorMessage = 'Failed to fetch policy list';
      mockPoliciesService.listPolicies.and.returnValue(
        throwError(() => new Error(errorMessage))
      );

      service.getPolicyList().subscribe({
        error: err => {
          expect(err.message).toBe(errorMessage);
          done();
        },
      });
    });

    it('should handle empty policy list', done => {
      const emptyList: FileTreeNodeList = { items: [], totalCount: 0 };
      (mockPoliciesService.listPolicies as jasmine.Spy).and.returnValue(
        of(emptyList)
      );

      service.getPolicyList().subscribe(result => {
        expect(result).toEqual(emptyList);
        expect(result.items.length).toBe(0);
        expect(result.totalCount).toBe(0);
        done();
      });
    });
  });

  describe('getPolicyDetails', () => {
    const testPath = '/policies/test-policy.rego';

    it('should call getOPAPolicy with correct path and "main" branch', done => {
      const result$ = service.getPolicyDetails(testPath, undefined);

      result$.subscribe(result => {
        expect(result).toEqual(mockPolicyContent);
        expect(result).not.toBeNull();
        if (result) {
          expect(result.name).toBe('test-policy.rego');
          expect(result.path).toBe('/policies/test-policy.rego');
        }

        expect(mockOpaPoliciesService.getOPAPolicy).toHaveBeenCalledWith(
          testPath,
          'main'
        );
        expect(mockOpaPoliciesService.getOPAPolicy).toHaveBeenCalledTimes(1);
        done();
      });
    });

    it('should return Observable that emits policy content', done => {
      service.getPolicyDetails(testPath, undefined).subscribe(result => {
        expect(result).toEqual(mockPolicyContent);
        expect(result).not.toBeNull();
        if (result) {
          expect(result.script).toBeDefined();
          expect(result.metadata).toBeDefined();
        }
        done();
      });
    });

    it('should handle different file paths correctly', () => {
      const differentPath = '/policies/another-folder/another-policy.rego';
      const differentPolicyContent: OpaPolicyContentResponse = {
        ...mockPolicyContent,
        name: 'another-policy.rego',
        path: differentPath,
      };
      (mockOpaPoliciesService.getOPAPolicy as jasmine.Spy).and.returnValue(
        of(differentPolicyContent)
      );

      service.getPolicyDetails(differentPath, undefined).subscribe(result => {
        expect(result).not.toBeNull();
        if (result) {
          expect(result.name).toBe('another-policy.rego');
          expect(result.path).toBe(differentPath);
        }
      });

      expect(mockOpaPoliciesService.getOPAPolicy).toHaveBeenCalled();
    });

    it('should handle errors from getOPAPolicy', () => {
      const errorMessage = 'Policy not found';
      (mockOpaPoliciesService.getOPAPolicy as jasmine.Spy).and.returnValue(
        throwError(() => new Error(errorMessage))
      );

      const result$ = service.getPolicyDetails(testPath, undefined);

      result$.subscribe({
        error: err => {
          expect(err).toBeDefined();
        },
      });

      expect(mockOpaPoliciesService.getOPAPolicy).toHaveBeenCalled();
    });

    it('should handle empty path parameter', () => {
      const emptyPath = '';

      service.getPolicyDetails(emptyPath, undefined).subscribe();

      expect(mockOpaPoliciesService.getOPAPolicy).toHaveBeenCalled();
    });

    it('should handle null path parameter', () => {
      const nullPath = null as any;

      service.getPolicyDetails(nullPath, undefined).subscribe();

      expect(mockOpaPoliciesService.getOPAPolicy).toHaveBeenCalled();
    });
  });

  describe('Integration scenarios', () => {
    it('should maintain correct call order when both methods are called', () => {
      service.getPolicyList().subscribe();
      service.getPolicyDetails('/test-path', undefined).subscribe();

      expect(mockPoliciesService.listPolicies).toHaveBeenCalledTimes(1);
      expect(mockOpaPoliciesService.getOPAPolicy).toHaveBeenCalledTimes(1);
    });

    it('should handle concurrent calls to the same method', () => {
      service.getPolicyList().subscribe();
      service.getPolicyList().subscribe();

      expect(mockPoliciesService.listPolicies).toHaveBeenCalledTimes(2);
    });
  });
  describe('setEditPolicyJson', () => {
    it('should update editPolicyJson$ observable with new data', done => {
      const testPolicyData = {
        name: 'test-policy',
        mode: 'advanced',
        edit: true,
      };

      service.setEditPolicyJson(testPolicyData);

      service.editPolicyJson$.subscribe(data => {
        expect(data).toEqual(testPolicyData);
        done();
      });
    });

    it('should handle null policy data', done => {
      service.setEditPolicyJson(null);

      service.editPolicyJson$.subscribe(data => {
        expect(data).toBeNull();
        done();
      });
    });
  });

  describe('getBranch', () => {
    const mockDrafts: any[] = [
      { name: 'draft_test-policy', url: '/drafts/test-policy' },
      { name: 'draft_another-policy', url: '/drafts/another-policy' },
    ];

    it('should return matching draft for folder name', () => {
      const result = service.getBranch('test-policy', mockDrafts);
      expect(result).toEqual(mockDrafts[0]);
    });

    it('should return undefined when no match found', () => {
      const result = service.getBranch('non-existent', mockDrafts);
      expect(result).toBeUndefined();
    });

    it('should handle undefined draft list', () => {
      const result = service.getBranch('test-policy', undefined);
      expect(result).toBeUndefined();
    });

    it('should handle empty draft list', () => {
      const result = service.getBranch('test-policy', []);
      expect(result).toBeUndefined();
    });
  });

  describe('getBranchUrl', () => {
    const mockDrafts: any[] = [
      { name: 'draft_test-policy', url: '/drafts/test-policy' },
    ];

    it('should return URL of matching draft', () => {
      const result = service.getBranchUrl('test-policy', mockDrafts);
      expect(result).toBe('/drafts/test-policy');
    });

    it('should return undefined when no match found', () => {
      const result = service.getBranchUrl('non-existent', mockDrafts);
      expect(result).toBeUndefined();
    });
  });

  describe('getPolicyDrafts$', () => {
    it('should return observable of drafts', done => {
      service.getPolicyDrafts$.subscribe(drafts => {
        expect(drafts).toBeDefined();
        done();
      });
    });
  });

  describe('updatePolicyName', () => {
    it('should update policyName$ observable', done => {
      service.updatePolicyName('new-policy');

      TestBed.runInInjectionContext(() => {
        service.policyName$.subscribe(name => {
          expect(name).toBe('new-policy');
          done();
        });
      });
    });
  });

  describe('checkIsSaveFormVisible', () => {
    it('should update isSaveFormVisible observable', done => {
      service.checkIsSaveFormVisible(true);

      service.isSaveFormVisible.subscribe(isVisible => {
        expect(isVisible).toBe(true);
        done();
      });
    });

    it('should handle false value', done => {
      service.checkIsSaveFormVisible(false);

      service.isSaveFormVisible.subscribe(isVisible => {
        expect(isVisible).toBe(false);
        done();
      });
    });
  });

  describe('setRegoData', () => {
    it('should update regoData observable with string', done => {
      const testCode = 'package test\ndefault allow = false';
      service.setRegoData(testCode);

      service.regoData.subscribe(data => {
        expect(data).toBe(testCode);
        done();
      });
    });

    it('should handle null value', done => {
      service.setRegoData(null);

      service.regoData.subscribe(data => {
        expect(data).toBeNull();
        done();
      });
    });
  });

  describe('refreshDrafts', () => {
    it('should trigger getPolicyDrafts$ to re-emit', (done: DoneFn) => {
      let emitCount = 0;

      service.getPolicyDrafts$.subscribe(() => {
        emitCount++;
        if (emitCount >= 2) {
          expect(emitCount).toBeGreaterThanOrEqual(2);
          done();
        }
      });

      // Allow initial signal effect to run then trigger refresh
      setTimeout(() => {
        service.refreshDrafts();
      }, 0);
    }, 10000);
  });

  describe('getDraftBranchForPolicy', () => {
    it('should return draft matching policy name', done => {
      service.getDraftBranchForPolicy('test-policy').subscribe(draft => {
        expect(draft).toBeDefined();
        expect(draft?.name).toBe('draft_test-policy');
        done();
      });
    });

    it('should return undefined for non-existent policy', done => {
      service
        .getDraftBranchForPolicy('non-existent-policy')
        .subscribe(draft => {
          expect(draft).toBeUndefined();
          done();
        });
    });
  });

  describe('getBranchFromList', () => {
    const mockDraftList: Draft[] = [
      { name: 'draft_test-policy', url: '/drafts/test', isDefault: false },
      { name: 'draft_folder_test', url: '/drafts/folder', isDefault: false },
    ];

    it('should find branch with underscore pattern', () => {
      const result = service.getBranchFromList('test-policy', mockDraftList);
      expect(result?.name).toBe('draft_test-policy');
    });

    it('should find branch with base name when underscore pattern fails', () => {
      const result = service.getBranchFromList('folder/test', mockDraftList);
      expect(result?.name).toBe('draft_folder_test');
    });

    it('should handle .rego extension in policy name', () => {
      const draftList: Draft[] = [
        { name: 'draft_test', url: '/drafts/test', isDefault: false },
      ];
      const result = service.getBranchFromList('test.rego', draftList);
      expect(result?.name).toBe('draft_test');
    });

    it('should handle slashes in policy path', () => {
      const draftList: Draft[] = [
        { name: 'draft_policies_test', url: '/drafts', isDefault: false },
      ];
      const result = service.getBranchFromList('policies/test', draftList);
      expect(result?.name).toBe('draft_policies_test');
    });

    it('should return undefined for empty draft list', () => {
      const result = service.getBranchFromList('test-policy', []);
      expect(result).toBeUndefined();
    });

    it('should return undefined for undefined draft list', () => {
      const result = service.getBranchFromList('test-policy', undefined);
      expect(result).toBeUndefined();
    });
  });

  describe('openSaveModal', () => {
    it('should return observable boolean from confirmation service', done => {
      service.openSaveModal().subscribe(result => {
        expect(typeof result).toBe('boolean');
        done();
      });
    });
  });

  describe('openDeployModal', () => {
    it('should return observable boolean from confirmation service', done => {
      service.openDeployModal().subscribe(result => {
        expect(typeof result).toBe('boolean');
        done();
      });
    });
  });

  describe('draftBranchName$', () => {
    it('should filter out default branches', done => {
      const draftsWithDefault: Draft[] = [
        { name: 'main', url: '/main', isDefault: true },
        { name: 'draft_test', url: '/draft', isDefault: false },
      ];

      (mockPoliciesService.listPolicyDrafts as jasmine.Spy).and.returnValue(
        of({ items: draftsWithDefault, totalCount: 2 })
      );

      service.draftBranchName$.subscribe(filtered => {
        expect(filtered.length).toBe(1);
        expect((filtered[0] as any).name).toBe('draft_test');
        done();
      });
    });
  });

  // Tests for gitLabMainUrl signal
  describe('gitLabMainUrl signal', () => {
    it('should return default draft url when default exists', done => {
      const draftsWithDefault: any = {
        items: [
          { name: 'main', url: '/main', isDefault: true },
          { name: 'draft_test', url: '/draft', isDefault: false },
        ],
        totalCount: 2,
      };

      (mockPoliciesService.listPolicyDrafts as jasmine.Spy).and.returnValue(
        of(draftsWithDefault)
      );

      // trigger refresh so service picks up new drafts
      service.refreshDrafts();

      service.getPolicyDrafts$.pipe(take(1)).subscribe(() => {
        expect(service.gitLabMainUrl()).toBe('/main');
        done();
      });
    });

    it('should be undefined when no default draft exists', done => {
      const draftsNoDefault: any = {
        items: [{ name: 'draft_a', url: '/drafts/a', isDefault: false }],
        totalCount: 1,
      };

      (mockPoliciesService.listPolicyDrafts as jasmine.Spy).and.returnValue(
        of(draftsNoDefault)
      );

      service.refreshDrafts();

      service.getPolicyDrafts$.pipe(take(1)).subscribe(() => {
        expect(service.gitLabMainUrl()).toBeUndefined();
        done();
      });
    });
  });

  describe('getRegoData', () => {
    it('should call generateRego and return result', done => {
      mockRegoService.generateRego.and.returnValue(of('generated rego' as any));
      service.getRegoData({ policyJson: '{}' } as any).subscribe(result => {
        expect(result).toBe('generated rego');
        done();
      });
    });

    it('should propagate error from generateRego', done => {
      const error = new Error('generate error');
      mockRegoService.generateRego.and.returnValue(throwError(() => error));
      service.getRegoData({ policyJson: '{}' } as any).subscribe({
        error: err => {
          expect(err).toBe(error);
          done();
        },
      });
    });
  });

  describe('validateRegoData', () => {
    it('should call validateRego and return result', done => {
      const mockResp = { result: 'valid' } as any;
      mockRegoService.validateRego.and.returnValue(of(mockResp));
      service
        .validateRegoData({ source: 'package test' } as any)
        .subscribe(result => {
          expect(result).toEqual(mockResp);
          done();
        });
    });

    it('should propagate error from validateRego', done => {
      const error = new Error('validate error');
      mockRegoService.validateRego.and.returnValue(throwError(() => error));
      service.validateRegoData({ source: 'code' } as any).subscribe({
        error: err => {
          expect(err).toBe(error);
          done();
        },
      });
    });
  });

  describe('evaluatePolicyData', () => {
    it('should call evaluateRego and return result', done => {
      const mockResp = { result: [{ expressions: [{ value: true }] }] } as any;
      mockRegoService.evaluateRego.and.returnValue(of(mockResp));
      service
        .evaluatePolicyData({
          regoCode: 'package test',
          input: '{}',
          data: '{}',
        })
        .subscribe(result => {
          expect(result).toEqual(mockResp);
          done();
        });
    });

    it('should propagate error from evaluateRego', done => {
      const error = new Error('evaluate error');
      mockRegoService.evaluateRego.and.returnValue(throwError(() => error));
      service
        .evaluatePolicyData({ regoCode: 'code', input: '{}', data: '{}' })
        .subscribe({
          error: err => {
            expect(err).toBe(error);
            done();
          },
        });
    });
  });

  describe('formatRegoData', () => {
    it('should call formatRego and return result', done => {
      const mockResp = { result: 'formatted code' } as any;
      mockRegoService.formatRego.and.returnValue(of(mockResp));
      service.formatRegoData('package test').subscribe(result => {
        expect(result).toEqual(mockResp);
        done();
      });
    });

    it('should propagate error from formatRego', done => {
      const error = new Error('format error');
      mockRegoService.formatRego.and.returnValue(throwError(() => error));
      service.formatRegoData('code').subscribe({
        error: err => {
          expect(err).toBe(error);
          done();
        },
      });
    });
  });

  describe('formatCode', () => {
    it('should show error alert and return false when code is empty', done => {
      service.formatRegoCode('   ').subscribe(result => {
        expect(result).toBeFalse();
        expect(mockAlertService.error).toHaveBeenCalled();
        done();
      });
    });

    it('should show error alert and return false when code is undefined', done => {
      service.formatRegoCode(undefined).subscribe(result => {
        expect(result).toBeFalse();
        expect(mockAlertService.error).toHaveBeenCalled();
        done();
      });
    });

    it('should format code successfully and show success alert', done => {
      mockRegoService.formatRego.and.returnValue(
        of({ result: 'formatted code' } as any)
      );

      service.formatRegoCode('valid rego code').subscribe(result => {
        expect(result).toBeTrue();
        expect(mockAlertService.success).toHaveBeenCalled();
        done();
      });
    });

    it('should call setRegoData with formatted result on success', done => {
      mockRegoService.formatRego.and.returnValue(
        of({ result: 'formatted code' } as any)
      );

      spyOn(service, 'setRegoData');

      service.formatRegoCode('valid rego code').subscribe(() => {
        expect(service.setRegoData).toHaveBeenCalledWith('formatted code');
        done();
      });
    });

    it('should show error alert when response contains error', done => {
      mockRegoService.formatRego.and.returnValue(
        of({ error: 'format error' } as any)
      );

      service.formatRegoCode('valid rego code').subscribe(result => {
        expect(result).toBeFalse();
        expect(mockAlertService.error).toHaveBeenCalledWith('format error');
        done();
      });
    });

    it('should return false and not show alert on HTTP error', done => {
      mockRegoService.formatRego.and.returnValue(
        throwError(() => new Error('HTTP error'))
      );

      service.formatRegoCode('valid rego code').subscribe(result => {
        expect(result).toBeFalse();
        done();
      });
    });
  });

  describe('lintCheckRegoData', () => {
    it('should return parsed JSON when response is a Blob', done => {
      const lintResp = { violations: [] };
      const blob = new Blob([JSON.stringify(lintResp)], {
        type: 'application/json',
      });
      mockRegoService.lintCheckRego.and.returnValue(of(blob as any));

      service
        .lintCheckRegoData({ source: 'package test' })
        .subscribe(result => {
          expect(result).toEqual(lintResp as any);
          done();
        });
    });

    it('should return response directly when not a Blob', done => {
      const lintResp = { violations: [{ title: 'issue' }] } as any;
      mockRegoService.lintCheckRego.and.returnValue(of(lintResp));

      service
        .lintCheckRegoData({ source: 'package test' })
        .subscribe(result => {
          expect(result).toEqual(lintResp);
          done();
        });
    });

    it('should propagate error from lintCheckRego', done => {
      const error = new Error('lint error');
      mockRegoService.lintCheckRego.and.returnValue(throwError(() => error));
      service.lintCheckRegoData({ source: 'code' }).subscribe({
        error: err => {
          expect(err).toBe(error);
          done();
        },
      });
    });
  });

  describe('savePolicy', () => {
    const policyFile: any = { name: 'test', script: {}, metadata: {} };

    it('should call saveOPAPolicy after confirmation', done => {
      (
        mockConfirmationService.openConfirmationModal as jasmine.Spy
      ).and.returnValue(of(true));
      mockOpaPoliciesService.saveOPAPolicy.and.returnValue(
        of({ name: 'saved' } as any)
      );

      service.savePolicy(policyFile).subscribe(() => {
        expect(mockOpaPoliciesService.saveOPAPolicy).toHaveBeenCalled();
        done();
      });
    });

    it('should not call saveOPAPolicy when confirmation is false', () => {
      (
        mockConfirmationService.openConfirmationModal as jasmine.Spy
      ).and.returnValue(of(false));
      service.savePolicy(policyFile).subscribe();
      expect(mockOpaPoliciesService.saveOPAPolicy).not.toHaveBeenCalled();
    });

    it('should return Draft with empty name when violations exist in error', done => {
      (
        mockConfirmationService.openConfirmationModal as jasmine.Spy
      ).and.returnValue(of(true));
      const errorWithViolations = { error: { violations: [{ code: 'err' }] } };
      mockOpaPoliciesService.saveOPAPolicy.and.returnValue(
        throwError(() => errorWithViolations)
      );

      service.savePolicy(policyFile).subscribe(result => {
        expect((result as Draft).name).toBe('');
        done();
      });
    });

    it('should rethrow error when no violations in error', done => {
      (
        mockConfirmationService.openConfirmationModal as jasmine.Spy
      ).and.returnValue(of(true));
      const error = { error: {} };
      mockOpaPoliciesService.saveOPAPolicy.and.returnValue(
        throwError(() => error)
      );

      service.savePolicy(policyFile).subscribe({
        error: err => {
          expect(err).toBe(error);
          done();
        },
      });
    });
  });

  describe('deployPolicy', () => {
    it('should call deployOpaPolicies after confirmation', done => {
      (
        mockConfirmationService.openConfirmationModal as jasmine.Spy
      ).and.returnValue(of(true));
      mockOpaPoliciesService.deployOpaPolicies.and.returnValue(of(null as any));

      service.deployPolicy('test-policy', 'draft_v1').subscribe(result => {
        expect(mockOpaPoliciesService.deployOpaPolicies).toHaveBeenCalledWith(
          'test-policy',
          'draft_v1',
          true
        );
        expect(result.name).toBe('draft_v1');
        done();
      });
    });

    it('should use main as default when no draftVersion', done => {
      (
        mockConfirmationService.openConfirmationModal as jasmine.Spy
      ).and.returnValue(of(true));
      mockOpaPoliciesService.deployOpaPolicies.and.returnValue(of(null as any));

      service.deployPolicy('test-policy').subscribe(() => {
        expect(mockOpaPoliciesService.deployOpaPolicies).toHaveBeenCalledWith(
          'test-policy',
          'main',
          true
        );
        done();
      });
    });

    it('should not deploy when confirmation is false', () => {
      (
        mockConfirmationService.openConfirmationModal as jasmine.Spy
      ).and.returnValue(of(false));
      service.deployPolicy('test-policy').subscribe();
      expect(mockOpaPoliciesService.deployOpaPolicies).not.toHaveBeenCalled();
    });

    it('should return Draft with empty name when violations exist in error', done => {
      (
        mockConfirmationService.openConfirmationModal as jasmine.Spy
      ).and.returnValue(of(true));
      const errorWithViolations = { error: { violations: [{ code: 'err' }] } };
      mockOpaPoliciesService.deployOpaPolicies.and.returnValue(
        throwError(() => errorWithViolations)
      );

      service.deployPolicy('test-policy', 'draft_v1').subscribe(result => {
        expect(result.name).toBe('');
        done();
      });
    });

    it('should rethrow error when no violations in error', done => {
      (
        mockConfirmationService.openConfirmationModal as jasmine.Spy
      ).and.returnValue(of(true));
      const error = { error: {} };
      mockOpaPoliciesService.deployOpaPolicies.and.returnValue(
        throwError(() => error)
      );

      service.deployPolicy('test-policy').subscribe({
        error: err => {
          expect(err).toBe(error);
          done();
        },
      });
    });
  });

  describe('getFreshDraftBranchForPolicy', () => {
    it('should return matching draft', done => {
      (mockPoliciesService.listPolicyDrafts as jasmine.Spy).and.returnValue(
        of({
          items: [
            {
              name: 'draft_test-policy',
              url: '/drafts/test',
              isDefault: false,
            },
          ],
          totalCount: 1,
        })
      );

      service.getFreshDraftBranchForPolicy('test-policy').subscribe(draft => {
        expect(draft?.name).toBe('draft_test-policy');
        done();
      });
    });

    it('should return undefined on error', done => {
      (mockPoliciesService.listPolicyDrafts as jasmine.Spy).and.returnValue(
        throwError(() => new Error('network error'))
      );

      service.getFreshDraftBranchForPolicy('test-policy').subscribe(draft => {
        expect(draft).toBeUndefined();
        done();
      });
    });
  });

  describe('getBuiltInAttr', () => {
    it('should return empty array before functions are loaded', () => {
      const result = service.getBuiltInAttr();
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe('setJson Signal Management', () => {
    it('should update _json signal when setJson is called', done => {
      const testSchema = {
        type: 'object',
        properties: { name: { type: 'string' } },
      };
      service.setJson(testSchema);

      service.json$.pipe(take(1)).subscribe(json => {
        expect(json).toEqual(testSchema);
        done();
      });
    });

    it('should set _json to null when setJson receives null', done => {
      service.setJson(null);

      service.json$.pipe(take(1)).subscribe(json => {
        expect(json).toBeNull();
        done();
      });
    });

    it('should replace previous json value with new value', done => {
      const schema1 = { type: 'object', id: 1 };
      const schema2 = { type: 'object', id: 2 };

      service.setJson(schema1);
      service.setJson(schema2);

      service.json$.pipe(take(1)).subscribe(json => {
        expect(json).toEqual(schema2);
        expect((json as any)?.id).toBe(2);
        done();
      });
    });

    it('should emit new value through json$ observable on setJson call', done => {
      const testSchema = { data: 'test' };

      service.setJson(testSchema);

      setTimeout(() => {
        service.json$.pipe(take(1)).subscribe(json => {
          expect(json).toEqual(testSchema as any);
          done();
        });
      }, 10);
    });

    it('should handle setting complex nested objects', done => {
      const complexSchema = {
        type: 'object',
        properties: {
          user: {
            type: 'object',
            properties: {
              profile: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  age: { type: 'number' },
                },
              },
            },
          },
        },
      };

      service.setJson(complexSchema);

      service.json$.pipe(take(1)).subscribe(json => {
        expect(json).toEqual(complexSchema);
        expect(
          (json as any).properties.user.properties.profile.properties.name.type
        ).toBe('string');
        done();
      });
    });

    it('should handle rapid successive setJson calls', done => {
      const schemas = [{ id: 1 }, { id: 2 }, { id: 3 }, { id: 4 }, { id: 5 }];

      // Signals coalesce synchronous updates; only the last value is emitted
      schemas.forEach(schema => service.setJson(schema));

      setTimeout(() => {
        service.json$.pipe(take(1)).subscribe(json => {
          expect(json).toEqual({ id: 5 } as any);
          done();
        });
      }, 10);
    });
  });

  describe('Other Signal Methods', () => {
    it('should update _data signal through setData', done => {
      const testData = { key: 'value' };
      service.setData(testData);

      service.data$.pipe(take(1)).subscribe(data => {
        expect(data).toEqual(testData);
        done();
      });
    });

    it('should update _input signal through setInput', done => {
      const testInput = { user: 'john' };
      service.setInput(testInput);

      service.input$.pipe(take(1)).subscribe(input => {
        expect(input).toEqual(testInput);
        done();
      });
    });

    it('should update _highlightLine signal through setHighlightLine', done => {
      const lineNumber = 42;
      service.setHighlightLine(lineNumber);

      service.highlightLine$.pipe(take(1)).subscribe(line => {
        expect(line).toBe(lineNumber);
        done();
      });
    });

    it('should set _highlightLine to null through setHighlightLine', done => {
      service.setHighlightLine(10);
      service.setHighlightLine(null);

      service.highlightLine$.pipe(take(1)).subscribe(line => {
        expect(line).toBeNull();
        done();
      });
    });

    it('should update _output signal through updateOutput', done => {
      const testOutput = { message: 'Success', data: {} };
      service.updateOutput(testOutput);

      service.output$.pipe(take(1)).subscribe(output => {
        expect(output).toEqual(testOutput);
        done();
      });
    });

    it('should update _lint signal through updateLint', done => {
      const lintData = { message: 'No violations' };
      service.updateLint(lintData);

      service.lint$.pipe(take(1)).subscribe(lint => {
        expect(lint).toEqual(lintData);
        done();
      });
    });

    it('should update _previewPolicy signal through setPreviewPolicyJson', done => {
      const policyJson = {
        edit: false,
        mode: 'advanced',
        name: 'test_policy',
        script: 'package test',
        metadata: { policyId: 'test' },
      };

      service.setPreviewPolicyJson(policyJson);

      service.previewPolicyJson$.pipe(take(1)).subscribe(policy => {
        expect(policy).toEqual(policyJson);
        done();
      });
    });
  });

  describe('Signal Getter Methods', () => {
    it('should return current rego code through getCurrentRego', () => {
      const testCode = 'package test\nallow = true';
      (service as any)._data.set(testCode);

      expect(service.getCurrentRego()).toBe(testCode);
    });

    it('should return current input through getCurrentInput', done => {
      const testInput = { region: 'us' };
      service.setInput(testInput);

      setTimeout(() => {
        expect(service.getCurrentInput()).toEqual(testInput);
        done();
      }, 0);
    });

    it('should return current data through getCurrentData', done => {
      const testData = { resources: ['res1'] };
      service.setData(testData);

      setTimeout(() => {
        expect(service.getCurrentData()).toEqual(testData);
        done();
      }, 0);
    });
  });

  describe('Basic Mode Signal', () => {
    it('should update isBasic signal through checkIsBasicMode', done => {
      service.checkIsBasicMode(true);

      service.isBasicMode.pipe(take(1)).subscribe(isBasic => {
        expect(isBasic).toBe(true);
        done();
      });
    });

    it('should set isBasic to false', done => {
      service.checkIsBasicMode(false);

      service.isBasicMode.pipe(take(1)).subscribe(isBasic => {
        expect(isBasic).toBe(false);
        done();
      });
    });
  });

  describe('Signal Integration Tests', () => {
    it('should properly manage multiple signals together', done => {
      const input = { userId: '123' };
      const data = { resources: ['r1', 'r2'] };
      const schema = { type: 'object' };

      service.setInput(input);
      service.setData(data);
      service.setJson(schema);

      combineLatest([service.input$, service.data$, service.json$])
        .pipe(take(1))
        .subscribe(([inp, dat, sch]) => {
          expect(inp).toEqual(input);
          expect(dat).toEqual(data);
          expect(sch).toEqual(schema);
          done();
        });
    });

    it('should preserve signal independence', done => {
      const input = { a: 1 };
      const data = { b: 2 };

      service.setInput(input);
      service.setData(data);

      service.input$.pipe(take(1)).subscribe(inp => {
        expect(inp).toEqual(input);
        expect((inp as any)?.b).toBeUndefined();

        service.data$.pipe(take(1)).subscribe(dat => {
          expect(dat).toEqual(data);
          expect((dat as any)?.a).toBeUndefined();
          done();
        });
      });
    });

    it('should handle signal updates without affecting other services', () => {
      const schema = { test: 'schema' };
      const input = { test: 'input' };

      expect(() => {
        service.setJson(schema);
        service.setInput(input);
      }).not.toThrow();
    });
  });

  describe('Signal Observable Conversion', () => {
    it('should properly convert signals to observables through toObservable', done => {
      const testValue = { data: 'test' };
      service.setJson(testValue);

      service.json$.pipe(take(1)).subscribe(json => {
        expect(json as any).toEqual(testValue);
        done();
      });
    });

    it('should emit latest signal value when observable is subscribed', done => {
      const testValue = { latest: true };
      service.setJson(testValue);

      setTimeout(() => {
        service.json$.pipe(take(1)).subscribe(json => {
          expect(json as any).toEqual(testValue);
          done();
        });
      }, 10);
    });

    it('should maintain reactivity through signal-to-observable conversion', done => {
      service.setJson({ first: true });

      setTimeout(() => {
        service.json$.pipe(take(1)).subscribe(json => {
          expect(json).toEqual({ first: true } as any);

          service.setJson({ second: true });

          setTimeout(() => {
            service.json$.pipe(take(1)).subscribe(json2 => {
              expect(json2).toEqual({ second: true } as any);
              done();
            });
          }, 10);
        });
      }, 10);
    });
  });

  describe('Memory and Performance', () => {
    it('should handle large objects in schema signal', done => {
      const largeSchema: Record<string, unknown> = { properties: {} };
      for (let i = 0; i < 1000; i++) {
        (largeSchema.properties as Record<string, unknown>)[`prop_${i}`] = {
          type: 'string',
        };
      }

      service.setJson(largeSchema);

      service.json$.pipe(take(1)).subscribe(json => {
        expect(Object.keys((json as any).properties).length).toBe(1000);
        done();
      });
    });

    it('should properly clean up old signals on destroy', () => {
      const testSchema = { test: 'cleanup' };
      service.setJson(testSchema);

      expect(() => service.ngOnDestroy()).not.toThrow();
    });
  });
});
