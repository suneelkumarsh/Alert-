/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Injectable, OnDestroy, inject, signal } from '@angular/core';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { HttpClient } from '@angular/common/http';
import {
  combineLatest,
  from,
  Observable,
  of,
  ReplaySubject,
  Subject,
  throwError,
} from 'rxjs';
import {
  catchError,
  concatMap,
  map,
  shareReplay,
  switchMap,
  filter,
  take,
  tap,
} from 'rxjs/operators';
import * as yaml from 'js-yaml';
import {
  PoliciesService,
  FileTreeNodeList,
  OpaPolicyContentResponse,
  OpaPoliciesService,
  OpaPolicyContentRequest,
  Draft,
  RegoService,
  GenerateRegoRequest,
  ValidateRegoResp,
  ValidateRegoRequest,
  LintCheckRegoRequest,
  LintCheckRegoResp,
  FormatRego200Response,
  EvaluateRegoRequest,
  EvaluateRego200Response,
  PolicyStatus,
} from '../../../../../openapi/output';
import { ModalConfirmationService } from 'src/app/services/common-functionalities/modal-confirmation.service';
import {
  EvalResult,
  PolicyJson,
  SchemaNode,
  BuiltinFunctionDef,
} from 'src/app/model/OpaBuilderPolicy.model';
import { TranslateService } from '@ngx-translate/core';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

export interface AttrData {
  data: string;
  type: string;
}

@Injectable({
  providedIn: 'root',
})
export class PolicyBuilderService implements OnDestroy {
  private readonly regoService = inject(RegoService);
  private readonly policiesService = inject(PoliciesService);
  private readonly opaPoliciesService = inject(OpaPoliciesService);
  private readonly confirmationService = inject(ModalConfirmationService);
  private readonly http = inject(HttpClient);
  private readonly alertService = inject(TnapAlertService);
  private readonly translate = inject(TranslateService);
  private builtinFunctionList: (BuiltinFunctionDef & { type?: string })[] = [];

  // Cached once for the lifetime of the service — avoids repeated HTTP GETs
  private readonly builtinFunctions$ = this.http
    .get<
      (BuiltinFunctionDef & { type?: string })[]
    >('assets/builtin-functions.json')
    .pipe(
      tap(data => {
        this.builtinFunctionList = data;
      }),
      catchError(() => of([])),
      shareReplay({ refCount: true, bufferSize: 1 })
    );

  // ── Signals ────────────────────────────────────────────────────────────────
  private readonly _isFormVisible = signal(false);
  private readonly _regoCode = signal<string | null>(null);
  private readonly _policyName = signal('');
  private readonly _currentTab = signal('listPolicy');
  private readonly _data = signal('');
  private readonly _dataSource = signal<Record<string, unknown> | null>(null);
  private readonly _output = signal<EvalResult | null>(null);
  private readonly _highlightLine = signal<number | null>(null);
  private readonly _input = signal<Record<string, unknown> | unknown[] | null>(
    null
  );
  private readonly _isBasic = signal<boolean | null>(null);
  private readonly _lint = signal<EvalResult>({
    message: 'No Linter Violations',
  });
  private readonly _json = signal<SchemaNode | null>(null);
  private readonly _previewPolicy = signal<PolicyJson | null>(null);
  private readonly _draftBranch = signal<Draft | undefined>(undefined);
  private readonly _refreshDrafts = signal(0);

  protected readonly _errorMessage = signal<string | null>(null);
  private readonly _errorDecision = signal<boolean | null>(null);
  // ReplaySubject kept as-is (no getValue() needed, single replay semantic)
  private readonly editPolicyJsonSource = new ReplaySubject<PolicyJson | null>(
    1
  );
  readonly editPolicyJson$ = this.editPolicyJsonSource.asObservable();

  private readonly insertPathSource = new Subject<string>();
  readonly insertPath$ = this.insertPathSource.asObservable();

  insertPath(path: string): void {
    this.insertPathSource.next(path);
  }

  private readonly policyVersionCache = new Map<string, string | undefined>();

  private readonly policyStatusCache = new Map<
    string,
    PolicyStatus.StatusEnum | undefined
  >();

  // ── Observable facades (backward-compatible) ───────────────────────────────
  readonly isSaveFormVisible = toObservable(this._isFormVisible);
  readonly regoData = toObservable(this._regoCode);
  readonly currentTab$ = toObservable(this._currentTab);
  policyData = toObservable(this._data);
  data$ = toObservable(this._dataSource);
  output$ = toObservable(this._output);
  highlightLine$ = toObservable(this._highlightLine);
  input$ = toObservable(this._input);
  isBasicMode = toObservable(this._isBasic);
  lint$ = toObservable(this._lint);
  json$ = toObservable(this._json);
  previewPolicyJson$ = toObservable(this._previewPolicy);
  readonly errorDecision = this._errorDecision.asReadonly();
  // ── Read-only signal accessors ─────────────────────────────────────────────
  readonly regoCode$ = this._regoCode.asReadonly();
  readonly currentTabSig = this._currentTab.asReadonly();

  setPreviewPolicyJson(jsonData: PolicyJson) {
    this._previewPolicy.set(jsonData);
  }

  setHighlightLine(line: number | null) {
    this._highlightLine.set(line);
  }

  setData(data: Record<string, unknown>) {
    this._dataSource.set(data);
  }

  setInput(input: Record<string, unknown> | unknown[]) {
    this._input.set(input);
  }

  setJson(json: Record<string, unknown> | null): void {
    this._json.set(json);
  }

  updateOutput(output: EvalResult): void {
    this._output.set(output);
  }

  getCurrentRego(): string {
    return this._data();
  }

  getCurrentInput(): Record<string, unknown> | unknown[] | null {
    return this._input();
  }

  getCurrentData(): Record<string, unknown> | null {
    return this._dataSource();
  }

  checkIsBasicMode(isBasicMode: boolean) {
    this._isBasic.set(isBasicMode);
  }

  updateLint(data: EvalResult): void {
    this._lint.set(data);
  }

  get policyName$() {
    return toObservable(this._policyName);
  }

  get draftBranch$() {
    return toObservable(this._draftBranch);
  }

  get errorMessage() {
    return this._errorMessage;
  }

  readonly getPolicyDrafts$ = toObservable(this._refreshDrafts).pipe(
    switchMap(() =>
      this.policiesService.listPolicyDrafts().pipe(
        catchError(() => {
          return of({ items: [] });
        })
      )
    ),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  readonly draftBranchName$ = this.getPolicyDrafts$.pipe(
    map(result =>
      (result as { items: { isDefault: boolean }[] }).items.filter(
        item => !item.isDefault
      )
    )
  );

  readonly gitLabMainUrl = toSignal(
    this.getPolicyDrafts$.pipe(
      map(draftList => draftList.items?.find(item => item.isDefault)?.url)
    )
  );

  readonly getDefaultBranch$ = this.policiesService
    .getPoliciesSourceDraft()
    .pipe(
      map(item => item.name),
      shareReplay({ refCount: true, bufferSize: 1 })
    );

  checkIsSaveFormVisible(isSaveFormVisible: boolean): void {
    this._isFormVisible.set(isSaveFormVisible);
  }

  setDecisionValue(isDecisionValid: boolean): void {
    this._errorDecision.set(isDecisionValid);
  }

  setRegoData(regoData: string | null): void {
    this._regoCode.set(regoData);
  }

  setErrorMsg(errorMsg: string | null): void {
    this._errorMessage.set(errorMsg);
  }

  updatePolicyName(policyName: string): void {
    this._policyName.set(policyName);
  }

  setEditPolicyJson(jsonData: PolicyJson | null): void {
    this.editPolicyJsonSource.next(jsonData);
  }

  refreshDrafts(): void {
    this._refreshDrafts.update(v => v + 1);
  }

  getBranch(
    policyName: string,
    draftBranch: Draft[] | undefined
  ): Draft | undefined {
    return this.getBranchFromList(policyName, draftBranch);
  }

  getBranchUrl(
    policyName: string,
    draftBranch: Draft[] | undefined
  ): string | undefined {
    return this.getBranchFromList(policyName, draftBranch)?.url;
  }

  readonly initialRanPolicyPageData$ = combineLatest([
    this.policyName$,
    this.draftBranch$,
  ]).pipe(
    switchMap(([policyFileName, draft]) => {
      return this.getPolicyDetails(policyFileName, draft).pipe(
        map(ranPolicy => ({
          ranPolicy: ranPolicy,
          draft: draft,
        }))
      );
    })
  );

  getDraftBranchForPolicy(packageName: string): Observable<Draft | undefined> {
    return this.getPolicyDrafts$.pipe(
      map(draftList =>
        this.getBranch(packageName, (draftList as { items: Draft[] }).items)
      ),
      catchError(() => {
        return of(undefined);
      })
    );
  }

  // Get draft branch with fresh API call (bypasses cache)
  getFreshDraftBranchForPolicy(
    packageName: string
  ): Observable<Draft | undefined> {
    return this.policiesService.listPolicyDrafts().pipe(
      map(draftList =>
        this.getBranch(packageName, (draftList as { items: Draft[] }).items)
      ),
      catchError(() => {
        return of(undefined);
      })
    );
  }

  getPolicyList(): Observable<FileTreeNodeList> {
    return this.getDefaultBranch$.pipe(
      switchMap(defaultBranchName =>
        this.policiesService.listPolicies(defaultBranchName)
      )
    );
  }

  getPolicyDetails(
    policy: string,
    draftBranch: Draft | undefined
  ): Observable<OpaPolicyContentResponse> {
    return this.getDefaultBranch$.pipe(
      switchMap(defaultBranchName =>
        this.opaPoliciesService.getOPAPolicy(
          policy,
          draftBranch?.name || defaultBranchName
        )
      )
    );
  }

  getPolicyVersionCached(policyName: string): Observable<string | undefined> {
    if (this.policyVersionCache.has(policyName)) {
      return of(this.policyVersionCache.get(policyName));
    }

    return this.getPolicyDetails(policyName, undefined).pipe(
      map(response => {
        const version = response.metadata?.policyVersion;
        this.policyVersionCache.set(policyName, version);
        return version;
      }),
      catchError(() => {
        return of(undefined);
      })
    );
  }

  clearPolicyVersionCache(policyName?: string): void {
    if (policyName) {
      this.policyVersionCache.delete(policyName);
    } else {
      this.policyVersionCache.clear();
    }
  }

  getPolicyStatusCached(
    policyName: string
  ): Observable<PolicyStatus.StatusEnum | undefined> {
    if (this.policyStatusCache.has(policyName)) {
      return of(this.policyStatusCache.get(policyName));
    }

    return this.getDefaultBranch$.pipe(
      switchMap(defaultBranchName =>
        this.policiesService.getPolicy(policyName, defaultBranchName)
      ),
      switchMap(policyContent => {
        let policyData:
          | {
              type: string;
              type_version: string;
              name: string;
              version: string;
            }
          | undefined;

        if (policyContent?.content) {
          try {
            const parsedContent = yaml.load(policyContent.content, {
              schema: yaml.JSON_SCHEMA,
            }) as Record<string, unknown>;
            policyData = this.extractPolicyData(
              (
                parsedContent as {
                  topology_template?: { policies?: unknown[] };
                }
              )?.topology_template?.policies
            );
            if (!policyData) {
              policyData = this.extractOpaPolicyData(parsedContent);
            }
          } catch {
            // Parsing failed
          }
        }

        if (!policyData) {
          return of('UNKNOWN' as PolicyStatus.StatusEnum);
        }

        return this.policiesService
          .getPolicyStatus(
            policyData.type,
            policyData.type_version,
            policyData.name,
            policyData.version
          )
          .pipe(
            map(response => {
              const status = response.status || 'UNKNOWN';
              this.policyStatusCache.set(policyName, status);
              return status;
            }),
            catchError(() => {
              return of('UNKNOWN' as PolicyStatus.StatusEnum);
            })
          );
      }),
      catchError(() => {
        return of('UNKNOWN' as PolicyStatus.StatusEnum);
      }),
      shareReplay({ refCount: true, bufferSize: 1 })
    );
  }

  private extractPolicyData(
    policies: unknown[] | undefined
  ):
    | { type: string; type_version: string; name: string; version: string }
    | undefined {
    if (!policies || !Array.isArray(policies) || policies.length === 0) {
      return undefined;
    }

    const policy = policies[0];
    if (!policy || typeof policy !== 'object') {
      return undefined;
    }

    const policyKey = Object.keys(policy)[0];
    if (!policyKey) {
      return undefined;
    }

    const policyData = (policy as Record<string, unknown>)[policyKey] as {
      type?: string;
      type_version?: string;
      name?: string;
      version?: string;
    };

    if (
      !policyData?.type ||
      !policyData?.type_version ||
      !policyData?.name ||
      !policyData?.version
    ) {
      return undefined;
    }

    return {
      type: policyData.type,
      type_version: policyData.type_version,
      name: policyData.name,
      version: policyData.version,
    };
  }

  private extractOpaPolicyData(
    content: Record<string, unknown>
  ):
    | { type: string; type_version: string; name: string; version: string }
    | undefined {
    const type = content?.type as string | undefined;
    const type_version = content?.type_version as string | undefined;
    const name = content?.name as string | undefined;
    const version = content?.version as string | undefined;

    if (!type || !type_version || !name || !version) {
      return undefined;
    }

    return { type, type_version, name, version };
  }

  clearPolicyStatusCache(policyName?: string): void {
    if (policyName) {
      this.policyStatusCache.delete(policyName);
    } else {
      this.policyStatusCache.clear();
    }
  }

  savePolicy(
    policyFile: OpaPolicyContentRequest
  ): Observable<Draft | OpaPolicyContentResponse> {
    return this.openSaveModal().pipe(
      take(1),
      filter(confirm => confirm === true),
      concatMap(() => {
        return this.opaPoliciesService
          .saveOPAPolicy(policyFile.name, policyFile)
          .pipe(
            tap(() => {
              this.clearPolicyVersionCache(policyFile.name);
            }),
            catchError((err: unknown) => {
              const errorWithViolations = err as {
                error?: { violations?: unknown[] };
              };
              const hasViolations =
                (errorWithViolations?.error?.violations?.length ?? 0) > 0;
              if (hasViolations) {
                return of({ name: '', isDefault: false } as Draft);
              }
              return throwError(() => err);
            })
          );
      })
    );
  }

  deployPolicy(policyFile: string, draftVersion?: string): Observable<Draft> {
    return this.openDeployModal().pipe(
      take(1),
      filter(confirm => confirm === true),
      concatMap(() =>
        this.opaPoliciesService
          .deployOpaPolicies(
            policyFile,
            draftVersion ? `${draftVersion}` : 'main',
            true
          )
          .pipe(
            tap(() => {
              this.clearPolicyStatusCache(policyFile);
            }),
            map(() => {
              return {
                name: draftVersion,
                isDefault: false,
              } as Draft;
            }),
            catchError((err: unknown) => {
              const errorWithViolations = err as {
                error?: { violations?: unknown[] };
              };
              const hasViolations =
                (errorWithViolations?.error?.violations?.length ?? 0) > 0;
              if (hasViolations) {
                return of({ name: '', isDefault: false } as Draft);
              }
              return throwError(() => err);
            })
          )
      )
    );
  }

  getBranchFromList(
    policyName: string,
    draftBranchList: Draft[] | undefined
  ): Draft | undefined {
    if (!draftBranchList) {
      return undefined;
    }

    const baseName = policyName.replace(/\.[^/.]+$/, '').replaceAll('/', '_');
    const branchWithUnderscore = draftBranchList.find(item =>
      item.name.endsWith('_' + baseName)
    );
    if (branchWithUnderscore) {
      return branchWithUnderscore;
    }

    return draftBranchList.find(item => item.name.endsWith(baseName));
  }

  openSaveModal(): Observable<boolean> {
    return this.confirmationService.openConfirmationModal(
      'common.buttons.yes',
      'ranTemplate.modal.save.title',
      'ranTemplate.modal.save.text'
    );
  }

  openDeployModal(): Observable<boolean> {
    return this.confirmationService.openConfirmationModal(
      'common.buttons.yes',
      'ranTemplate.modal.deploy.title',
      'ranTemplate.modal.deploy.text'
    );
  }

  loadBuiltInFunctions(): Observable<
    (BuiltinFunctionDef & { type?: string })[]
  > {
    return this.builtinFunctions$;
  }

  getBuiltInAttr(): AttrData[] {
    return this.builtinFunctionList.map(f => ({
      data: f.name,
      type: f.type || 'function',
    }));
  }

  getRegoData(data: GenerateRegoRequest): Observable<string> {
    return this.regoService
      .generateRego(data)
      .pipe(catchError(err => throwError(() => err)));
  }

  validateRegoData(data: ValidateRegoRequest): Observable<ValidateRegoResp> {
    return this.regoService
      .validateRego(data)
      .pipe(catchError(err => throwError(() => err)));
  }

  evaluatePolicyData(
    data: EvaluateRegoRequest
  ): Observable<EvaluateRego200Response> {
    return this.regoService
      .evaluateRego(data)
      .pipe(catchError(err => throwError(() => err)));
  }

  formatRegoData(data: string): Observable<FormatRego200Response> {
    return this.regoService
      .formatRego(data)
      .pipe(catchError(err => throwError(() => err)));
  }

  formatRegoCode(code?: string): Observable<boolean> {
    const regoCode = code ?? this.regoCode$();
    if (!regoCode?.trim()) {
      this.alertService.error(
        this.translate.instant('policyBuilder.error.regoCodeEmpty')
      );
      return of(false);
    }

    return this.formatRegoData(regoCode).pipe(
      tap((res: FormatRego200Response) => {
        if (res.result) {
          this.setRegoData(res.result);
          this.alertService.success(
            this.translate.instant('policyBuilder.message.formatSuccess')
          );
        } else if (res.error) {
          this.alertService.error(res.error);
        }
      }),
      map((res: FormatRego200Response) => !!res.result),
      catchError(() => of(false))
    );
  }

  lintCheckRegoData(data: LintCheckRegoRequest): Observable<LintCheckRegoResp> {
    return this.regoService
      .lintCheckRego(data)
      .pipe(
        switchMap((res: unknown) =>
          res instanceof Blob
            ? from(res.text()).pipe(
                map(t => JSON.parse(t) as LintCheckRegoResp)
              )
            : of(res as LintCheckRegoResp)
        )
      );
  }

  ngOnDestroy(): void {
    this.editPolicyJsonSource.complete();
    this.policyVersionCache.clear();
    this.policyStatusCache.clear();
  }
}
