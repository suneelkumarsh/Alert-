/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  AfterViewInit,
  Component,
  DestroyRef,
  ElementRef,
  inject,
  input,
  model,
  output,
  viewChild,
  viewChildren,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TranslateService } from '@ngx-translate/core';
import {
  AttrData,
  PolicyBuilderService,
} from '../shared/policy-builder.service';
import { LoadSchemaDataService } from '../shared/load-schema-data.service';
import { CommonService } from '../shared/common.service';
import { HelperFunctionsConditionRowService } from '../shared/helper-functions-condition-row.service';
import { validateFunctionDefinition } from './function-validation.util';
import { ConditionRowComponent } from '../condition-row/condition-row.component';
import {
  Condition,
  Rule,
  SchemaNode,
  CONDITION_TYPE_OPERATORS,
  CONDITION_TYPE_KEYWORDS,
} from 'src/app/model/OpaBuilderPolicy.model';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-rule-block',
  standalone: false,
  templateUrl: './rule-block.component.html',
  styleUrl: './rule-block.component.css',
})
export class RuleBlockComponent implements AfterViewInit {
  // ── Inputs ─────────────────────────────────────────────────────────────────
  readonly rule = input.required<Rule>();
  readonly rules = input.required<Rule[]>();
  readonly isFirst = input(false);
  readonly previewOnly = input(false);
  readonly ownerCondition = input<Condition>();
  readonly ruleNames = input<string[]>([]);
  readonly globalVars = input<
    { key: string; value: string; type: string; default: boolean }[]
  >([]);
  readonly customFunctions = input<
    { name: string; args: string[]; returnVar: string; returnType: string }[]
  >([]);

  // ── Outputs ─────────────────────────────────────────────────────────────
  readonly newRuleRequested = output<string>();
  readonly newFunctionRequested = output<{
    name: string;
    args: string[];
    returnVar: string;
    returnType: string;
  }>();
  readonly remove = output<void>();
  readonly ruleChange = output<Rule>();
  readonly clearParentRuleNameErrors = output<void>();
  readonly externalRuleNameError = model('');

  // ── UI State ─────────────────────────────────────────────────────────────
  protected selectedOperator = 'is';
  protected filteredOptions: string[] = [];
  protected schemaAttrs: AttrData[] = [];
  protected ruleNameWidth = 100;
  protected ruleValueWidth = 100;
  private json: SchemaNode | null = null;

  // ── View Queries ────────────────────────────────────────────────────────
  readonly conditionRows = viewChildren(ConditionRowComponent);
  private readonly ruleNameMeasure = viewChild<ElementRef>('ruleNameMeasure');
  private readonly ruleValueMeasure = viewChild<ElementRef>('ruleValueMeasure');

  // ── Services ────────────────────────────────────────────────────────────────
  private readonly alertService = inject(TnapAlertService);
  private readonly commonService = inject(CommonService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly elRef = inject(ElementRef);
  private readonly helperFunctionsService = inject(
    HelperFunctionsConditionRowService
  );
  private readonly loadSchemaDataService = inject(LoadSchemaDataService);
  private readonly policyBuilderService = inject(PolicyBuilderService);
  private readonly translateService = inject(TranslateService);

  // ── Lifecycle ─────────────────────────────────────────────────────────────
  ngAfterViewInit(): void {
    if (this.rule()) {
      if (this.rule().isContains) {
        this.selectedOperator = 'contains';
      }
    }
    setTimeout(() => {
      this.updateRuleNameWidth();
      this.updateRuleValueWidth();
    });

    this.policyBuilderService.json$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: jsonData => {
          this.json =
            typeof jsonData === 'string'
              ? (JSON.parse(jsonData) as SchemaNode)
              : (jsonData as SchemaNode | null);
          [, this.schemaAttrs] = this.loadSchemaDataService.loadOperandOptions(
            this.json,
            [],
            [],
            false
          );
          this.onInputChange();
        },
        error: (err: Error) =>
          this.alertService.error('Error loading schema: ' + err.message),
      });
    this.onInputChange();
  }

  // ── Input Change / Options ──────────────────────────────────────────────────────────────
  onInputChange(): void {
    this.clearRuleValueError();
    this.ruleChange.emit(this.rule());
  }

  // ── Condition CRUD ────────────────────────────────────────────────────────
  protected addCondition(
    type: 'condition' | 'assignment' | 'iteration' = 'condition'
  ): void {
    const operator = CONDITION_TYPE_OPERATORS[type];
    const keyword = type === 'condition' ? CONDITION_TYPE_KEYWORDS[type] : type;

    this.rule().conditions.push({
      keyword,
      leftOperand: '',
      leftOperandType: 'string',
      rightOperandType: 'string',
      operator,
      rightOperand: '',
      type,
    });
    this.ruleChange.emit(this.rule());
  }

  protected updateCondition(index: number, condition: Condition): void {
    this.rule().conditions[index] = condition;
    this.ruleChange.emit(this.rule());
  }

  protected removeCondition(index: number): void {
    this.rule().conditions.splice(index, 1);
    this.ruleChange.emit(this.rule());
  }

  protected removeRule(): void {
    if (this.rule()?.isEvery && this.ownerCondition()) {
      const idx =
        this.ownerCondition()!.everyRuleBlocks?.indexOf(this.rule()) ?? -1;
      if (idx >= 0) {
        this.ownerCondition()!.everyRuleBlocks?.splice(idx, 1);
        this.ruleChange.emit(this.rule());
      }
      return;
    }
    this.remove.emit();
  }

  // ── Utility Methods ────────────────────────────────────────────────────────
  updateFilteredOptions(value: string | null | undefined): void {
    if (!value) {
      this.filteredOptions = [...this.valueOptions];
    } else {
      this.filteredOptions = this.valueOptions.filter(opt =>
        opt.toLowerCase().includes((value ?? '').toString().toLowerCase())
      );
    }
  }

  addFunctionToFirstCondition(): void {
    const first = this.conditionRows()[0];
    if (first) {
      first.openCustomFunctionModal();
    }
  }

  isCustomFunctionName(name: string): boolean {
    return !!this.customFunctions().find(f => f.name === name);
  }
  // ── Width Measurement ─────────────────────────────────────────────────────
  updateRuleNameWidth(): void {
    const el = this.ruleNameMeasure()?.nativeElement;
    if (!el) return;
    this.ruleNameWidth = Math.min(Math.max(50, el.offsetWidth + 20), 300);
  }

  updateRuleValueWidth(): void {
    const el = this.ruleValueMeasure()?.nativeElement;
    if (!el) return;
    this.ruleValueWidth = Math.max(50, el.offsetWidth + 20);
  }

  // ── Error Management ─────────────────────────────────────────────────────
  clearAllErrors(): void {
    if (!this.rules()) return;

    this.externalRuleNameError.set('');

    this.rules().forEach(rule => {
      rule.error = '';
      rule.valueError = '';
      if (rule.argErrors) {
        rule.argErrors = rule.argErrors.map(() => '');
      }

      rule.conditions?.forEach(cond => {
        cond.leftOperandError = '';
        cond.rightOperandError = '';
      });

      if (rule.everyRuleBlocks?.length) {
        rule.everyRuleBlocks.forEach(every => {
          every.error = '';
          every.valueError = '';
          if (every.argErrors) {
            every.argErrors = every.argErrors.map(() => '');
          }
        });
      }
    });

    const errorNodes = (
      this.elRef.nativeElement as HTMLElement
    ).querySelectorAll('.custom-error');
    errorNodes.forEach(node => {
      (node as HTMLElement).innerText = '';
    });
  }
  // ── Rule Actions ───────────────────────────────────────────────────────────
  forwardNewRule(value: string): void {
    this.newRuleRequested.emit(value);
  }

  addOrRule(): void {
    this.rule().error = '';
    this.rule().valueError = '';
    this.externalRuleNameError.set('');
    const leftOperands =
      this.rule().conditions.map(item => item.leftOperand) || [];

    if (this.rule().argErrors && this.rule().argErrors!.length) {
      this.rule().argErrors = this.rule().argErrors!.map(() => '');
    }

    this.rule().conditions.forEach(c => {
      c.leftOperandError = '';
      c.rightOperandError = '';
      c.parentLeftOperand = leftOperands;
    });
    this.newRuleRequested.emit('OR:' + this.rule().name.value);
    this.clearAllErrors();
    this.clearParentRuleNameErrors.emit();
  }

  addOtherwise(): void {
    this.newRuleRequested.emit('Otherwise:' + this.rule().name.value);
    this.clearAllErrors();
    this.clearParentRuleNameErrors.emit();
  }

  onSelectedOperatorChange(value: string): void {
    this.selectedOperator = value;
    this.rule().isContains = value === 'contains';
    this.ruleChange.emit(this.rule());
  }

  addConditionAfter(
    index: number,
    type: 'condition' | 'assignment' | 'iteration' = 'condition',
    operator?: string
  ): void {
    const newCondition: Condition = {
      keyword: 'and',
      leftOperand: '',
      leftOperandType: 'string',
      rightOperandType: 'string',
      operator: operator ?? '',
      rightOperand: '',
      type: type,
      everyRuleBlocks: [],
    };

    let insertIndex = index + 1;

    if (this.rule().conditions[index]?.everyRuleBlocks?.length) {
      insertIndex = index + 1;
    }

    this.rule().conditions.splice(insertIndex, 0, newCondition);
    this.rule().conditions = [...this.rule().conditions];
  }

  isBuiltinOrCustom(leftOperand: string): boolean {
    const isBuiltin = this.conditionRows().some(row =>
      row.builtinFunctionList?.some(f => f.name === leftOperand)
    );

    const isCustom = this.conditionRows().some(row =>
      row.customFunctions()?.some(f => f.name === leftOperand)
    );

    return isBuiltin || isCustom;
  }

  // ── Validation ─────────────────────────────────────────────────────────────
  validateRuleName(): boolean {
    this.rule().error = '';
    const name = this.rule().name.value;

    if (!name?.trim()) {
      this.rule().error = '*required';
      return false;
    }

    const isInvalidShape =
      /^\{\s*\}$/.test(name) ||
      /^\{\s*\d+\s*\}$/.test(name) ||
      /^\[\s*\]$/.test(name);

    if (
      isInvalidShape ||
      (!this.helperFunctionsService.isValidRegex(name) &&
        !this.allowForRuleHeadContainingLiterals(name))
    ) {
      this.rule().error = this.translateService.instant(
        'policyBuilder.error.invalidName'
      );
      return false;
    }

    return true;
  }

  allowForRuleHeadContainingLiterals(input: string): boolean {
    if (!input || typeof input !== 'string') return false;
    const identifier = `[A-Za-z_][A-Za-z0-9_]*`;
    const stringLiteral = `"([^"\\\\]|\\\\.)*"`;
    const pattern = new RegExp(`^${identifier}\\[${stringLiteral}\\]$`);
    return pattern.test(input);
  }

  validateRuleBlock(rule: Rule = this.rule()): boolean {
    // Only validate rule name for the main rule, not for child everyRuleBlocks
    let isValid = rule === this.rule() ? this.validateRuleName() : true;

    const seenLeftOperands = new Set<string>();
    for (const row of this.conditionRows() ?? []) {
      if (!row.validateConditionInputs()) return false;

      const { leftOperand, operator } = row.condition();

      if (operator === ':=') {
        if (seenLeftOperands.has(leftOperand)) {
          row.condition().leftOperandError = this.translateService.instant(
            'policyBuilder.error.duplicateVariable'
          );
          return false;
        }
        seenLeftOperands.add(leftOperand);
      }

      if (
        (operator === ':=' || operator === 'inl' || operator === 'ni') &&
        this.isBuiltinOrCustom(leftOperand)
      ) {
        row.condition().leftOperandError = this.translateService.instant(
          'policyBuilder.error.cannotAssignToFunction'
        );
        return false;
      }
    }

    isValid = this.validateRuleValue(rule, isValid);
    // Only validate everyRuleBlocks for the main rule, not for child rules
    if (rule === this.rule() && !this.isValidEveryRule(rule?.everyRuleBlocks))
      isValid = false;

    if (rule.isFunction) {
      rule.argErrors ??= [];
      rule.args?.forEach((arg, i) => {
        const error = !arg?.trim()
          ? '*required'
          : !this.helperFunctionsService.isValidRegexValue(arg)
            ? 'Invalid value'
            : '';
        rule.argErrors![i] = error;
        if (error) isValid = false;
      });
    }

    return isValid;
  }

  validateRuleValue(rule: Rule, isValid: boolean): boolean {
    if (!rule.isFunction && (rule.value == null || rule.value === '')) {
      rule.valueError = '*required';
      isValid = false;
    } else if (rule.isFunction && !rule.returnVar) {
      rule.valueError = '*required';
      isValid = false;
    } else if (
      !rule.isFunction &&
      typeof rule.value === 'string' &&
      !this.helperFunctionsService.isValidRegexValue(rule.value)
    ) {
      rule.valueError = 'Invalid Name';
      isValid = false;
    }
    return isValid;
  }

  isValidEveryRule(
    everyRuleBlocks: Rule[] | undefined = this.rule()?.everyRuleBlocks
  ): boolean {
    let isValid = true;
    if (everyRuleBlocks?.length) {
      for (const every of everyRuleBlocks) {
        const name = every.name?.value?.trim() || '';
        const nameCheck = this.helperFunctionsService.isValidEveryName(name);
        if (!nameCheck.isValid) {
          isValid = false;
          every.error = nameCheck.error;
        }
        if (
          typeof every.value === 'string' &&
          !this.helperFunctionsService.isValidRegexValue(every.value || '')
        ) {
          isValid = false;
          every.valueError = 'Invalid Variable';
        }
        const childValid = this.validateRuleBlock(every);
        if (!childValid) {
          isValid = false;
        }
      }
    }
    return isValid;
  }

  onFunctionArgChange(value: string, index: number): void {
    if (!this.rule().args) {
      this.rule().args = [];
    }
    if (this.rule().argErrors) {
      this.rule().argErrors![index] = '';
    }
    this.rule().args![index] = value;
    this.validateFunction();
  }

  onArgsBlur(): void {
    this.validateFunction();
    this.ruleChange.emit({
      ...this.rule(),
      args: [...(this.rule().args || [])],
    });
  }

  clearRuleError(): void {
    if (
      this.rule().name.value &&
      (this.rule().error || this.externalRuleNameError())
    ) {
      this.rule().error = '';
      this.externalRuleNameError.set('');
      this.validateFunction();
    }
  }

  clearRuleValueError(): void {
    if (this.rule().value && this.rule().valueError) {
      this.rule().valueError = '';
    }

    if (this.rule().returnVar && this.rule().valueError) {
      this.rule().valueError = '';
    }
  }

  private createInitialEveryCondition(parentLeftOperands: string[]): Condition {
    return {
      keyword: CONDITION_TYPE_KEYWORDS['condition'],
      leftOperand: '',
      leftOperandType: 'string',
      rightOperandType: 'string',
      parentLeftOperand: parentLeftOperands,
      operator: CONDITION_TYPE_OPERATORS['condition'],
      rightOperand: '',
      type: 'condition',
    };
  }

  private createEveryRule(leftOperands: string[]): Rule {
    return {
      name: { value: '' },
      category: '',
      conditions: [this.createInitialEveryCondition(leftOperands)],
      isEvery: true,
      isFunction: false,
      isOtherwise: false,
      isOr: false,
      value: '',
      args: [],
    };
  }

  protected onEveryClicked(): void {
    if (!this.rule().everyRuleBlocks) {
      this.rule().everyRuleBlocks = [];
    }

    const leftOperands = this.rule().conditions.map(item => item.leftOperand);
    const newEvery = this.createEveryRule(leftOperands);

    this.rule().everyRuleBlocks!.push(newEvery);
    this.ruleChange.emit(this.rule());
  }

  get valueOptions(): string[] {
    const options = this.rule().isEvery ? [] : ['true', 'false'];

    if (this.globalVars()?.length) {
      options.push(...this.globalVars().map(v => v.key));
    }

    if (this.rule().isEvery) {
      if (this.schemaAttrs) {
        options.push(
          ...this.schemaAttrs
            .map(attr => attr.data)
            .filter(v => v && v.trim() !== '')
        );
      }
      if (this.rule()?.conditions?.length) {
        const localVars = this.rule()
          .conditions.map(c => c.leftOperand)
          .filter(v => v && !options.includes(v));
        options.push(...localVars);
      }
    }

    return [...new Set(options)]
      .filter(Boolean)
      .sort((a, b) => a.localeCompare(b));
  }

  setSelectedSchema(): void {
    this.commonService.selectedHierarchy$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: value => {
          if (!value) return;
          if (!this.rule().value) {
            this.rule().value = `input.${value}`;
            this.commonService.clearSelectedHierarchy();
          }
        },
        error: (err: Error) =>
          this.alertService.error(
            'Error loading selected schema: ' + err.message
          ),
      });
    this.setEveryArrayOptions();
  }
  setEveryArrayOptions(): void {
    const sources: string[] = [
      ...this.globalVars().map(v => v.key),
      ...(this.rule()?.conditions.map(c => c.leftOperand) ?? []),
      ...(this.rule()?.conditions?.[0]?.parentLeftOperand ?? []),
    ];

    const unique = [...new Set(sources)].filter(Boolean) as string[];
    if (unique.length > 0) {
      this.filteredOptions = unique.sort((a, b) => a.localeCompare(b));
    }
  }

  validateFunction(): void {
    if (!this.rule().isFunction) return;

    const result = validateFunctionDefinition(
      this.rule().name?.value,
      this.rule().args || [],
      this.rule().returnVar
    );

    this.rule().error = result.nameError
      ? this.translateService.instant(result.nameError)
      : '';
    this.rule().argErrors =
      result.argErrors?.map(e => (e ? this.translateService.instant(e) : '')) ??
      [];
    this.rule().valueError = result.returnVarError
      ? this.translateService.instant(result.returnVarError)
      : '';
  }
}
