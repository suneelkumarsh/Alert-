/*
 * Copyright (c) 2022. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component } from '@angular/core';
import {
  AlarmListColumnName,
  AlarmListState,
  DefaultAlarmListColumnNames,
  ExportAlarmFields,
  RefreshIntervals,
} from 'src/app/model/alarm.model';
import { UnsubscribeService } from 'src/app/services/unsubscribe/unsubscribe.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import {
  filter,
  map,
  scan,
  shareReplay,
  startWith,
  switchMap,
  take,
  takeUntil,
  tap,
} from 'rxjs/operators';
import { UserSettingsService } from 'src/app/services/user-settings.service';
import { ConfirmationModalComponent } from 'src/app/components/shared/confirmation-modal/confirmation-modal.component';
import { EMPTY, merge, Observable, Subject } from 'rxjs';
import { AlarmService } from 'src/app/services/alarm.service';
import {
  addFieldPrefix,
  createFilter,
  filterBuilder,
  FilterOperator,
  parseFilterFromUrl,
} from 'src/app/helpers/filter-helpers';
import { AlarmsService } from 'openapi/output';
import { FileSaverService } from 'ngx-filesaver';
import { isNotNull } from 'src/app/helpers/helpers';
import { exportFileName } from 'src/app/modules/alarm/configuration';
import { QueryParamService } from '../../../services/query-param.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-alarm-list-container',
  templateUrl: './alarm-list-container.component.html',
  styleUrls: ['./alarm-list-container.component.css'],
  providers: [UnsubscribeService],
  standalone: false,
})
export class AlarmListContainerComponent {
  ALARM_EXPORT_FILENAME = exportFileName;

  refreshIntervalType = RefreshIntervals;
  refreshIntervals: RefreshIntervals[] = Object.values(
    this.refreshIntervalType
  );
  initialAlarmListState: AlarmListState = {
    refreshInterval: RefreshIntervals.NO_INTERVAL,
    visibleColumns: new Set(DefaultAlarmListColumnNames),
  };
  exportAlarmFields = ExportAlarmFields;
  ColumnName = AlarmListColumnName;
  public alarmIds: Set<number> = new Set();

  readonly filter$ = this.queryParamService.getValueOf('filter');

  private checkedColumns: Set<AlarmListColumnName> = new Set(
    DefaultAlarmListColumnNames
  );
  readonly availableColumns$: Observable<Map<AlarmListColumnName, string>> =
    this.customAlarmsService.getAvailableColumns();

  public btnRefresh: Subject<RefreshIntervals> =
    new Subject<RefreshIntervals>();

  private commands: Observable<any> = merge(
    this.btnRefresh.pipe(map(selectedInterval => ({ selectedInterval }))),
    this.userSettingsService.getPreferences$().pipe(
      tap(preferences => {
        this.checkedColumns = new Set(preferences.columns);
      }),
      map(preferences => ({
        refreshInterval: preferences.refreshInterval,
        visibleColumns: preferences.columns,
      }))
    )
  );

  public alarmListState: Observable<AlarmListState> = this.commands.pipe(
    startWith(this.initialAlarmListState),
    scan(
      (alarmListState: AlarmListState, command): AlarmListState => ({
        ...alarmListState,
        ...command,
      })
    ),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  constructor(
    private translateService: TranslateService,
    private customAlarmsService: AlarmService,
    private userSettingsService: UserSettingsService,
    private unsubscribeService: UnsubscribeService,
    private modalService: NgbModal,
    private alertService: TnapAlertService,
    private alarmsService: AlarmsService,
    private fileSaverService: FileSaverService,
    private queryParamService: QueryParamService
  ) {
    this.btnRefresh
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap(interval =>
          this.userSettingsService.updatePreferences({
            refreshInterval: interval,
          })
        )
      )
      .subscribe();
  }

  public reloadAlarms(): void {
    this.customAlarmsService.refreshData();
  }

  public changeSelectedColumns(value: AlarmListColumnName, event: any): void {
    if (event.target.checked) {
      this.checkedColumns.add(value);
    }
    if (!event.target.checked) {
      this.checkedColumns.delete(value);
    }
  }

  public saveUserSettings(): void {
    this.userSettingsService
      .updatePreferences({
        columns: [...this.checkedColumns],
      })
      .pipe(takeUntil(this.unsubscribeService.unsubscribe$))
      .subscribe();
  }

  public disableSorting(): number {
    return 0;
  }

  public setSelectedAlarmIds(ids: Set<number>) {
    this.alarmIds = ids;
  }

  public exportSelectedAlarms(): void {
    if (this.alarmIds.size === 0) {
      return;
    }
    const filterByIds = createFilter(
      addFieldPrefix(this.ColumnName.ID),
      FilterOperator.EQUAL_IN,
      [...this.alarmIds].map(id => String(id)),
      true
    );
    this.exportAlarmsWithFilter(filterByIds, undefined).subscribe(blob =>
      this.fileSaverService.save(blob, this.ALARM_EXPORT_FILENAME)
    );
  }
  public exportFilteredAlarms(): void {
    this.filter$
      .pipe(
        filter(isNotNull),
        take(1),
        switchMap(filter => {
          const parsedFilter = parseFilterFromUrl(filter);
          return this.exportAlarmsWithFilter(
            filterBuilder(parsedFilter, true),
            undefined
          );
        })
      )
      .subscribe(blob =>
        this.fileSaverService.save(blob, this.ALARM_EXPORT_FILENAME)
      );
  }
  public exportAllAlarms(): void {
    this.exportAlarmsWithFilter(undefined, undefined).subscribe(blob =>
      this.fileSaverService.save(blob, this.ALARM_EXPORT_FILENAME)
    );
  }

  private exportAlarmsWithFilter(
    filter: string | undefined,
    sort: string | undefined
  ) {
    return this.alarmsService
      .downloadAlarms(this.exportAlarmFields, sort, filter)
      .pipe(take(1));
  }

  openResetPreferencesModal(): void {
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalRef.componentInstance.okText = this.translateService.instant(
      'common.buttons.submit'
    );
    modalRef.componentInstance.title = this.translateService.instant(
      'alarms.modal.resetPreferences.title'
    );
    modalRef.componentInstance.text = this.translateService.instant(
      'alarms.modal.resetPreferences.text'
    );
    modalRef.closed
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap((confirm: boolean) => {
          if (confirm) {
            this.checkedColumns = new Set(DefaultAlarmListColumnNames);
            return this.userSettingsService.updatePreferences({
              columns: DefaultAlarmListColumnNames,
              columnsOrder: DefaultAlarmListColumnNames,
            });
          }
          return EMPTY;
        }),
        tap(() => {
          this.alertService.success(
            this.translateService.instant(
              'alarms.modal.resetPreferences.success'
            ),
            { keepAfterRouteChange: true }
          );
        })
      )
      .subscribe();
  }
}
