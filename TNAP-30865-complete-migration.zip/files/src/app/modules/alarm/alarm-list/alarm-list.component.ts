/*
 * Copyright (c) 2022. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Component,
  EventEmitter,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import {
  catchError,
  delay,
  distinctUntilChanged,
  distinctUntilKeyChanged,
  filter,
  map,
  repeatWhen,
  shareReplay,
  switchMap,
  takeUntil,
  tap,
  withLatestFrom,
} from 'rxjs/operators';
import { combineLatest, EMPTY, Observable, of, Subject, timer } from 'rxjs';
import {
  ActionsResponse,
  Alarm,
  AlarmsService,
  OverviewAlarmListResponse,
} from 'openapi/output';
import { environment } from 'src/environments/environment.development';
import {
  parseSortStringToSort,
  parseSortToSortJsonString,
} from 'src/app/helpers/sorting-helpers';
import {
  Sort,
  SortDirection,
} from 'src/app/components/shared/sort/sort.component';
import {
  AlarmListColumnName,
  columnConfig,
  RefreshIntervals,
} from 'src/app/model/alarm.model';
import {
  filterBuilder,
  parseFilterFromUrl,
} from 'src/app/helpers/filter-helpers';
import { OAuthService } from 'angular-oauth2-oidc';
import { TranslateService } from '@ngx-translate/core';
import { UnsubscribeService } from 'src/app/services/unsubscribe/unsubscribe.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmationModalComponent } from '../../../components/shared/confirmation-modal/confirmation-modal.component';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { AlarmService } from 'src/app/services/alarm.service';
import { UserSettingsService } from '../../../services/user-settings.service';
import { HistoryService } from '../../../services/history.service';
import {
  ActionType,
  CreateActionModel,
  EntityAlarmHistoryActionModel,
  EntityType,
} from '../../../model/user-last-action.model';
import { UpdateUserPreferenceModel } from '../../../model/user-preferences.model';
import { ContextMenuComponent } from '@perfectmemory/ngx-contextmenu';
import { animate, style, transition, trigger } from '@angular/animations';
import { createAlarmPattern } from 'src/app/helpers/component-helpers';
import { I18nPluralPipe } from '@angular/common';
import { isNotNullOrUndefined } from 'src/app/helpers/helpers';
import { alarmListPaginationCountOptions } from 'src/app/modules/alarm/configuration';
import { QueryParamService } from '../../../services/query-param.service';
import { PaginationService } from '../../../services/common-functionalities/pagination.service';
import { BaseFilterService } from '../../../services/common-functionalities/base-filter.service';
import { Router } from '@angular/router';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-alarm-list',
  templateUrl: './alarm-list.component.html',
  styleUrls: ['./alarm-list.component.css'],
  providers: [UnsubscribeService],
  animations: [
    trigger('expand', [
      transition(':enter', [
        style({ height: '0', overflow: 'hidden' }),
        animate(250, style({ height: '*' })),
      ]),
    ]),
  ],
  standalone: false,
})
export class AlarmListComponent implements OnInit, OnDestroy {
  @Output() selectedAlarmsEvent = new EventEmitter<Set<number>>();
  readonly dateTimeFormat = environment.dateTimeFormat;
  readonly paginationCountOptions = alarmListPaginationCountOptions;

  SortDirection = SortDirection;
  ColumnName = AlarmListColumnName;
  contextMenuClickedAlarmID = -1;
  columns: AlarmListColumnName[] = [];
  expandRowMap: Map<number, Observable<Alarm>> = new Map();

  readonly columnConfig = columnConfig;
  // Observable for getting changes
  private reload$ = this.customAlarmsService.getReloadListChanges$();
  private updatePreferencesSubject$ = new Subject<UpdateUserPreferenceModel>();
  private readonly userEmail: string | undefined = this.loginEmail;
  public checkedAlarmIds: Set<number> = new Set();
  public checkMasterCheckbox: Subject<any> = new Subject();
  public isMasterChecked = false;

  @ViewChild(ContextMenuComponent) public basicMenu!: ContextMenuComponent<any>;

  // Observables for getting changes from Preferences service
  readonly userPreferences$ = this.userSettingsService
    .getPreferences$()
    .pipe(
      distinctUntilChanged(),
      shareReplay({ refCount: true, bufferSize: 1 })
    );
  readonly visibleColumns$ = this.userPreferences$.pipe(
    map(settings => new Set(settings.columns))
  );
  private readonly refreshInterval$ = this.userPreferences$.pipe(
    distinctUntilKeyChanged('refreshInterval'),
    map(settings => settings.refreshInterval)
  );
  readonly showEmptyProperties$: Observable<boolean> =
    this.userPreferences$.pipe(
      distinctUntilKeyChanged(
        'alarms',
        (d1, d2) =>
          JSON.stringify(d1.showEmptyProperties) ===
          JSON.stringify(d2.showEmptyProperties)
      ),
      takeUntil(this.unsubscribeService.unsubscribe$),
      map(data => {
        return data.alarms.showEmptyProperties;
      })
    );
  private readonly columnsOrder$ = this.userPreferences$.pipe(
    distinctUntilKeyChanged('columnsOrder'),
    map(settings => settings.columnsOrder)
  );
  readonly page$ = this.queryParamService.getQueryParamAsNumber('page');
  readonly pageSize$ = this.queryParamService.getQueryParamAsNumber(
    'pageSize',
    200
  );
  readonly sort$ = this.queryParamService.getValueOf('sort').pipe(
    map(sort => {
      return sort
        ? parseSortStringToSort(sort)
        : parseSortStringToSort(AlarmListColumnName.SEVERITY);
    })
  );
  readonly filter$ = this.queryParamService.getValueOf('filter');
  readonly alarmId$ = this.queryParamService.getValueOf('alarmId');
  readonly searchValue$ = this.queryParamService.getValueFromQueryFilter('$.*');

  public alarms$: Observable<OverviewAlarmListResponse> = combineLatest([
    this.page$,
    this.pageSize$,
    this.sort$,
    this.filter$,
    this.visibleColumns$,
    this.refreshInterval$,
  ]).pipe(
    switchMap(
      ([page, pageSize, sort, filterFromUrl, fields, refreshInterval]) => {
        const request$ = this.makeRequest(
          fields,
          page,
          pageSize,
          sort,
          filterFromUrl
        ).pipe(repeatWhen(() => this.reload$));
        if (refreshInterval === RefreshIntervals.NO_INTERVAL) {
          return request$;
        }
        return timer(0, parseInt(refreshInterval) * 60 * 1000).pipe(
          switchMap(() => request$)
        );
      }
    ),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  constructor(
    private alarmsService: AlarmsService,
    private oAuthService: OAuthService,
    private translateService: TranslateService,
    private readonly unsubscribeService: UnsubscribeService,
    private readonly modalService: NgbModal,
    private customAlarmsService: AlarmService,
    private userSettingsService: UserSettingsService,
    private historyService: HistoryService,
    private i18nPluralPipe: I18nPluralPipe,
    private queryParamService: QueryParamService,
    private alertService: TnapAlertService,
    private paginationService: PaginationService,
    private filterService: BaseFilterService,
    private router: Router
  ) {
    // set default value for RAISED_AT and SEVERITY
    this.filter$
      .pipe(takeUntil(this.unsubscribeService.unsubscribe$))
      .subscribe(filterFromUrl => {
        const parsedFilters = parseFilterFromUrl(filterFromUrl);
        this.filterService.changeAlarmFilter(parsedFilters);
      });
  }
  get loginEmail(): string | undefined {
    const claims = Object(this.oAuthService.getIdentityClaims());
    return claims.email ? claims.email : undefined;
  }

  public onChangePage(page: number): void {
    this.paginationService.changePage(page);
  }

  public onChangePageSize(pageSize: number): void {
    this.paginationService.changePageSize(pageSize);
  }

  public reloadAlarms(): void {
    this.customAlarmsService.refreshData();
  }

  public onRightClick(alarmId: number): void {
    this.contextMenuClickedAlarmID = alarmId;
  }

  public convertToSet(event: any): Set<number> {
    return new Set<number>(event.value);
  }
  public clearAlarms(alarmIds: Set<number> | number[]): void {
    if (!this.userEmail) {
      this.alertService.error(
        this.translateService.instant(
          'alarms.contextMenu.messages.error.noEmail'
        ),
        { keepAfterRouteChange: true }
      );
      return;
    }
    const translateMessage = this.i18nPluralPipe.transform(
      [...alarmIds].length,
      {
        '=1': 'alarms.modal.clear.singularText',
        other: 'alarms.modal.clear.pluralText',
      }
    );
    //open confirmation modal for clearing the alarm
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalRef.componentInstance.okText = this.translateService.instant(
      'common.buttons.clear'
    );
    modalRef.componentInstance.title = this.translateService.instant(
      'alarms.modal.clear.title'
    );
    modalRef.componentInstance.text = this.translateService.instant(
      translateMessage,
      {
        alarmCount: [...alarmIds].length,
      }
    );
    modalRef.closed
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap((confirm: boolean) => {
          if (confirm) {
            const pattern = createAlarmPattern(alarmIds);
            return this.alarmsService.clearAlarms({
              clearUserId: this.userEmail!,
              alarmPattern: pattern,
            });
          }
          return EMPTY;
        }),
        switchMap(() => this.addHistoryAction(ActionType.CLEAR, alarmIds)),
        tap(() => {
          this.resetCheckedAlarms();
          this.alertService.success(
            this.translateService.instant(
              'alarms.contextMenu.messages.success.clear'
            ),
            { keepAfterRouteChange: true }
          );
        })
      )
      .subscribe(() => this.reloadAlarms());
  }

  public acknowledgeAlarms(alarmIds: Set<number>): void {
    if (!this.userEmail) {
      this.alertService.error(
        this.translateService.instant(
          'alarms.contextMenu.messages.error.noEmail'
        ),
        { keepAfterRouteChange: true }
      );
      return;
    }
    const pattern = createAlarmPattern(alarmIds);
    this.alarmsService
      .acknowledgeAlarms({
        acknowledgeUserId: this.userEmail,
        alarmPattern: pattern,
      })
      .pipe(
        switchMap(() => this.addHistoryAction(ActionType.ACK, alarmIds)),
        takeUntil(this.unsubscribeService.unsubscribe$),
        tap(() => {
          this.resetCheckedAlarms();
          this.alertService.success(
            this.translateService.instant(
              'alarms.contextMenu.messages.success.acknowledge'
            ),
            { keepAfterRouteChange: true }
          );
        })
      )
      .subscribe(() => this.reloadAlarms());
  }

  public unacknowledgeAlarms(alarmIds: Set<number>): void {
    if (!this.userEmail) {
      this.alertService.error(
        this.translateService.instant(
          'alarms.contextMenu.messages.error.noEmail'
        ),
        { keepAfterRouteChange: true }
      );
      return;
    }
    const pattern = createAlarmPattern(alarmIds);
    this.alarmsService
      .unacknowledgeAlarms({
        unacknowledgeUserId: this.userEmail,
        alarmPattern: pattern,
      })
      .pipe(
        switchMap(() => this.addHistoryAction(ActionType.UNACK, alarmIds)),
        takeUntil(this.unsubscribeService.unsubscribe$),
        tap(() => {
          this.resetCheckedAlarms();
          this.alertService.success(
            this.translateService.instant(
              'alarms.contextMenu.messages.success.unacknowledge'
            ),
            { keepAfterRouteChange: true }
          );
        })
      )
      .subscribe(() => this.reloadAlarms());
  }

  ngOnDestroy() {
    window.removeEventListener('scroll', this.onScroll, true);
  }

  ngOnInit() {
    this.alarmId$
      .pipe(
        filter(isNotNullOrUndefined),
        takeUntil(this.unsubscribeService.unsubscribe$)
      )
      .subscribe((id: string) => {
        this.expandRowChange(Number(id));
      });

    this.updatePreferencesSubject$
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap(preferences =>
          this.userSettingsService.updatePreferences(preferences)
        )
      )
      .subscribe();

    window.addEventListener('scroll', this.onScroll, true);

    combineLatest([this.visibleColumns$, this.columnsOrder$])
      .pipe(takeUntil(this.unsubscribeService.unsubscribe$))
      .subscribe(([columnsName, order]) => {
        const visibleColumns = columnsName;
        const columnsOrder = order;
        this.columns = [];

        columnsOrder.forEach(column => {
          this.addToColumns(visibleColumns, column);
        });
        visibleColumns.forEach(column => {
          if (!this.columns.includes(column)) {
            this.columns.push(column);
          }
        });
      });

    this.checkMasterCheckbox
      .pipe(
        withLatestFrom(this.alarms$),
        takeUntil(this.unsubscribeService.unsubscribe$)
      )
      .subscribe(([event, alarms]) => {
        if (event.target.checked) {
          this.isMasterChecked = true;
          alarms.items
            .map(alarm => alarm.id)
            .forEach(id => this.checkedAlarmIds.add(id));
        }
        if (!event.target.checked) {
          this.isMasterChecked = false;
          this.checkedAlarmIds = new Set();
        }
        this.selectedAlarmsEvent.emit(this.checkedAlarmIds);
      });
  }

  private onScroll(): void {
    if (this.contextMenuClickedAlarmID !== -1) {
      document.dispatchEvent(new Event('click'));
    }
  }

  public dropCol(event: CdkDragDrop<AlarmListColumnName[]>): void {
    moveItemInArray(this.columns, event.previousIndex, event.currentIndex);
    this.updatePreferencesSubject$.next({ columnsOrder: this.columns });
  }

  private addToColumns(
    visibleColumns: Set<AlarmListColumnName>,
    item: AlarmListColumnName
  ): void {
    if ([...visibleColumns].includes(item)) {
      this.columns.push(item);
    }
  }

  public expandRowChange(id: number): void {
    if (this.expandRowMap.has(id)) {
      this.expandRowMap.delete(id);
      return;
    }

    const alarmDetail = this.alarmsService.getAlarm(Number(id)).pipe(
      repeatWhen(() => {
        return this.reload$.pipe(delay(5000));
      })
    );
    this.expandRowMap.set(id, alarmDetail);
  }

  public changeSelectedAlarms(id: number, event: any): void {
    this.isMasterChecked = false;
    if (event.target.checked) {
      this.checkedAlarmIds.add(id);
    }
    if (!event.target.checked) {
      this.checkedAlarmIds.delete(id);
    }
    this.selectedAlarmsEvent.emit(this.checkedAlarmIds);
  }

  private resetCheckedAlarms(): void {
    this.checkedAlarmIds = new Set();
    this.isMasterChecked = false;
    this.selectedAlarmsEvent.emit(this.checkedAlarmIds);
  }

  public addHistoryAction(
    actionType: ActionType,
    value: Set<number> | number[] | string
  ): Observable<ActionsResponse | null> {
    return this.historyService
      .createHistoryAction(<CreateActionModel<EntityAlarmHistoryActionModel>>{
        type: actionType,
        entity: EntityType.ALARM,
        entityParams: {
          alarmId:
            typeof value === 'string' ? value : String([...value].join(',')),
        },
      })
      .pipe(catchError(() => of(null)));
  }

  public trackByFn(index: number, item: Alarm): number | null {
    if (!item) return null;
    return item.id!;
  }
  private makeRequest(
    fields: Set<AlarmListColumnName>,
    page: number,
    pageSize: number,
    sort: Sort,
    filtersFromUrl: string | null
  ) {
    const sorting = sort
      ? parseSortToSortJsonString(sort).replace(/@/g, '\\@')
      : undefined;
    const parsedFilters = parseFilterFromUrl(
      filtersFromUrl,
      this.router,
      'statusPage',
      {
        header: 'common.error.badRequest.header',
        message: 'common.error.badRequest.message',
      }
    );
    const filters = filterBuilder(parsedFilters, true);
    const fieldsValue = this.createFieldsString(fields);
    return this.alarmsService.listAlarms(
      fieldsValue,
      page,
      pageSize,
      sorting,
      filters
    );
  }
  private createFieldsString(fields: Set<AlarmListColumnName>): string {
    return Array.from(fields.keys())
      .map(field => field.split('.')[0])
      .join(',');
  }
}
