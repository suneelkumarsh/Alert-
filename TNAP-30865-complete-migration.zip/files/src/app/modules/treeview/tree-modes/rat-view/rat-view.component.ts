/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ChangeDetectionStrategy,
  Component,
  inject,
  signal,
  computed,
  viewChild,
  afterRenderEffect,
  output,
  input,
  OnInit,
  DestroyRef,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { InputSearchComponent } from '@portal-mfe/tnap-ui-kit/components/input-search';
import {
  TreeViewComponent,
  TreeNode,
  NodeAriaLabelFn,
} from '@portal-mfe/ng-tree-lib';
import { BadgeComponent } from '@portal-mfe/tnap-ui-kit/components/badge';
import {
  MIN_SEARCH_QUERY_LENGTH,
  TreeExpansionService,
} from '../../shared/tree-expansion.service';
import { Subject, of, merge } from 'rxjs';
import {
  debounceTime,
  distinctUntilChanged,
  filter,
  map,
  switchMap,
  catchError,
  tap,
  take,
} from 'rxjs/operators';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { QueryParamService } from 'src/app/services/query-param.service';
import { RATVIEW_ICON } from 'src/app/modules/treeview/configuration';
import { SharedModule } from 'src/app/shared.module';
import { HighlightPipe } from 'src/app/pipes/highlight.pipe';
import { TreeViewServiceType } from 'src/app/model/treeview.model';
import { CustomTreeviewService } from 'src/app/services/custom-treeview.service';
import { TreeviewListResponse } from 'openapi/output';
import {
  findNodeByPathKey,
  parseRanNodeKey,
  ranNodeKey,
  ranPathKey,
  resolvePathPrefix,
} from '../../shared/ran-node-key';
import { AutoSelectOnSearchService } from '../../shared/auto-select-on-search.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-rat-view',
  standalone: true,
  imports: [
    CommonModule,
    TranslateModule,
    InputSearchComponent,
    TreeViewComponent,
    SharedModule,
    BadgeComponent,
    HighlightPipe,
  ],
  templateUrl: './rat-view.component.html',
  styleUrls: ['./rat-view.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  // Per view, not root: the parameter it consumes is armed and spent by this tree alone.
  providers: [AutoSelectOnSearchService],
})
export class RatViewComponent implements OnInit {
  private readonly customTreeviewService = inject(CustomTreeviewService);
  private readonly treeExpansionService = inject(TreeExpansionService);
  readonly autoSelect = inject(AutoSelectOnSearchService);
  private readonly translateService = inject(TranslateService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly queryParamService = inject(QueryParamService);
  private readonly alertService = inject(TnapAlertService);

  readonly RATVIEW_ICON = RATVIEW_ICON;
  readonly TreeViewServiceType = TreeViewServiceType;
  readonly ranNodeKey = ranNodeKey;

  /**
   * The row's accessible name, passed to the library rather than set in the node template: the
   * `aria-label` the library puts on the `treeitem` suppresses that row's own subtree for naming,
   * so the vendor badge is displayed but never announced and no attribute the template sets can
   * change that.
   *
   * A field holding an arrow function rather than a method, so the input keeps one stable identity
   * and needs no `.bind(this)` in the template. `instant` rather than a stream because the library
   * wants a plain string; the library re-reads it per cycle, so a language switch is picked up.
   */
  readonly ratNodeAriaLabel: NodeAriaLabelFn = flatNode => {
    const model = flatNode.node.metadata?.['model'] as
      | { vendor?: string }
      | undefined;
    if (!model?.vendor) {
      return flatNode.node.label;
    }
    const vendor = this.translateService.instant(
      'treeview.ratView.vendorLabel',
      { vendor: model.vendor }
    );
    return `${flatNode.node.label}, ${vendor}`;
  };

  treeComponent = viewChild<TreeViewComponent>('ratTree');

  activatedNodes = input<string[]>([]);
  activatedPaths = input<string[][]>([]);
  nodeSelectionChanged = output<TreeNode[]>();
  /** The segment of a bookmarked path that no longer resolves - see `revealActivatedPath`. */
  nodeNotFound = output<string>();
  /**
   * Emitted after an unfiltered (no search query, no technology filter) load's `stampPaths` has
   * run. Callers use this to upgrade pre-path URLs: `findPathSegmentsTo` takes first occurrence, and
   * over a pruned tree that can be a path the full tree does not have.
   */
  treeLoaded = output<TreeNode[]>();

  readonly searchInput = signal('');
  readonly searchQuery = signal('');
  readonly treeData = signal<TreeNode[]>([]);
  readonly isLoading = signal(false);
  readonly selectedTechnology = signal('');

  /**
   * What the tree's status region announces, as a key plus its params rather than a rendered
   * string, so a language switch retranslates the message that is currently in the region.
   */
  readonly statusMessage = signal<{
    key: string;
    params: Record<string, unknown>;
  } | null>(null);

  readonly technologyCategories = computed(() => [
    {
      label: this.translateService.instant('treeview.ratView.filter.all'),
      value: '',
    },
    { label: 'GSM', value: 'GSM' },
    { label: 'LTE', value: 'LTE' },
    { label: 'LTE-NB-IoT', value: 'LTE-NB-IoT' },
    { label: 'NR', value: 'NR' },
  ]);

  private readonly searchSubject = new Subject<string>();
  private readonly technologySubject = new Subject<string>();
  private lastExpandedQuery = '';

  constructor() {
    this.setupTreeExpansion();
  }

  ngOnInit(): void {
    // Armed before the search is seeded below, so the parameter is set by the time the first
    // response arrives and a deep link's own query can auto-select.
    this.autoSelect.armFromUrl(this.destroyRef);

    this.queryParamService
      .getValueOf('query')
      .pipe(
        take(1),
        map(q => q ?? '')
      )
      .subscribe(query => {
        this.searchInput.set(query);
        this.initializeSearchWithLoad(query);
      });
  }

  onSearchQueryChange(query: string): void {
    // Only the search box calls this - the URL's own query is seeded straight into searchSubject -
    // so reaching here means the user is searching, which spends AC2.1's parameter.
    this.autoSelect.userSearchStarted();
    this.searchInput.set(query);
    this.searchSubject.next(query);
    this.queryParamService.updateQueryParam({
      query: query && query.trim().length > 0 ? query : null,
    });
  }

  clearSearch(): void {
    this.autoSelect.userSearchStarted();
    this.autoSelect.forgetLastQuery();
    this.lastExpandedQuery = '';
    this.searchInput.set('');
    this.searchQuery.set('');
    this.searchSubject.next('');
    this.queryParamService.updateQueryParam({ query: null });
  }

  private initializeSearchWithLoad(initialQuery: string): void {
    const searchTrigger$ = this.searchSubject.pipe(
      debounceTime(500),
      distinctUntilChanged(),
      filter(query => query.length === 0 || query.length > 2)
    );

    // Technology change always reloads using the already-normalised search query
    const technologyTrigger$ = this.technologySubject.pipe(
      distinctUntilChanged(),
      map(() => this.searchQuery())
    );

    merge(searchTrigger$, technologyTrigger$)
      .pipe(
        tap(query => {
          this.isLoading.set(true);
          this.searchQuery.set(query);
        }),
        switchMap(() => this.loadTreeData()),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(items => {
        this.isLoading.set(false);
        this.treeData.set(items);
        this.statusMessage.set({
          key: 'treeview.ratView.status.treeLoaded',
          params: { count: items.length },
        });
        this.autoSelectSingleMatch(items);
        // Only an unfiltered tree is safe to upgrade a legacy URL against: findPathSegmentsTo takes
        // the first occurrence, and over a pruned tree that can be a path the full tree does not have.
        if (!this.searchQuery() && !this.selectedTechnology()) {
          this.treeLoaded.emit(items);
        }
      });

    // Seed initial load from URL query (or empty for default)
    this.searchSubject.next(initialQuery);
  }

  /**
   * AC2.1 of TNAP-30342: with `select=true` an unambiguous match is opened without a click.
   *
   * Emitted through the normal selection output, so the URL round-trip (`selectedNodes` →
   * `activatedNodes`) is what actually selects. `items` have been through `stampPaths`, so the
   * emitted node carries `metadata.path`; without it the URL entry is path-less and, with
   * `pathScopedKeys`, marks no row.
   *
   * The emitted array replaces any caller-supplied `selectedNodes` rather than extending it:
   * `TreeviewComponent.updateSelectedNodesInUrl` writes the whole param from the emitted array,
   * so a CGI link carrying `select=true`, a `query` and its own `selectedNodes` loses the latter;
   * the AC-mandated unique match deliberately wins.
   *
   * A search response is the whole pruned subtree, so "exactly one match" needs no completeness
   * argument here - unlike the paginated node view.
   */
  private autoSelectSingleMatch(items: TreeNode[]): void {
    const match = this.autoSelect.consumeFor(this.searchQuery(), items);
    if (match) {
      this.nodeSelectionChanged.emit([match]);
    }
  }

  /**
   * The row's id when that - and not its label - is why the search matched it, otherwise null. The
   * template renders it so an id hit carries a visible reason; see `TreeExpansionService`.
   */
  matchedIdOnly(node: TreeNode, searchQuery: string): string | null {
    return this.treeExpansionService.matchedIdOnly(node, searchQuery);
  }

  private loadTreeData() {
    const selectedRadioAccessTech = this.selectedTechnology();
    const query = this.searchQuery();
    // Only the unfiltered tree is lazy. A search still returns the full pruned subtree, because
    // TreeExpansionService reveals matches by walking a materialised children tree.
    const depth = query ? undefined : 1;
    const revealPath = query ? undefined : this.activatedPaths().at(-1);
    // A pre-path bookmark has no `path`, so activatedPaths drops it. Fall back to the bare composite
    // key so the backend still materialises the branch - that is what lets upgradeLegacySelection
    // find the node and rewrite the URL with a real path.
    const revealSegment = query
      ? undefined
      : (revealPath?.at(-1) ?? this.activatedNodes().at(-1));
    // The backend needs the two halves separately: the id names the node, the type tells it which
    // reverse lookup to start from. Without the type it probes types in a fixed order and a shared
    // id resolves to the wrong one.
    const reveal = revealSegment ? parseRanNodeKey(revealSegment) : undefined;
    // Only emit nodeNotFound when the payload was guaranteed to contain the full unfiltered tree.
    // Under a technology filter "absent" and "deleted" are indistinguishable.
    const reportMissing = !query && !selectedRadioAccessTech;
    return this.customTreeviewService
      .getRANTreeview(
        query,
        selectedRadioAccessTech,
        depth,
        reveal?.id,
        reveal?.aaiType || undefined
      )
      .pipe(
        catchError(() => of<TreeviewListResponse>({ items: [] })),
        map(response =>
          this.revealActivatedPath(
            this.stampPaths(
              response?.items?.map(item =>
                this.customTreeviewService.mapToFinalData(item)
              ) ?? []
            ),
            revealPath,
            reportMissing
          )
        )
      );
  }

  /**
   * Records each node's own root-first path in its metadata, so a selection emitted from the tree
   * can be written back to the URL without re-walking the tree to rediscover where it sits.
   */
  private stampPaths(items: TreeNode[], parentPath: string[] = []): TreeNode[] {
    for (const item of items) {
      const path = [...parentPath, ranNodeKey(item)];
      item.metadata = { ...item.metadata, path };
      if (item.children?.length) {
        this.stampPaths(item.children, path);
      }
    }
    return items;
  }

  /**
   * Opens the branch the URL names.
   *
   * `revealedPath` from the backend is not usable here: `resolveAncestorPath` resolves a cell by
   * trying PNF before generic-VNF, so a URL naming the gNodeB comes back revealed under the BBU.
   * Walking the URL's own path instead is exact.
   *
   * Costs at most one extra request. `serviceInstanceChildren` returns PNFs *and* generic-VNFs at
   * the same level, so a diverging level-3 ancestor is already in the payload with only its cells
   * missing; divergence cannot happen higher up, because nms and service-instance are
   * single-parent and the cell is the leaf.
   *
   * @param reportMissing Whether to emit `nodeNotFound` when an ancestor cannot be resolved.
   *   Callers pass false for filtered or search loads: "absent from the results" is not "deleted
   *   from AAI" when the payload is a subset.
   */
  private revealActivatedPath(
    items: TreeNode[],
    path: string[] | undefined,
    reportMissing: boolean
  ): TreeNode[] {
    if (!path || path.length < 2) {
      return items;
    }

    // Only the ANCESTORS are expected in this payload. The target itself is routinely absent -
    // that is the whole bug being fixed: the backend reveals the cell under the BBU, so the
    // gNodeB arrives collapsed with children===undefined. Validating the full path here would
    // report every correct deep link as not-found.
    const ancestors = path.slice(0, -1);
    const prefix = resolvePathPrefix(items, ancestors);
    if (!prefix || prefix.depth < ancestors.length) {
      // The first ancestor segment that no longer resolves. Nothing is selected, and the URL is
      // deliberately left alone - rewriting it risks a modal/navigation loop.
      if (reportMissing) {
        this.nodeNotFound.emit(
          parseRanNodeKey(ancestors[prefix ? prefix.depth : 0]).id
        );
      }
      return items;
    }

    let level: TreeNode[] | undefined = items;
    for (const segment of ancestors) {
      const node: TreeNode | undefined = level?.find(
        candidate => ranNodeKey(candidate) === segment
      );
      if (!node) {
        // Unreachable: resolvePathPrefix matched every ancestor above; this guard is defensive.
        return items;
      }
      // resolvePathPrefix only locates the prefix; this loop is what sets isExpanded on each ancestor.
      // The target is selected and scrolled to, never pre-opened - hence ancestors only.
      node.isExpanded = true;
      level = node.children;
    }

    const target = path[path.length - 1];
    if (level) {
      // The parent's children are already materialised, so the target's absence is real.
      if (!level.some(child => ranNodeKey(child) === target)) {
        if (reportMissing) {
          this.nodeNotFound.emit(parseRanNodeKey(target).id);
        }
      }
      return items;
    }

    // Marking isExpanded is not enough for a parent the backend left unmaterialised: nodeExpand
    // fires only on user interaction. Reuse onNodeExpand rather than issuing a parallel request -
    // it owns the parent-type guard, the isLoading flag, the children===undefined cache guard and
    // the error path. It also defers the not-found verdict until the children actually arrive,
    // which is necessary: until then, a missing target is indistinguishable from an unfetched one.
    prefix.node.isExpanded = true;
    this.onNodeExpand(prefix.node, reportMissing ? target : undefined);
    return items;
  }

  /**
   * Fetches a node's children the first time it is expanded. Nodes arrive from a depth=1 response
   * with only a childCount, so the chevron is present but the children are not.
   *
   * @param revealTarget Segment of a deep-linked node expected among the arriving children. When
   *   it is absent from the response the bookmarked path is stale, which can only be judged here:
   *   before the response, "missing" and "not yet fetched" look identical.
   */
  onNodeExpand(node: TreeNode, revealTarget?: string): void {
    if (!node.hasChildren || node.children !== undefined || node.isLoading) {
      return;
    }

    const aaiType = node.metadata?.['aaiType'] as string | undefined;
    const parentType = this.customTreeviewService.toRanParentType(aaiType);
    if (!parentType) {
      // A chevron on a type the children endpoint does not accept means the payload disagrees
      // with the contract - firing the request anyway would only produce a 400. Unlike a failed
      // request this can never succeed on retry, so the node is marked loaded and stays a leaf.
      console.error(
        `[rat-view] BFF payload violates the children contract: node ${node.id} advertises children but its aaiType "${aaiType}" is not an accepted parentType. Expected one of network-management-system, service-instance, pnf, generic-vnf.`
      );
      node.children = [];
      this.alertService.error(
        this.translateService.instant('treeview.ratView.loadChildrenError'),
        { keepAfterRouteChange: true }
      );
      this.treeData.update(data => [...data]);
      return;
    }

    node.isLoading = true;
    this.customTreeviewService
      .getRANTreeviewChildren(node.id, parentType, this.selectedTechnology())
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: children => {
          node.isLoading = false;
          // Assign even when empty: `children === undefined` is the cache guard above, so leaving
          // it unset would refetch a level known to be empty on every collapse/expand cycle.
          node.children = this.stampPaths(
            children,
            (node.metadata?.['path'] as string[] | undefined) ?? []
          );
          // The tree mutates in place, so the signal needs a new array identity to re-flatten.
          this.treeData.update(data => [...data]);
          // Expanding moves no focus, so without this the newly revealed rows are silent.
          this.statusMessage.set({
            key: 'treeview.ratView.status.childrenLoaded',
            params: { count: children.length, name: node.label },
          });
          if (
            revealTarget &&
            !children.some(child => ranNodeKey(child) === revealTarget)
          ) {
            this.nodeNotFound.emit(parseRanNodeKey(revealTarget).id);
          }
        },
        error: () => {
          node.isLoading = false;
          // Deliberately leave `children` undefined: a transient failure must not be cached as
          // "this node has none". Collapsing and re-expanding is then the retry, which is why
          // this is an error callback rather than a catchError that would feed [] into next.
          this.alertService.error(
            this.translateService.instant('treeview.ratView.loadChildrenError'),
            { keepAfterRouteChange: true }
          );
          this.treeData.update(data => [...data]);
        },
      });
  }

  /**
   * The value the parent's `querySelector('[data-node-id=…]').focus()` looks for. Must match the
   * key the library renders, so it is the composed path whenever one was stamped.
   */
  nodeDomKey(node: TreeNode): string {
    const path = node.metadata?.['path'] as string[] | undefined;
    return path?.length ? ranPathKey(path) : ranNodeKey(node);
  }

  onTechnologySelect(technology: string): void {
    this.selectedTechnology.set(technology);
    this.technologySubject.next(technology);
  }

  isTechnologySelected(technology: string): boolean {
    return this.selectedTechnology() === technology;
  }

  selectionChanged(selectedIds: string[]): void {
    this.nodeSelectionChanged.emit(
      selectedIds
        .map(key => findNodeByPathKey(this.treeData(), key))
        .filter((node): node is TreeNode => node !== null)
    );
  }

  private setupTreeExpansion(): void {
    afterRenderEffect(() => {
      const tree = this.treeComponent();
      const data = this.treeData();
      const query = this.searchQuery();

      if (!this.shouldExpandTree(tree, data, query)) {
        return;
      }

      if (this.lastExpandedQuery === query) {
        return;
      }

      this.lastExpandedQuery = query;
      this.treeExpansionService.expandNodesForSearchResults(tree!, data, query);
    });
  }

  private shouldExpandTree(
    tree: TreeViewComponent | undefined,
    data: TreeNode[],
    query: string
  ): boolean {
    return !!(
      tree &&
      data.length &&
      query.length >= MIN_SEARCH_QUERY_LENGTH &&
      !this.isLoading()
    );
  }
}
