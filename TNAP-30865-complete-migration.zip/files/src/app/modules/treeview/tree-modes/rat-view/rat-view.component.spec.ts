/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ComponentFixture,
  TestBed,
  fakeAsync,
  tick,
} from '@angular/core/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { of, throwError } from 'rxjs';
import { RatViewComponent } from './rat-view.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { CustomTreeviewService } from 'src/app/services/custom-treeview.service';
import { TreeExpansionService } from '../../shared/tree-expansion.service';
import { composePathKey, TreeNode } from '@portal-mfe/ng-tree-lib';
import { ranNodeKey } from '../../shared/ran-node-key';
import { TreeViewServiceType } from 'src/app/model/treeview.model';
import { NodeType } from 'src/app/model/topology.model';
import { QueryParamService } from 'src/app/services/query-param.service';
import { TreeviewParentType } from 'openapi/output';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

const RAN_PARENT_TYPES: TreeviewParentType[] = [
  TreeviewParentType.NETWORK_MANAGEMENT_SYSTEM,
  TreeviewParentType.SERVICE_INSTANCE,
  TreeviewParentType.PNF,
  TreeviewParentType.GENERIC_VNF,
];

describe('RatViewComponent', () => {
  let component: RatViewComponent;
  let fixture: ComponentFixture<RatViewComponent>;
  let mockCustomTreeviewService: jasmine.SpyObj<CustomTreeviewService>;
  let mockTreeExpansionService: jasmine.SpyObj<TreeExpansionService>;
  let mockAlertService: jasmine.SpyObj<TnapAlertService>;
  let mockQueryParamService: jasmine.SpyObj<QueryParamService>;

  const waitForDebounce = () => {
    tick(500);
    fixture.detectChanges();
  };

  const resetServiceSpy = () => {
    mockCustomTreeviewService.getRANTreeview.calls.reset();
  };

  const resetChildrenSpy = () => {
    mockCustomTreeviewService.getRANTreeviewChildren.calls.reset();
  };

  beforeEach(fakeAsync(async () => {
    const translateServiceSpy = jasmine.createSpyObj('TranslateService', [
      'stream',
      'get',
      'instant',
    ]);
    translateServiceSpy.stream.and.returnValue(of({}));
    translateServiceSpy.get.and.returnValue(of('Translated'));
    translateServiceSpy.instant.and.returnValue('All');

    mockCustomTreeviewService = jasmine.createSpyObj('CustomTreeviewService', [
      'getRANTreeview',
      'mapToFinalData',
      'getRANTreeviewChildren',
      'toRanParentType',
    ]);
    mockCustomTreeviewService.getRANTreeview.and.returnValue(of({ items: [] }));
    mockCustomTreeviewService.getRANTreeviewChildren.and.returnValue(of([]));
    // Mirrors the real mapping: only the four RAN parent types resolve, everything else is
    // undefined - the component's behaviour differs per branch, so the stub must too.
    mockCustomTreeviewService.toRanParentType.and.callFake((type?: string) =>
      RAN_PARENT_TYPES.includes(type as TreeviewParentType)
        ? (type as TreeviewParentType)
        : undefined
    );
    mockCustomTreeviewService.mapToFinalData.and.returnValue({
      id: 'test',
      label: 'Test Node',
      metadata: {},
    });

    mockTreeExpansionService = jasmine.createSpyObj('TreeExpansionService', [
      'expandNodesForSearchResults',
      'findSingleMatch',
      'matchedIdOnly',
    ]);
    // Delegates to the real matcher: a canned return would assert nothing about *which* node
    // auto-selection picks, or that it declines an ambiguous result.
    mockTreeExpansionService.findSingleMatch.and.callFake(
      (treeData: TreeNode[], searchQuery: string) =>
        new TreeExpansionService().findSingleMatch(treeData, searchQuery)
    );
    mockTreeExpansionService.matchedIdOnly.and.callFake(
      (node: TreeNode, searchQuery: string) =>
        new TreeExpansionService().matchedIdOnly(node, searchQuery)
    );

    mockAlertService = jasmine.createSpyObj('TnapAlertService', ['error']);

    mockQueryParamService = jasmine.createSpyObj('QueryParamService', [
      'getValueOf',
      'updateQueryParam',
    ]);
    mockQueryParamService.getValueOf.and.returnValue(of(null));
    mockQueryParamService.updateQueryParam.and.stub();

    await TestBed.configureTestingModule({
      imports: [RatViewComponent, TranslateModule.forRoot()],
      providers: [
        { provide: TranslateService, useValue: translateServiceSpy },
        { provide: CustomTreeviewService, useValue: mockCustomTreeviewService },
        { provide: TreeExpansionService, useValue: mockTreeExpansionService },
        { provide: QueryParamService, useValue: mockQueryParamService },
        { provide: TnapAlertService, useValue: mockAlertService },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    })
      .overrideComponent(RatViewComponent, {
        set: { template: '' },
      })
      .compileComponents();

    fixture = TestBed.createComponent(RatViewComponent);
    component = fixture.componentInstance;

    // Clear any initialization calls
    mockCustomTreeviewService.getRANTreeview.calls.reset();

    fixture.detectChanges();

    // Wait for initial load to complete
    tick(300);
    fixture.detectChanges();
    tick(1);

    // Reset again after initialization
    mockCustomTreeviewService.getRANTreeview.calls.reset();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize component properly', () => {
    expect(component).toBeDefined();
    expect(component.treeData).toBeDefined();
    expect(component.searchInput).toBeDefined();
    expect(component.searchQuery).toBeDefined();
    expect(component.isLoading).toBeDefined();
    expect(component.selectedTechnology).toBeDefined();
    expect(component.technologyCategories).toBeDefined();
  });

  it('should handle search query changes', fakeAsync(() => {
    // Non-empty activatedNodes so the undefined 4th argument proves search suppresses revealNodeId,
    // not that activatedNodes was already empty.
    fixture.componentRef.setInput('activatedNodes', ['nms-1']);
    fixture.detectChanges();

    component.onSearchQueryChange('test query');
    expect(component.searchInput()).toBe('test query');

    waitForDebounce();

    expect(component.searchQuery()).toBe('test query');
    expect(mockCustomTreeviewService.getRANTreeview).toHaveBeenCalledWith(
      'test query',
      '',
      undefined,
      undefined,
      undefined
    );
  }));

  it('should clear search properly', fakeAsync(() => {
    component.onSearchQueryChange('test');
    waitForDebounce();

    resetServiceSpy();

    component.clearSearch();
    expect(component.searchInput()).toBe('');
    expect(component.searchQuery()).toBe('');

    waitForDebounce();

    expect(mockCustomTreeviewService.getRANTreeview).toHaveBeenCalledWith(
      '',
      '',
      1,
      undefined,
      undefined
    );
  }));

  it('should handle technology selection', () => {
    const technology = 'LTE';
    component.onTechnologySelect(technology);
    expect(component.selectedTechnology()).toBe(technology);
    expect(component.isTechnologySelected(technology)).toBe(true);
  });

  it('should call getRANTreeview with selected technology when technology filter changes', fakeAsync(() => {
    resetServiceSpy();

    component.onTechnologySelect('NR');
    tick(500);
    fixture.detectChanges();

    expect(component.selectedTechnology()).toBe('NR');
    expect(mockCustomTreeviewService.getRANTreeview).toHaveBeenCalledWith(
      '',
      'NR',
      1,
      undefined,
      undefined
    );
  }));

  it('should call getRANTreeview with both search query and selected technology', fakeAsync(() => {
    component.onSearchQueryChange('test query');
    waitForDebounce();
    resetServiceSpy();

    component.onTechnologySelect('LTE');
    tick(500);
    fixture.detectChanges();

    expect(mockCustomTreeviewService.getRANTreeview).toHaveBeenCalledWith(
      'test query',
      'LTE',
      undefined,
      undefined,
      undefined
    );
  }));

  it('should reset technology selection to all when empty string is selected', () => {
    component.onTechnologySelect('LTE');
    expect(component.isTechnologySelected('LTE')).toBe(true);
    expect(component.isTechnologySelected('')).toBe(false);

    component.onTechnologySelect('');
    expect(component.selectedTechnology()).toBe('');
    expect(component.isTechnologySelected('')).toBe(true);
    expect(component.isTechnologySelected('LTE')).toBe(false);
  });

  it('should handle node selection changes', () => {
    const mockTreeData: TreeNode[] = [
      {
        id: 'node1',
        label: 'Test Node 1',
        metadata: {
          serviceType: 'TEST_SERVICE',
          aaiType: 'TEST_TYPE',
          type: TreeViewServiceType.GNODEB,
        },
      },
    ];

    component.treeData.set(mockTreeData);
    spyOn(component.nodeSelectionChanged, 'emit');

    component.selectionChanged(['TEST_TYPE:node1']);

    expect(component.nodeSelectionChanged.emit).toHaveBeenCalledWith([
      {
        id: 'node1',
        label: 'Test Node 1',
        metadata: {
          serviceType: 'TEST_SERVICE',
          aaiType: 'TEST_TYPE',
          type: TreeViewServiceType.GNODEB,
        },
      },
    ]);
  });

  it('should handle RAN node type correctly in selection', () => {
    const mockTreeData: TreeNode[] = [
      {
        id: 'ran1',
        label: 'RAN Node 1',
        metadata: {
          aaiType: 'GNODEB',
          type: TreeViewServiceType.RAN_NODE,
        },
      },
    ];

    component.treeData.set(mockTreeData);
    spyOn(component.nodeSelectionChanged, 'emit');

    component.selectionChanged(['GNODEB:ran1']);

    expect(component.nodeSelectionChanged.emit).toHaveBeenCalledWith([
      {
        id: 'ran1',
        label: 'RAN Node 1',
        metadata: {
          aaiType: 'GNODEB',
          type: TreeViewServiceType.RAN_NODE,
        },
      },
    ]);
  });

  it('emits the pnf, not the service instance that shares its id', () => {
    const emitted: TreeNode[][] = [];
    component.nodeSelectionChanged.subscribe(nodes => emitted.push(nodes));
    component.treeData.set([
      {
        id: 'mae-tmcz',
        label: 'mae-tmcz',
        metadata: { aaiType: 'service-instance' },
        children: [
          {
            id: 'mae-tmcz',
            label: 'As_Okruzni-A-84061',
            metadata: { aaiType: 'pnf' },
          },
        ],
      },
    ]);

    component.selectionChanged(['service-instance:mae-tmcz/pnf:mae-tmcz']);

    expect(emitted.length).toBe(1);
    expect(emitted[0].length).toBe(1);
    expect(emitted[0][0].label).toBe('As_Okruzni-A-84061');
    expect(emitted[0][0].metadata?.['aaiType']).toBe('pnf');
  });

  it('should find nodes in tree data via selectionChanged', () => {
    const mockTreeData: TreeNode[] = [
      {
        id: 'node1',
        label: 'Test Node 1',
        children: [
          {
            id: 'node2',
            label: 'Test Node 2',
          },
        ],
      },
    ];

    component.treeData.set(mockTreeData);

    const emitted: TreeNode[][] = [];
    component.nodeSelectionChanged.subscribe(nodes => emitted.push(nodes));

    // Composed path key for the root node (no aaiType → ':node1')
    component.selectionChanged([':node1']);
    expect(emitted[0].length).toBe(1);
    expect(emitted[0][0].id).toBe('node1');

    // Composed path key for the child: ':node1/:node2'
    component.selectionChanged([':node1/:node2']);
    expect(emitted[1].length).toBe(1);
    expect(emitted[1][0].id).toBe('node2');

    // Non-existent node emits empty
    component.selectionChanged([':node1/:nonexistent']);
    expect(emitted[2].length).toBe(0);
  });

  it('should handle technology categories properly', () => {
    const categories = component.technologyCategories();
    expect(categories.length).toBeGreaterThan(0);
  });

  it('should handle error in data loading gracefully', fakeAsync(() => {
    mockCustomTreeviewService.getRANTreeview.and.returnValue(
      throwError(() => new Error('Network error'))
    );

    component.onSearchQueryChange('test');
    waitForDebounce();

    expect(component.isLoading()).toBe(false);
    expect(component.treeData()).toEqual([]);
  }));

  it('should handle short search queries correctly', fakeAsync(() => {
    resetServiceSpy();

    component.onSearchQueryChange('t');
    waitForDebounce();

    expect(mockCustomTreeviewService.getRANTreeview).not.toHaveBeenCalled();
  }));

  it('should handle null service response', fakeAsync(() => {
    mockCustomTreeviewService.getRANTreeview.and.returnValue(of(null as any));

    component.onSearchQueryChange('test');
    waitForDebounce();

    expect(component.isLoading()).toBe(false);
    expect(component.treeData()).toEqual([]);
  }));

  it('should handle empty selected node IDs', () => {
    spyOn(component.nodeSelectionChanged, 'emit');

    component.selectionChanged([]);

    expect(component.nodeSelectionChanged.emit).toHaveBeenCalledWith([]);
  });

  it('should handle non-existent node IDs in selection', () => {
    const mockTreeData: TreeNode[] = [
      { id: 'node1', label: 'Node 1', metadata: {} },
    ];

    component.treeData.set(mockTreeData);
    spyOn(component.nodeSelectionChanged, 'emit');

    component.selectionChanged(['nonexistent']);

    expect(component.nodeSelectionChanged.emit).toHaveBeenCalledWith([]);
  });

  it('should handle nodes without metadata in selection', () => {
    const mockTreeData: TreeNode[] = [{ id: 'node1', label: 'Node 1' }];

    component.treeData.set(mockTreeData);
    spyOn(component.nodeSelectionChanged, 'emit');

    component.selectionChanged([':node1']);

    expect(component.nodeSelectionChanged.emit).toHaveBeenCalledWith([
      {
        id: 'node1',
        label: 'Node 1',
      },
    ]);
  });

  it('should request only the root level when there is no search query', fakeAsync(() => {
    resetServiceSpy();

    component.onTechnologySelect('');
    tick(500);
    fixture.detectChanges();

    // 22018 nodes / 4046 KB / 3.8 s becomes 9 nodes / ~2 KB.
    expect(mockCustomTreeviewService.getRANTreeview).toHaveBeenCalledWith(
      '',
      '',
      1,
      undefined,
      undefined
    );
  }));

  it('should load children on expand and assign them to the node', fakeAsync(() => {
    const child: TreeNode = { id: 'si-1', label: 'SI-1', metadata: {} };
    mockCustomTreeviewService.getRANTreeviewChildren.and.returnValue(
      of([child])
    );

    const node: TreeNode = {
      id: 'nms-1',
      label: 'NMS-1',
      hasChildren: true,
      metadata: { aaiType: NodeType.NMS },
    };
    component.treeData.set([node]);

    const before = component.treeData();
    component.onNodeExpand(node);
    tick();

    expect(
      mockCustomTreeviewService.getRANTreeviewChildren
    ).toHaveBeenCalledWith(
      'nms-1',
      TreeviewParentType.NETWORK_MANAGEMENT_SYSTEM,
      ''
    );
    expect(node.children).toEqual([child]);
    expect(node.isLoading).toBeFalse();
    // The array identity must change so the lib's ngOnChanges re-flattens the tree;
    // without this the chevron opens but children never render.
    expect(component.treeData()).not.toBe(before);
  }));

  it('should not reload children that are already present', fakeAsync(() => {
    const node: TreeNode = {
      id: 'nms-1',
      label: 'NMS-1',
      hasChildren: true,
      children: [{ id: 'si-1', label: 'SI-1', metadata: {} }],
      metadata: { aaiType: NodeType.NMS },
    };
    component.treeData.set([node]);
    resetChildrenSpy();

    component.onNodeExpand(node);
    tick();

    expect(
      mockCustomTreeviewService.getRANTreeviewChildren
    ).not.toHaveBeenCalled();
  }));

  it('should not request children for a leaf node', fakeAsync(() => {
    const node: TreeNode = {
      id: 'cell-1',
      label: 'Cell-1',
      hasChildren: false,
      metadata: { aaiType: NodeType.CELL },
    };
    resetChildrenSpy();

    component.onNodeExpand(node);
    tick();

    expect(
      mockCustomTreeviewService.getRANTreeviewChildren
    ).not.toHaveBeenCalled();
  }));

  it('should alert and clear the loading flag when the children request fails', fakeAsync(() => {
    mockCustomTreeviewService.getRANTreeviewChildren.and.returnValue(
      throwError(() => new Error('boom'))
    );
    const node: TreeNode = {
      id: 'nms-1',
      label: 'NMS-1',
      hasChildren: true,
      metadata: { aaiType: NodeType.NMS },
    };
    component.treeData.set([node]);

    component.onNodeExpand(node);
    tick();

    // A stuck spinner is worse than an empty level.
    expect(node.isLoading).toBeFalse();
    // Without the alert an expanded-but-empty node is indistinguishable from a broken one.
    // The translate spy returns 'All' for every key, so assert on the key it was asked for.
    expect(TestBed.inject(TranslateService).instant).toHaveBeenCalledWith(
      'treeview.ratView.loadChildrenError'
    );
    expect(mockAlertService.error).toHaveBeenCalledWith('All', {
      keepAfterRouteChange: true,
    });
  }));

  it('should log the contract violation for an unsupported aaiType', fakeAsync(() => {
    // The generic alert is all the user can act on, but an aaiType the endpoint rejects is a
    // BFF-vs-API mismatch: it needs a distinct, diagnosable signal, not the same line a network
    // failure produces.
    const consoleSpy = spyOn(console, 'error');
    const node: TreeNode = {
      id: 'cell-1',
      label: 'Cell-1',
      hasChildren: true,
      metadata: { aaiType: NodeType.CELL },
    };
    component.treeData.set([node]);

    component.onNodeExpand(node);
    tick();

    expect(consoleSpy).toHaveBeenCalled();
    const logged = consoleSpy.calls.mostRecent().args[0] as string;
    expect(logged).toContain('cell-1');
    expect(logged).toContain(NodeType.CELL);
  }));

  it('should not log a contract violation when the request merely fails', fakeAsync(() => {
    const consoleSpy = spyOn(console, 'error');
    mockCustomTreeviewService.getRANTreeviewChildren.and.returnValue(
      throwError(() => new Error('boom'))
    );
    const node: TreeNode = {
      id: 'nms-1',
      label: 'NMS-1',
      hasChildren: true,
      metadata: { aaiType: NodeType.NMS },
    };
    component.treeData.set([node]);

    component.onNodeExpand(node);
    tick();

    expect(consoleSpy).not.toHaveBeenCalled();
  }));

  it('should not refetch a node whose children came back empty', fakeAsync(() => {
    mockCustomTreeviewService.getRANTreeviewChildren.and.returnValue(of([]));
    const node: TreeNode = {
      id: 'nms-1',
      label: 'NMS-1',
      hasChildren: true,
      metadata: { aaiType: NodeType.NMS },
    };
    component.treeData.set([node]);

    component.onNodeExpand(node);
    tick();

    // children === undefined is the cache guard, so an empty result must still be stored -
    // otherwise every collapse/expand cycle re-requests a node known to have nothing.
    expect(node.children).toEqual([]);

    resetChildrenSpy();
    component.onNodeExpand(node);
    tick();

    expect(
      mockCustomTreeviewService.getRANTreeviewChildren
    ).not.toHaveBeenCalled();
  }));

  it('should retry a node whose children request failed', fakeAsync(() => {
    mockCustomTreeviewService.getRANTreeviewChildren.and.returnValue(
      throwError(() => new Error('boom'))
    );
    const node: TreeNode = {
      id: 'nms-1',
      label: 'NMS-1',
      hasChildren: true,
      metadata: { aaiType: NodeType.NMS },
    };
    component.treeData.set([node]);

    component.onNodeExpand(node);
    tick();

    // A transient failure must not be cached as "this node has no children", so children stays
    // undefined and collapsing/re-expanding is the retry.
    expect(node.children).toBeUndefined();

    const child: TreeNode = { id: 'si-1', label: 'SI-1', hasChildren: false };
    mockCustomTreeviewService.getRANTreeviewChildren.and.returnValue(
      of([child])
    );
    resetChildrenSpy();

    component.onNodeExpand(node);
    tick();

    expect(
      mockCustomTreeviewService.getRANTreeviewChildren
    ).toHaveBeenCalledWith(
      'nms-1',
      TreeviewParentType.NETWORK_MANAGEMENT_SYSTEM,
      ''
    );
    expect(node.children).toEqual([child]);
  }));

  it('should not request children for an aaiType the endpoint does not accept', fakeAsync(() => {
    // Only the four TreeviewParentType values are valid parents; a chevron on anything else
    // (e.g. a cell, or a node-view-only type) would produce a request the API rejects with 400.
    const node: TreeNode = {
      id: 'cell-1',
      label: 'Cell-1',
      hasChildren: true,
      metadata: { aaiType: NodeType.CELL },
    };
    component.treeData.set([node]);
    resetChildrenSpy();

    component.onNodeExpand(node);
    tick();

    expect(
      mockCustomTreeviewService.getRANTreeviewChildren
    ).not.toHaveBeenCalled();
    // The translate spy returns 'All' for every key, so assert on the key it was asked for.
    expect(TestBed.inject(TranslateService).instant).toHaveBeenCalledWith(
      'treeview.ratView.loadChildrenError'
    );
    expect(mockAlertService.error).toHaveBeenCalledWith('All', {
      keepAfterRouteChange: true,
    });
    expect(node.isLoading).toBeFalsy();
    expect(node.children).toEqual([]);
  }));

  it('should pass the selected technology when loading children', fakeAsync(() => {
    mockCustomTreeviewService.getRANTreeviewChildren.and.returnValue(of([]));
    component.onTechnologySelect('LTE');
    tick(500);
    fixture.detectChanges();

    const node: TreeNode = {
      id: 'si-1',
      label: 'SI-1',
      hasChildren: true,
      metadata: { aaiType: NodeType.SERVICE_INSTANCE },
    };
    component.treeData.set([node]);

    component.onNodeExpand(node);
    tick();

    // A chevron that ignored the RAT filter would show cells the filter excludes.
    expect(
      mockCustomTreeviewService.getRANTreeviewChildren
    ).toHaveBeenCalledWith('si-1', TreeviewParentType.SERVICE_INSTANCE, 'LTE');
  }));

  it('should reveal the deep-linked node on the initial load', fakeAsync(() => {
    resetServiceSpy();
    // activatedPaths drives the reveal, not activatedNodes
    fixture.componentRef.setInput('activatedPaths', [
      [':nms-1', ':si-1', ':pnf-1'],
    ]);
    fixture.detectChanges();

    component.onTechnologySelect('');
    tick(500);
    fixture.detectChanges();

    // The last segment of the last path names the reveal target.
    expect(mockCustomTreeviewService.getRANTreeview).toHaveBeenCalledWith(
      '',
      '',
      1,
      'pnf-1',
      undefined
    );
  }));

  it('should expand every ancestor the URL names except the target itself', fakeAsync(() => {
    // The payload materialises nms-1 > si-1 > pnf-1. Without the reveal, the chain arrives
    // present but rendered collapsed - a broken deep link.
    const pnf: TreeNode = { id: 'pnf-1', label: 'PNF-1', metadata: {} };
    const si: TreeNode = {
      id: 'si-1',
      label: 'SI-1',
      hasChildren: true,
      children: [pnf],
      metadata: {},
    };
    const nms: TreeNode = {
      id: 'nms-1',
      label: 'NMS-1',
      hasChildren: true,
      children: [si],
      metadata: {},
    };
    mockCustomTreeviewService.getRANTreeview.and.returnValue(
      of({ items: [{}] } as any)
    );
    mockCustomTreeviewService.mapToFinalData.and.returnValue(nms);

    // revealActivatedPath uses activatedPaths, not the backend's revealedPath
    fixture.componentRef.setInput('activatedPaths', [
      [':nms-1', ':si-1', ':pnf-1'],
    ]);
    fixture.detectChanges();

    component.onTechnologySelect('');
    tick(500);
    fixture.detectChanges();

    expect(nms.isExpanded).toBeTrue();
    expect(si.isExpanded).toBeTrue();
    // The target is revealed and selected, not pre-opened.
    expect(pnf.isExpanded).toBeFalsy();
  }));

  it('should leave the tree collapsed when no activatedPaths is set', fakeAsync(() => {
    // Both acts run the same fixture shape so the empty path is measured against one a non-empty
    // path does expand - asserting only the empty case would hold even if expansion never happened.
    const chain = (): { nms: TreeNode; si: TreeNode } => {
      const si: TreeNode = {
        id: 'si-1',
        label: 'SI-1',
        hasChildren: true,
        isExpanded: false,
        metadata: {},
      };
      const nms: TreeNode = {
        id: 'nms-1',
        label: 'NMS-1',
        hasChildren: true,
        isExpanded: false,
        children: [si],
        metadata: {},
      };
      return { nms, si };
    };

    const stale = chain();
    mockCustomTreeviewService.getRANTreeview.and.returnValue(
      of({ items: [{}] } as any)
    );
    mockCustomTreeviewService.mapToFinalData.and.returnValue(stale.nms);

    // activatedPaths defaults to [] - no paths, nothing to reveal
    component.onTechnologySelect('');
    tick(500);
    fixture.detectChanges();

    expect(stale.nms.isExpanded).toBeFalse();
    expect(stale.si.isExpanded).toBeFalse();
    expect(component.treeData()).toEqual([stale.nms]);

    const revealed = chain();
    mockCustomTreeviewService.getRANTreeview.and.returnValue(
      of({ items: [{}] } as any)
    );
    mockCustomTreeviewService.mapToFinalData.and.returnValue(revealed.nms);

    fixture.componentRef.setInput('activatedPaths', [[':nms-1', ':si-1']]);
    fixture.detectChanges();

    component.onTechnologySelect('LTE');
    tick(500);
    fixture.detectChanges();

    // Same fixture, non-empty path: the ancestor opens. This is what the empty path must not do.
    expect(revealed.nms.isExpanded).toBeTrue();
    expect(revealed.si.isExpanded).toBeFalse();
  }));

  it('should fetch children of an ancestor the URL names but the payload left unmaterialised', fakeAsync(() => {
    // revealActivatedPath detects that the gNodeB's children are not in the payload and calls
    // onNodeExpand directly, rather than waiting for user interaction.
    const nms: TreeNode = {
      id: 'nms-1',
      label: 'NMS-1',
      hasChildren: true,
      metadata: { aaiType: NodeType.NMS },
    };
    mockCustomTreeviewService.getRANTreeview.and.returnValue(
      of({ items: [{}] } as any)
    );
    mockCustomTreeviewService.mapToFinalData.and.returnValue(nms);
    mockCustomTreeviewService.getRANTreeviewChildren.and.returnValue(of([]));

    fixture.componentRef.setInput('activatedPaths', [
      ['network-management-system:nms-1', 'service-instance:si-1'],
    ]);
    fixture.detectChanges();

    component.onTechnologySelect('');
    tick(500);
    fixture.detectChanges();
    tick(); // let onNodeExpand's subscription complete

    expect(
      mockCustomTreeviewService.getRANTreeviewChildren
    ).toHaveBeenCalledWith(
      'nms-1',
      TreeviewParentType.NETWORK_MANAGEMENT_SYSTEM,
      ''
    );
  }));

  it('should reveal only the last selected node when multiple are selected', fakeAsync(() => {
    resetServiceSpy();
    // Multi-select is reachable via Ctrl-click; activatedPaths.at(-1) is the last one.
    // The API accepts only one revealNodeId.
    fixture.componentRef.setInput('activatedPaths', [[':pnf-1'], [':nms-2']]);
    fixture.detectChanges();

    component.onTechnologySelect('');
    tick(500);
    fixture.detectChanges();

    expect(mockCustomTreeviewService.getRANTreeview).toHaveBeenCalledWith(
      '',
      '',
      1,
      'nms-2',
      undefined
    );
  }));

  it('splits the composite segment into revealNodeId and revealNodeType', fakeAsync(() => {
    resetServiceSpy();
    // The last segment of the last path names type and id separately for the backend lookup.
    fixture.componentRef.setInput('activatedPaths', [['pnf:mae-tmcz']]);
    fixture.detectChanges();

    component.onTechnologySelect('');
    tick(500);
    fixture.detectChanges();

    expect(mockCustomTreeviewService.getRANTreeview).toHaveBeenCalledWith(
      '',
      '',
      1,
      'mae-tmcz',
      'pnf'
    );
  }));

  it('parseRanNodeKey tolerates a path segment with no type prefix', fakeAsync(() => {
    // activatedPaths production values always have a type prefix (from stampPaths → ranNodeKey).
    // This test covers parseRanNodeKey's bare-id branch directly; the real legacy-bookmark
    // regression test is 'uses the last activatedNodes entry as the reveal key when activatedPaths
    // is empty' below.
    resetServiceSpy();
    fixture.componentRef.setInput('activatedPaths', [['mae-tmcz']]);
    fixture.detectChanges();

    component.onTechnologySelect('');
    tick(500);
    fixture.detectChanges();

    expect(mockCustomTreeviewService.getRANTreeview).toHaveBeenCalledWith(
      '',
      '',
      1,
      'mae-tmcz',
      undefined
    );
  }));

  it('uses the last activatedNodes entry as the reveal key when activatedPaths is empty', fakeAsync(() => {
    // A pre-path bookmark (selectedNodes=[{id:'cell-A',aaiType:'cell'}]) has no `path`, so
    // activatedPaths$ drops it, leaving activatedPaths=[]. Without a fallback, revealPath is
    // undefined and the backend returns depth=1 roots only — upgradeLegacySelection finds nothing
    // and the URL never gains a path (regression introduced in a6efd59d).
    resetServiceSpy();
    fixture.componentRef.setInput('activatedPaths', []);
    fixture.componentRef.setInput('activatedNodes', ['cell:cell-A']);
    fixture.detectChanges();

    component.onTechnologySelect('');
    tick(500);
    fixture.detectChanges();

    expect(mockCustomTreeviewService.getRANTreeview).toHaveBeenCalledWith(
      '',
      '',
      1,
      'cell-A',
      'cell'
    );
  }));

  it('should skip children fetch and leave isLoading false when node has no aaiType', fakeAsync(() => {
    // Without this guard the generated client throws synchronously from onNodeExpand, which escapes
    // the lib's click handler and leaves node.isLoading === true forever (stuck spinner).
    const node: TreeNode = {
      id: 'unknown-1',
      label: 'Unknown',
      hasChildren: true,
      metadata: {},
    };
    component.treeData.set([node]);
    resetChildrenSpy();

    component.onNodeExpand(node);
    tick();

    expect(
      mockCustomTreeviewService.getRANTreeviewChildren
    ).not.toHaveBeenCalled();
    expect(node.isLoading).toBeFalsy();
  }));

  describe('nodeDomKey', () => {
    it('returns the composed path key for a node whose path was stamped', () => {
      const path = ['service-instance:si-1', 'generic-vnf:gnb-1'];
      const node: TreeNode = {
        id: 'gnb-1',
        label: 'gNodeB',
        metadata: { aaiType: 'generic-vnf', path },
      };
      expect(component.nodeDomKey(node)).toBe(composePathKey(path));
    });

    it('returns the segment key for an unstamped node', () => {
      const node: TreeNode = {
        id: 'gnb-1',
        label: 'gNodeB',
        metadata: { aaiType: 'generic-vnf' },
      };
      expect(component.nodeDomKey(node)).toBe(ranNodeKey(node));
    });
  });

  describe('path-based reveal', () => {
    // Maps BFF-format response items to TreeNode objects, mirroring the real mapToFinalData.
    const mapBffItem = (item: any): TreeNode => ({
      id: item.id,
      label: item.name ?? item.label,
      hasChildren:
        item.childCount != null ? item.childCount > 0 : !!item.children?.length,
      children: item.children?.map(mapBffItem),
      metadata: {
        aaiType: item.type ?? item.metadata?.aaiType,
        serviceType: item.serviceType ?? item.metadata?.serviceType,
      },
    });

    const payload = () => ({
      items: [
        {
          id: 'si-1',
          name: 'SI',
          type: 'service-instance',
          serviceType: 'NR',
          childCount: 2,
          children: [
            {
              id: 'bbu-1',
              name: 'BBU',
              type: 'pnf',
              serviceType: 'NR',
              childCount: 1,
            },
            {
              id: 'gnb-1',
              name: 'gNodeB',
              type: 'generic-vnf',
              serviceType: 'NR',
              childCount: 1,
            },
          ],
        },
      ],
      // Deliberately disagrees with the path under test: this is exactly the backend behaviour
      // the reveal must ignore.
      revealedPath: ['si-1', 'bbu-1', 'cell-A'],
    });

    beforeEach(() => {
      mockCustomTreeviewService.mapToFinalData.and.callFake(mapBffItem);
    });

    it('fetches the children of the ancestor the URL names, not the revealed one', fakeAsync(() => {
      resetServiceSpy();
      resetChildrenSpy();
      mockCustomTreeviewService.getRANTreeview.and.returnValue(
        of(payload() as any)
      );
      mockCustomTreeviewService.getRANTreeviewChildren.and.returnValue(
        of([
          {
            id: 'cell-A',
            label: 'Cell A',
            metadata: { aaiType: 'cell' },
          } as TreeNode,
        ])
      );
      fixture.componentRef.setInput('activatedPaths', [
        ['service-instance:si-1', 'generic-vnf:gnb-1', 'cell:cell-A'],
      ]);
      fixture.detectChanges();

      component.onTechnologySelect('');
      tick(500);
      fixture.detectChanges();
      tick();

      expect(
        mockCustomTreeviewService.getRANTreeviewChildren
      ).toHaveBeenCalledTimes(1);
      expect(
        mockCustomTreeviewService.getRANTreeviewChildren.calls.mostRecent()
          .args[0]
      ).toBe('gnb-1');
    }));

    it('stamps every node with its own composed path', fakeAsync(() => {
      resetServiceSpy();
      mockCustomTreeviewService.getRANTreeview.and.returnValue(
        of(payload() as any)
      );

      component.onTechnologySelect('');
      tick(500);
      fixture.detectChanges();

      const gnb = component.treeData()[0].children![1];
      expect(gnb.metadata!['path']).toEqual([
        'service-instance:si-1',
        'generic-vnf:gnb-1',
      ]);
    }));

    it('reports the missing segment when the path has gone stale', fakeAsync(() => {
      resetServiceSpy();
      mockCustomTreeviewService.getRANTreeview.and.returnValue(
        of(payload() as any)
      );
      const missing: string[] = [];
      component.nodeNotFound.subscribe((id: string) => missing.push(id));
      fixture.componentRef.setInput('activatedPaths', [
        ['service-instance:si-1', 'generic-vnf:deleted', 'cell:cell-A'],
      ]);
      fixture.detectChanges();

      component.onTechnologySelect('');
      tick(500);

      expect(missing).toEqual(['deleted']);
    }));

    it('does not report not-found while the target is merely unfetched', fakeAsync(() => {
      resetServiceSpy();
      resetChildrenSpy();
      mockCustomTreeviewService.getRANTreeview.and.returnValue(
        of(payload() as any)
      );
      mockCustomTreeviewService.getRANTreeviewChildren.and.returnValue(
        of([
          {
            id: 'cell-A',
            label: 'Cell A',
            metadata: { aaiType: 'cell' },
          } as TreeNode,
        ])
      );
      const missing: string[] = [];
      component.nodeNotFound.subscribe((id: string) => missing.push(id));
      fixture.componentRef.setInput('activatedPaths', [
        ['service-instance:si-1', 'generic-vnf:gnb-1', 'cell:cell-A'],
      ]);
      fixture.detectChanges();

      component.onTechnologySelect('');
      tick(500);

      // The gNodeB arrives collapsed with children===undefined, so the cell is absent from the
      // payload on every correct deep link. Validating the full path up front would fire the
      // modal here - which is why revealActivatedPath validates ancestors only.
      expect(missing).toEqual([]);
    }));

    it('does not report not-found when a search load lacks the selected branch', fakeAsync(() => {
      // A pruned search response that does not contain the selected ancestors must not pop the
      // "node not found" modal - "absent from search results" is not "deleted from AAI".
      resetServiceSpy();
      mockCustomTreeviewService.getRANTreeview.and.returnValue(
        of({ items: [] } as any)
      );
      const missing: string[] = [];
      component.nodeNotFound.subscribe((id: string) => missing.push(id));
      fixture.componentRef.setInput('activatedPaths', [
        ['service-instance:si-1', 'generic-vnf:gnb-1', 'cell:cell-A'],
      ]);
      fixture.detectChanges();

      component.onSearchQueryChange('abc');
      tick(500);

      expect(missing).toEqual([]);
    }));

    it('does not report not-found when a technology-filter load lacks the selected branch', fakeAsync(() => {
      // A filtered response that does not contain the NR branch must not pop the modal -
      // "absent from GSM filter" is not "deleted from AAI".
      resetServiceSpy();
      mockCustomTreeviewService.getRANTreeview.and.returnValue(
        of({ items: [] } as any)
      );
      const missing: string[] = [];
      component.nodeNotFound.subscribe((id: string) => missing.push(id));
      fixture.componentRef.setInput('activatedPaths', [
        ['service-instance:si-1', 'generic-vnf:gnb-1', 'cell:cell-A'],
      ]);
      fixture.detectChanges();

      component.onTechnologySelect('GSM');
      tick(500);

      expect(missing).toEqual([]);
    }));
  });

  describe('auto-selection of a single match (select=true)', () => {
    /**
     * Both params are read in ngOnInit, so the component has to be built after the stub knows their
     * values - hence a fresh fixture rather than a setter on the existing one.
     *
     * `query` arrives through the URL, the way a CGI deep link delivers it, because typing into the
     * search box is what *spends* the parameter: an unattended link is the only case AC2.1 covers.
     */
    const createWithParams = (
      select: string | null,
      query: string | null = null,
      selectParamName = 'select'
    ): TreeNode[][] => {
      mockQueryParamService.getValueOf.and.callFake((param: string) => {
        if (param === selectParamName) {
          return of(select);
        }
        return of(param === 'query' ? query : null);
      });
      fixture = TestBed.createComponent(RatViewComponent);
      component = fixture.componentInstance;
      const emitted: TreeNode[][] = [];
      component.nodeSelectionChanged.subscribe(nodes => emitted.push(nodes));

      fixture.detectChanges();
      // The initial load - unfiltered, or filtered by the URL's own query
      tick(500);
      fixture.detectChanges();
      return emitted;
    };

    const respondWith = (nodes: TreeNode[]): void => {
      mockCustomTreeviewService.getRANTreeview.and.returnValue(
        of({ items: nodes.map(node => ({ id: node.id })) } as any)
      );
      mockCustomTreeviewService.mapToFinalData.and.callFake(
        (item: any) => nodes.find(node => node.id === item.id) as any
      );
    };

    const cell = (id: string, label: string): TreeNode => ({
      id,
      label,
      metadata: { aaiType: 'cell' },
    });

    it('selects the only matching node, carrying its stamped path', fakeAsync(() => {
      respondWith([cell('cell-A', 'Cell A'), cell('cell-B', 'Cell B')]);
      const emitted = createWithParams('true', 'cell-A');

      expect(emitted.length).toBe(1);
      expect(emitted[0].length).toBe(1);
      expect(emitted[0][0].id).toBe('cell-A');
      // Without the stamped path the URL entry is path-less, and with pathScopedKeys the detail
      // pane opens while no row is marked.
      expect(emitted[0][0].metadata!['path']).toEqual(['cell:cell-A']);
    }));

    it('ignores an upper-case SELECT param, but not an upper-case value', fakeAsync(() => {
      respondWith([cell('cell-A', 'Cell A')]);
      const ignored = createWithParams('true', 'cell-A', 'SELECT');

      expect(ignored).toEqual([]);

      const emitted = createWithParams('TRUE', 'cell-A');

      expect(emitted.length).toBe(1);
      expect(emitted[0][0].id).toBe('cell-A');
    }));

    it('selects nothing when two nodes match', fakeAsync(() => {
      respondWith([cell('cell-A1', 'Cell A1'), cell('cell-A2', 'Cell A2')]);
      const emitted = createWithParams('true', 'cell-A');

      // Both nodes match the substring; AC2.1 selects only an unambiguous match.
      expect(component.treeData().length).toBe(2);
      expect(emitted).toEqual([]);
    }));

    it('selects nothing without the parameter', fakeAsync(() => {
      respondWith([cell('cell-A', 'Cell A')]);
      const emitted = createWithParams(null, 'cell-A');

      expect(component.treeData().length).toBe(1);
      expect(emitted).toEqual([]);
    }));

    it('selects nothing when the parameter is not true', fakeAsync(() => {
      respondWith([cell('cell-A', 'Cell A')]);
      const emitted = createWithParams('false', 'cell-A');

      expect(emitted).toEqual([]);
    }));

    it('selects nothing on the unfiltered load, however few nodes it returns', fakeAsync(() => {
      respondWith([cell('cell-A', 'Cell A')]);
      const emitted = createWithParams('true');

      // One node in the whole tree is not "one match": with no query there is nothing to match.
      expect(component.treeData().length).toBe(1);
      expect(emitted).toEqual([]);
    }));

    it('does not auto-select a query the user typed after arriving with the parameter', fakeAsync(() => {
      respondWith([cell('cell-A', 'Cell A'), cell('cell-B', 'Cell B')]);
      // Armed, but the link brought no filter, so nothing was ever auto-selected.
      const emitted = createWithParams('true');

      component.onSearchQueryChange('cell-A');
      tick(500);
      fixture.detectChanges();

      // A single match, and yet nothing is selected: select=true describes the filter the link
      // arrived with. Honouring it mid-typing would move focus to the row and swallow the rest of
      // the user's keystrokes.
      expect(component.treeData().length).toBe(2);
      expect(emitted).toEqual([]);
    }));

    it('selects once per session, not again after a reload or a cleared search', fakeAsync(() => {
      respondWith([cell('cell-A', 'Cell A')]);
      const emitted = createWithParams('true', 'cell-A');

      expect(emitted.length).toBe(1);

      // A technology change reloads the same query - re-selecting here would reopen a pane the
      // user has closed, or override a node they selected meanwhile.
      component.onTechnologySelect('LTE');
      tick(500);
      fixture.detectChanges();
      expect(emitted.length).toBe(1);

      component.clearSearch();
      tick(500);
      fixture.detectChanges();
      component.onSearchQueryChange('cell-A');
      tick(500);
      fixture.detectChanges();

      // clearSearch resets the per-query guard, so a consumed select=true is the only thing left to
      // block this. The parameter is a one-shot entry instruction, not a session mode.
      expect(emitted.length).toBe(1);
    }));

    it('does not auto-select again after select=true was consumed by the first match', fakeAsync(() => {
      respondWith([cell('cell-A', 'Cell A'), cell('cell-B', 'Cell B')]);
      const emitted = createWithParams('true', 'cell-A');

      // First query: exactly one match, auto-selected. Proves the setup actually fires.
      expect(emitted.length).toBe(1);
      expect(emitted[0][0].id).toBe('cell-A');

      // A second, differently-matching query: the per-query guard holds 'cell-A' and so would not
      // block 'cell-B' on its own. Only the spent parameter does.
      component.onSearchQueryChange('cell-B');
      tick(500);
      fixture.detectChanges();
      expect(emitted.length).toBe(1);
    }));

    it('drops the parameter from the URL once it has been spent', fakeAsync(() => {
      respondWith([cell('cell-A', 'Cell A'), cell('cell-B', 'Cell B')]);
      createWithParams('true', 'cell-A');
      // The removal is deferred by a macrotask so the selection's own navigation goes first.
      tick(0);

      const removals = mockQueryParamService.updateQueryParam.calls
        .allArgs()
        .filter(([params]) => 'select' in params);
      expect(removals.length).toBe(1);
      expect(removals[0][0]).toEqual({ select: null });
      // Without replaceUrl, Back would return to the still-armed URL and select all over again.
      expect(removals[0][2]).toEqual({ replaceUrl: true });
    }));

    it('announces the auto-selected node for assistive technology', fakeAsync(() => {
      respondWith([cell('cell-A', 'Cell A'), cell('cell-B', 'Cell B')]);
      createWithParams('true', 'cell-A');

      // Nothing else reports it: the tree never took focus, and this view's rows have no tab stop
      // for focusSelectedRow to move it to.
      expect(component.autoSelect.announcedLabel()).toBe('Cell A');
    }));

    it('says nothing when no unique match was found', fakeAsync(() => {
      respondWith([cell('cell-A1', 'Cell A1'), cell('cell-A2', 'Cell A2')]);
      createWithParams('true', 'cell-A');

      expect(component.autoSelect.announcedLabel()).toBe('');
    }));
  });

  describe('matchedIdOnly', () => {
    it('returns the id only when the label does not explain the match', () => {
      const node: TreeNode = { id: '262-01-1-99', label: 'Cell A' };

      expect(component.matchedIdOnly(node, '262-01')).toBe('262-01-1-99');
      expect(component.matchedIdOnly(node, 'Cell')).toBeNull();
    });
  });
});
