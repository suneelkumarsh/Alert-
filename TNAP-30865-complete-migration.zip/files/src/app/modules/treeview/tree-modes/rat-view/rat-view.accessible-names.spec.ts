/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ComponentFixture,
  TestBed,
  discardPeriodicTasks,
  fakeAsync,
  tick,
} from '@angular/core/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';
import { TreeNode } from '@portal-mfe/ng-tree-lib';

import { RatViewComponent } from './rat-view.component';
import { TreeExpansionService } from '../../shared/tree-expansion.service';
import { CustomTreeviewService } from 'src/app/services/custom-treeview.service';
import { QueryParamService } from 'src/app/services/query-param.service';
import { TreeviewParentType } from 'openapi/output';
import en from 'src/assets/i18n/en.json';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

/**
 * Renders the *real* `ng-treeview`, unlike `rat-view.component.spec.ts` which replaces the template
 * with an empty one. Everything asserted here lives in the library's row markup: the row's name is
 * an `aria-label` on the `treeitem`, and that label suppresses the row's own subtree for naming, so
 * whether the vendor is announced cannot be told from this component's template alone.
 *
 * The real `en.json` is loaded rather than a fixture translation set, so a renamed or dropped key
 * fails here instead of silently announcing the key itself.
 */
describe('RatViewComponent accessible names', () => {
  let fixture: ComponentFixture<RatViewComponent>;
  let component: RatViewComponent;

  const state = { items: [] as TreeNode[] };

  /** A BBU carrying a vendor - the badge the row renders but, before 19.5.0, never announced. */
  const bbuWithVendor: TreeNode = {
    id: '73000024',
    label: '73000024',
    hasChildren: true,
    metadata: {
      model: { vendor: 'Ericsson' },
      type: 'PNF',
      aaiType: 'pnf',
      serviceType: 'pnf',
    },
  };

  const nmsWithoutVendor: TreeNode = {
    id: 'nms-1',
    label: 'RAN-NMS',
    hasChildren: true,
    metadata: {
      model: {},
      type: 'NETWORK-MANAGEMENT-SYSTEM',
      aaiType: 'network-management-system',
      serviceType: 'nms',
    },
  };

  /** The node template's own container, i.e. the part of the row this repo owns. */
  const rows = (): HTMLElement[] =>
    Array.from(fixture.nativeElement.querySelectorAll('[data-node-id]'));

  const treeitemNameOf = (row: HTMLElement): string | null | undefined =>
    row.closest('[role="treeitem"]')?.getAttribute('aria-label');

  const statusRegionText = (): string =>
    fixture.nativeElement.querySelector('.qa_tree_status').textContent.trim();

  const render = (): void => {
    fixture = TestBed.createComponent(RatViewComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
    // The initial load is seeded through the search subject, so it waits out the debounce.
    tick(500);
    fixture.detectChanges();

    // A viewport with no height renders no rows. Its size is measured once, before the response
    // arrives, so setting the style is not enough on its own.
    fixture.nativeElement.querySelector(
      'cdk-virtual-scroll-viewport'
    ).style.height = '600px';
    component.treeComponent()!.viewport.checkViewportSize();
    fixture.detectChanges();
    tick(1000);
    fixture.detectChanges();
  };

  beforeEach(async () => {
    state.items = [bbuWithVendor, nmsWithoutVendor];

    const customTreeviewServiceSpy = jasmine.createSpyObj(
      'CustomTreeviewService',
      [
        'getRANTreeview',
        'getRANTreeviewChildren',
        'mapToFinalData',
        'toRanParentType',
      ]
    );
    customTreeviewServiceSpy.getRANTreeview.and.callFake(() =>
      of({ items: state.items })
    );
    customTreeviewServiceSpy.mapToFinalData.and.callFake(
      (item: TreeNode) => item
    );
    customTreeviewServiceSpy.toRanParentType.and.returnValue(
      TreeviewParentType.PNF
    );

    const queryParamServiceSpy = jasmine.createSpyObj('QueryParamService', [
      'getValueOf',
      'updateQueryParam',
    ]);
    queryParamServiceSpy.getValueOf.and.returnValue(of(null));

    await TestBed.configureTestingModule({
      imports: [RatViewComponent, TranslateModule.forRoot()],
      providers: [
        { provide: CustomTreeviewService, useValue: customTreeviewServiceSpy },
        { provide: QueryParamService, useValue: queryParamServiceSpy },
        {
          provide: TnapAlertService,
          useValue: jasmine.createSpyObj('TnapAlertService', ['error']),
        },
        TreeExpansionService,
      ],
    }).compileComponents();

    const translate = TestBed.inject(TranslateService);
    translate.setTranslation('en', en);
    translate.use('en');
  });

  afterEach(() => {
    fixture?.destroy();
  });

  it('names the tree itself, on the element that carries role=tree', fakeAsync(() => {
    render();

    // The host is a role-less custom element, so an aria-label there is prohibited ARIA and names
    // nothing - the role sits on the viewport inside, which only the library can reach.
    const treeElement = fixture.nativeElement.querySelector('[role="tree"]');

    expect(treeElement).withContext('tree element not found').toBeTruthy();
    expect(treeElement?.hasAttribute('aria-label')).toBeTrue();
    expect(treeElement?.getAttribute('aria-label')?.trim()).not.toEqual('');

    discardPeriodicTasks();
  }));

  it('announces the vendor as part of the row name, not from the badge', fakeAsync(() => {
    render();

    const row = rows()[0];

    expect(row.textContent).toContain('Ericsson');
    // Prohibited on every element the node template renders: the badge, the label span and the
    // matched-id hint all expose no role of their own, so they can hold no accessible name.
    expect(row.querySelectorAll('[aria-label]').length).toBe(0);
    const accessibleName = treeitemNameOf(row);

    expect(accessibleName).toContain('73000024');
    expect(accessibleName).toContain('Ericsson');

    discardPeriodicTasks();
  }));

  it('leaves a vendor-less row named by its label alone', fakeAsync(() => {
    render();

    const row = rows()[1];

    // The icon is the only thing beside the label here, and an image is named by its alt text.
    expect(row.querySelector('img')?.getAttribute('alt')).toBe(
      en.treeview.ratView.imgText.nms
    );
    expect(row.querySelectorAll('[aria-label]').length).toBe(0);
    expect(treeitemNameOf(row)).toBe('RAN-NMS');

    discardPeriodicTasks();
  }));

  it('keeps the rows out of any live region', fakeAsync(() => {
    render();

    // The rows are virtualised: a live region anywhere above them announces every row that
    // scrolls into view, which is why neither the tree nor the label span may be one.
    expect(
      fixture.nativeElement.querySelectorAll(
        'cdk-virtual-scroll-viewport [aria-live]'
      ).length
    ).toBe(0);

    discardPeriodicTasks();
  }));

  it('announces a finished load through the status region', fakeAsync(() => {
    render();

    expect(statusRegionText()).toBe('Tree updated: 2 top-level elements');

    discardPeriodicTasks();
  }));

  it('announces the rows a node expansion revealed', fakeAsync(() => {
    render();
    const customTreeviewService = TestBed.inject(
      CustomTreeviewService
    ) as jasmine.SpyObj<CustomTreeviewService>;
    customTreeviewService.getRANTreeviewChildren.and.returnValue(
      of([
        { id: 'cell-1', label: 'Cell 1', hasChildren: false },
        { id: 'cell-2', label: 'Cell 2', hasChildren: false },
      ])
    );

    component.onNodeExpand(component.treeData()[0]);
    fixture.detectChanges();

    expect(statusRegionText()).toBe('2 elements loaded under 73000024');

    discardPeriodicTasks();
  }));
});
