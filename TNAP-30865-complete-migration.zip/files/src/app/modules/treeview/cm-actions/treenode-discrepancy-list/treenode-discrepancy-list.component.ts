/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Component,
  computed,
  inject,
  signal,
  ChangeDetectionStrategy,
  DestroyRef,
  input,
  OnInit,
} from '@angular/core';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { Router } from '@angular/router';
import { finalize, catchError, filter, switchMap } from 'rxjs/operators';
import { of } from 'rxjs';
import {
  DiscrepancyService,
  NodeDiscrepancyListResponse,
} from 'src/app/services/discrepancylist-service/discrepancy.service';
import { DiscrepancyDetailsResponse } from 'openapi/output/model/discrepancyDetailsResponse.model';
import {
  ColumnDefinition,
  TableConfigService,
} from '@portal-mfe/tnap-ui-kit/components/data-table';
import { TranslateService } from '@ngx-translate/core';
import { ModalConfirmationService } from 'src/app/services/common-functionalities/modal-confirmation.service';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

export type TableTypes = 'waiting-discrepancies' | 'other-discrepancies';

interface ApprovalTextParams {
  name: string;
}

@Component({
  selector: 'app-treenode-discrepancy-list',
  templateUrl: './treenode-discrepancy-list.component.html',
  styleUrls: ['./treenode-discrepancy-list.component.css'],
  providers: [TableConfigService],
  standalone: false,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TreenodeDiscrepancyListComponent implements OnInit {
  private readonly translateService = inject(TranslateService);
  private readonly discrepancyService = inject(DiscrepancyService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly router = inject(Router);
  private readonly modalConfirmationService = inject(ModalConfirmationService);
  private readonly alertService = inject(TnapAlertService);

  readonly permissions = inject(PERMISSIONS_TOKEN);

  // Statuses that allow approval actions (can be different from waiting statuses)
  private readonly APPROVABLE_STATUSES = ['waiting_for_approval'];

  readonly filter = input<Record<string, unknown> | null>(null);

  readonly data = signal<NodeDiscrepancyListResponse>({
    items: [],
    totalCount: 0,
  });
  readonly loading = signal<boolean>(false);
  readonly selectedItems = signal<Set<string>>(new Set());

  readonly isWaitingForApprovalTableExpanded = signal<boolean>(true);
  readonly isOtherDiscrepanciesTableExpanded = signal<boolean>(true);

  readonly manageObjectFilter = signal<string | undefined>(undefined);

  private readonly lang = toSignal(this.translateService.onLangChange);

  // Actionable items (new and waiting_for_approval)
  readonly waitingForApprovalDiscrepanciesItems = computed(() => {
    const originalData = this.data();
    const manageObjectFilter = this.manageObjectFilter()?.toLowerCase();

    let filteredItems = originalData.items.filter(
      item => item.status && this.APPROVABLE_STATUSES.includes(item.status)
    );

    // Apply manage object filter
    if (manageObjectFilter) {
      filteredItems = filteredItems.filter(item =>
        item.modifiedManagedObjectName
          ?.toLowerCase()
          .includes(manageObjectFilter)
      );
    }

    return {
      items: filteredItems,
      totalCount: filteredItems.length,
    };
  });

  // Filtered items other than waiting for approval
  readonly otherDiscrepanciesItems = computed(() => {
    const originalData = this.data();
    const manageObjectFilter = this.manageObjectFilter()?.toLowerCase();

    let filteredItems = originalData.items.filter(
      item => !item.status || !this.APPROVABLE_STATUSES.includes(item.status)
    );

    // Apply manage object filter
    if (manageObjectFilter) {
      filteredItems = filteredItems.filter(item =>
        item.modifiedManagedObjectName
          ?.toLowerCase()
          .includes(manageObjectFilter)
      );
    }

    return {
      items: filteredItems,
      totalCount: filteredItems.length,
    };
  });

  // Keep the original filteredData for backward compatibility if needed
  readonly filteredData = computed(() => {
    const actionable = this.waitingForApprovalDiscrepanciesItems();
    const nonActionable = this.otherDiscrepanciesItems();

    return {
      items: [...actionable.items, ...nonActionable.items],
      totalCount: actionable.totalCount + nonActionable.totalCount,
    };
  });

  readonly checkedRowIds = computed(() => {
    const selected = this.selectedItems();
    const currentData = this.filteredData();
    return currentData.items
      .filter(
        item =>
          selected.has(item.configManagementActionId) &&
          this.isRowSelectable(item)
      )
      .map(item => item.configManagementActionId);
  });

  readonly isAllSelected = computed(() => {
    const currentData = this.filteredData();
    const selectableItems = currentData.items.filter(item =>
      this.isRowSelectable(item)
    );
    if (selectableItems.length === 0) return false;
    return selectableItems.every(item =>
      this.selectedItems().has(item.configManagementActionId)
    );
  });

  readonly COLUMNS = computed<ColumnDefinition<DiscrepancyDetailsResponse>[]>(
    () => {
      this.lang();
      return [
        {
          key: 'loopType',
          label: this.translateService.instant('treeview.discrepancyList.loop'),
          value: (row: DiscrepancyDetailsResponse) => row.loopType,
          visible: false,
        },
        {
          key: 'status',
          label: this.translateService.instant(
            'treeview.discrepancyList.status'
          ),
          value: (row: DiscrepancyDetailsResponse) => row.status,
        },
        {
          key: 'managedObject',
          label: this.translateService.instant(
            'treeview.discrepancyList.manageObject'
          ),
          value: (row: DiscrepancyDetailsResponse) =>
            row.modifiedManagedObjectName,
        },
        {
          key: 'attributeName',
          label: this.translateService.instant(
            'treeview.discrepancyList.attributeName'
          ),
          value: (row: DiscrepancyDetailsResponse) => row.attributeName,
        },
        {
          key: 'sourceValue',
          label: this.translateService.instant(
            'treeview.discrepancyList.source'
          ),
          value: (row: DiscrepancyDetailsResponse) => row.sourceValue,
        },
        {
          key: 'targetValue',
          label: this.translateService.instant(
            'treeview.discrepancyList.target'
          ),
          value: (row: DiscrepancyDetailsResponse) => row.targetValue,
        },
        {
          key: 'actions',
          label: this.translateService.instant(
            'treeview.discrepancyList.actions'
          ),
          value: () => {},
        },
      ];
    }
  );

  ngOnInit(): void {
    this.loadDiscrepancies();
  }

  private loadDiscrepancies(): void {
    const nodeName = this.filter()?.modifiedManagedObjectName;

    if (!nodeName) {
      this.resetData();
      return;
    }

    this.loading.set(true);

    this.discrepancyService
      .getDiscrepanciesByNode(nodeName as string)
      .pipe(
        catchError(() => {
          this.resetData();
          return of(null);
        }),
        finalize(() => this.loading.set(false)),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: (response: NodeDiscrepancyListResponse | null) => {
          if (response) {
            this.data.set(response);
            this.clearInvalidSelections();
          }
        },
      });
  }

  private resetData(): void {
    this.data.set({
      items: [],
      totalCount: 0,
    });
    this.clearSelection();
  }

  public redirectToDetail(row: DiscrepancyDetailsResponse): void {
    if (!row.configManagementActionId) {
      return;
    }

    this.router.navigate(['/cm-action/list'], {
      queryParams: { status: row.status, id: row.configManagementActionId },
    });
  }

  public canShowApproveButton(row: DiscrepancyDetailsResponse): boolean {
    const approvableStatuses = ['waiting_for_approval'];
    return row.status ? approvableStatuses.includes(row.status) : false;
  }

  // Selection methods
  public onCheckAllCheckbox(event: boolean): void {
    const currentSelected = new Set(this.selectedItems());
    const currentData = this.data();

    if (event) {
      currentData.items.forEach(item => {
        if (this.isRowSelectable(item)) {
          currentSelected.add(item.configManagementActionId);
        }
      });
    } else {
      currentData.items.forEach(item => {
        currentSelected.delete(item.configManagementActionId);
      });
    }

    this.selectedItems.set(currentSelected);
  }

  public onRowCheckedChange(event: {
    row: DiscrepancyDetailsResponse;
    checked: boolean;
    id: string | number;
  }): void {
    if (!this.canShowApproveButton(event.row)) {
      return;
    }

    const currentSelected = new Set(this.selectedItems());

    if (event.checked) {
      currentSelected.add(event.row.configManagementActionId);
    } else {
      currentSelected.delete(event.row.configManagementActionId);
    }

    this.selectedItems.set(currentSelected);
  }

  public isRowSelectable(row: DiscrepancyDetailsResponse): boolean {
    return this.canShowApproveButton(row);
  }

  public getSelectedItems(): DiscrepancyDetailsResponse[] {
    const selected = this.selectedItems();
    const currentData = this.data();
    return currentData.items.filter(item =>
      selected.has(item.configManagementActionId)
    );
  }

  public clearSelection(): void {
    this.selectedItems.set(new Set());
  }

  private clearInvalidSelections(): void {
    const currentSelected = this.selectedItems();
    const currentData = this.data();
    const validSelected = new Set<string>();

    currentData.items.forEach(item => {
      if (
        currentSelected.has(item.configManagementActionId) &&
        this.isRowSelectable(item)
      ) {
        validSelected.add(item.configManagementActionId);
      }
    });

    this.selectedItems.set(validSelected);
  }

  // Filter methods
  public onChangeManageObject(value: string | undefined): void {
    this.manageObjectFilter.set(value);
  }

  // Accordion toggle methods
  public onClickToggleTable(
    type: TableTypes,
    event?: KeyboardEvent | MouseEvent
  ): void {
    if (event && event instanceof KeyboardEvent) {
      if (event.key !== 'Enter' && event.key !== ' ') {
        return;
      }
      event.preventDefault();
    }

    if (type === 'waiting-discrepancies') {
      this.isWaitingForApprovalTableExpanded.set(
        !this.isWaitingForApprovalTableExpanded()
      );
    } else if (type === 'other-discrepancies') {
      this.isOtherDiscrepanciesTableExpanded.set(
        !this.isOtherDiscrepanciesTableExpanded()
      );
    }
  }

  public approveDiscrepancies(row?: DiscrepancyDetailsResponse): void {
    const approvalData = this.prepareApprovalData(row);

    if (!approvalData) {
      return;
    }

    this.showApprovalConfirmationModal(
      approvalData.actionIds,
      approvalData.textParams,
      row
    );
  }

  private prepareApprovalData(
    row?: DiscrepancyDetailsResponse
  ): { actionIds: string[]; textParams: ApprovalTextParams } | null {
    if (row) {
      return this.prepareSingleItemApproval(row);
    } else {
      return this.prepareBulkApproval();
    }
  }

  private prepareSingleItemApproval(
    row: DiscrepancyDetailsResponse
  ): { actionIds: string[]; textParams: ApprovalTextParams } | null {
    if (!row.configManagementActionId || !this.canShowApproveButton(row)) {
      return null;
    }

    return {
      actionIds: [row.configManagementActionId],
      textParams: { name: row.modifiedManagedObjectName || '' },
    };
  }

  private prepareBulkApproval(): {
    actionIds: string[];
    textParams: ApprovalTextParams;
  } | null {
    const selectedItems = this.getSelectedItems();
    const approvableItems = selectedItems.filter(item =>
      this.canShowApproveButton(item)
    );
    const actionIds = approvableItems
      .map(item => item.configManagementActionId)
      .filter(id => id);

    if (actionIds.length === 0) {
      return null;
    }

    const selectedNames = approvableItems
      .map(item => item.modifiedManagedObjectName)
      .filter(name => name)
      .join(',  ');

    return {
      actionIds,
      textParams: { name: selectedNames },
    };
  }

  private showApprovalConfirmationModal(
    actionIds: string[],
    textParams: ApprovalTextParams,
    row?: DiscrepancyDetailsResponse
  ): void {
    // Create HTML content with bold values
    const htmlContent = this.createModalHtmlContent(textParams);

    this.modalConfirmationService
      .openConfirmationModalWithHtml(
        'treeview.discrepancyList.modals.approve.okBtn',
        'treeview.discrepancyList.modals.approve.title',
        htmlContent
      )
      .pipe(
        filter(result => result === true),
        switchMap(() =>
          this.discrepancyService.approveDiscrepancies(actionIds)
        ),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: response => this.handleApprovalSuccess(response, row),
      });
  }

  private handleApprovalSuccess(
    response: { [key: string]: string } | null,
    row?: DiscrepancyDetailsResponse
  ): void {
    if (response && Object.keys(response).length > 0) {
      const message = this.buildApprovalMessage(response);
      this.alertService.success(message);

      // Clear selection immediately for bulk operations (when no specific row was passed)
      if (!row) {
        this.clearSelection();
      }

      setTimeout(() => {
        this.loadDiscrepancies();
      }, 500);
    }
  }

  private buildApprovalMessage(response: { [key: string]: string }): string {
    const statusCounts = new Map<string, number>();

    // Count occurrences of each status message
    Object.values(response).forEach(status => {
      const currentCount = statusCounts.get(status) || 0;
      statusCounts.set(status, currentCount + 1);
    });

    const totalActions = Object.keys(response).length;
    const statusDetails: string[] = [];

    // Build detailed status messages
    statusCounts.forEach((count, status) => {
      const actionWord = count === 1 ? 'action has' : 'actions have';
      const statusDetail = this.translateService.instant(
        'treeview.discrepancyList.modals.approval.responseStatus',
        { count, actionWord, status }
      );
      statusDetails.push(statusDetail);
    });

    if (statusDetails.length === 1) {
      const actionWord = totalActions === 1 ? 'action' : 'actions';
      return this.translateService.instant(
        'treeview.discrepancyList.modals.approval.successSingle',
        { totalActions, actionWord, statusDetails: statusDetails[0] }
      );
    } else {
      const lastDetail = statusDetails.pop();
      const statusDetailsText = statusDetails.join(', ') + ' and ' + lastDetail;
      return this.translateService.instant(
        'treeview.discrepancyList.modals.approval.successMultiple',
        { totalActions, statusDetails: statusDetailsText }
      );
    }
  }

  private createModalHtmlContent(textParams: ApprovalTextParams): string {
    const baseText = this.translateService.instant(
      'treeview.discrepancyList.modals.approve.text'
    );

    if (textParams?.name) {
      // Format multiple names with bold styling and spaces
      const names = textParams.name.split(',');
      const formattedNames = names
        .map((name: string) => `<div><strong>- ${name.trim()}</strong></div>`)
        .join(' ');

      // Replace {{name}} placeholder with formatted names
      return baseText.replace('{{name}}', formattedNames);
    }

    return baseText;
  }
}
