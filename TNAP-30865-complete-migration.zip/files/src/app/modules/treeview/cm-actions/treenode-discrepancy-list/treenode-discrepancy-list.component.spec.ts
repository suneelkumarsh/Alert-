/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { NO_ERRORS_SCHEMA } from '@angular/core';
import {
  ComponentFixture,
  TestBed,
  fakeAsync,
  tick,
} from '@angular/core/testing';
import { Router } from '@angular/router';

import { TranslateModule } from '@ngx-translate/core';

import { of, throwError, Subject } from 'rxjs';
import { ModalConfirmationService } from 'src/app/services/common-functionalities/modal-confirmation.service';

import {
  DiscrepancyService,
  NodeDiscrepancyListResponse,
} from 'src/app/services/discrepancylist-service/discrepancy.service';
import { DiscrepancyDetailsResponse } from 'openapi/output/model/discrepancyDetailsResponse.model';
import { ConfigActionStatus } from 'openapi/output/model/configActionStatus.model';

import {
  TreenodeDiscrepancyListComponent,
  TableTypes,
} from './treenode-discrepancy-list.component';

import { TableConfigService } from '@portal-mfe/tnap-ui-kit/components/data-table';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('TreenodeDiscrepancyListComponent', () => {
  let component: TreenodeDiscrepancyListComponent;
  let fixture: ComponentFixture<TreenodeDiscrepancyListComponent>;

  let mockDiscrepancyService: jasmine.SpyObj<DiscrepancyService>;
  let mockRouter: jasmine.SpyObj<Router>;
  let mockModalConfirmationService: jasmine.SpyObj<ModalConfirmationService>;
  let mockAlertService: jasmine.SpyObj<TnapAlertService>;

  const mockDiscrepancies: DiscrepancyDetailsResponse[] = [
    {
      configManagementActionId: 'cm-action-001',
      modifiedManagedObjectName: 'ManagedElement',
      attributeName: 'nRTAC',
      sourceValue: '12345',
      targetValue: '67890',
      status: 'waiting_for_approval' as ConfigActionStatus,
      loopType: 'open',
    },
    {
      configManagementActionId: 'cm-action-002',
      modifiedManagedObjectName: 'OtherElement',
      attributeName: 'attribute2',
      sourceValue: 'oldValue',
      targetValue: 'newValue',
      status: 'activation_completed' as ConfigActionStatus,
      loopType: 'close',
    },
  ];

  const mockResponse: NodeDiscrepancyListResponse = {
    items: mockDiscrepancies,
    totalCount: 2,
  };

  beforeEach(async () => {
    mockDiscrepancyService = jasmine.createSpyObj('DiscrepancyService', [
      'getDiscrepanciesByNode',
      'approveDiscrepancies',
    ]);

    mockRouter = jasmine.createSpyObj('Router', ['navigate']);

    mockModalConfirmationService = jasmine.createSpyObj(
      'ModalConfirmationService',
      ['openConfirmationModalWithHtml']
    );

    mockAlertService = jasmine.createSpyObj('TnapAlertService', ['success']);

    mockDiscrepancyService.getDiscrepanciesByNode.and.returnValue(
      of(mockResponse)
    );

    mockDiscrepancyService.approveDiscrepancies.and.returnValue(
      of({
        action1: 'APPROVED',
      })
    );
    mockModalConfirmationService.openConfirmationModalWithHtml.and.returnValue(
      of(true)
    );

    await TestBed.configureTestingModule({
      declarations: [TreenodeDiscrepancyListComponent],
      imports: [TranslateModule.forRoot()],
      providers: [
        {
          provide: DiscrepancyService,
          useValue: mockDiscrepancyService,
        },
        {
          provide: Router,
          useValue: mockRouter,
        },
        {
          provide: ModalConfirmationService,
          useValue: mockModalConfirmationService,
        },
        {
          provide: TnapAlertService,
          useValue: mockAlertService,
        },
        TableConfigService,
        { provide: PERMISSIONS_TOKEN, useValue: [] },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    })
      .overrideComponent(TreenodeDiscrepancyListComponent, {
        set: { template: '' },
      })
      .compileComponents();

    fixture = TestBed.createComponent(TreenodeDiscrepancyListComponent);
    component = fixture.componentInstance;
  });

  afterEach(() => {
    fixture.destroy();
  });

  describe('Initialization', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should initialize default state', () => {
      expect(component.loading()).toBeFalse();
      expect(component.data()).toEqual({
        items: [],
        totalCount: 0,
      });
      expect(component.isWaitingForApprovalTableExpanded()).toBeTrue();
      expect(component.isOtherDiscrepanciesTableExpanded()).toBeTrue();
      expect(component.selectedItems()).toEqual(new Set());
    });

    it('should not load discrepancies on init without filter', () => {
      fixture.detectChanges();
      expect(
        mockDiscrepancyService.getDiscrepanciesByNode
      ).not.toHaveBeenCalled();
    });

    it('should load discrepancies on init with filter', () => {
      fixture.componentRef.setInput('filter', {
        modifiedManagedObjectName: 'TestNode',
      });
      fixture.detectChanges();
      expect(
        mockDiscrepancyService.getDiscrepanciesByNode
      ).toHaveBeenCalledWith('TestNode');
    });

    it('should populate data after successful load', fakeAsync(() => {
      fixture.componentRef.setInput('filter', {
        modifiedManagedObjectName: 'TestNode',
      });
      fixture.detectChanges();
      tick();

      expect(component.data()).toEqual(mockResponse);
      expect(component.loading()).toBeFalse();
    }));
  });

  describe('Loading State', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('filter', {
        modifiedManagedObjectName: 'TestNode',
      });
    });

    it('should set loading true while request is active', () => {
      const subject = new Subject<NodeDiscrepancyListResponse>();

      mockDiscrepancyService.getDiscrepanciesByNode.and.returnValue(
        subject.asObservable()
      );

      fixture.detectChanges();
      expect(component.loading()).toBeTrue();
    });

    it('should set loading false after request completes', fakeAsync(() => {
      const subject = new Subject<NodeDiscrepancyListResponse>();

      mockDiscrepancyService.getDiscrepanciesByNode.and.returnValue(
        subject.asObservable()
      );

      fixture.detectChanges();
      subject.next(mockResponse);
      subject.complete();
      tick();

      expect(component.loading()).toBeFalse();
    }));
  });

  describe('Error Handling', () => {
    beforeEach(() => {
      fixture.componentRef.setInput('filter', {
        modifiedManagedObjectName: 'TestNode',
      });
    });

    it('should reset data on API error', fakeAsync(() => {
      mockDiscrepancyService.getDiscrepanciesByNode.and.returnValue(
        throwError(() => new Error('API Error'))
      );

      fixture.detectChanges();
      tick();

      expect(component.data()).toEqual({
        items: [],
        totalCount: 0,
      });

      expect(component.loading()).toBeFalse();
    }));

    it('should handle null response safely', fakeAsync(() => {
      mockDiscrepancyService.getDiscrepanciesByNode.and.returnValue(
        of(null as any)
      );

      fixture.detectChanges();
      tick();

      expect(component.data()).toEqual({
        items: [],
        totalCount: 0,
      });
    }));
  });

  describe('Filter Input Handling', () => {
    it('should reset data when filter is null', () => {
      fixture.componentRef.setInput('filter', null);
      fixture.detectChanges();

      expect(component.data()).toEqual({
        items: [],
        totalCount: 0,
      });
      expect(
        mockDiscrepancyService.getDiscrepanciesByNode
      ).not.toHaveBeenCalled();
    });

    it('should reset data when filter has no modifiedManagedObjectName', () => {
      fixture.componentRef.setInput('filter', { otherProperty: 'value' });
      fixture.detectChanges();

      expect(component.data()).toEqual({
        items: [],
        totalCount: 0,
      });
      expect(
        mockDiscrepancyService.getDiscrepanciesByNode
      ).not.toHaveBeenCalled();
    });

    it('should load discrepancies when filter has valid modifiedManagedObjectName', fakeAsync(() => {
      fixture.componentRef.setInput('filter', {
        modifiedManagedObjectName: 'ValidNode',
      });
      fixture.detectChanges();
      tick();

      expect(
        mockDiscrepancyService.getDiscrepanciesByNode
      ).toHaveBeenCalledWith('ValidNode');
      expect(component.data()).toEqual(mockResponse);
    }));
  });

  describe('Translation Reactivity', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    it('should generate columns with translation keys', () => {
      const columns = component.COLUMNS();
      expect(columns.length).toBe(7);
      expect(columns.map(c => c.label)).toEqual([
        'treeview.discrepancyList.loop',
        'treeview.discrepancyList.status',
        'treeview.discrepancyList.manageObject',
        'treeview.discrepancyList.attributeName',
        'treeview.discrepancyList.source',
        'treeview.discrepancyList.target',
        'treeview.discrepancyList.actions',
      ]);
    });
  });

  describe('Columns', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    it('should generate table columns', () => {
      const columns = component.COLUMNS();

      expect(columns.length).toBe(7);
      expect(columns.map(c => c.key)).toEqual([
        'loopType',
        'status',
        'managedObject',
        'attributeName',
        'sourceValue',
        'targetValue',
        'actions',
      ]);
    });

    it('should have proper translation keys as labels', () => {
      const columns = component.COLUMNS();

      expect(columns.map(c => c.label)).toEqual([
        'treeview.discrepancyList.loop',
        'treeview.discrepancyList.status',
        'treeview.discrepancyList.manageObject',
        'treeview.discrepancyList.attributeName',
        'treeview.discrepancyList.source',
        'treeview.discrepancyList.target',
        'treeview.discrepancyList.actions',
      ]);
    });

    it('should extract row values correctly', () => {
      const row = mockDiscrepancies[0];
      const columns = component.COLUMNS();

      expect(columns[0].value(row)).toBe('open');
      expect(columns[1].value(row)).toBe('waiting_for_approval');
      expect(columns[2].value(row)).toBe('ManagedElement');
      expect(columns[3].value(row)).toBe('nRTAC');
      expect(columns[4].value(row)).toBe('12345');
      expect(columns[5].value(row)).toBe('67890');
      expect(columns[6].value(row)).toBeUndefined();
    });

    describe('Accordion Functionality', () => {
      beforeEach(() => {
        fixture.detectChanges();
      });

      it('should toggle actionable table', () => {
        expect(component.isWaitingForApprovalTableExpanded()).toBeTrue();

        component.onClickToggleTable('waiting-discrepancies' as TableTypes);

        expect(component.isWaitingForApprovalTableExpanded()).toBeFalse();
      });

      it('should toggle non-actionable table', () => {
        expect(component.isOtherDiscrepanciesTableExpanded()).toBeTrue();

        component.onClickToggleTable('other-discrepancies' as TableTypes);

        expect(component.isOtherDiscrepanciesTableExpanded()).toBeFalse();
      });

      it('should handle keyboard events for actionable table', () => {
        const enterEvent = new KeyboardEvent('keydown', { key: 'Enter' });
        spyOn(enterEvent, 'preventDefault');

        component.onClickToggleTable(
          'waiting-discrepancies' as TableTypes,
          enterEvent
        );

        expect(enterEvent.preventDefault).toHaveBeenCalled();
        expect(component.isWaitingForApprovalTableExpanded()).toBeFalse();
      });

      it('should handle space key events for non-actionable table', () => {
        const spaceEvent = new KeyboardEvent('keydown', { key: ' ' });
        spyOn(spaceEvent, 'preventDefault');

        component.onClickToggleTable(
          'other-discrepancies' as TableTypes,
          spaceEvent
        );

        expect(spaceEvent.preventDefault).toHaveBeenCalled();
        expect(component.isOtherDiscrepanciesTableExpanded()).toBeFalse();
      });

      it('should ignore other keyboard events', () => {
        const escEvent = new KeyboardEvent('keydown', { key: 'Escape' });

        component.onClickToggleTable(
          'waiting-discrepancies' as TableTypes,
          escEvent
        );

        expect(component.isWaitingForApprovalTableExpanded()).toBeTrue();
      });
    });

    describe('Data Filtering', () => {
      beforeEach(() => {
        component.data.set(mockResponse);
        fixture.detectChanges();
      });

      it('should filter waiting for approval discrepancies correctly', () => {
        const waitingForApprovalData =
          component.waitingForApprovalDiscrepanciesItems();

        expect(waitingForApprovalData.items.length).toBe(1);
        expect(waitingForApprovalData.items[0].status).toBe(
          'waiting_for_approval'
        );
        expect(waitingForApprovalData.totalCount).toBe(1);
      });

      it('should filter other discrepancies correctly', () => {
        const otherDiscrepanciesData = component.otherDiscrepanciesItems();

        expect(otherDiscrepanciesData.items.length).toBe(1);
        expect(otherDiscrepanciesData.items[0].status).toBe(
          'activation_completed'
        );
        expect(otherDiscrepanciesData.totalCount).toBe(1);
      });

      it('should apply manage object filter to waiting for approval discrepancies', () => {
        component.onChangeManageObject('managed');

        const waitingForApprovalData =
          component.waitingForApprovalDiscrepanciesItems();
        expect(waitingForApprovalData.items.length).toBe(1);
        expect(waitingForApprovalData.items[0].modifiedManagedObjectName).toBe(
          'ManagedElement'
        );
      });

      it('should apply manage object filter to other discrepancies', () => {
        component.onChangeManageObject('other');

        const otherDiscrepanciesData = component.otherDiscrepanciesItems();
        expect(otherDiscrepanciesData.items.length).toBe(1);
        expect(otherDiscrepanciesData.items[0].modifiedManagedObjectName).toBe(
          'OtherElement'
        );
      });
    });

    describe('Approval Button Visibility', () => {
      it('should show approve button for waiting_for_approval status', () => {
        const row = mockDiscrepancies[0]; // waiting_for_approval
        expect(component.canShowApproveButton(row)).toBeTrue();
      });

      it('should not show approve button for completed status', () => {
        const row = mockDiscrepancies[1]; // activation_completed
        expect(component.canShowApproveButton(row)).toBeFalse();
      });

      it('should not show approve button for undefined status', () => {
        const row = { ...mockDiscrepancies[0], status: undefined };
        expect(component.canShowApproveButton(row as any)).toBeFalse();
      });
    });

    describe('Approval Functionality', () => {
      beforeEach(() => {
        component.data.set(mockResponse);
        fixture.detectChanges();
      });

      describe('Single Item Approval', () => {
        it('should approve single discrepancy when modal is confirmed', fakeAsync(() => {
          const waitingItem = mockDiscrepancies[0];

          component.approveDiscrepancies(waitingItem);
          tick();

          expect(
            mockModalConfirmationService.openConfirmationModalWithHtml
          ).toHaveBeenCalledWith(
            'treeview.discrepancyList.modals.approve.okBtn',
            'treeview.discrepancyList.modals.approve.title',
            jasmine.any(String)
          );
          expect(
            mockDiscrepancyService.approveDiscrepancies
          ).toHaveBeenCalledWith(['cm-action-001']);
          expect(mockAlertService.success).toHaveBeenCalled();
        }));

        it('should not approve when modal is canceled', fakeAsync(() => {
          mockModalConfirmationService.openConfirmationModalWithHtml.and.returnValue(
            of(false)
          );
          const waitingItem = mockDiscrepancies[0];

          component.approveDiscrepancies(waitingItem);
          tick();

          expect(
            mockModalConfirmationService.openConfirmationModalWithHtml
          ).toHaveBeenCalled();
          expect(
            mockDiscrepancyService.approveDiscrepancies
          ).not.toHaveBeenCalled();
          expect(mockAlertService.success).not.toHaveBeenCalled();
        }));

        it('should not approve discrepancy without configManagementActionId', () => {
          const itemWithoutId = {
            ...mockDiscrepancies[0],
            configManagementActionId: undefined,
          };

          component.approveDiscrepancies(
            itemWithoutId as unknown as DiscrepancyDetailsResponse
          );

          expect(
            mockModalConfirmationService.openConfirmationModalWithHtml
          ).not.toHaveBeenCalled();
          expect(
            mockDiscrepancyService.approveDiscrepancies
          ).not.toHaveBeenCalled();
        });

        it('should not approve discrepancy with non-approvable status', () => {
          const completedItem = mockDiscrepancies[1]; // activation_completed status

          component.approveDiscrepancies(completedItem);

          expect(
            mockModalConfirmationService.openConfirmationModalWithHtml
          ).not.toHaveBeenCalled();
          expect(
            mockDiscrepancyService.approveDiscrepancies
          ).not.toHaveBeenCalled();
        });
      });

      describe('Bulk Approval', () => {
        beforeEach(() => {
          // Select the approvable item
          component.selectedItems.set(new Set(['cm-action-001']));
        });

        it('should approve multiple selected discrepancies when modal is confirmed', fakeAsync(() => {
          component.approveDiscrepancies();
          tick();

          expect(
            mockModalConfirmationService.openConfirmationModalWithHtml
          ).toHaveBeenCalled();
          expect(
            mockDiscrepancyService.approveDiscrepancies
          ).toHaveBeenCalledWith(['cm-action-001']);
          expect(mockAlertService.success).toHaveBeenCalled();
        }));

        it('should not approve when modal is canceled for bulk operation', fakeAsync(() => {
          mockModalConfirmationService.openConfirmationModalWithHtml.and.returnValue(
            of(false)
          );

          component.approveDiscrepancies();
          tick();

          expect(
            mockModalConfirmationService.openConfirmationModalWithHtml
          ).toHaveBeenCalled();
          expect(
            mockDiscrepancyService.approveDiscrepancies
          ).not.toHaveBeenCalled();
          expect(mockAlertService.success).not.toHaveBeenCalled();
        }));

        it('should clear selection after successful bulk approval', fakeAsync(() => {
          component.approveDiscrepancies();
          tick(500); // Wait for the timeout

          expect(component.selectedItems()).toEqual(new Set());
        }));

        it('should not approve when no approvable items are selected', () => {
          component.selectedItems.set(new Set(['cm-action-002'])); // Only select non-approvable item

          component.approveDiscrepancies();

          expect(
            mockModalConfirmationService.openConfirmationModalWithHtml
          ).not.toHaveBeenCalled();
          expect(
            mockDiscrepancyService.approveDiscrepancies
          ).not.toHaveBeenCalled();
        });

        it('should not approve when no items are selected', () => {
          component.selectedItems.set(new Set());

          component.approveDiscrepancies();

          expect(
            mockModalConfirmationService.openConfirmationModalWithHtml
          ).not.toHaveBeenCalled();
          expect(
            mockDiscrepancyService.approveDiscrepancies
          ).not.toHaveBeenCalled();
        });
      });

      describe('Modal Confirmation Filter', () => {
        it('should filter for true result before proceeding with approval', fakeAsync(() => {
          const waitingItem = mockDiscrepancies[0];

          // Test that only true results pass through the filter
          mockModalConfirmationService.openConfirmationModalWithHtml.and.returnValue(
            of(true)
          );

          component.approveDiscrepancies(waitingItem);
          tick();

          expect(
            mockDiscrepancyService.approveDiscrepancies
          ).toHaveBeenCalled();

          // Reset and test false result
          mockDiscrepancyService.approveDiscrepancies.calls.reset();
          mockModalConfirmationService.openConfirmationModalWithHtml.and.returnValue(
            of(false)
          );

          component.approveDiscrepancies(waitingItem);
          tick();

          expect(
            mockDiscrepancyService.approveDiscrepancies
          ).not.toHaveBeenCalled();
        }));
      });
    });
  });

  describe('Navigation', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    it('should navigate to detail page', () => {
      component.redirectToDetail(mockDiscrepancies[0]);

      expect(mockRouter.navigate).toHaveBeenCalledWith(['/cm-action/list'], {
        queryParams: { status: 'waiting_for_approval', id: 'cm-action-001' },
      });
    });

    it('should not navigate for row without configManagementActionId', () => {
      const rowWithoutId = {
        modifiedManagedObjectName: 'TestNode',
        attributeName: 'attr',
        sourceValue: 'source',
        targetValue: 'target',
        status: 'activation_completed' as ConfigActionStatus,
      } as unknown as DiscrepancyDetailsResponse;

      component.redirectToDetail(rowWithoutId);

      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should not navigate for null row', () => {
      const rowWithoutId = {} as DiscrepancyDetailsResponse;
      component.redirectToDetail(rowWithoutId);
      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });
  });
});
