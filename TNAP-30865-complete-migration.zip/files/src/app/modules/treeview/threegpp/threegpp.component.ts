/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  ElementRef,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild,
  computed,
  inject,
  input,
  signal,
} from '@angular/core';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { ConfigDataService } from 'openapi/output';
import { ApplyChange, TreeviewFinalModel } from 'src/app/model/treeview.model';
import { KeyboardNavigationShortcuts } from 'src/app/model/keyboard-shortcuts.model';
import { CustomTreeviewService } from 'src/app/services/custom-treeview.service';
import {
  ConfigTableRow,
  ThreegppConfigDataService,
} from 'src/app/services/threegpp-config-data.service';
import { Observable, Subject, of } from 'rxjs';
import {
  catchError,
  debounceTime,
  map,
  shareReplay,
  startWith,
  switchMap,
  take,
  tap,
} from 'rxjs/operators';
import { SegmentedControlItem } from '@portal-mfe/tnap-ui-kit/components/segmented-control';
import { TranslateService } from '@ngx-translate/core';
import { TreeviewEditService } from 'src/app/services/treeview-edit.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';
export type ConfigurationViewMode = 'table' | 'tree';

@Component({
  selector: 'app-threegpp-treeview',
  templateUrl: './threegpp.component.html',
  styleUrls: ['./threegpp.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: false,
})
export class ThreegppComponent implements OnInit, OnChanges {
  @Input() treeviewElement!: TreeviewFinalModel;
  @Input() synchronizedFilter: string | null = null;
  @Input() allowEditAttribute = false;
  private readonly customTreeviewService = inject(CustomTreeviewService);
  private readonly configDataService = inject(ConfigDataService);
  private readonly threegppConfigDataService = inject(
    ThreegppConfigDataService
  );
  private readonly treeviewEditService = inject(TreeviewEditService);
  private readonly destroyRef$ = inject(DestroyRef);
  private readonly translateService = inject(TranslateService);
  private readonly alertService = inject(TnapAlertService);

  readonly isPlanningSelfLinkData = input<boolean>(false);

  SELECT_FILTER_INPUT_SHORTCUT =
    KeyboardNavigationShortcuts.SELECT_FILTER_INPUT_SHORTCUT;

  private readonly filter$ = new Subject<string>();
  nodes$: Observable<any> = new Observable<any>();
  public notValidSelflink = false;

  private readonly DEBOUNCE_TIME = 500;
  private readonly manualReload$ = new Subject<void>();
  private readonly nrPCIChanged$ = new Subject<number>();

  readonly currentFilter = signal('');
  readonly viewMode = signal<ConfigurationViewMode>('tree');

  private readonly translations$ = this.translateService.stream([
    'treeview.configurationView.table',
    'treeview.configurationView.tree',
  ]);
  private readonly translations = toSignal(this.translations$, {
    initialValue: {} as Record<string, string>,
  });
  readonly viewModeItems = computed<SegmentedControlItem[]>(() => {
    const t = this.translations();
    return [
      {
        label: t['treeview.configurationView.table'] ?? 'Table',
        value: 'table',
        icon: 'bi-table',
      },
      {
        label: t['treeview.configurationView.tree'] ?? 'Treeview',
        value: 'tree',
        icon: 'bi-diagram-3',
      },
    ];
  });
  readonly tableRows = signal<ConfigTableRow[]>([]);
  readonly filteredTableRows = signal<ConfigTableRow[]>([]);
  readonly tableLoading = signal(false);
  readonly tableLoaded = signal(false);

  readonly noDataMessage = computed(() =>
    this.isPlanningSelfLinkData()
      ? 'treeview.messages.noPlanningLink'
      : 'treeview.messages.noSelflink'
  );

  @ViewChild('searchInput', { read: ElementRef })
  private readonly searchInput?: ElementRef<HTMLElement>;

  ngOnInit() {
    this.filter$
      .pipe(
        debounceTime(this.DEBOUNCE_TIME),
        takeUntilDestroyed(this.destroyRef$),
        map(value => value.toLowerCase())
      )
      .subscribe(value => {
        this.currentFilter.set(value);
        this.applyTableFilter();
      });
    const selfLink = this.isPlanningSelfLinkData()
      ? this.treeviewElement?.model?.planningSelflink
      : this.treeviewElement?.model?.selflink;

    if (!selfLink) {
      this.notValidSelflink = true;
      return;
    }

    // Single shared HTTP call — table view and tree view both read from this.
    // shareReplay(1) ensures that switching to the tree view replays the already-
    // fetched data instead of triggering a second network request.
    const configData$ = this.manualReload$.pipe(
      startWith(void 0),
      tap(() => this.tableLoading.set(true)),
      switchMap(() =>
        this.customTreeviewService.getPlainConfigData(selfLink).pipe(
          catchError(() => of({})),
          take(1)
        )
      ),
      shareReplay(1)
    );

    // Table view: build flat rows from the shared data.
    configData$
      .pipe(takeUntilDestroyed(this.destroyRef$))
      .subscribe(configData => {
        this.tableRows.set(
          this.threegppConfigDataService.buildConfigTableRows(configData)
        );
        this.applyTableFilter();
        this.tableLoading.set(false);
        this.tableLoaded.set(true);
      });

    // Tree view: transform the same raw data — no extra HTTP call.
    this.nodes$ = configData$.pipe(
      map(data => this.customTreeviewService.mapRawConfigToTreeNodes(data))
    );

    // nRPCI update: fetch current config lazily, only when the user actually
    // changes the value — not eagerly on component init.
    this.nrPCIChanged$
      .pipe(
        debounceTime(300),
        switchMap(newNrPci =>
          this.customTreeviewService.getPlainConfigData(selfLink).pipe(
            take(1),
            switchMap(config => {
              if (!config?.NRCellDU?.attributes) {
                return of(undefined);
              }
              config.NRCellDU.attributes.nRPCI = newNrPci;
              return this.configDataService.updateCpsConfigData(
                selfLink,
                this.treeviewElement?.name || '',
                this.treeviewElement
                  ? this.threegppConfigDataService.getAaiObjectReference(
                      this.treeviewElement
                    )
                  : undefined,
                config
              );
            })
          )
        ),
        takeUntilDestroyed(this.destroyRef$)
      )
      .subscribe(() => this.manualReload$.next());
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.synchronizedFilter) {
      this.filter$.next(changes.synchronizedFilter.currentValue ?? '');
    }
  }

  onFilterChange(value: string): void {
    this.filter$.next(value);
  }

  onViewModeChange(mode: string): void {
    const targetMode = mode as ConfigurationViewMode;

    if (targetMode === 'table') {
      // Scenario A: User modified fields -> Show confirmation popup
      if (
        this.treeviewEditService.editMode() &&
        this.treeviewEditService.modifiedFields.length > 0
      ) {
        this.treeviewEditService
          .confirmSwitchToTableView()
          .subscribe(result => {
            if (result) {
              this.treeviewEditService.modifiedFields = [];
              this.treeviewEditService.editMode.set(false);
              this.viewMode.set(targetMode);
            }
          });
        return;
      }

      // Scenario B: User is in edit mode but made NO changes -> Turn off edit mode automatically
      if (this.treeviewEditService.editMode()) {
        this.treeviewEditService.editMode.set(false);
      }
    }

    // Default routing for normal view switches
    this.viewMode.set(targetMode);
  }

  clearFilter(): void {
    this.filter$.next('');
    this.currentFilter.set('');
    this.applyTableFilter();
    this.focusSearchInput();
  }

  onTreeDataChanged(): void {
    this.manualReload$.next();
  }

  onNrpciValueChanged(newValue: number): void {
    this.nrPCIChanged$.next(newValue);
  }

  onApplyRequested(changes: ApplyChange[]): void {
    const selfLink = this.treeviewElement?.model?.planningSelflink;

    if (!selfLink || !changes.length) {
      return;
    }

    this.customTreeviewService
      .getPlainConfigData(selfLink)
      .pipe(
        take(1),
        switchMap(config => {
          changes.forEach(change => {
            this.threegppConfigDataService.updateByPath(
              config,
              change.path,
              change.newValue
            );
          });
          const payload = this.threegppConfigDataService.buildPayload(
            selfLink,
            config
          );
          return this.configDataService.updateCpsConfigData(
            selfLink,
            this.treeviewElement?.name || '',
            this.threegppConfigDataService.getAaiObjectReference(
              this.treeviewElement
            ),
            payload
          );
        })
      )
      .subscribe({
        next: () => {
          this.manualReload$.next();
          this.alertService.success(
            this.translateService.instant('treeview.messages.updateSuccess'),
            { keepAfterRouteChange: true }
          );
        },
      });
  }

  private focusSearchInput(): void {
    this.searchInput?.nativeElement?.querySelector('input')?.focus();
  }

  private applyTableFilter(): void {
    this.filteredTableRows.set(
      this.threegppConfigDataService.filterTableRows(
        this.tableRows(),
        this.currentFilter()
      )
    );
  }
}
