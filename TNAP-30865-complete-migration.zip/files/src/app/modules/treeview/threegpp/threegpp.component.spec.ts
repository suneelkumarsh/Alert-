/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/// <reference types="jasmine" />

import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { of } from 'rxjs';
import { ConfigDataService } from 'openapi/output';
import { NodeType } from 'src/app/model/topology.model';
import { CustomTreeviewService } from 'src/app/services/custom-treeview.service';
import { ThreegppComponent } from './threegpp.component';
import { TranslateModule } from '@ngx-translate/core';
import { ApplyChange } from 'src/app/model/treeview.model';
import {
  TreeviewEditService,
  ModifiedFields,
} from 'src/app/services/treeview-edit.service';
import { signal } from '@angular/core';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('ThreegppComponent', () => {
  let component: ThreegppComponent;
  let customTreeviewService: jasmine.SpyObj<CustomTreeviewService>;
  let configDataService: jasmine.SpyObj<ConfigDataService>;
  let alertServiceMock: jasmine.SpyObj<TnapAlertService>;
  let treeviewEditServiceSpy: jasmine.SpyObj<TreeviewEditService>;
  const configResponse = {
    ManagedElement: {
      id: '73000005',
      attributes: {
        swVersion: '24.Q1',
      },
    },
    GNBDUFunction: {
      id: '1',
      attributes: {
        gNBId: 83017746,
      },
    },
    NRCellDU: {
      id: 'cell-1',
      attributes: {
        nRPCI: 10,
      },
    },
  };

  beforeEach(async () => {
    customTreeviewService = jasmine.createSpyObj('CustomTreeviewService', [
      'getTreeviewConfigData',
      'getPlainConfigData',
      'mapRawConfigToTreeNodes',
    ]);
    configDataService = jasmine.createSpyObj('ConfigDataService', [
      'updateCpsConfigData',
    ]);
    alertServiceMock = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
    ]);

    customTreeviewService.getTreeviewConfigData.and.returnValue(of([]));
    customTreeviewService.mapRawConfigToTreeNodes.and.returnValue([]);
    customTreeviewService.getPlainConfigData.and.returnValue(
      of(configResponse)
    );
    configDataService.updateCpsConfigData.and.returnValue(of({} as any));
    treeviewEditServiceSpy = jasmine.createSpyObj<TreeviewEditService>(
      'TreeviewEditService',
      ['confirmSwitchToTableView']
    );

    treeviewEditServiceSpy.confirmSwitchToTableView.and.returnValue(of(true));

    (treeviewEditServiceSpy as any).modifiedFields = [];
    (treeviewEditServiceSpy as any).editMode = signal(false);
    await TestBed.configureTestingModule({
      declarations: [ThreegppComponent],
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: CustomTreeviewService, useValue: customTreeviewService },
        { provide: ConfigDataService, useValue: configDataService },
        {
          provide: TnapAlertService,
          useValue: alertServiceMock,
        },
        {
          provide: TreeviewEditService,
          useValue: treeviewEditServiceSpy,
        },
      ],
    })
      .overrideComponent(ThreegppComponent, {
        set: { template: '' },
      })
      .compileComponents();

    const fixture = TestBed.createComponent(ThreegppComponent);
    component = fixture.componentInstance;
  });
  function setDefaultTreeviewElement(): void {
    component.treeviewElement = {
      name: 'Node-1',
      aaiType: NodeType.CELL,
      model: {
        selflink: '/aai/v22/network/cell/123',
        cellId: '123',
      },
    } as any;
  }

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should mark invalid state if selflink is missing', () => {
    component.treeviewElement = {
      name: 'Node-1',
      aaiType: NodeType.CELL,
      model: {},
    } as any;

    component.ngOnInit();

    expect(component.notValidSelflink).toBeTrue();
    expect(customTreeviewService.getPlainConfigData).not.toHaveBeenCalled();
  });

  it('should load and map table rows on init', () => {
    setDefaultTreeviewElement();

    component.ngOnInit();

    expect(customTreeviewService.getPlainConfigData).toHaveBeenCalledWith(
      '/aai/v22/network/cell/123'
    );
    expect(component.tableLoaded()).toBeTrue();
    expect(component.tableLoading()).toBeFalse();
    expect(component.tableRows().length).toBeGreaterThan(0);
    expect(component.filteredTableRows().length).toBe(
      component.tableRows().length
    );
  });

  it('should format moIdPath with = for both single objects and nested array items', () => {
    setDefaultTreeviewElement();
    customTreeviewService.getPlainConfigData.and.returnValue(
      of({
        NRCellDU: {
          id: '84000023',
          RRMPolicyRatio: [
            { id: '1-PRB_DL', attributes: { resourceType: 'PRB_DL' } },
            { id: '1-PRB_UL', attributes: { resourceType: 'PRB_UL' } },
          ],
          attributes: { nRPCI: 10 },
        },
      })
    );

    component.ngOnInit();

    const cellRow = component.tableRows().find(r => r.attribute === 'nRPCI');
    expect(cellRow?.moIdPath).toBe('NRCellDU=84000023');

    const prbDlRow = component.tableRows().find(r => r.value === 'PRB_DL');
    expect(prbDlRow?.moIdPath).toBe(
      'NRCellDU=84000023/RRMPolicyRatio=1-PRB_DL'
    );

    const prbUlRow = component.tableRows().find(r => r.value === 'PRB_UL');
    expect(prbUlRow?.moIdPath).toBe(
      'NRCellDU=84000023/RRMPolicyRatio=1-PRB_UL'
    );
  });

  it('should format array indices as [n] in attribute paths', () => {
    setDefaultTreeviewElement();
    customTreeviewService.getPlainConfigData.and.returnValue(
      of({
        NRCellDU: {
          id: 'cell-1',
          attributes: {
            rRMPolicyMemberList: [
              { mnc: '01', mcc: '262' },
              { mnc: '02', mcc: '263' },
            ],
          },
        },
      })
    );

    component.ngOnInit();

    const mncRow0 = component
      .tableRows()
      .find(r => r.attribute === 'rRMPolicyMemberList[0].mnc');
    expect(mncRow0).toBeTruthy();
    expect(mncRow0?.value).toBe('01');

    const mncRow1 = component
      .tableRows()
      .find(r => r.attribute === 'rRMPolicyMemberList[1].mnc');
    expect(mncRow1).toBeTruthy();
    expect(mncRow1?.value).toBe('02');
  });

  it('should keep table rows empty for invalid config payload', () => {
    setDefaultTreeviewElement();
    customTreeviewService.getPlainConfigData.and.returnValue(of(null as any));

    component.ngOnInit();

    expect(component.tableLoaded()).toBeTrue();
    expect(component.tableLoading()).toBeFalse();
    expect(component.tableRows()).toEqual([]);
    expect(component.filteredTableRows()).toEqual([]);
  });

  it('should apply filter with debounce', fakeAsync(() => {
    setDefaultTreeviewElement();
    component.ngOnInit();

    component.onFilterChange('gnb');
    tick(500);

    expect(component.currentFilter()).toBe('gnb');
    expect(component.filteredTableRows().length).toBeGreaterThan(0);
    expect(
      component.filteredTableRows().some(row => row.attribute === 'gNBId')
    ).toBeTrue();
  }));

  it('should update config and trigger reload when nRPCI changes', fakeAsync(() => {
    setDefaultTreeviewElement();
    component.ngOnInit();

    component.onNrpciValueChanged(99);
    tick(300);

    expect(configDataService.updateCpsConfigData).toHaveBeenCalled();
    // After the fix: 1 call on init (shared configData$) + 1 lazy call for
    // the nRPCI update + 1 call for the subsequent manualReload$ = 3 total.
    // Previously combineLatest caused an eager extra subscription on init,
    // inflating the count to >3.
    expect(customTreeviewService.getPlainConfigData.calls.count()).toBe(3);
  }));

  it('should switch view mode', () => {
    component.onViewModeChange('tree');
    expect(component.viewMode()).toBe('tree');
  });

  it('should provide view mode items with correct values and icons', () => {
    const items = component.viewModeItems();
    expect(items.length).toBe(2);
    expect(items[0].value).toBe('table');
    expect(items[0].icon).toBe('bi-table');
    expect(items[1].value).toBe('tree');
    expect(items[1].icon).toBe('bi-diagram-3');
  });

  it('should clear filter and reset filteredTableRows', () => {
    setDefaultTreeviewElement();
    component.ngOnInit();

    component.currentFilter.set('something');
    component.clearFilter();

    expect(component.currentFilter()).toBe('');
    expect(component.filteredTableRows().length).toBe(
      component.tableRows().length
    );
  });

  it('should use planningSelflink when isPlanningSelfLinkData is true', () => {
    const fixture = TestBed.createComponent(ThreegppComponent);
    component = fixture.componentInstance;

    component.treeviewElement = {
      name: 'Node-1',
      aaiType: NodeType.SERVICE_INSTANCE,
      model: {
        selflink: '/aai/v22/network/service/123',
        planningSelflink: '/aai/v22/network/service/123/planning',
      },
    } as any;

    fixture.componentRef.setInput('isPlanningSelfLinkData', true);
    component.ngOnInit();

    expect(customTreeviewService.getPlainConfigData).toHaveBeenCalledWith(
      '/aai/v22/network/service/123/planning'
    );
  });

  it('should use selflink when isPlanningSelfLinkData is false', () => {
    const fixture = TestBed.createComponent(ThreegppComponent);
    component = fixture.componentInstance;

    component.treeviewElement = {
      name: 'Node-1',
      aaiType: NodeType.PNF,
      model: {
        selflink: '/aai/v22/network/pnf/123',
        planningSelflink: '/aai/v22/network/pnf/123/planning',
      },
    } as any;

    fixture.componentRef.setInput('isPlanningSelfLinkData', false);
    component.ngOnInit();

    expect(customTreeviewService.getPlainConfigData).toHaveBeenCalledWith(
      '/aai/v22/network/pnf/123'
    );
  });

  it('should handle missing planningSelflink gracefully', () => {
    component.treeviewElement = {
      name: 'Node-1',
      aaiType: NodeType.CELL,
      model: {
        selflink: '/aai/v22/network/cell/123',
        // planningSelflink is missing
      },
    } as any;

    const fixture = TestBed.createComponent(ThreegppComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('isPlanningSelfLinkData', true);
    component.ngOnInit();

    expect(component.notValidSelflink).toBeTrue();
    expect(customTreeviewService.getPlainConfigData).not.toHaveBeenCalled();
  });

  it('should return correct no data message based on planning flag', () => {
    component.treeviewElement = {
      name: 'Node-1',
      aaiType: NodeType.SERVICE_INSTANCE,
      model: {},
    } as any;

    const fixture = TestBed.createComponent(ThreegppComponent);
    component = fixture.componentInstance;

    // Test planning selflink message
    fixture.componentRef.setInput('isPlanningSelfLinkData', true);
    fixture.detectChanges();
    expect(component.noDataMessage()).toBe('treeview.messages.noPlanningLink');

    // Test regular selflink message
    fixture.componentRef.setInput('isPlanningSelfLinkData', false);
    fixture.detectChanges();
    expect(component.noDataMessage()).toBe('treeview.messages.noSelflink');
  });

  // ///apply////
  it('should apply changes and update config with generated payload', () => {
    const selfLink =
      "/aai/v22/network/pnf/123/planning/node?xpath=/ran-node[@ran-node-id='12']/enodeb[@enodeb-id='90']/cell-lte[@cell-local-id='21']";

    component.treeviewElement = {
      name: 'Node-1',
      model: {
        planningSelflink: selfLink,
      },
    } as any;

    const config = {
      'cell-lte': {
        height: 10,
        azimuth: 69,
        latitude: 50.213818,
        beamwidth: 65,
        'cell-local-id': 21,
      },
    };

    const changes: ApplyChange[] = [
      {
        path: ['cell-lte', 'height'],
        key: 'height',
        oldValue: 10,
        newValue: 67,
      },
    ];

    customTreeviewService.getPlainConfigData.and.returnValue(of(config));
    configDataService.updateCpsConfigData.and.returnValue(of({} as any));

    component.onApplyRequested(changes);

    expect(configDataService.updateCpsConfigData).toHaveBeenCalledWith(
      selfLink,
      'Node-1',
      undefined,
      {
        'ran-planning:cell-lte': {
          height: 67,
          azimuth: 69,
          latitude: 50.213818,
          beamwidth: 65,
          'cell-local-id': 21,
        },
      }
    );
  });
  it('should reload data and show success alert after successful update', () => {
    const changes: ApplyChange[] = [
      {
        path: ['cell-lte', 'height'],
        key: 'height',
        oldValue: 68.9,
        newValue: 67,
      },
    ];

    component.treeviewElement = {
      name: 'Node-1',
      model: {
        planningSelflink:
          "/aai/v22/network/pnf/123/planning/node?xpath=/ran-node[@ran-node-id='12']/enodeb[@enodeb-id='90']/cell-lte[@cell-local-id='21']",
      },
    } as any;

    customTreeviewService.getPlainConfigData.and.returnValue(
      of({ 'cell-lte': { height: 67 } })
    );

    configDataService.updateCpsConfigData.and.returnValue(of({} as any));

    spyOn(component['manualReload$'], 'next');

    component.onApplyRequested(changes);

    expect(component['manualReload$'].next).toHaveBeenCalled();
    expect(alertServiceMock.success).toHaveBeenCalledWith(
      'treeview.messages.updateSuccess',
      { keepAfterRouteChange: true }
    );
  });

  it('should return when changes array is empty', () => {
    component.treeviewElement = {
      model: {
        planningSelflink: '/planning/link',
      },
    } as any;

    component.onApplyRequested([]);

    expect(customTreeviewService.getPlainConfigData).not.toHaveBeenCalled();
    expect(configDataService.updateCpsConfigData).not.toHaveBeenCalled();
  });

  it('should not update when planningSelflink is missing', () => {
    component.treeviewElement = {
      name: 'Node-1',
      model: {},
    } as any;

    component.onApplyRequested([
      {
        key: 'enabled',
        oldValue: false,
        newValue: true,
        path: ['settings', 'enabled'],
      },
    ]);

    expect(customTreeviewService.getPlainConfigData).not.toHaveBeenCalled();
    expect(configDataService.updateCpsConfigData).not.toHaveBeenCalled();
  });

  it('should preserve sibling cells when updating nested cell value', () => {
    const selfLink =
      "/aai/v22/network/pnf/123/planning/node?xpath=/ran-node[@ran-node-id='12']/enodeb[@enodeb-id='90']/cell-lte[@cell-local-id='21']";

    component.treeviewElement = {
      name: 'Node-1',
      model: {
        planningSelflink: selfLink,
      },
    } as any;

    const config = {
      'cell-lte': [
        {
          'cell-local-id': 21,
          height: 10,
          azimuth: 69,
        },
        {
          'cell-local-id': 22,
          height: 30,
          azimuth: 90,
        },
      ],
    };

    const changes: ApplyChange[] = [
      {
        path: ['cell-lte', 0, 'height'],
        key: 'height',
        oldValue: 10,
        newValue: 67,
      },
    ];

    customTreeviewService.getPlainConfigData.and.returnValue(of(config));
    configDataService.updateCpsConfigData.and.returnValue(of({} as any));

    component.onApplyRequested(changes);

    expect(configDataService.updateCpsConfigData).toHaveBeenCalledWith(
      selfLink,
      'Node-1',
      undefined,
      {
        'ran-planning:cell-lte': [
          {
            'cell-local-id': 21,
            height: 67,
            azimuth: 69,
          },
          {
            'cell-local-id': 22,
            height: 30,
            azimuth: 90,
          },
        ],
      }
    );
  });
  it('should keep sibling cells when updating nested cell entry', () => {
    const selfLink =
      "/aai/v22/network/pnf/123/planning/node?xpath=/ran-node[@ran-node-id='12']/enodeb[@enodeb-id='90']/cell-lte[@cell-local-id='21']";

    component.treeviewElement = {
      name: 'Node-1',
      model: {
        planningSelflink: selfLink,
      },
    } as any;

    const config = {
      'cell-lte': [
        {
          'cell-local-id': 21,
          height: 10,
          azimuth: 69,
        },
        {
          'cell-local-id': 22,
          height: 30,
          azimuth: 90,
        },
      ],
    };

    const changes: ApplyChange[] = [
      {
        path: ['cell-lte', 0, 'height'],
        key: 'height',
        oldValue: 10,
        newValue: 67,
      },
    ];

    customTreeviewService.getPlainConfigData.and.returnValue(of(config));
    configDataService.updateCpsConfigData.and.returnValue(of({} as any));

    component.onApplyRequested(changes);

    expect(configDataService.updateCpsConfigData).toHaveBeenCalledWith(
      selfLink,
      'Node-1',
      undefined,
      {
        'ran-planning:cell-lte': [
          {
            'cell-local-id': 21,
            height: 67, // updated
            azimuth: 69,
          },
          {
            'cell-local-id': 22,
            height: 30, // unchanged sibling
            azimuth: 90,
          },
        ],
      }
    );
  });

  it('should switch to table view when there are no unsaved changes', () => {
    treeviewEditServiceSpy.modifiedFields = [];
    treeviewEditServiceSpy.editMode.set(true);

    component.onViewModeChange('table');

    expect(component.viewMode()).toBe('table');
    expect(
      treeviewEditServiceSpy.confirmSwitchToTableView
    ).not.toHaveBeenCalled();
  });
  it('should open confirmation modal when switching with unsaved changes', () => {
    (treeviewEditServiceSpy as any).modifiedFields = [
      {
        node: {} as any,
        key: 'name',
        oldValue: 'old',
        newValue: 'new',
      },
    ];

    treeviewEditServiceSpy.editMode.set(true);

    component.onViewModeChange('table');

    expect(treeviewEditServiceSpy.confirmSwitchToTableView).toHaveBeenCalled();
  });
  it('should switch to table view when user confirms', () => {
    treeviewEditServiceSpy.modifiedFields = [{} as ModifiedFields];

    treeviewEditServiceSpy.editMode.set(true);

    treeviewEditServiceSpy.confirmSwitchToTableView.and.returnValue(of(true));

    component.onViewModeChange('table');

    expect(component.viewMode()).toBe('table');
    expect(treeviewEditServiceSpy.modifiedFields).toEqual([]);
    expect(treeviewEditServiceSpy.editMode()).toBeFalse();
  });
  it('should stay in tree view when user cancels confirmation dialog', () => {
    component.viewMode.set('tree');

    treeviewEditServiceSpy.modifiedFields = [{} as ModifiedFields];

    treeviewEditServiceSpy.editMode.set(true);

    treeviewEditServiceSpy.confirmSwitchToTableView.and.returnValue(of(false));

    component.onViewModeChange('table');

    expect(component.viewMode()).toBe('tree');
  });
});
