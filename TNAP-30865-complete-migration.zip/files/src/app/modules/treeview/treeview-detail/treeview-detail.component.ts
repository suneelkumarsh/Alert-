/*
 * Copyright (c) 2023. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  inject,
  Input,
  OnChanges,
  OnInit,
  Output,
  signal,
  SimpleChanges,
  computed,
} from '@angular/core';
import {
  TreeviewFinalModel,
  TreeViewServiceType,
} from 'src/app/model/treeview.model';
import { NodeType } from 'src/app/model/topology.model';
import { ConfirmationModalComponent } from 'src/app/components/shared/confirmation-modal/confirmation-modal.component';
import {
  exhaustMap,
  filter,
  finalize,
  map,
  switchMap,
  take,
  takeUntil,
} from 'rxjs/operators';
import { ActionType, EntityType } from 'src/app/model/user-last-action.model';
import { EMPTY, Observable } from 'rxjs';
import { UnsubscribeService } from 'src/app/services/unsubscribe/unsubscribe.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { HistoryService } from 'src/app/services/history.service';
import {
  AlarmAggregationSeverity,
  CellRuResponse,
  PnfsService,
  TreeViewSite,
} from 'openapi/output';
import { AuthService, HasPermissionPipe } from '@portal-mfe/auth';
import { ActivatedRoute, Router } from '@angular/router';
import { DictionaryAttributePaneCustomRenderer } from 'src/app/model/dictionary-attribute-panel.model';
import { DictionaryAttributePaneRenderersService } from 'src/app/components/dictionary-attribute-pane/dictionary-attribute-pane-renderers.service';
import { KeyboardNavigationShortcuts } from 'src/app/model/keyboard-shortcuts.model';
import {
  TREEVIEW_AAI_TAB_CONFIG,
  TREEVIEW_CELL_TAB_CONFIG,
  TREEVIEW_PNF_TAB_CONFIG,
  TREEVIEW_SERVICE_INSTANCE_TAB_CONFIG,
  TREEVIEW_SLICES_TAB_CONFIG,
  TREEVIEW_VNF_TAB_CONFIG,
  TREEVIEW_NMS_CONFIG,
} from '../configuration';
import { flatMapObject } from 'src/app/helpers/flat-map-object';
import { TREEVIEW_ICONS } from 'src/app/modules/treeview/configuration';
import { TreeNode } from '@portal-mfe/ng-tree-lib';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { CustomTreeviewService } from 'src/app/services/custom-treeview.service';
import { TopologyNavigationService } from 'src/app/services/topologyNavigation-service/topology-navigation.service';
import { UserSettingsService } from 'src/app/services/user-settings.service';
import { defaultTreeViewSettings } from 'src/app/model/user-preferences.model';
import { visibleDetailSections } from 'src/app/helpers/detail-sections';
import { toSignal } from '@angular/core/rxjs-interop';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

interface KeyValuePair {
  key: string;
  value: unknown;
}

/**
 * "The user has not chosen a tab yet" marker for `activeTab`. Deliberately outside the ids the
 * template uses (0…8): `0` is the Slices tab, so reusing it as the marker made a click on
 * Slices indistinguishable from the untouched state and `setDefaultActiveTab()` overwrote it.
 * No `ngbNavItem` matches -1, so the nav simply shows no active tab until one is picked.
 */
export const NO_TAB_CHOSEN = -1;

/** Tabs rendered by `app-dictionary-attribute-pane` — the only ones the "only filled" switch affects. */
export const TYPE_DETAILS_TAB = 3;
export const AAI_TAB = 4;
export const SLICES_TAB = 0;

const TIMESTAMP_ATTRIBUTE_KEYS = [
  'aaiCreatedTs',
  'aaiUpdatedTs',
  'aaiLastModTs',
  'lastSeenNetwork',
  'lastSeenPlan',
];

const YES_NO_ATTRIBUTE_KEYS = [
  'inMaint',
  'isClosedLoopDisabled',
  'spareEquipmentIndicator',
  'encryptedAccessFlag',
];

@Component({
  selector: 'app-treeview-detail',
  templateUrl: './treeview-detail.component.html',
  styleUrls: ['./treeview-detail.component.css'],
  providers: [HasPermissionPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: false,
})
export class TreeviewDetailComponent implements OnChanges, OnInit {
  private readonly router = inject(Router);
  private readonly hasPermissionPipe = inject(HasPermissionPipe);
  private readonly userSettingsService = inject(UserSettingsService);
  readonly permissions = inject(PERMISSIONS_TOKEN);

  @Input() selectedNode:
    | {
        id: string;
        name: string;
        serviceType: string | null;
        aaiType: string | null;
      }
    | undefined;

  @Input() synchronizedFilter$!: Observable<string>;
  @Input() alarmAggregationData: AlarmAggregationSeverity[] | undefined;
  @Input() keyValuePairsNew: KeyValuePair[] | undefined;
  @Input() objectToDisplay: { [key: string]: unknown } | undefined;
  @Input() properties: (string | string[])[] = [];
  @Input() detailCount = 0;

  @Output() closeDetail = new EventEmitter<void>();

  ServiceType = TreeViewServiceType;
  NodeType = NodeType;
  SELECT_DETAIL_PANE_SHORTCUT =
    KeyboardNavigationShortcuts.SELECT_DETAIL_PANE_SHORTCUT;
  activeTab: number = NO_TAB_CHOSEN;
  protected readonly TYPE_DETAILS_TAB = TYPE_DETAILS_TAB;
  protected readonly AAI_TAB = AAI_TAB;
  protected readonly SLICES_TAB = SLICES_TAB;
  selectedCell: CellRuResponse | undefined;
  private readonly keyValuePairState = signal<KeyValuePair[]>([]);
  readonly keyValuePair = this.keyValuePairState.asReadonly();
  isLoadingNodeDetails = true;
  node = signal<TreeNode<TreeviewFinalModel> | null>(null);
  TREEVIEW_AAI_TAB_CONFIG = TREEVIEW_AAI_TAB_CONFIG;

  private readonly hasPlanTabPermission = toSignal(
    this.hasPermissionPipe.transform(this.permissions.VIEW_RAT_VIEW),
    { initialValue: false }
  );

  readonly onlyFilled = toSignal(
    this.userSettingsService
      .getPreferences$()
      .pipe(map(preferences => preferences.treeViewSettings.onlyFilled)),
    { initialValue: defaultTreeViewSettings.onlyFilled }
  );

  readonly showAllProperties = computed(() => !this.onlyFilled());

  readonly typeDetailSections = computed(() => {
    const aaiType = this.node()?.metadata?.aaiType;
    return visibleDetailSections(
      aaiType ? (this.globalConfig[aaiType] ?? []) : [],
      this.keyValuePair(),
      this.onlyFilled()
    );
  });

  readonly aaiSections = computed(() =>
    visibleDetailSections(
      TREEVIEW_AAI_TAB_CONFIG,
      this.keyValuePair(),
      this.onlyFilled()
    )
  );
  // Computed signals for reactive template logic
  isServiceTypeRU = computed(
    () =>
      this.node()?.metadata?.serviceType?.toUpperCase() === this.ServiceType.RU
  );

  readonly showPlanTab = computed(
    () =>
      this.hasPlanTabPermission() &&
      (this.node()?.metadata?.aaiType === NodeType.SERVICE_INSTANCE ||
        this.node()?.metadata?.aaiType === NodeType.PNF ||
        this.node()?.metadata?.aaiType === NodeType.CELL ||
        this.node()?.metadata?.aaiType === NodeType.GENERIC_VNF)
  );

  globalConfig = {
    pnf: TREEVIEW_PNF_TAB_CONFIG,
    'generic-vnf': TREEVIEW_VNF_TAB_CONFIG,
    cell: TREEVIEW_CELL_TAB_CONFIG,
    'service-instance': TREEVIEW_SERVICE_INSTANCE_TAB_CONFIG,
    slices: TREEVIEW_SLICES_TAB_CONFIG,
    'network-management-system': TREEVIEW_NMS_CONFIG,
  };

  detailPropertiesCustomRenderers: DictionaryAttributePaneCustomRenderer[] = [
    ...TIMESTAMP_ATTRIBUTE_KEYS.map(key => ({
      key,
      renderer: this.renderers.timestampToDateStringRenderer,
    })),
    ...YES_NO_ATTRIBUTE_KEYS.map(key => ({
      key,
      renderer: this.renderers.yesNoRenderer,
    })),
  ];

  public TREEVIEW_ICONS = TREEVIEW_ICONS;

  public loggedUserId$ = this.authService.getLoggedUserId();

  constructor(
    private readonly renderers: DictionaryAttributePaneRenderersService,
    private readonly route: ActivatedRoute,
    private readonly authService: AuthService,
    private readonly unsubscribeService: UnsubscribeService,
    private readonly modalService: NgbModal,
    private readonly translateService: TranslateService,
    private readonly historyService: HistoryService,
    private readonly alertService: TnapAlertService,
    private readonly pnfsService: PnfsService,
    private readonly customTreeviewService: CustomTreeviewService,
    private readonly topologyNavService: TopologyNavigationService
  ) {}

  changeOnlyFilled(onlyFilled: boolean): void {
    this.userSettingsService
      .updatePreferences({ treeViewSettings: { onlyFilled: onlyFilled } })
      .pipe(take(1))
      .subscribe();
  }

  close() {
    this.closeDetail.emit();
  }

  public openModalRebootCell(cell: TreeNode<TreeviewFinalModel>): void {
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalRef.componentInstance.okText = this.translateService.instant(
      'topology.labels.cell.reboot'
    );
    modalRef.componentInstance.title = this.translateService.instant(
      'topology.labels.cell.modal.reboot.title'
    );
    modalRef.componentInstance.text = this.translateService.instant(
      'topology.labels.cell.modal.reboot.text',
      {
        cellName: cell.label,
      }
    );

    modalRef.closed
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap((confirm: boolean) => {
          if (confirm) {
            this.loggedUserId$
              .pipe(
                take(1),
                filter((userName): userName is string => !!userName),
                exhaustMap(userName => {
                  return this.pnfsService
                    .rebootPnf(cell.label, {
                      jobName: `reboot_${Date.now()}`,
                      userName,
                    })
                    .pipe(
                      switchMap(() =>
                        this.historyService.createRuRebootHistoryAction({
                          type: ActionType.REBOOT,
                          entity: EntityType.PNF,
                          entityParams: { pnfName: cell.label, userName },
                        })
                      )
                    );
                }),
                take(1)
              )
              .subscribe(
                () =>
                  this.alertService.success(
                    this.translateService.instant(
                      'topology.labels.cell.modal.reboot.messages.success',
                      {
                        cellName: cell.label,
                      }
                    ),
                    { keepAfterRouteChange: true }
                  ),
                () => {
                  this.alertService.error(
                    this.translateService.instant(
                      'topology.labels.cell.modal.reboot.messages.error',
                      {
                        cellName: cell.label,
                      }
                    ),
                    { keepAfterRouteChange: true }
                  );
                }
              );
          }
          return EMPTY;
        })
      )
      .subscribe();
  }

  get sitesArray(): TreeViewSite[] {
    const sites = this.node()?.metadata?.sites;
    return Array.isArray(sites) ? sites : [];
  }

  onCellSelect(cell: CellRuResponse | undefined) {
    this.selectedCell = cell;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (!changes.selectedNode) {
      return;
    }

    // A different node means the previous tab choice no longer applies, so hand the
    // "untouched" marker back to setDefaultActiveTab() — otherwise it would treat the
    // old node's tab as a deliberate choice and never apply the default again.
    this.activeTab = NO_TAB_CHOSEN;
    this.fetchNodeDetails();
  }

  //if redirected from ru management
  ngOnInit(): void {
    if (this.route.snapshot.queryParams['type'] === 'RU') {
      this.activeTab = 5;
    }
  }

  private flatMapService() {
    //remove children from a final detail, because otherwise it renders children properties as well
    const currentNode = this.node();
    if (!currentNode) {
      return [];
    }

    const nodeToFlatten = { ...currentNode, children: [] };
    return flatMapObject(nodeToFlatten);
  }

  private fetchNodeDetails(): void {
    if (!this.selectedNode?.id || !this.selectedNode?.serviceType) {
      return;
    }
    const nodeType = this.mapServiceTypeToNodeType(
      this.selectedNode.serviceType
    );
    if (!nodeType) {
      return;
    }

    this.isLoadingNodeDetails = true;
    this.customTreeviewService
      .getInstancePropertiesById(this.selectedNode.id, nodeType)
      .pipe(
        map(item => this.createNodeData(item)),
        takeUntil(this.unsubscribeService.unsubscribe$),
        finalize(() => (this.isLoadingNodeDetails = false))
      )
      .subscribe({
        next: () => this.handleFetchSuccess(),
        error: () => this.handleFetchError(),
      });
  }

  private mapServiceTypeToNodeType(serviceType: string): NodeType | null {
    const serviceTypeMap: Record<string, NodeType> = {
      'service-instance': NodeType.SERVICE_INSTANCE,
      'generic-vnf': NodeType.GENERIC_VNF,
      pnf: NodeType.PNF,
      cell: NodeType.CELL,
      bbu: NodeType.SERVICE_INSTANCE,
      gNodeB: NodeType.GENERIC_VNF,
      eNodeB: NodeType.GENERIC_VNF,
      'RAN Node': NodeType.SERVICE_INSTANCE,
      BTS: NodeType.GENERIC_VNF,
      'network-management-system': NodeType.NMS,
    };

    const nodeType = serviceTypeMap[serviceType];
    if (!nodeType) {
      this.alertService.warn(`Unsupported service type: ${serviceType}`);
      return null;
    }
    return nodeType;
  }

  private createNodeData(item: any): any {
    const nodeData: TreeNode<TreeviewFinalModel> = {
      id: this.selectedNode?.id || '',
      label: this.selectedNode?.name || '',
      children: [],
      metadata: {
        id: this.selectedNode?.id || '',
        name: this.selectedNode?.name || '',
        model: item || {},
        type: this.selectedNode?.serviceType?.toUpperCase() as TreeViewServiceType,
        aaiType: this.selectedNode?.aaiType
          ? (this.selectedNode.aaiType as NodeType)
          : undefined,
        sites: item?.sites || [],
        serviceType:
          this.selectedNode?.serviceType?.toUpperCase() as TreeViewServiceType,
        hasSlice: item?.hasSlice || false,
      },
    };

    this.node.set(nodeData);
    return item;
  }

  private handleFetchSuccess(): void {
    this.keyValuePairState.set(this.flatMapService() ?? []);
    this.setDefaultActiveTab();
  }

  private setDefaultActiveTab(): void {
    // Only pick the default while the user has not chosen a tab themselves. `activeId` is
    // two-way bound, so a click writes `activeTab` immediately — whereas this runs when the
    // node-detail response resolves, which can be later. Overwriting unconditionally
    // yanked the user back to tab 3 after they had already opened another tab, destroying
    // the tab body they were interacting with.
    if (this.activeTab === NO_TAB_CHOSEN) {
      this.activeTab = 3;
    }
  }

  private handleFetchError(): void {
    this.alertService.error(
      this.translateService.instant('treeview.details.fetchPropertiesError'),
      { keepAfterRouteChange: true }
    );
  }

  showTopologyView(
    item:
      | TreeNode<TreeviewFinalModel>
      | null
      | (() => TreeNode<TreeviewFinalModel>)
  ): void {
    if (!item) return;
    if (typeof item === 'function') {
      item = item();
    }

    if (!item) return;
    this.topologyNavService.navigateToTopology(item);
  }
}
