/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
  NO_TAB_CHOSEN,
  TreeviewDetailComponent,
} from './treeview-detail.component';
import { DictionaryAttributePaneRenderersService } from 'src/app/components/dictionary-attribute-pane/dictionary-attribute-pane-renderers.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService, HasPermissionPipe } from '@portal-mfe/auth';
import { UnsubscribeService } from 'src/app/services/unsubscribe/unsubscribe.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {
  TranslateService,
  TranslateModule,
  LangChangeEvent,
  TranslationChangeEvent,
  DefaultLangChangeEvent,
} from '@ngx-translate/core';
import { HistoryService } from 'src/app/services/history.service';
import { PnfsService } from 'openapi/output';
import { of, BehaviorSubject, Subject } from 'rxjs';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { RouterTestingModule } from '@angular/router/testing';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared.module';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { CustomTreeviewService } from 'src/app/services/custom-treeview.service';
import { NodeType } from 'src/app/model/topology.model';
import { QueryParamService } from 'src/app/services/query-param.service';
import { DatePipe } from '@angular/common';
import {
  TreeviewFinalModel,
  TreeViewServiceType,
} from 'src/app/model/treeview.model';
import { TreeNode } from '@portal-mfe/ng-tree-lib';
import {
  TREEVIEW_CELL_TAB_CONFIG,
  TREEVIEW_PNF_TAB_CONFIG,
} from '../configuration';
import { UserSettingsService } from 'src/app/services/user-settings.service';
import {
  defaultUserSettings,
  UserPreferencesModel,
} from 'src/app/model/user-preferences.model';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('TreeviewDetailComponent', () => {
  let component: TreeviewDetailComponent;
  let fixture: ComponentFixture<TreeviewDetailComponent>;

  const mockDictionaryAttributePaneRenderersService = {
    timestampToDateStringRenderer: () => 'mockDate',
    yesNoRenderer: () => 'mockYesNo',
  };
  const mockRouter = { navigate: jasmine.createSpy('navigate') };
  const mockActivatedRoute = { snapshot: { queryParams: {} } };
  const mockAuthService = {
    getLoggedUserId: () => of('testUser'),
    getUserPermissions: () => of([]),
  };
  const mockUnsubscribeService = {
    unsubscribe$: new Subject<void>(),
  };
  const mockNgbModal = {
    open: jasmine
      .createSpy('open')
      .and.returnValue({ closed: of(true), componentInstance: {} }),
  };
  const mockTranslateService = {
    instant: (key: string) => key,
    get: (key: string) => of(key),
    getDefaultLang: () => 'en',
    setTranslation: jasmine.createSpy('setTranslation'),
    onLangChange: new Subject<LangChangeEvent>(),
    onTranslationChange: new Subject<TranslationChangeEvent>(),
    onDefaultLangChange: new Subject<DefaultLangChangeEvent>(),
  };
  const mockHistoryService = {
    createRuRebootHistoryAction: jasmine
      .createSpy('createRuRebootHistoryAction')
      .and.returnValue(of(null)),
  };
  const mockAlertService = {
    success: jasmine.createSpy('success'),
    error: jasmine.createSpy('error'),
  };
  const mockPnfsService = {
    rebootPnf: jasmine.createSpy('rebootPnf').and.returnValue(of({})),
  };
  const mockCustomTreeviewService = {
    getInstancePropertiesById: jasmine
      .createSpy('getInstancePropertiesById')
      .and.returnValue(
        of({
          serviceType: 'pnf',
          type: 'PNF',
          sites: [],
          hasSlice: false,
        })
      ),
  };

  const mockQueryParamService = {
    getValueOf: jasmine.createSpy('getValueOf').and.returnValue(of(null)),
    setValueOf: jasmine.createSpy('setValueOf'),
  };

  const hasPermissionPipeMock = jasmine.createSpyObj('HasPermissionPipe', [
    'transform',
  ]);

  hasPermissionPipeMock.transform.and.returnValue(of(true));

  let preferences$: BehaviorSubject<UserPreferencesModel>;
  const mockUserSettingsService = {
    getPreferences$: () => preferences$.asObservable(),
    updatePreferences: jasmine
      .createSpy('updatePreferences')
      .and.returnValue(of({})),
  };

  beforeEach(async () => {
    mockRouter.navigate.calls.reset();
    preferences$ = new BehaviorSubject<UserPreferencesModel>(
      defaultUserSettings
    );
    mockUserSettingsService.updatePreferences.calls.reset();

    await TestBed.configureTestingModule({
      imports: [
        CommonModule,
        SharedModule,
        RouterTestingModule,
        TranslateModule.forRoot(),
        HttpClientTestingModule,
      ],
      declarations: [TreeviewDetailComponent],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [
        {
          provide: DictionaryAttributePaneRenderersService,
          useValue: mockDictionaryAttributePaneRenderersService,
        },
        { provide: Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: AuthService, useValue: mockAuthService },
        { provide: UnsubscribeService, useValue: mockUnsubscribeService },
        { provide: NgbModal, useValue: mockNgbModal },
        { provide: TranslateService, useValue: mockTranslateService },
        { provide: HistoryService, useValue: mockHistoryService },
        { provide: TnapAlertService, useValue: mockAlertService },
        { provide: PnfsService, useValue: mockPnfsService },
        { provide: CustomTreeviewService, useValue: mockCustomTreeviewService },
        { provide: QueryParamService, useValue: mockQueryParamService },
        { provide: DatePipe, useValue: { transform: () => 'mocked-date' } },
        {
          provide: PERMISSIONS_TOKEN,
          useValue: {
            VIEW_RAT_VIEW: ['VIEW_RAT_VIEW'],
            VIEW_TREEVIEW_AAI: ['VIEW_TREEVIEW_AAI'],
            VIEW_SLICE_LIST: ['VIEW_SLICE_LIST'],
          },
        },
        { provide: HasPermissionPipe, useValue: hasPermissionPipeMock },
        { provide: UserSettingsService, useValue: mockUserSettingsService },
      ],
    }).compileComponents();

    TestBed.overrideComponent(TreeviewDetailComponent, {
      set: {
        providers: [
          {
            provide: HasPermissionPipe,
            useValue: hasPermissionPipeMock,
          },
        ],
      },
    });

    fixture = TestBed.createComponent(TreeviewDetailComponent);
    component = fixture.componentInstance;
    component.selectedNode = {
      id: 'test-id',
      name: 'Test Node',
      serviceType: 'pnf',
      aaiType: NodeType.PNF,
    };
    // Set initial node signal value
    component.node.set({
      id: 'test-id',
      label: 'Test Node',
      children: [],
      metadata: {
        id: 'test-id',
        name: 'Test Node',
        aaiType: NodeType.PNF,
        serviceType: 'RU',
        model: {
          serviceInstanceId: 'test-service-instance-id',
        },
        sites: [],
        hasSlice: false,
      },
    });
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should configure source recency fields for PNF and cell details', () => {
    const pnfSourceRecency = TREEVIEW_PNF_TAB_CONFIG.find(
      section => section.name === 'sourceRecency'
    );
    const cellSourceRecency = TREEVIEW_CELL_TAB_CONFIG.find(
      section => section.name === 'sourceRecency'
    );

    expect(pnfSourceRecency?.properties).toEqual([
      'perspective',
      'lastSeenNetwork',
      'lastSeenPlan',
    ]);
    expect(cellSourceRecency?.properties).toEqual(pnfSourceRecency?.properties);
  });

  it('should configure cell spatial fields and cellMoId in the cell details', () => {
    const spatialSection = TREEVIEW_CELL_TAB_CONFIG.find(
      section => section.name === 'spatial'
    );
    const idsSection = TREEVIEW_CELL_TAB_CONFIG.find(
      section => section.name === 'IDs'
    );

    expect(spatialSection?.properties).toEqual([
      'latitude',
      'longitude',
      'azimuth',
      'beamwidth',
      'height',
    ]);
    expect(idsSection?.properties).toContain('cellMoId');
  });

  it('should render source recency timestamps with the date renderer', () => {
    const rendererByKey = new Map(
      component.detailPropertiesCustomRenderers.map(renderer => [
        renderer.key,
        renderer.renderer,
      ])
    );

    expect(rendererByKey.get('lastSeenNetwork')).toBe(
      mockDictionaryAttributePaneRenderersService.timestampToDateStringRenderer
    );
    expect(rendererByKey.get('lastSeenPlan')).toBe(
      mockDictionaryAttributePaneRenderersService.timestampToDateStringRenderer
    );
  });

  describe('ngOnChanges', () => {
    it('should call fetchNodeDetails when selectedNode changes', () => {
      const fetchSpy = spyOn(component, 'fetchNodeDetails' as any);

      component.ngOnChanges({
        selectedNode: {
          currentValue: {
            id: 'test-id',
            name: 'Test Node',
            serviceType: 'pnf',
            aaiType: NodeType.PNF,
          },
          previousValue: null,
          firstChange: true,
          isFirstChange: () => true,
        },
      });

      expect(fetchSpy).toHaveBeenCalled();
    });

    it('should not process changes if selectedNode is not changed', () => {
      const fetchSpy = spyOn(component, 'fetchNodeDetails' as any);

      component.ngOnChanges({
        otherProperty: {
          currentValue: 'value',
          previousValue: null,
          firstChange: true,
          isFirstChange: () => true,
        },
      });

      expect(fetchSpy).not.toHaveBeenCalled();
    });
  });

  describe('fetchNodeDetails', () => {
    beforeEach(() => {
      // Reset spy calls before each test
      mockCustomTreeviewService.getInstancePropertiesById.calls.reset();
      // Ensure unsubscribe$ doesn't complete during tests
      mockUnsubscribeService.unsubscribe$ = new Subject<void>();
    });

    it('should set activeTab to 0 for SERVICE_INSTANCE after API call', () => {
      component.selectedNode = {
        id: 'test-id',
        name: 'Test Service Instance',
        serviceType: 'service-instance',
        aaiType: NodeType.SERVICE_INSTANCE,
      };

      // Mock the service to return simple data
      const mockData = {
        sites: [],
        hasSlice: false,
      };
      mockCustomTreeviewService.getInstancePropertiesById.and.returnValue(
        of(mockData)
      );

      // Mock flatMapService to avoid issues
      spyOn(component as any, 'flatMapService').and.returnValue([]);

      // Set initial state
      component.activeTab = 3;
      component.isLoadingNodeDetails = false;

      // Execute the method
      (component as any).fetchNodeDetails();

      // Check results - since we're using observables, the subscription should complete synchronously with 'of'
      expect(component.node()).toBeTruthy();
      expect(component.node()?.metadata?.aaiType).toBe(
        NodeType.SERVICE_INSTANCE
      );
      expect(component.activeTab).toBe(3);
    });

    it('should set activeTab to 3 for PNF after API call', () => {
      component.selectedNode = {
        id: 'test-id',
        name: 'Test PNF',
        serviceType: 'pnf',
        aaiType: NodeType.PNF,
      };

      // Mock the service to return simple data
      const mockData = {
        sites: [],
        hasSlice: false,
      };
      mockCustomTreeviewService.getInstancePropertiesById.and.returnValue(
        of(mockData)
      );

      // Mock flatMapService to avoid issues
      spyOn(component as any, 'flatMapService').and.returnValue([]);

      // Set initial state
      component.activeTab = 3;
      component.isLoadingNodeDetails = false;

      // Execute the method
      (component as any).fetchNodeDetails();

      // Check results
      expect(component.node()).toBeTruthy();
      expect(component.node()?.metadata?.aaiType).toBe(NodeType.PNF);
      expect(component.activeTab).toBe(3);
    });

    it('should set activeTab to 2 for GENERIC_VNF after API call', () => {
      component.selectedNode = {
        id: 'test-id',
        name: 'Test VNF',
        serviceType: 'generic-vnf',
        aaiType: NodeType.GENERIC_VNF,
      };

      // Mock the service to return simple data
      const mockData = {
        sites: [],
        hasSlice: false,
      };
      mockCustomTreeviewService.getInstancePropertiesById.and.returnValue(
        of(mockData)
      );

      // Mock flatMapService to avoid issues
      spyOn(component as any, 'flatMapService').and.returnValue([]);

      // Set initial state
      component.activeTab = 3;
      component.isLoadingNodeDetails = false;

      // Execute the method
      (component as any).fetchNodeDetails();

      // Check results
      expect(component.node()).toBeTruthy();
      expect(component.node()?.metadata?.aaiType).toBe(NodeType.GENERIC_VNF);
      expect(component.activeTab).toBe(3);
    });

    it('should apply the default tab when the user has not picked one', () => {
      component.selectedNode = {
        id: 'test-id',
        name: 'Test PNF',
        serviceType: 'pnf',
        aaiType: NodeType.PNF,
      };
      mockCustomTreeviewService.getInstancePropertiesById.and.returnValue(
        of({ sites: [], hasSlice: false })
      );
      spyOn(component as any, 'flatMapService').and.returnValue([]);

      component.activeTab = NO_TAB_CHOSEN;

      (component as any).fetchNodeDetails();

      expect(component.activeTab).toBe(3);
    });

    it('should keep a tab the user opened before the details resolved', () => {
      component.selectedNode = {
        id: 'test-id',
        name: 'Test PNF',
        serviceType: 'pnf',
        aaiType: NodeType.PNF,
      };
      mockCustomTreeviewService.getInstancePropertiesById.and.returnValue(
        of({ sites: [], hasSlice: false })
      );
      spyOn(component as any, 'flatMapService').and.returnValue([]);

      // The Configurations tab, opened while the request was still in flight. Resetting it
      // to 3 here destroys the tab body mid-interaction.
      component.activeTab = 2;

      (component as any).fetchNodeDetails();

      expect(component.activeTab).toBe(2);
    });

    it('should keep the Slices tab, whose id is the falsy 0', () => {
      component.selectedNode = {
        id: 'test-id',
        name: 'Test PNF',
        serviceType: 'pnf',
        aaiType: NodeType.PNF,
      };
      mockCustomTreeviewService.getInstancePropertiesById.and.returnValue(
        of({ sites: [], hasSlice: false })
      );
      spyOn(component as any, 'flatMapService').and.returnValue([]);

      // Regression guard: 0 is a real ngbNavItem id (Slices, shown for PNF and
      // SERVICE_INSTANCE), so it must not double as the "no tab chosen" marker.
      component.activeTab = 0;

      (component as any).fetchNodeDetails();

      expect(component.activeTab).toBe(0);
    });

    it('should re-apply the default tab when a different node is selected', () => {
      mockCustomTreeviewService.getInstancePropertiesById.and.returnValue(
        of({ sites: [], hasSlice: false })
      );
      spyOn(component as any, 'flatMapService').and.returnValue([]);

      component.selectedNode = {
        id: 'other-id',
        name: 'Other PNF',
        serviceType: 'pnf',
        aaiType: NodeType.PNF,
      };
      component.activeTab = 2;

      component.ngOnChanges({
        selectedNode: {
          currentValue: component.selectedNode,
          previousValue: null,
          firstChange: false,
          isFirstChange: () => false,
        },
      });

      expect(component.activeTab).toBe(3);
    });

    it('should handle missing selectedNode gracefully', () => {
      component.selectedNode = undefined;

      // Reset any previous spy calls
      mockCustomTreeviewService.getInstancePropertiesById.calls.reset();

      expect(() => {
        (component as any).fetchNodeDetails();
      }).not.toThrow();

      expect(
        mockCustomTreeviewService.getInstancePropertiesById
      ).not.toHaveBeenCalled();
    });

    it('should set activeTab to 3 for NMS after API call', () => {
      component.selectedNode = {
        id: 'test-id',
        name: 'Test NMS',
        serviceType: 'network-management-system',
        aaiType: NodeType.NMS,
      };

      // Mock the service to return simple data
      const mockData = {
        sites: [],
        hasSlice: false,
      };
      mockCustomTreeviewService.getInstancePropertiesById.and.returnValue(
        of(mockData)
      );

      // Mock flatMapService to avoid issues
      spyOn(component as any, 'flatMapService').and.returnValue([]);

      // Set initial state
      component.activeTab = 3;
      component.isLoadingNodeDetails = false;

      // Execute the method
      (component as any).fetchNodeDetails();

      // Check results
      expect(component.node()).toBeTruthy();
      expect(component.node()?.metadata?.aaiType).toBe(NodeType.NMS);
      expect(component.activeTab).toBe(3);
    });
  });

  describe('ngOnInit', () => {
    it('should set activeTab to 5 when redirected from RU management', () => {
      mockActivatedRoute.snapshot.queryParams = { type: 'RU' };

      component.ngOnInit();

      expect(component.activeTab).toBe(5);
    });

    it('should not change activeTab when not redirected from RU management', () => {
      mockActivatedRoute.snapshot.queryParams = {};
      component.activeTab = NO_TAB_CHOSEN;

      component.ngOnInit();

      expect(component.activeTab).toBe(NO_TAB_CHOSEN);
    });
  });

  describe('close', () => {
    it('should emit closeDetail event', () => {
      spyOn(component.closeDetail, 'emit');

      component.close();

      expect(component.closeDetail.emit).toHaveBeenCalled();
    });
  });

  describe('onCellSelect', () => {
    it('should set selectedCell with provided cell', () => {
      const mockCell = { cellName: 'test-cell' } as any;

      component.onCellSelect(mockCell);

      expect(component.selectedCell).toBe(mockCell);
    });

    it('should set selectedCell to undefined when no cell is provided', () => {
      component.selectedCell = { cellName: 'existing-cell' } as any;

      component.onCellSelect(undefined);

      expect(component.selectedCell).toBeUndefined();
    });
  });

  describe('flatMapService', () => {
    it('should return flattened object without children', () => {
      component.node.set({
        id: 'test-id',
        label: 'Test Node',
        metadata: {
          id: 'test-id',
          name: 'Test Node',
          aaiType: NodeType.PNF,
          model: {
            property1: 'value1',
            property2: 'value2',
          },
        },
        children: [{ label: 'child' } as any],
      });

      const result = (component as any).flatMapService();

      expect(result).toBeDefined();
      expect(Array.isArray(result)).toBe(true);
      // Make sure the result doesn't contain undefined values that could cause "every" errors
      if (Array.isArray(result)) {
        result.forEach(item => {
          expect(item).toBeDefined();
        });
      }
    });

    it('should return empty array when node is null', () => {
      component.node.set(null);

      const result = (component as any).flatMapService();

      expect(result).toEqual([]);
    });

    it('should handle undefined flatMapObject result gracefully', () => {
      // Set a node with minimal structure that might cause flatMapObject issues
      component.node.set({
        id: 'test-id',
        label: 'Test Node',
        metadata: {
          id: 'test-id',
          name: 'Test Node',
        }, // Empty object instead of null to avoid Object.entries error
        children: [],
      });

      const result = (component as any).flatMapService();

      expect(Array.isArray(result)).toBe(true);
    });

    it('should handle null node gracefully in flatMapService', () => {
      component.node.set(null);

      const result = (component as any).flatMapService();

      expect(Array.isArray(result)).toBe(true);
      expect(result).toEqual([]);
    });
  });

  describe('sitesArray', () => {
    it('should return sites array from node metadata', () => {
      const mockSites = [{ name: 'Site1' }, { name: 'Site2' }];
      component.node.set({
        id: 'test-id',
        label: 'Test Node',
        metadata: {
          id: 'test-id',
          name: 'Test Node',
          sites: mockSites,
        },
      });

      const result = component.sitesArray;

      expect(result).toEqual(mockSites);
    });

    it('should return empty array when no sites in node metadata', () => {
      component.node.set({
        id: 'test-id',
        label: 'Test Node',
        metadata: {
          id: 'test-id',
          name: 'Test Node',
        },
      });

      const result = component.sitesArray;

      expect(result).toEqual([]);
    });

    it('should return empty array when node is null', () => {
      component.node.set(null);

      const result = component.sitesArray;

      expect(result).toEqual([]);
    });
  });

  describe('Network (configuration) tab visibility', () => {
    // The tab's label renders as its raw translation key: the mocked TranslateService returns the
    // key it was given, which makes the assertions independent of the de/en wording ("Network").
    const NETWORK_TAB_KEY = 'treeview.detail.tabs.configurations';

    function showNode(
      type: TreeViewServiceType | undefined,
      aaiType: NodeType
    ): void {
      component.node.set({
        id: 'test-id',
        label: 'Test Node',
        children: [],
        metadata: {
          id: 'test-id',
          name: 'Test Node',
          aaiType,
          type,
          serviceType: type,
          model: {},
          sites: [],
          hasSlice: false,
        },
      });
      fixture.detectChanges();
    }

    function tabLabels(): string[] {
      return Array.from(
        fixture.nativeElement.querySelectorAll('a.nav-link') as
          | NodeListOf<HTMLElement>
          | never[]
      ).map(link => (link.textContent ?? '').trim());
    }

    it('shows the tab for a RAN Node service instance', () => {
      // TNAP-32279: a RAN Node carries a populated selflink, so suppressing the tab made its live
      // configuration unreachable. `type` is AAI's serviceType uppercased and says nothing about
      // the self-link, which is why the condition cannot stand in for one.
      showNode(TreeViewServiceType.RAN_NODE, NodeType.SERVICE_INSTANCE);

      expect(tabLabels()).toContain(NETWORK_TAB_KEY);
    });

    it('keeps hiding the tab for the types that have no CPS document', () => {
      for (const type of [
        TreeViewServiceType.GNB,
        TreeViewServiceType.BBU,
        TreeViewServiceType.NMS,
      ]) {
        showNode(type, NodeType.SERVICE_INSTANCE);

        expect(tabLabels()).not.toContain(NETWORK_TAB_KEY);
      }
    });

    it('shows the tab for a PNF', () => {
      showNode(TreeViewServiceType.PNF, NodeType.PNF);

      expect(tabLabels()).toContain(NETWORK_TAB_KEY);
    });
  });

  describe('showTopologyView', () => {
    function createMockNode(aaiType: NodeType): TreeNode<TreeviewFinalModel> {
      return {
        id: '123',
        label: 'TestLabel',
        metadata: {
          aaiType: aaiType,
        } as TreeviewFinalModel,
      };
    }

    it('should navigate to SERVICE_INSTANCE without queryParams', () => {
      const node = createMockNode(NodeType.SERVICE_INSTANCE);
      component.showTopologyView(node);
      expect(mockRouter.navigate).toHaveBeenCalledWith(
        ['/topology', '123'],
        {}
      );
    });

    it('should navigate to GENERIC_VNF with queryParams', () => {
      const node = createMockNode(NodeType.GENERIC_VNF);
      component.showTopologyView(node);
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/topology', '123'], {
        queryParams: { type: NodeType.GENERIC_VNF },
      });
    });

    it('should navigate to PNF using label with queryParams', () => {
      const node = createMockNode(NodeType.PNF);
      component.showTopologyView(node);
      expect(mockRouter.navigate).toHaveBeenCalledWith(
        ['/topology', 'TestLabel'],
        { queryParams: { type: NodeType.PNF } }
      );
    });

    it('should navigate to CELL with queryParams', () => {
      const node = createMockNode(NodeType.CELL);
      component.showTopologyView(node);
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/topology', '123'], {
        queryParams: { type: NodeType.CELL },
      });
    });

    it('should support function input returning node', () => {
      const nodeFn = () => createMockNode(NodeType.SERVICE_INSTANCE);
      component.showTopologyView(nodeFn);
      expect(mockRouter.navigate).toHaveBeenCalledWith(
        ['/topology', '123'],
        {}
      );
    });

    it('should not navigate for unsupported aaiType', () => {
      mockRouter.navigate.calls.reset();
      const node = createMockNode('UNKNOWN' as NodeType);
      component.showTopologyView(node);
      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should not navigate when item is null', () => {
      mockRouter.navigate.calls.reset();
      component.showTopologyView(null);
      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should handle function returning null', () => {
      mockRouter.navigate.calls.reset();
      component.showTopologyView(() => null as any);
      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should exit without navigation when no condition matches', () => {
      mockRouter.navigate.calls.reset();
      const node = {
        id: '123',
        label: 'Test',
        metadata: {
          aaiType: 'INVALID_TYPE',
        },
      } as any;
      component.showTopologyView(node);
      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should work with signal value', () => {
      const node = createMockNode(NodeType.SERVICE_INSTANCE);
      component.node.set(node);
      component.showTopologyView(component.node());
      expect(mockRouter.navigate).toHaveBeenCalled();
    });

    it('should not navigate when metadata is undefined', () => {
      mockRouter.navigate.calls.reset();
      const node = {
        id: '123',
        label: 'Test',
      } as any;
      component.showTopologyView(node);
      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should not navigate when metadata is null', () => {
      mockRouter.navigate.calls.reset();
      const node = {
        id: '123',
        label: 'Test',
        metadata: null,
      } as any;
      component.showTopologyView(node);
      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should not navigate when aaiType is missing', () => {
      mockRouter.navigate.calls.reset();
      const node = {
        id: '123',
        label: 'Test',
        metadata: {},
      } as any;
      component.showTopologyView(node);
      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should not navigate when metadata is undefined', () => {
      mockRouter.navigate.calls.reset();
      const node = {
        id: '123',
        label: 'Test',
      } as any;
      component.showTopologyView(node);
      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should not navigate when metadata is null', () => {
      mockRouter.navigate.calls.reset();
      const node = {
        id: '123',
        label: 'Test',
        metadata: null,
      } as any;
      component.showTopologyView(node);
      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should not navigate when aaiType is missing', () => {
      mockRouter.navigate.calls.reset();
      const node = {
        id: '123',
        label: 'Test',
        metadata: {},
      } as any;
      component.showTopologyView(node);
      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should handle function returning invalid node safely', () => {
      mockRouter.navigate.calls.reset();
      component.showTopologyView(
        () =>
          ({
            id: '123',
            label: 'Test',
            metadata: null,
          }) as any
      );
      expect(mockRouter.navigate).not.toHaveBeenCalled();
    });

    it('should navigate with correct params for PNF label usage', () => {
      const node = {
        id: '123',
        label: 'Label123',
        metadata: { aaiType: NodeType.PNF },
      } as any;
      component.showTopologyView(node);
      expect(mockRouter.navigate).toHaveBeenCalledWith(
        ['/topology', 'Label123'],
        { queryParams: { type: NodeType.PNF } }
      );
    });

    it('should navigate for CELL', () => {
      const node = {
        id: '123',
        label: 'Test',
        metadata: { aaiType: NodeType.CELL },
      } as any;
      component.showTopologyView(node);
      expect(mockRouter.navigate).toHaveBeenCalled();
    });

    it('should call showTopologyView manually', () => {
      spyOn(component, 'showTopologyView');
      const node = {
        id: '123',
        label: 'Test',
        metadata: { aaiType: NodeType.SERVICE_INSTANCE },
      } as any;
      component.showTopologyView(node);
      expect(component.showTopologyView).toHaveBeenCalled();
    });
  });

  // The persisted `onlyFilled` flag must reach the dictionary panes negated.
  describe('only filled preference', () => {
    const emitOnlyFilled = (onlyFilled: boolean) =>
      preferences$.next({
        ...defaultUserSettings,
        treeViewSettings: { onlyFilled: onlyFilled },
      });

    it('should hide empty properties until the user picks otherwise', () => {
      expect(component.onlyFilled()).toBeTrue();
      expect(component.showAllProperties()).toBeFalse();
    });

    it('should show all properties once the switch is off', () => {
      emitOnlyFilled(false);

      expect(component.onlyFilled()).toBeFalse();
      expect(component.showAllProperties()).toBeTrue();
    });

    it('should hide empty properties once the switch is on', () => {
      emitOnlyFilled(true);

      expect(component.onlyFilled()).toBeTrue();
      expect(component.showAllProperties()).toBeFalse();
    });

    it('should persist the switch state', () => {
      component.changeOnlyFilled(true);

      expect(mockUserSettingsService.updatePreferences).toHaveBeenCalledWith({
        treeViewSettings: { onlyFilled: true },
      });
    });

    // A section whose attributes are all missing carries no information under "Only Filled",
    // so it must disappear instead of rendering a heading above an empty pane.
    it('should drop sections without a single value while the switch is on', () => {
      component['keyValuePairState'].set([
        { key: 'pnfName', value: 'pnf-e2e-01' },
      ]);

      emitOnlyFilled(false);
      expect(component.typeDetailSections().map(s => s.name)).toContain(
        'sourceRecency'
      );

      emitOnlyFilled(true);
      expect(component.typeDetailSections().map(s => s.name)).not.toContain(
        'sourceRecency'
      );
      expect(component.typeDetailSections().map(s => s.name)).toContain(
        'general'
      );
    });
  });
});
