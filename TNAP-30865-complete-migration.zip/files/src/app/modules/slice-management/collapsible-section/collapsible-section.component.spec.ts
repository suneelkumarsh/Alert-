/*
 * Copyright (c) 2024. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
} from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { CollapsibleSectionComponent } from './collapsible-section.component';
import { DictionaryAttributePaneComponent } from '../../../components/dictionary-attribute-pane/dictionary-attribute-pane.component';
import { SLICE_MANAGEMENT_DETAILS_TAB_CONFIG } from '../configuration';
import { flatMapObject } from '../../../helpers/flat-map-object';
import { SliceProfile } from '../../../../../openapi/output/model/sliceProfile.model';
import en from '../../../../assets/i18n/en.json';
import de from '../../../../assets/i18n/de.json';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('CollapsibleSectionComponent', () => {
  let component: CollapsibleSectionComponent;
  let fixture: ComponentFixture<CollapsibleSectionComponent>;
  let alertServiceSpy: jasmine.SpyObj<TnapAlertService>;

  beforeEach(async () => {
    alertServiceSpy = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
    ]);

    await TestBed.configureTestingModule({
      declarations: [CollapsibleSectionComponent],
      imports: [CommonModule, TranslateModule.forRoot()],
      providers: [{ provide: TnapAlertService, useValue: alertServiceSpy }],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CollapsibleSectionComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should toggle isExpanded when toggle() is called', () => {
    expect(component.isExpanded).toBe(true);
    component.toggle();
    expect(component.isExpanded).toBe(false);
    component.toggle();
    expect(component.isExpanded).toBe(true);
  });

  // Under "Only Filled" a section without a single value would render as a bare heading above
  // an empty pane, so it has to disappear entirely.
  describe('sections without a value', () => {
    const renderSection = (showAllProperties: boolean) => {
      component.configItem = {
        name: 'sliceCharacteristics',
        collapsable: true,
        properties: ['name', 'status'],
      };
      component.collapsable = true;
      component.keyValuePair = [{ key: 'unrelated', value: 'x' }];
      component.showAllProperties = showAllProperties;
      component.ngOnChanges();
      fixture.detectChanges();
    };

    it('should render the heading while all properties are shown', () => {
      renderSection(true);

      expect(fixture.nativeElement.querySelector('h3')).not.toBeNull();
    });

    it('should render nothing when only filled is on', () => {
      renderSection(false);

      expect(fixture.nativeElement.querySelector('h3')).toBeNull();
      expect(
        fixture.nativeElement.querySelector('app-dictionary-attribute-pane')
      ).toBeNull();
    });

    it('should keep a section that still has one value', () => {
      component.configItem = {
        name: 'sliceCharacteristics',
        collapsable: true,
        properties: ['name', 'status'],
      };
      component.collapsable = true;
      component.keyValuePair = [
        { key: 'name', value: 'slice-0001' },
        { key: 'status', value: null },
      ];
      component.showAllProperties = false;
      component.ngOnChanges();
      fixture.detectChanges();

      expect(fixture.nativeElement.querySelector('h3')).not.toBeNull();
    });
  });

  describe('QA heading class (section_heading_text_*)', () => {
    it('should render the QA class on the heading when collapsable', () => {
      component.configItem = {
        name: 'sliceCharacteristics',
        collapsable: true,
        properties: ['name'],
      };
      component.collapsable = true;
      fixture.detectChanges();

      const heading = fixture.nativeElement.querySelector('h3');
      expect(
        heading?.classList.contains('section_heading_text_sliceCharacteristics')
      ).toBe(true);
    });

    it('should render the QA class on the heading in the static (non-collapsible) branch', () => {
      component.configItem = {
        name: 'identifiers',
        collapsable: false,
        showHeading: true,
        properties: ['profileId'],
      };
      component.collapsable = false;
      fixture.detectChanges();

      const heading = fixture.nativeElement.querySelector('h3');
      expect(
        heading?.classList.contains('section_heading_text_identifiers')
      ).toBe(true);
    });
  });

  describe('copySectionData', () => {
    const translateService = () => TestBed.inject(TranslateService);

    beforeEach(() => {
      component.configItem = {
        name: 'sliceCharacteristics',
        collapsable: true,
        properties: ['name', 'age'],
      };
      component.keyValuePair = [
        { key: 'name', value: 'John' },
        { key: 'age', value: null },
      ];
    });

    it('should show a success alert when the clipboard write succeeds', fakeAsync(() => {
      spyOn(navigator.clipboard, 'writeText').and.resolveTo();

      component.copySectionData();
      tick();

      expect(navigator.clipboard.writeText).toHaveBeenCalled();
      expect(alertServiceSpy.success).toHaveBeenCalledWith(
        translateService().instant('common.copySuccess'),
        { keepAfterRouteChange: true }
      );
      expect(alertServiceSpy.error).not.toHaveBeenCalled();
    }));

    it('should show an error alert when the clipboard write fails', fakeAsync(() => {
      spyOn(navigator.clipboard, 'writeText').and.rejectWith(
        new Error('denied')
      );

      component.copySectionData();
      tick();

      expect(alertServiceSpy.error).toHaveBeenCalledWith(
        translateService().instant('common.copyFailed'),
        { keepAfterRouteChange: true }
      );
      expect(alertServiceSpy.success).not.toHaveBeenCalled();
    }));

    it('should omit properties with no matching value from the copied text', fakeAsync(() => {
      const writeTextSpy = spyOn(
        navigator.clipboard,
        'writeText'
      ).and.resolveTo();

      component.copySectionData();
      tick();

      const copiedText = writeTextSpy.calls.mostRecent().args[0] as string;
      const lines = copiedText.split('\n');
      expect(lines.length).toBe(1);
      expect(lines[0]).toContain('John');
      expect(lines.some(line => line.startsWith('age'))).toBe(false);
    }));
  });

  describe('slicePriority (AAI schema v32)', () => {
    const detailsSection = SLICE_MANAGEMENT_DETAILS_TAB_CONFIG.find(
      section => section.name === 'sliceCharacteristics'
    )!;

    it('should be listed in the details section config', () => {
      expect(detailsSection.properties).toContain('slicePriority');
    });

    // The config name has to match the key flatMapObject produces for the nested
    // sliceProfile; a mismatch makes handleSingleValueProperty drop the field silently.
    it('should surface the value from a flattened slice profile', () => {
      const sliceProfile: SliceProfile = {
        profileId: 'video-test-slice-portal-1',
        slicePriority: 7,
      };
      const keyValuePair = flatMapObject({ sliceProfile });

      const paneFixture = TestBed.createComponent(
        DictionaryAttributePaneComponent
      );
      paneFixture.componentRef.setInput('keyValuePairsNew', keyValuePair);
      paneFixture.componentRef.setInput(
        'properties',
        detailsSection.properties
      );
      paneFixture.componentRef.setInput('mode', 'only');
      paneFixture.componentInstance.ngOnChanges();

      expect(paneFixture.componentInstance.keyValuePairs).toContain([
        'slicePriority',
        7,
      ]);
    });

    it('should have a translated label in every locale', () => {
      expect(en.sliceManagement.detail.properties.slicePriority).toBe(
        'Slice Priority'
      );
      expect(de.sliceManagement.detail.properties.slicePriority).toBe(
        'Slice-Priorität'
      );
    });
  });
});
