/*
 * Copyright (c) 2024. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, inject, Input, OnChanges } from '@angular/core';
import { DictionaryAttributePaneCustomRenderer } from 'src/app/model/dictionary-attribute-panel.model';
import { TranslateService } from '@ngx-translate/core';
import { SliceManagementConfigProperty } from '../configuration';
import { copyToClipboardWithAlert } from 'src/app/helpers/clipboard.helper';
import { sectionHasValues } from 'src/app/helpers/detail-sections';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

interface KeyValuePair {
  key: string;
  value: unknown;
}

@Component({
  selector: 'app-collapsible-section',
  templateUrl: './collapsible-section.component.html',
  styleUrl: './collapsible-section.component.css',
  standalone: false,
})
export class CollapsibleSectionComponent implements OnChanges {
  @Input() configItem!: {
    name: string;
    collapsable: boolean;
    properties: SliceManagementConfigProperty[];
    showHeading?: boolean;
  };
  @Input() keyValuePair: KeyValuePair[] | undefined;
  @Input() collapsable = false;
  @Input() formatedJsonPropertyName = '';
  @Input() showAllProperties = true;
  @Input() customRenderers: DictionaryAttributePaneCustomRenderer[] = [];
  isExpanded = true;
  /** Under "Only Filled" a section without a single value would render as a bare heading. */
  protected visible = true;

  private readonly translateService = inject(TranslateService);
  private readonly alertService = inject(TnapAlertService);

  ngOnChanges(): void {
    this.visible =
      this.showAllProperties ||
      sectionHasValues(this.configItem?.properties ?? [], this.keyValuePair);
  }

  toggle() {
    this.isExpanded = !this.isExpanded;
  }

  copySectionData(): void {
    const flatKeys = (this.configItem.properties ?? []).flatMap(property => {
      if (Array.isArray(property)) {
        return property;
      }
      if (typeof property === 'string') {
        return [property];
      }
      return [property.key];
    });
    const pairs = this.keyValuePair ?? [];

    const lines = flatKeys
      .map(key => {
        const match = pairs.find(pair => pair.key === key);
        if (
          !match ||
          match.value === null ||
          match.value === undefined ||
          match.value === ''
        ) {
          return null;
        }
        const label = this.translateService.instant(
          `sliceManagement.detail.properties.${this.toCamelCase(key)}`
        );
        return `${label}: ${match.value}`;
      })
      .filter((line): line is string => line !== null);

    copyToClipboardWithAlert(
      lines.join('\n'),
      this.alertService,
      this.translateService
    );
  }

  private toCamelCase(value: string): string {
    return value.replace(/([A-Z]{2,})/g, match => {
      return match.charAt(0) + match.slice(1).toLowerCase();
    });
  }
}
