/*
 * Copyright (c) 2024. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { inject, Injectable } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { finalize, switchMap, take, tap } from 'rxjs/operators';
import { EMPTY, Observable } from 'rxjs';
import {
  NetworkSlicesService,
  SliceResponse,
} from '../../../../../openapi/output';
import { LoadingIndicatorService } from '../../../services/loading-indicator.service';
import { ConfirmationModalComponent } from '../../../components/shared/confirmation-modal/confirmation-modal.component';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

export type SliceActionType = 'reinforce' | 'terminate';

interface SliceActionTexts {
  title: string;
  text: string;
  okText: string;
  cancelText: string;
  successMsg: string;
  errorMsg: string;
}

@Injectable({
  providedIn: 'root',
})
export class SliceActionService {
  private readonly modalService = inject(NgbModal);
  private readonly translateService = inject(TranslateService);
  private readonly alertService = inject(TnapAlertService);
  private readonly networkSlicesService = inject(NetworkSlicesService);
  private readonly loadingIndicatorService = inject(LoadingIndicatorService);

  public executeSliceAction(
    action: SliceActionType,
    slice: SliceResponse
  ): Observable<void> {
    const texts = this.getActionTexts(action, slice);
    const modalRef = this.openConfirmationModal(texts);

    return modalRef.closed.pipe(
      take(1),
      switchMap((confirmed: boolean) => {
        if (!confirmed) return EMPTY;

        const apiCall$ = this.getApiCall(action, slice);
        if (!apiCall$) return EMPTY;

        return this.executeApiCall(apiCall$, texts);
      })
    );
  }

  private getActionTexts(
    action: SliceActionType,
    slice: SliceResponse
  ): SliceActionTexts {
    const isReinforce = action === 'reinforce';
    const translationKey = isReinforce ? 'reinforce' : 'terminate';

    return {
      title: this.translateService.instant(
        `sliceManagement.list.dialog.${translationKey}.title`
      ),
      text: this.translateService.instant(
        `sliceManagement.list.dialog.${translationKey}.text`,
        { sliceID: slice.name }
      ),
      okText: this.translateService.instant(
        'sliceManagement.list.dialog.common.ok'
      ),
      cancelText: this.translateService.instant(
        'sliceManagement.list.dialog.common.cancel'
      ),
      successMsg: this.translateService.instant(
        `sliceManagement.list.dialog.${translationKey}.alertSuccessMessage`
      ),
      errorMsg: this.translateService.instant(
        `sliceManagement.list.dialog.${translationKey}.alertFailedMessage`
      ),
    };
  }

  private openConfirmationModal(texts: SliceActionTexts) {
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });

    Object.assign(modalRef.componentInstance, {
      title: texts.title,
      text: texts.text,
      okText: texts.okText,
      cancelText: texts.cancelText,
    });

    return modalRef;
  }

  private getApiCall(
    action: SliceActionType,
    slice: SliceResponse
  ): Observable<any> | undefined {
    const { operationalStatus, id, feasibilityJob } = slice;
    const jobId = feasibilityJob?.feasibilityCheckAndReservationJobId ?? '';

    if (action === 'reinforce') {
      return this.getReinforceApiCall(operationalStatus, id, jobId);
    }

    if (action === 'terminate') {
      return this.getTerminateApiCall(operationalStatus, id, jobId);
    }

    return undefined;
  }

  private getReinforceApiCall(
    operationalStatus: string | undefined,
    id: string,
    jobId: string
  ): Observable<any> | undefined {
    if (operationalStatus === 'ACTIVE') {
      return this.networkSlicesService.reinforceSliceActivation(id, jobId);
    }
    if (operationalStatus === 'TERMINATED') {
      return this.networkSlicesService.reinforceSliceTermination(id, jobId);
    }
    return undefined;
  }

  private getTerminateApiCall(
    operationalStatus: string | undefined,
    id: string,
    jobId: string
  ): Observable<any> | undefined {
    if (operationalStatus === 'ACTIVE') {
      return this.networkSlicesService.terminateSlice(id, jobId);
    }
    return undefined;
  }

  private executeApiCall(
    apiCall$: Observable<any>,
    texts: SliceActionTexts
  ): Observable<void> {
    this.loadingIndicatorService.show();

    return apiCall$.pipe(
      finalize(() => this.loadingIndicatorService.hide()),
      tap({
        next: () => {
          this.alertService.success(texts.successMsg, {
            keepAfterRouteChange: true,
          });
        },
        error: err => {
          console.error('Slice action API error:', err);
          this.alertService.error(texts.errorMsg, {
            keepAfterRouteChange: true,
          });
        },
      })
    );
  }
}
