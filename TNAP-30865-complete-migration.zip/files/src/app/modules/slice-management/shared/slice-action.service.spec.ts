/*
 * Copyright (c) 2024. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { TestBed } from '@angular/core/testing';
import { SliceActionService } from './slice-action.service';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import {
  NetworkSlicesService,
  SliceResponse,
  SliceUpdateResponse,
} from '../../../../../openapi/output';
import { LoadingIndicatorService } from '../../../services/loading-indicator.service';
import { of, throwError } from 'rxjs';
import { HttpResponse } from '@angular/common/http';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('SliceActionService', () => {
  let service: SliceActionService;
  let modalServiceSpy: jasmine.SpyObj<NgbModal>;
  let translateServiceSpy: jasmine.SpyObj<TranslateService>;
  let alertServiceSpy: jasmine.SpyObj<TnapAlertService>;
  let networkSlicesServiceSpy: jasmine.SpyObj<NetworkSlicesService>;
  let loadingIndicatorServiceSpy: jasmine.SpyObj<LoadingIndicatorService>;
  let modalRefSpy: jasmine.SpyObj<NgbModalRef>;

  beforeEach(() => {
    modalServiceSpy = jasmine.createSpyObj('NgbModal', ['open']);
    translateServiceSpy = jasmine.createSpyObj('TranslateService', ['instant']);
    alertServiceSpy = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
    ]);
    networkSlicesServiceSpy = jasmine.createSpyObj('NetworkSlicesService', [
      'reinforceSliceActivation',
      'reinforceSliceTermination',
      'terminateSlice',
    ]);
    loadingIndicatorServiceSpy = jasmine.createSpyObj(
      'LoadingIndicatorService',
      ['show', 'hide']
    );
    modalRefSpy = jasmine.createSpyObj('NgbModalRef', ['close'], {
      componentInstance: {},
      closed: of(true),
    });

    TestBed.configureTestingModule({
      providers: [
        SliceActionService,
        { provide: NgbModal, useValue: modalServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
        { provide: NetworkSlicesService, useValue: networkSlicesServiceSpy },
        {
          provide: LoadingIndicatorService,
          useValue: loadingIndicatorServiceSpy,
        },
      ],
    });

    service = TestBed.inject(SliceActionService);
    translateServiceSpy.instant.and.returnValue('translated text');
    modalServiceSpy.open.and.returnValue(modalRefSpy);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('executeSliceAction', () => {
    const mockSlice: SliceResponse = {
      id: 'slice-123',
      name: 'Test Slice',
      operationalStatus: 'ACTIVE',
      feasibilityJob: {
        feasibilityCheckAndReservationJobId: 'job-456',
      },
    } as SliceResponse;

    it('should open confirmation modal for reinforce action', () => {
      service.executeSliceAction('reinforce', mockSlice);

      expect(modalServiceSpy.open).toHaveBeenCalled();
      expect(translateServiceSpy.instant).toHaveBeenCalledWith(
        'sliceManagement.list.dialog.reinforce.title'
      );
    });

    it('should call API and show success alert on reinforce ACTIVE slice', done => {
      const mockResponse = new HttpResponse<SliceUpdateResponse>({
        status: 200,
        body: {} as SliceUpdateResponse,
      });
      networkSlicesServiceSpy.reinforceSliceActivation.and.returnValue(
        of(mockResponse)
      );

      service.executeSliceAction('reinforce', mockSlice).subscribe({
        next: () => {
          expect(
            networkSlicesServiceSpy.reinforceSliceActivation
          ).toHaveBeenCalledWith('slice-123', 'job-456');
          expect(loadingIndicatorServiceSpy.show).toHaveBeenCalled();
          expect(alertServiceSpy.success).toHaveBeenCalled();
        },
        complete: () => {
          expect(loadingIndicatorServiceSpy.hide).toHaveBeenCalled();
          done();
        },
        error: done.fail,
      });
    });

    it('should call API and show success alert on reinforce TERMINATED slice', done => {
      const terminatedSlice = { ...mockSlice, operationalStatus: 'TERMINATED' };
      const mockResponse = new HttpResponse<SliceUpdateResponse>({
        status: 200,
        body: {} as SliceUpdateResponse,
      });
      networkSlicesServiceSpy.reinforceSliceTermination.and.returnValue(
        of(mockResponse)
      );

      service.executeSliceAction('reinforce', terminatedSlice).subscribe({
        next: () => {
          expect(
            networkSlicesServiceSpy.reinforceSliceTermination
          ).toHaveBeenCalledWith('slice-123', 'job-456');
          expect(alertServiceSpy.success).toHaveBeenCalled();
          done();
        },
        error: done.fail,
      });
    });

    it('should call API and show success alert on terminate ACTIVE slice', done => {
      const mockResponse = new HttpResponse<SliceUpdateResponse>({
        status: 200,
        body: {} as SliceUpdateResponse,
      });
      networkSlicesServiceSpy.terminateSlice.and.returnValue(of(mockResponse));

      service.executeSliceAction('terminate', mockSlice).subscribe({
        next: () => {
          expect(networkSlicesServiceSpy.terminateSlice).toHaveBeenCalledWith(
            'slice-123',
            'job-456'
          );
          expect(alertServiceSpy.success).toHaveBeenCalled();
          done();
        },
        error: done.fail,
      });
    });

    it('should show error alert on API failure', done => {
      networkSlicesServiceSpy.reinforceSliceActivation.and.returnValue(
        throwError(() => new Error('API Error'))
      );

      service.executeSliceAction('reinforce', mockSlice).subscribe({
        next: () => done.fail('Should have errored'),
        complete: () => done.fail('Should have errored'),
        error: () => {
          expect(alertServiceSpy.error).toHaveBeenCalled();
          // finalize runs after error callback, so we need to wait
          setTimeout(() => {
            expect(loadingIndicatorServiceSpy.hide).toHaveBeenCalled();
            done();
          }, 0);
        },
      });
    });

    it('should complete Observable after successful API call', done => {
      const mockResponse = new HttpResponse<SliceUpdateResponse>({
        status: 200,
        body: {} as SliceUpdateResponse,
      });
      networkSlicesServiceSpy.reinforceSliceActivation.and.returnValue(
        of(mockResponse)
      );

      service.executeSliceAction('reinforce', mockSlice).subscribe({
        next: () => {
          // Observable emits void on success
          expect(true).toBe(true);
        },
        complete: () => {
          // Observable should complete
          done();
        },
        error: done.fail,
      });
    });

    it('should not emit if modal is cancelled', done => {
      const cancelledModalRefSpy = jasmine.createSpyObj(
        'NgbModalRef',
        ['close'],
        {
          componentInstance: {},
          closed: of(false),
        }
      );
      modalServiceSpy.open.and.returnValue(cancelledModalRefSpy);

      let emitted = false;
      service.executeSliceAction('reinforce', mockSlice).subscribe({
        next: () => {
          emitted = true;
        },
        complete: () => {
          expect(emitted).toBe(false);
          expect(
            networkSlicesServiceSpy.reinforceSliceActivation
          ).not.toHaveBeenCalled();
          done();
        },
      });
    });
  });
});
