/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/* tslint:disable:no-unused-variable */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
  provideHttpClient,
  withInterceptorsFromDi,
} from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { TranslateModule } from '@ngx-translate/core';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { of, Subject, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { QueryParamService } from 'src/app/services/query-param.service';
import { SliceTemplateListComponent } from './slice-template-list.component';
import { ServiceTemplateService } from '../services/service-template.service';
import { ConfirmationModalComponent } from 'src/app/components/shared/confirmation-modal/confirmation-modal.component';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('SliceTemplateListComponent', () => {
  let component: SliceTemplateListComponent;
  let fixture: ComponentFixture<SliceTemplateListComponent>;
  let serviceTemplateService: jasmine.SpyObj<ServiceTemplateService>;
  let queryParamService: jasmine.SpyObj<QueryParamService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let modalService: jasmine.SpyObj<NgbModal>;
  let router: Router;
  let navigateSpy: jasmine.Spy;

  const mockSliceTemplateData = {
    items: [
      {
        activeUuid: '91e4087efbdf7f518fccf038110df7b6aaacb70d',
        latestUuid: '91e4087efbdf7f518fccf038110df7b6aaacb70d',
        version: '1.0',
        name: 'template1',
      },
      {
        activeUuid: '91e4087efbdf7f518fccf036110df7b6aaacb76d',
        latestUuid: '91e4087efbdf7f518fccf032110df7b6aaacb50d',
        version: '2.0',
        name: 'template2',
      },
    ],
    totalCount: 2,
  };

  const statusSubject = new Subject<string>();

  beforeEach(async () => {
    const serviceSpy = jasmine.createSpyObj('ServiceTemplateService', [
      'getServiceTemplateData',
      'deleteServiceTemplate',
    ]);
    const querySpy = jasmine.createSpyObj('QueryParamService', [
      'getValueOf',
      'updateQueryParam',
    ]);
    const alertSpy = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
    ]);
    const modalSpy = jasmine.createSpyObj('NgbModal', ['open']);

    await TestBed.configureTestingModule({
      declarations: [SliceTemplateListComponent],
      imports: [TranslateModule.forRoot(), RouterTestingModule],
      providers: [
        { provide: ServiceTemplateService, useValue: serviceSpy },
        { provide: QueryParamService, useValue: querySpy },
        { provide: TnapAlertService, useValue: alertSpy },
        { provide: NgbModal, useValue: modalSpy },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting(),
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    serviceTemplateService = TestBed.inject(
      ServiceTemplateService
    ) as jasmine.SpyObj<ServiceTemplateService>;
    queryParamService = TestBed.inject(
      QueryParamService
    ) as jasmine.SpyObj<QueryParamService>;
    alertService = TestBed.inject(
      TnapAlertService
    ) as jasmine.SpyObj<TnapAlertService>;
    modalService = TestBed.inject(NgbModal) as jasmine.SpyObj<NgbModal>;

    queryParamService.getValueOf.and.returnValue(statusSubject.asObservable());
    serviceTemplateService.getServiceTemplateData.and.returnValue(
      of(mockSliceTemplateData)
    );

    router = TestBed.inject(Router);
    navigateSpy = spyOn(router, 'navigate').and.returnValue(
      Promise.resolve(true)
    );

    fixture = TestBed.createComponent(SliceTemplateListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    statusSubject.next(undefined as any);
  });

  // -------------------------
  // Component Creation Tests
  // -------------------------
  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should load sliceTemplateData$ on init', done => {
    component.sliceTemplateData$.subscribe(data => {
      expect(data).toEqual(mockSliceTemplateData);
      done();
    });
  });

  it('should NOT call updateQueryParam when filterStatus$ emits (constructor removed)', () => {
    statusSubject.next('active');
    expect(queryParamService.updateQueryParam).not.toHaveBeenCalled();
  });

  it('should call updateQueryParam when user triggers filter change', () => {
    component.onChangeFilter({ status: 'active' });
    expect(queryParamService.updateQueryParam).toHaveBeenCalledWith({
      status: 'active',
    });
  });

  // -------------------------
  // Column Tests
  // -------------------------
  it('should define COLUMNS with correct length', () => {
    expect(component.COLUMNS().length).toBe(5);
    expect(component.COLUMNS().length).toBe(5);
  });

  it('should return correct value for name column', () => {
    const col = component.COLUMNS().find(c => c.key === 'name');
    expect(col?.value({ name: 'abc' } as any)).toBe('abc');
  });

  it('should return version for version column', () => {
    const col = component.COLUMNS().find(c => c.key === 'version');
    expect(col?.value({ version: '3.0' } as any)).toBe('3.0');
  });

  it('should define all expected columns', () => {
    const cols = component.COLUMNS();

    expect(cols.map(col => col.key)).toEqual([
      'name',
      'status',
      'version',
      'activeUuid',
      'actions',
    ]);
  });
  it('should return activeUuid for specificationId column', () => {
    const col = component.COLUMNS().find(c => c.key === 'activeUuid');

    expect(
      col?.value({
        activeUuid: 'uuid-123',
      } as any)
    ).toBe('uuid-123');
  });
  // -------------------------
  // Navigation Tests
  // -------------------------
  it('should navigate to encoded edit page on onEditTemplate()', () => {
    const row = { name: 'my.template.v1' } as any;

    component.onEditTemplate(row);

    expect(navigateSpy).toHaveBeenCalledWith([
      '/slice-management/slice-template/edit',
      'my%2Etemplate%2Ev1',
    ]);
  });

  it('should navigate to create page on onCreateTemplate()', () => {
    component.onCreateTemplate();

    expect(navigateSpy).toHaveBeenCalledWith([
      '/slice-management/slice-template/create',
    ]);
  });

  // -------------------------
  // Delete Tests
  // -------------------------
  it('should open delete confirmation modal', () => {
    modalService.open.and.returnValue({
      closed: of(false),
      componentInstance: {},
    } as any);

    component.onDeleteTemplate({ name: 'temp1' } as any);

    expect(modalService.open).toHaveBeenCalledWith(
      ConfirmationModalComponent,
      jasmine.any(Object)
    );
  });

  it('should call deleteServiceTemplate when confirmed', () => {
    modalService.open.and.returnValue({
      closed: of(true),
      componentInstance: {},
    } as any);

    serviceTemplateService.deleteServiceTemplate.and.returnValue(of({}));

    component.onDeleteTemplate({ name: 'temp1' } as any);

    expect(serviceTemplateService.deleteServiceTemplate).toHaveBeenCalledWith(
      'temp1'
    );
    expect(alertService.success).toHaveBeenCalled();
  });

  it('should show error alert when delete fails', () => {
    modalService.open.and.returnValue({
      closed: of(true),
      componentInstance: {},
    } as any);

    serviceTemplateService.deleteServiceTemplate.and.returnValue(
      // Throw an error instead of emitting an object
      throwError(() => ({
        error: { detail: 'Invalid service YAML' },
      }))
    );

    component.onDeleteTemplate({ name: 'temp1' } as any);

    expect(alertService.error).toHaveBeenCalled();
  });
  // -------------------------
  // Badge Status Tests
  // -------------------------
  describe('getStatusBadgeType', () => {
    it('should return success for active status', () => {
      expect(component.getStatusBadgeType('active')).toBe('success');
    });

    it('should return secondary for creation_inprogress status', () => {
      expect(component.getStatusBadgeType('creation_inprogress')).toBe(
        'secondary'
      );
    });

    it('should return danger for not_active status', () => {
      expect(component.getStatusBadgeType('not_active')).toBe('danger');
    });

    it('should return secondary for unknown status', () => {
      expect(component.getStatusBadgeType('unknown')).toBe('secondary');
    });
  });
});
