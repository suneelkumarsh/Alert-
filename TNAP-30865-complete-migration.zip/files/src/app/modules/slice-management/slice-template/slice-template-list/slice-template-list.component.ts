/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, computed, DestroyRef, inject } from '@angular/core';
import { ServiceTemplateInfo } from '../../../../../../openapi/output';
import { Router } from '@angular/router';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { catchError, switchMap, tap } from 'rxjs/operators';
import { EMPTY } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { ConfirmationModalComponent } from 'src/app/components/shared/confirmation-modal/confirmation-modal.component';
import { ServiceTemplateService } from '../services/service-template.service';
import { environment } from 'src/environments/environment';
import { QueryParamService } from 'src/app/services/query-param.service';
import { ColumnDefinition } from '@portal-mfe/tnap-ui-kit/components/data-table';
import { BadgeType } from '@portal-mfe/tnap-ui-kit/model';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

type SliceTemplateTableItem = ServiceTemplateInfo;
type SliceTemplateStatus =
  | 'Not Active'
  | 'Active'
  | 'Active, creation in progress';

const SliceTemplateStatus = {
  NOTACTIVE: 'not_active' as SliceTemplateStatus,
  ACTIVE: 'active' as SliceTemplateStatus,
  CREATIONINPROGRESS: 'creation_inprogress' as SliceTemplateStatus,
};
type templateStatus = SliceTemplateStatus | 'all';
type StatusKey = 'active' | 'not_active' | 'creation_inprogress';

@Component({
  selector: 'app-slice-template-list',
  templateUrl: './slice-template-list.component.html',
  styleUrls: ['./slice-template-list.component.css'],
  standalone: false,
})
export class SliceTemplateListComponent {
  private readonly serviceTemplateService = inject(ServiceTemplateService);
  private readonly queryParamService = inject(QueryParamService);
  protected readonly templateStatusOptions: templateStatus[] = [
    'all',
    ...Object.values(SliceTemplateStatus),
  ];
  private router = inject(Router);
  private modalService = inject(NgbModal);
  private translateService = inject(TranslateService);
  private destroyRef = inject(DestroyRef);
  private alertService = inject(TnapAlertService);
  private readonly lang = toSignal(this.translateService.onLangChange);
  readonly url = environment.templateGitLabUrl;
  sliceTemplateData$ = this.serviceTemplateService.getServiceTemplateData();
  readonly statusFilter$ = this.queryParamService.getValueOf('status');

  readonly COLUMNS = computed(
    (): ColumnDefinition<SliceTemplateTableItem>[] => {
      this.lang();
      return [
        {
          key: 'name',
          label: this.translateService.instant(
            'sliceManagement.sliceTemplate.list.fields.fileName'
          ),
          value: (row: ServiceTemplateInfo) => row.name,
        },
        {
          key: 'status',
          label: this.translateService.instant(
            'sliceManagement.sliceTemplate.list.fields.status'
          ),
          value: () => '',
        },
        {
          key: 'version',
          label: this.translateService.instant(
            'sliceManagement.sliceTemplate.list.fields.version'
          ),
          value: (row: ServiceTemplateInfo) => row.version,
        },
        {
          key: 'activeUuid',
          label: this.translateService.instant(
            'sliceManagement.sliceTemplate.list.fields.specificationId'
          ),
          value: (row: ServiceTemplateInfo) => row.activeUuid, //specification ID == active UUID
        },
        {
          key: 'actions',
          label: this.translateService.instant(
            'sliceManagement.sliceTemplate.list.fields.action'
          ),
          value: () => '',
        },
      ];
    }
  );

  onEditTemplate(row: SliceTemplateTableItem) {
    const encodedPath = encodeURIComponent(row.name).replace(/\./g, '%2E');
    this.router.navigate([
      '/slice-management/slice-template/edit',
      encodedPath,
    ]);
  }

  onCreateTemplate() {
    this.router.navigate(['/slice-management/slice-template/create']);
  }

  onDeleteTemplate(row: SliceTemplateTableItem) {
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      centered: true,
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalRef.componentInstance.okText = this.translateService.instant(
      'common.buttons.delete'
    );
    modalRef.componentInstance.title = this.translateService.instant(
      'sliceManagement.sliceTemplate.modal.delete.title'
    );
    modalRef.componentInstance.text = this.translateService.instant(
      'sliceManagement.sliceTemplate.modal.delete.text',
      {
        templateName: row.name,
      }
    );

    modalRef.closed
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        switchMap((confirm: boolean) => {
          if (confirm) {
            return this.serviceTemplateService
              .deleteServiceTemplate(row.name)
              .pipe(
                tap(() => {
                  this.alertService.success(
                    this.translateService.instant(
                      'sliceManagement.sliceTemplate.messages.deleteSuccess'
                    ),
                    { keepAfterRouteChange: true }
                  );
                  this.refreshData();
                }),
                catchError(error => {
                  const errorDetail = error?.error?.detail || '';
                  let errorMessage =
                    'sliceManagement.sliceTemplate.messages.deleteError';

                  if (errorDetail.includes('Invalid service YAML')) {
                    if (
                      errorDetail.includes("Missing 'name' or 'unique_uuid'")
                    ) {
                      errorMessage =
                        'sliceManagement.sliceTemplate.messages.deleteErrorInvalidYamlMissingFields';
                    } else {
                      errorMessage =
                        'sliceManagement.sliceTemplate.messages.deleteErrorInvalidYaml';
                    }
                  }

                  this.alertService.error(
                    this.translateService.instant(errorMessage),
                    { keepAfterRouteChange: true }
                  );
                  return EMPTY;
                })
              );
          }
          return EMPTY;
        })
      )
      .subscribe();
  }

  private refreshData() {
    this.sliceTemplateData$ =
      this.serviceTemplateService.getServiceTemplateData();
  }

  public onChangeFilter(param: { [p: string]: any }): void {
    this.queryParamService.updateQueryParam(param);
  }
  public getStatusBadgeType(statusKey: string): BadgeType {
    const badgeMap: Record<StatusKey, BadgeType> = {
      active: 'success',
      creation_inprogress: 'secondary',
      not_active: 'danger',
    };

    return badgeMap[statusKey as StatusKey] ?? 'secondary';
  }
}
