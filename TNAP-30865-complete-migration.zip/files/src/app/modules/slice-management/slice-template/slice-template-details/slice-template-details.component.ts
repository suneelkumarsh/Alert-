/*
 * Copyright (c) 2025. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  AfterViewChecked,
  Component,
  computed,
  DestroyRef,
  ElementRef,
  inject,
  OnInit,
  Signal,
  signal,
  ViewChild,
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AbstractControl, FormArray, FormGroup } from '@angular/forms';
import { filter, map, switchMap, take, tap } from 'rxjs/operators';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import {
  PropertyFormControls,
  TemplateFormBuilderService,
} from '../services/template-form-builder.service';
import { getPredefinedProperties, PROPERTIES_WITH_UI, Type } from '../types';
import { CleanedProperty } from '../services/schema-mapper.service';

import { ServiceTemplate } from '../../../../../../openapi/output';
import {
  isNotNullOrUndefined,
  markAsDirtyAndValidate,
} from '../../../../helpers/helpers';
import { TranslateService } from '@ngx-translate/core';
import { SliceTemplateFormToRequestService } from './services/slice-template-form-to-request.service';
import { PropertyFactoryService } from './services/property-factory.service';
import { environment } from '../../../../../environments/environment';
import { ServiceTemplateService } from '../services/service-template.service';
import { FocusRestoreService } from '@portal-mfe/data-table';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-slice-template-details',
  templateUrl: './slice-template-details.component.html',
  styleUrls: ['./slice-template-details.component.css'],
  standalone: false,
})
export class SliceTemplateDetailsComponent implements OnInit, AfterViewChecked {
  private readonly CUSTOM_PROPERTY_NAME = 'custom_property';
  private setFocus = false;
  protected readonly PROPERTIES_WITH_UI = PROPERTIES_WITH_UI;
  @ViewChild('propertyDetails') detailsRegion!: ElementRef;
  private readonly focusRestore = inject(FocusRestoreService);

  private readonly router = inject(Router);
  private readonly formBuilder = inject(TemplateFormBuilderService);
  private readonly serviceTemplateService = inject(ServiceTemplateService);
  private readonly activatedRoute = inject(ActivatedRoute);
  private readonly destroyRef = inject(DestroyRef);
  private readonly templateFormToRequestService = inject(
    SliceTemplateFormToRequestService
  );
  private readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);
  private readonly propertyFactoryService = inject(PropertyFactoryService);
  private readonly filePath$ = this.activatedRoute.paramMap
    .pipe(map(paramsMap => paramsMap.get('path')))
    .pipe(map(val => (val ? decodeURIComponent(val) : undefined)));
  templateForm: FormGroup = this.formBuilder.createTemplateForm();

  name = this.templateForm.get('name');
  description = this.templateForm.get('description');
  sliceTemplateDeployDelay = environment.sliceTemplateDeployDelay;

  get isActionButtonsDisabled(): boolean {
    if (!this.templateForm.valid) {
      return true;
    }

    // Disable if name contains whitespaces
    if (/\s/.test(this.name?.value || '')) {
      return true;
    }

    return false;
  }

  get hasNameWhitespace(): boolean {
    return /\s/.test(this.name?.value || '');
  }

  originalTemplate: ServiceTemplate | undefined;
  propertySearchTerm = signal('');

  currentDraftVersion: string | undefined;
  isCreateMode = false;

  get searchTerm(): string {
    return this.propertySearchTerm();
  }

  set searchTerm(value: string) {
    this.propertySearchTerm.set(value);
  }

  detail: FormGroup<PropertyFormControls> | undefined;

  private readonly allProperties = toSignal(
    this.serviceTemplateService.getServiceTemplateSchema()
  );

  private readonly usedProperties = toSignal(
    this.templateForm.get('properties')!.valueChanges.pipe(
      map(() => {
        const formArray = this.templateForm.get('properties') as FormArray;
        const usedProperties = formArray.controls.map(control => {
          return control.get('name')?.value as string | undefined;
        });
        return usedProperties.filter(val => val);
      })
    )
  );

  public filteredProperties: Signal<CleanedProperty[]> = computed(() => {
    const properties = getPredefinedProperties(this.allProperties());
    if (!properties) {
      return [];
    }
    const searchTerm = this.propertySearchTerm();
    return properties.filter(
      property =>
        !this.usedProperties()?.includes(property.name) &&
        (!searchTerm ||
          property.name.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  });

  ngOnInit() {
    this.isCreateMode = !this.activatedRoute.snapshot.params['path'];
    this.loadTemplate();
  }

  ngAfterViewChecked() {
    if (this.setFocus) {
      this.setFocus = false;
      this.detailsRegion?.nativeElement.focus();
    }
  }

  private loadTemplate() {
    this.filePath$
      .pipe(
        filter(isNotNullOrUndefined),
        switchMap((fileName: string) => {
          return this.serviceTemplateService.getServiceTemplateForEdit(
            fileName
          );
        }),
        takeUntilDestroyed(this.destroyRef),
        tap(template => {
          this.originalTemplate = template;
          this.formBuilder.populateFormFromTemplate(
            this.templateForm,
            template,
            this.allProperties()
          );
        })
      )
      .subscribe({
        error: () => {
          this.alertService.error(
            this.translateService.instant(
              'sliceManagement.sliceTemplate.messages.loadError'
            ),
            { keepAfterRouteChange: true }
          );
        },
      });
  }

  private editTemplate(template: ServiceTemplate) {
    return this.serviceTemplateService
      .updateServiceTemplate(template)
      .pipe(take(1));
  }

  private createTemplate(template: ServiceTemplate) {
    return this.serviceTemplateService.createServiceTemplate(template);
  }

  onSave() {
    markAsDirtyAndValidate(this.templateForm);
    if (!this.templateForm.valid) {
      return;
    }

    let template: ServiceTemplate;
    try {
      template = this.createTemplateFromForm();
    } catch {
      this.alertService.error(
        this.translateService.instant(
          'sliceManagement.sliceTemplate.messages.invalidJson'
        ),
        { keepAfterRouteChange: true }
      );
      return;
    }

    // this.validateAndSaveTemplate(template);
    this.saveTemplate(template);
  }

  private createTemplateFromForm(): ServiceTemplate {
    const rawValue = this.templateForm.get('properties')?.getRawValue();
    const properties =
      this.templateFormToRequestService.transformFormToRequest(rawValue);

    const template: ServiceTemplate = {
      name: this.templateForm.get('name')!.value,
      description: this.templateForm.get('description')?.value,
      serviceRole: this.templateForm.get('serviceRole')?.value,
      serviceType: this.templateForm.get('serviceType')?.value,
      serviceCategory: this.templateForm.get('serviceCategory')?.value,
      components: this.templateForm.get('components')?.value ?? {},
      properties,
    };

    return template;
  }

  private saveTemplate(template: ServiceTemplate) {
    this.performSaveOperation(template)
      .pipe(take(1))
      .subscribe(() => {
        this.alertService.success(
          this.translateService.instant(
            'sliceManagement.sliceTemplate.messages.deploySuccess'
          ),
          { keepAfterRouteChange: true }
        );
        // we must go to the list view because we should not update the slice template
        // twice with same uniqId. Therefore, we need to reload the list
        this.router.navigate(['/slice-management/slice-template']);
      });
  }

  private handleValidationResponse(response: any) {
    if (response?.status !== 'SUCCESS') {
      const infoMessage = response?.additionalInfo
        ? this.translateService.instant(
            'sliceManagement.sliceTemplate.messages.validationFailed',
            { message: response.additionalInfo }
          )
        : this.translateService.instant(
            'sliceManagement.sliceTemplate.messages.validationError'
          );
      this.alertService.info(infoMessage, {
        keepAfterRouteChange: true,
        autoClose: true,
      });
    }
  }

  private performSaveOperation(template: ServiceTemplate) {
    return this.filePath$.pipe(
      take(1),
      switchMap(templatePath => {
        if (templatePath) {
          const templateData: ServiceTemplate = {
            name: template.name,
            description: template.description,
            serviceCategory: template.serviceCategory,
            serviceRole: template.serviceRole,
            serviceType: template.serviceType,
            components: template.components,
            properties: template.properties,
          };
          return this.editTemplate(templateData);
        } else {
          return this.createTemplate(template);
        }
      }),
      tap(rsp => {
        if (rsp?.name) {
          this.currentDraftVersion = rsp.name;
        }
      })
      // delay(this.sliceTemplateDeployDelay),
      // switchMap(() => this.performDeployOperation())
    );
  }

  onDiscard() {
    this.router.navigate(['/slice-management/slice-template']);
  }

  get properties(): FormArray<FormGroup> {
    return this.templateForm.get('properties') as FormArray<FormGroup>;
  }

  addProperty(property: CleanedProperty) {
    const type = (property.type ?? Type.json) as Type;
    const formGroup = this.propertyFactoryService
      .createProperty(property.name, this.allProperties(), {
        type,
        input: true,
        properties: {},
      })
      .toFormGroup();
    this.properties.push(formGroup);
  }

  addCustomProperty() {
    const propertyGroup = this.propertyFactoryService
      .createProperty(this.CUSTOM_PROPERTY_NAME, this.allProperties(), {
        type: Type.json,
        input: true,
        properties: {},
      })
      .toFormGroup();
    this.properties.push(propertyGroup);
  }

  setDetail(property: AbstractControl<PropertyFormControls>) {
    this.focusRestore.rememberOpener(document.activeElement as HTMLElement);
    this.detail = property as FormGroup;
    this.serviceTemplateService.templateDetailForm$.next(this.detail);
    this.setFocus = true;
  }

  removeProperty(index: number) {
    const formArray = this.templateForm.get('properties') as FormArray;
    formArray.removeAt(index);
  }

  ngOnDestroy() {
    this.serviceTemplateService.templateDetailForm$.next(null);
  }
}
