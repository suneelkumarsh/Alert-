/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { NO_ERRORS_SCHEMA } from '@angular/core';

import { SliceTemplateDetailsComponent } from './slice-template-details.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TranslateModule } from '@ngx-translate/core';
import { ServiceTemplateService } from '../services/service-template.service';
import { of } from 'rxjs';
import { Router } from '@angular/router';
import { PropertyFormControls } from '../services/template-form-builder.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

let component: SliceTemplateDetailsComponent;
let fixture: ComponentFixture<SliceTemplateDetailsComponent>;

beforeEach(() => {
  TestBed.configureTestingModule({
    declarations: [SliceTemplateDetailsComponent],
    imports: [
      RouterTestingModule,
      HttpClientTestingModule,
      TranslateModule.forRoot(),
      FormsModule,
      ReactiveFormsModule,
    ],
    schemas: [NO_ERRORS_SCHEMA],
  }).compileComponents();
});

describe('SliceTemplateDetailsComponent', () => {
  beforeEach(() => {
    fixture = TestBed.createComponent(SliceTemplateDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // isActionButtonsDisabled
  it('should disable action buttons when form invalid', () => {
    spyOnProperty(component.templateForm, 'valid', 'get').and.returnValue(
      false
    );
    expect(component.isActionButtonsDisabled).toBeTrue();
  });

  it('should disable action buttons when name contains whitespace', () => {
    component.name?.setValue('invalid name');
    expect(component.isActionButtonsDisabled).toBeTrue();
  });

  // searchTerm signal
  it('should update searchTerm signal', () => {
    component.searchTerm = 'network';
    expect(component.searchTerm).toBe('network');
  });

  // addProperty
  it('should add a new property form group', () => {
    const formArray = component.properties;
    const initialLength = formArray.length;
    component.addProperty({ name: 'prop1', type: 'json' } as any);
    expect(formArray.length).toBe(initialLength + 1);
  });

  it('should add custom property', () => {
    const initial = component.properties.length;
    component.addCustomProperty();
    expect(component.properties.length).toBe(initial + 1);
  });

  //  removeProperty
  it('should remove property at index', () => {
    component.addCustomProperty();
    component.addCustomProperty();
    expect(component.properties.length).toBe(2);
    component.removeProperty(0);
    expect(component.properties.length).toBe(1);
  });

  // setDetail
  it('should set detail and focus flag', () => {
    const control = new FormGroup({
      name: new FormControl('prop1'),
      type: new FormControl('json'),
      input: new FormControl(true),
      properties: new FormControl({}),
    }) as unknown as FormGroup<PropertyFormControls>;

    component.setDetail(control as any);
    expect(component.detail).toBe(control);
  });

  // saveTemplate CREATE
  it('should call create service on save when createMode', () => {
    (component as any).filePath$ = of(undefined);

    component.isCreateMode = true;

    spyOnProperty(component.templateForm, 'valid', 'get').and.returnValue(true);

    spyOn(component as any, 'createTemplateFromForm').and.returnValue({
      name: 'abc',
      properties: [],
    } as any);

    const service = TestBed.inject(ServiceTemplateService);
    const createSpy = spyOn(service, 'createServiceTemplate').and.returnValue(
      of({ name: 'draft-v1' } as any)
    );

    spyOn(TestBed.inject(TnapAlertService), 'success');
    spyOn(TestBed.inject(Router), 'navigate').and.stub();

    component.onSave();

    expect(createSpy).toHaveBeenCalled();
  });

  //  saveTemplate EDIT
  it('should call update service on save when editing', () => {
    (component as any).filePath$ = of('path/to/template.json');

    spyOnProperty(component.templateForm, 'valid', 'get').and.returnValue(true);

    spyOn(component as any, 'createTemplateFromForm').and.returnValue({
      name: 'myTemplate',
      properties: [],
    } as any);

    const service = TestBed.inject(ServiceTemplateService);
    const updateSpy = spyOn(service, 'updateServiceTemplate').and.returnValue(
      of({ name: 'draft-v2' } as any)
    );

    spyOn(TestBed.inject(TnapAlertService), 'success');
    spyOn(TestBed.inject(Router), 'navigate').and.stub();

    component.onSave();

    expect(updateSpy).toHaveBeenCalled();
  });

  //  error handling
  it('should show error alert when JSON is invalid in createTemplateFromForm', () => {
    spyOnProperty(component.templateForm, 'valid', 'get').and.returnValue(true);

    (component as any).filePath$ = of(undefined);

    spyOn(component as any, 'createTemplateFromForm').and.throwError('invalid');

    const alert = TestBed.inject(TnapAlertService);
    const alertSpy = spyOn(alert, 'error');

    component.onSave();

    expect(alertSpy).toHaveBeenCalledWith(
      'sliceManagement.sliceTemplate.messages.invalidJson',
      { keepAfterRouteChange: true }
    );
  });

  // discard
  it('should navigate on discard', () => {
    const router = TestBed.inject(Router);
    const navSpy = spyOn(router, 'navigate').and.stub();
    component.onDiscard();
    expect(navSpy).toHaveBeenCalledWith(['/slice-management/slice-template']);
  });
});
