/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */
import { SseSlicesListDataService } from '../shared/sse-slices-list-data.service';
import { SliceActionService } from '../shared/slice-action.service';
import { Component, computed, DestroyRef, inject } from '@angular/core';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';

import { VALIDATION_PATTERN } from '../../../model/validation-pattern.model';
import {
  SLICE_MANAGEMENT_DEFAULT_PAGE,
  SLICE_MANAGEMENT_DEFAULT_PAGE_SIZE,
  SLICE_MANAGEMENT_PAGINATION_COUNT,
} from '../configuration';
import { QueryParamService } from '../../../services/query-param.service';
import { PaginationService } from '../../../services/common-functionalities/pagination.service';
import { catchError, switchMap, tap } from 'rxjs/operators';
import { EMPTY, Subject, startWith, map } from 'rxjs';
import {
  Sort,
  SortDirection,
} from '../../../components/shared/sort/sort.component';
import { applyNewSorting } from '../../../helpers/sorting-helpers';
import {
  SliceResponse,
  NetworkSlicesService,
} from '../../../../../openapi/output';
import { KeyboardShortcuts } from '../../../services/shortcut.service';
import { Router } from '@angular/router';
import { ActionType, EntityType } from 'src/app/model/user-last-action.model';
import { TranslateService } from '@ngx-translate/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmationModalComponent } from 'src/app/components/shared/confirmation-modal/confirmation-modal.component';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { FocusRestoreService } from '@portal-mfe/data-table';
import { ColumnDefinition } from '@portal-mfe/tnap-ui-kit/components/data-table';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-slice-list',
  templateUrl: './slice-list.component.html',
  styleUrls: ['./slice-list.component.css'],
  providers: [SseSlicesListDataService],
  standalone: false,
})
export class SliceListComponent {
  private readonly destroyRef = inject(DestroyRef);
  private readonly focusRestore = inject(FocusRestoreService);

  readonly VALIDATION_PATTERN = VALIDATION_PATTERN;
  readonly SLICE_MANAGEMENT_DEFAULT_PAGE_SIZE =
    SLICE_MANAGEMENT_DEFAULT_PAGE_SIZE;
  readonly SLICE_MANAGEMENT_DEFAULT_PAGE = SLICE_MANAGEMENT_DEFAULT_PAGE;
  readonly SLICE_MANAGEMENT_PAGINATION_COUNT =
    SLICE_MANAGEMENT_PAGINATION_COUNT;

  public ACCESS_KEY = KeyboardShortcuts;
  readonly sliceId$ = this.slicesSseService.sliceId$;
  readonly page$ = this.slicesSseService.page$;
  readonly pageSize$ = this.slicesSseService.pageSize$;
  // Use client-side observable for searching, sorting, and pagination
  readonly slices$ = this.slicesSseService.clientSideSlices$;
  readonly filter$ = this.slicesSseService.filter$;
  readonly sort$ = this.slicesSseService.sort$;
  readonly defaultSort: Sort = {
    direction: SortDirection.NONE,
    parameter: '',
  };
  readonly currentSort = toSignal(
    this.sort$.pipe(
      map(value => value ?? this.defaultSort),
      startWith(this.defaultSort)
    ),
    { initialValue: this.defaultSort }
  );
  readonly permissions = inject(PERMISSIONS_TOKEN);
  private readonly translate = inject(TranslateService);
  private readonly lang = toSignal(this.translate.onLangChange);
  // Sorting functionality
  SortDirection = SortDirection;

  constructor(
    private readonly paginationService: PaginationService,
    private readonly queryParamService: QueryParamService,
    private readonly slicesSseService: SseSlicesListDataService,
    private readonly router: Router,
    private readonly translateService: TranslateService,
    private readonly alertService: TnapAlertService,
    private readonly modalService: NgbModal,
    private readonly networkSlicesService: NetworkSlicesService,
    private readonly sliceActionService: SliceActionService
  ) {}

  readonly COLUMNS = computed((): ColumnDefinition<SliceResponse>[] => {
    this.lang();
    return [
      {
        key: 'provisionStatus',
        label: this.translate.instant(
          'sliceManagement.list.fields.provisionStatus'
        ),
        value: row => row?.statusDetail,
        sorting: { enabled: true },
      },
      {
        key: 'startTime',
        label: this.translate.instant('sliceManagement.list.fields.startTime'),
        value: row => row?.dueDate,
        sorting: { enabled: true },
      },
      {
        key: 'endTime',
        label: this.translate.instant('sliceManagement.list.fields.endTime'),
        value: row => row?.endDate,
        sorting: { enabled: true },
      },
      {
        key: 'sliceName',
        label: this.translate.instant('sliceManagement.list.fields.sliceName'),
        value: row => row?.name,
        sorting: { enabled: true },
      },
      {
        key: 'snssai',
        label: this.translate.instant('sliceManagement.list.fields.snssai'),
        value: row => row?.environmentContext,
        sorting: { enabled: true },
      },
      {
        key: 'serviceType',
        label: this.translate.instant(
          'sliceManagement.list.fields.serviceType'
        ),
        value: row => row?.serviceRole,
        sorting: { enabled: true },
      },
      {
        key: 'feasible',
        label: this.translate.instant('sliceManagement.list.fields.feasible'),
        value: row => row?.feasibilityJob?.feasibilityResult,
        sorting: { enabled: true },
      },
      {
        key: 'cells',
        label: this.translate.instant('sliceManagement.list.fields.cells'),
        value: row => row?.cellIds?.length ?? 0,
        sorting: { enabled: true },
      },
      {
        key: 'operationalStatus',
        label: this.translate.instant(
          'sliceManagement.list.fields.operationalStatus'
        ),
        value: row => row?.operationalStatus,
        sorting: { enabled: true },
      },
      {
        key: 'orchestrationStatus',
        label: this.translate.instant(
          'sliceManagement.list.fields.orchestrationStatus'
        ),
        value: row => row?.orchestrationStatus,
        sorting: { enabled: true },
      },
      {
        key: 'slicePriority',
        label: this.translate.instant(
          'sliceManagement.list.fields.slicePriority'
        ),
        value: row => row?.sliceProfile?.slicePriority,
      },
      {
        key: 'actions',
        label: this.translate.instant('sliceManagement.list.fields.action'),
        value: () => '', // actions handled separately in the table (buttons)
      },
    ];
  });

  public onSortChange(sort: Sort): void {
    applyNewSorting(this.router, sort);
  }

  public onChangePage(page: number): void {
    this.paginationService.changePage(page);
  }

  public onChangePageSize(pageSize: number): void {
    this.paginationService.changePageSize(pageSize);
  }

  public openDetail(sliceId: string | undefined): void {
    this.focusRestore.rememberOpener(document.activeElement as HTMLElement);
    this.changeQueryParams({ sliceId });
  }

  public redirectToTopology(serviceInstanceId: string) {
    this.router.navigate(['/topology', serviceInstanceId]);
  }

  private changeQueryParams(queryParams): void {
    this.queryParamService.updateQueryParam({ ...queryParams }, [
      '/slice-management/slice-list',
    ]);
  }

  public resetSearch(): void {
    this.queryParamService.updateQueryParam({ filter: null });
  }

  public onSearchChange(filter: string): void {
    if (filter) {
      this.queryParamService.updateQueryParam({ filter: filter.trim() });
    } else {
      this.resetSearch();
    }
  }

  private readonly addNewActionToHistory$ = new Subject<{
    type: ActionType;
    entity: EntityType;
    sliceName: string;
  }>();

  private successDeleteMessage(): void {
    this.alertService.success(
      this.translateService.instant('sliceManagement.messages.success.deleted'),
      { keepAfterRouteChange: true }
    );
  }

  private reload() {
    this.slicesSseService.reload();
  }

  openModal(
    sliceId: string,
    sliceName: string | undefined,
    sliceReservationId: string
  ): void {
    // open confirmation modal for slice deletion
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalRef.componentInstance.okText = this.translateService.instant(
      'common.buttons.delete'
    );
    modalRef.componentInstance.title = this.translateService.instant(
      'sliceManagement.modal.delete.title'
    );
    modalRef.componentInstance.text = this.translateService.instant(
      'sliceManagement.modal.delete.text',
      {
        sliceName,
      }
    );
    modalRef.closed
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        switchMap((confirm: boolean) => {
          if (confirm) {
            this.addNewActionToHistory$.next({
              type: ActionType.DELETE,
              entity: EntityType.SLICEMANAGEMENT,
              sliceName: sliceId,
            });
            return this.networkSlicesService.deleteSlice(
              sliceId,
              sliceReservationId,
              sliceName
            );
          }
          return EMPTY;
        })
      )
      .subscribe(() => {
        this.reload();
        this.successDeleteMessage();
      });
  }

  public onSliceAction({
    action,
    slice,
  }: {
    action: string;
    slice: SliceResponse;
  }): void {
    if (action !== 'reinforce' && action !== 'terminate') {
      console.error('Invalid slice action:', action);
      return;
    }

    this.sliceActionService
      .executeSliceAction(action, slice)
      .pipe(
        tap(() => this.reload()),
        catchError(err => {
          console.error('Slice action failed:', err);
          return EMPTY;
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe();
  }
}
