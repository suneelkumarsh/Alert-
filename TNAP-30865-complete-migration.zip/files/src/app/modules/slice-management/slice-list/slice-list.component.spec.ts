/*
 * Copyright (c) 2024. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SliceListComponent } from './slice-list.component';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { of, throwError } from 'rxjs';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { OAuthStorage } from 'angular-oauth2-oidc';
import { FormsModule } from '@angular/forms';
import { InputSearchComponent } from '../../../components/shared/input-search/input-search.component';
import {
  HttpEvent,
  HttpResponse,
  provideHttpClient,
  withInterceptorsFromDi,
} from '@angular/common/http';
import { NetworkSlicesService, SliceUpdateResponse } from 'openapi/output';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LoadingIndicatorService } from 'src/app/services/loading-indicator.service';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import {
  Sort,
  SortDirection,
} from '../../../components/shared/sort/sort.component';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('SliceListComponent', () => {
  let component: SliceListComponent;
  let fixture: ComponentFixture<SliceListComponent>;
  let modalService: NgbModal;
  let networkSlicesService: jasmine.SpyObj<NetworkSlicesService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let router: Router;

  beforeEach(async () => {
    const networkSlicesSpy = jasmine.createSpyObj('NetworkSlicesService', [
      'reinforceSliceActivation',
      'reinforceSliceTermination',
      'terminateSlice',
      'deleteSlice',
    ]);

    const alertSpy = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
    ]);

    await TestBed.configureTestingModule({
      declarations: [SliceListComponent, InputSearchComponent],
      imports: [TranslateModule.forRoot(), FormsModule, RouterModule],
      providers: [
        { provide: NetworkSlicesService, useValue: networkSlicesSpy },
        { provide: TnapAlertService, useValue: alertSpy },
        NgbModal,
        TranslateService,
        LoadingIndicatorService,
        {
          provide: ActivatedRoute,
          useValue: { queryParamMap: of({ get: () => '' }) },
        },
        {
          provide: OAuthStorage,
          useValue: { getItem: () => '' },
        },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting(),
        { provide: PERMISSIONS_TOKEN, useValue: [] },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(SliceListComponent);
    component = fixture.componentInstance;
    modalService = TestBed.inject(NgbModal);
    networkSlicesService = TestBed.inject(
      NetworkSlicesService
    ) as jasmine.SpyObj<NetworkSlicesService>;
    alertService = TestBed.inject(
      TnapAlertService
    ) as jasmine.SpyObj<TnapAlertService>;
    router = TestBed.inject(Router);
    spyOn(router, 'navigate');
    fixture.detectChanges();
  });

  function mockModalConfirm() {
    const modalRef = {
      componentInstance: {},
      closed: of(true),
    };
    spyOn(modalService, 'open').and.returnValue(modalRef as any);
  }

  function mockHttpResponse(): HttpEvent<SliceUpdateResponse> {
    return new HttpResponse<SliceUpdateResponse>({
      body: {} as SliceUpdateResponse,
    });
  }

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call reinforceSliceActivation for ACTIVE slice', () => {
    const slice = {
      id: '1',
      operationalStatus: 'ACTIVE',
      feasibilityJob: {},
    } as any;

    mockModalConfirm();
    networkSlicesService.reinforceSliceActivation.and.returnValue(
      of(mockHttpResponse())
    );

    component.onSliceAction({ action: 'reinforce', slice });

    expect(modalService.open).toHaveBeenCalled();
    expect(networkSlicesService.reinforceSliceActivation).toHaveBeenCalledWith(
      '1',
      ''
    );
    expect(alertService.success).toHaveBeenCalled();
  });

  it('should call terminateSlice for ACTIVE slice', () => {
    const slice = {
      id: '2',
      operationalStatus: 'ACTIVE',
      feasibilityJob: {},
    } as any;

    mockModalConfirm();
    networkSlicesService.terminateSlice.and.returnValue(of(mockHttpResponse()));

    component.onSliceAction({ action: 'terminate', slice });

    expect(modalService.open).toHaveBeenCalled();
    expect(networkSlicesService.terminateSlice).toHaveBeenCalledWith('2', '');
    expect(alertService.success).toHaveBeenCalled();
  });

  it('should call reinforceSliceTermination for TERMINATED slice', () => {
    const slice = {
      id: '3',
      operationalStatus: 'TERMINATED',
      feasibilityJob: {},
    } as any;

    mockModalConfirm();
    networkSlicesService.reinforceSliceTermination.and.returnValue(
      of(mockHttpResponse())
    );

    component.onSliceAction({ action: 'reinforce', slice });

    expect(modalService.open).toHaveBeenCalled();
    expect(networkSlicesService.reinforceSliceTermination).toHaveBeenCalledWith(
      '3',
      ''
    );
    expect(alertService.success).toHaveBeenCalled();
  });

  it('should not call terminateSlice for TERMINATED slice', () => {
    const slice = {
      id: '4',
      operationalStatus: 'TERMINATED',
      feasibilityJob: {},
    } as any;

    mockModalConfirm();

    component.onSliceAction({ action: 'terminate', slice });

    expect(modalService.open).toHaveBeenCalled();
    expect(networkSlicesService.terminateSlice).not.toHaveBeenCalled();
  });

  it('should handle API errors', () => {
    const slice = {
      id: '5',
      operationalStatus: 'ACTIVE',
      feasibilityJob: {},
    } as any;

    mockModalConfirm();
    networkSlicesService.terminateSlice.and.returnValue(
      throwError(() => new Error('API Error'))
    );

    component.onSliceAction({ action: 'terminate', slice });

    expect(modalService.open).toHaveBeenCalled();
    expect(alertService.error).toHaveBeenCalled();
  });

  // Sorting functionality tests
  describe('Sorting functionality', () => {
    it('should expose SortDirection enum', () => {
      expect(component.SortDirection).toBe(SortDirection);
    });

    it('should expose a default currentSort signal when no sort is selected', () => {
      expect(component.currentSort()).toEqual({
        direction: SortDirection.NONE,
        parameter: '',
      });
    });

    it('should apply the parent-controlled sort result emitted by the table', () => {
      const mockSort: Sort = {
        parameter: 'startTime',
        direction: SortDirection.DESC,
      };

      component.onSortChange(mockSort);

      expect(router.navigate).toHaveBeenCalledWith([], {
        queryParams: {
          page: 1,
          sort: '-startTime',
        },
        queryParamsHandling: 'merge',
      });
    });

    it('should mark the correct columns as sortable in COLUMNS()', () => {
      const expectedColumns = [
        'provisionStatus',
        'startTime',
        'endTime',
        'sliceName',
        'snssai',
        'serviceType',
        'feasible',
        'cells',
        'operationalStatus',
        'orchestrationStatus',
      ];
      const sortableKeys = component
        .COLUMNS()
        .filter(c => c.sorting?.enabled)
        .map(c => c.key);
      expect(sortableKeys).toEqual(expectedColumns);
    });

    it('should call router navigate when onSortChange is called with ASC direction', () => {
      const mockSort: Sort = {
        parameter: 'sliceName',
        direction: SortDirection.ASC,
      };

      component.onSortChange(mockSort);

      expect(router.navigate).toHaveBeenCalledWith([], {
        queryParams: {
          page: 1,
          sort: 'sliceName',
        },
        queryParamsHandling: 'merge',
      });
    });

    it('should call router navigate when onSortChange is called with DESC direction', () => {
      const mockSort: Sort = {
        parameter: 'startTime',
        direction: SortDirection.DESC,
      };

      component.onSortChange(mockSort);

      expect(router.navigate).toHaveBeenCalledWith([], {
        queryParams: {
          page: 1,
          sort: '-startTime',
        },
        queryParamsHandling: 'merge',
      });
    });

    it('should call router navigate when onSortChange is called with NONE direction', () => {
      const mockSort: Sort = {
        parameter: 'endTime',
        direction: SortDirection.NONE,
      };

      component.onSortChange(mockSort);

      expect(router.navigate).toHaveBeenCalledWith([], {
        queryParams: { page: 1, sort: null },
        queryParamsHandling: 'merge',
      });
    });

    it('should handle sorting with onlyDesc flag', () => {
      const mockSort: Sort = {
        parameter: 'cells',
        direction: SortDirection.ASC,
        onlyDesc: true,
      };

      component.onSortChange(mockSort);

      expect(router.navigate).toHaveBeenCalledWith([], {
        queryParams: {
          page: 1,
          sort: 'cells',
        },
        queryParamsHandling: 'merge',
      });
    });

    it('should handle sorting for all sortable columns', () => {
      const sortableColumns = component
        .COLUMNS()
        .filter(c => c.sorting?.enabled)
        .map(c => c.key);

      sortableColumns.forEach(column => {
        const mockSort: Sort = {
          parameter: column,
          direction: SortDirection.ASC,
        };

        component.onSortChange(mockSort);

        expect(router.navigate).toHaveBeenCalledWith([], {
          queryParams: {
            page: 1,
            sort: column,
          },
          queryParamsHandling: 'merge',
        });
      });

      // Verify it was called once for each sortable column
      expect(router.navigate).toHaveBeenCalledTimes(sortableColumns.length);
    });
  });

  it('should define all expected columns', () => {
    const cols = component.COLUMNS();

    expect(cols.length).toBe(12);

    expect(cols.map(c => c.key)).toEqual([
      'provisionStatus',
      'startTime',
      'endTime',
      'sliceName',
      'snssai',
      'serviceType',
      'feasible',
      'cells',
      'operationalStatus',
      'orchestrationStatus',
      'slicePriority',
      'actions',
    ]);
  });
});
