/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  inject,
  signal,
} from '@angular/core';
import {
  ConfigActionService,
  ConfigActionStatus,
  ConfigManagementAction,
  ConfigManagementActionListResponse,
  DownloadConfigManagementActionsRequest,
} from '../../../../../openapi/output';
import { BehaviorSubject, combineLatest, EMPTY, Observable, of } from 'rxjs';
import { PaginationService } from '../../../services/common-functionalities/pagination.service';
import { QueryParamService } from '../../../services/query-param.service';
import {
  CM_ACTION_APPROVAL_COMPLETED,
  CM_ACTION_CANCELLATION_COMPLETED,
  CM_ACTION_DEFAULT_PAGE,
  CM_ACTION_DEFAULT_PAGE_SIZE,
  CM_ACTION_TABLE_BASIC_STORAGE_KEY,
  CM_ACTION_TABLE_STORAGE_KEY,
} from '../configuration';
import {
  CM_ACTION_COLUMNS,
  getCmActionQueryParam,
  getCmActionSearchFieldKey,
} from '../cm-action-columns.config';
import {
  CmActionColumnConfig,
  CmActionDateRange,
  CmActionFilterState,
} from '../cm-action.model';
import {
  distinctUntilChanged,
  filter,
  map,
  shareReplay,
  switchMap,
  take,
} from 'rxjs/operators';
import {
  ColumnDefinition,
  FocusRestoreService,
  TableConfigService,
} from '@portal-mfe/data-table';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {
  debounceTimeAfterFirst,
  withLoading,
} from '../../../helpers/custom-operators';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import {
  addFieldPrefix,
  parseFilterFromUrl,
  FROM_SUFFIX,
  TO_SUFFIX,
} from '../../../helpers/filter-helpers';
import { Sort, SortDirection } from '@portal-mfe/tnap-ui-kit/components/sort';
import { TranslateService } from '@ngx-translate/core';
import { FilterOption } from '@portal-mfe/tnap-ui-kit/model';
import { ColumnFilter } from 'src/app/helpers/listing';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { HasPermissionPipe } from '@portal-mfe/auth';
import { FileSaverService } from 'ngx-filesaver';
import { ConfirmationModalComponent } from '@portal-mfe/tnap-ui-kit/components/confirmation-modal';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

const SORT_STATE_LABEL_KEYS: Record<SortDirection, string> = {
  [SortDirection.ASC]: 'common.sorting.ascending',
  [SortDirection.DESC]: 'common.sorting.descending',
  [SortDirection.NONE]: 'common.sorting.none',
};

@Component({
  selector: 'app-cm-action-table',
  templateUrl: './cm-action-table.component.html',
  styleUrls: ['./cm-action-table.component.css'],
  providers: [TableConfigService, HasPermissionPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: false,
})
export class CmActionTableComponent {
  private static readonly DEFAULT_COLUMN_KEY_ORDER: readonly string[] = [
    'object',
    'status',
    'executedDate',
    'loopType',
    'activationErrorDescription',
  ];

  private static readonly DEFAULT_COLUMN_KEY_RANK: ReadonlyMap<string, number> =
    new Map(
      CmActionTableComponent.DEFAULT_COLUMN_KEY_ORDER.map((key, index) => [
        key,
        index,
      ])
    );

  private orderColumnsByDefault<T extends { key: string }>(columns: T[]): T[] {
    const originalIndex = new Map(
      columns.map((column, index) => [column, index])
    );
    return [...columns].sort((a, b) => {
      const rankA =
        CmActionTableComponent.DEFAULT_COLUMN_KEY_RANK.get(a.key) ??
        Number.MAX_SAFE_INTEGER;
      const rankB =
        CmActionTableComponent.DEFAULT_COLUMN_KEY_RANK.get(b.key) ??
        Number.MAX_SAFE_INTEGER;
      if (rankA !== rankB) {
        return rankA - rankB;
      }
      return (originalIndex.get(a) ?? 0) - (originalIndex.get(b) ?? 0);
    });
  }

  private readonly cmActionService = inject(ConfigActionService);
  private readonly paginationService = inject(PaginationService);
  private readonly queryParamService = inject(QueryParamService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly focusRestore = inject(FocusRestoreService);
  private readonly translateService = inject(TranslateService);
  private readonly modalService = inject(NgbModal);
  private readonly lang = toSignal(this.translateService.onLangChange);

  readonly permissions = inject(PERMISSIONS_TOKEN);
  private readonly fileSaverService = inject(FileSaverService);
  private readonly alertService = inject(TnapAlertService);
  public activeTab: 'actionList' | 'dashboard' = 'actionList';
  private readonly hasPermissionPipe = inject(HasPermissionPipe);
  protected readonly hasCancelPermission = toSignal(
    this.hasPermissionPipe
      .transform(this.permissions.ALLOW_CM_ACTION_CANCEL)
      .pipe(distinctUntilChanged())
  );
  readonly hasSearchPermission$ = this.hasPermissionPipe
    .transform(this.permissions.VIEW_CM_ACTION_SEARCH)
    .pipe(
      distinctUntilChanged(),
      shareReplay({ refCount: true, bufferSize: 1 })
    );
  private readonly hasSearchPermission = toSignal(this.hasSearchPermission$);

  /**
   * The table config is persisted on `ngOnInit` of the data table, so columns and
   * storage key must be final before it renders.
   */
  readonly permissionsResolved = computed(
    () =>
      this.hasSearchPermission() !== undefined &&
      this.hasCancelPermission() !== undefined
  );

  /**
   * Without the search permission the list endpoint is used, which only supports the
   * legacy filter fields — every other column would be unfilterable, so it is hidden.
   */
  readonly availableColumns = computed<CmActionColumnConfig[]>(() =>
    this.orderColumnsByDefault(
      CM_ACTION_COLUMNS.filter(
        column => this.hasSearchPermission() === true || column.legacy === true
      )
    )
  );

  /** Column preferences must not be shared between the two endpoint variants. */
  readonly tableStorageKey = computed(() =>
    this.hasSearchPermission()
      ? CM_ACTION_TABLE_STORAGE_KEY
      : CM_ACTION_TABLE_BASIC_STORAGE_KEY
  );

  /** Columns whose header filter the current user is allowed to see. */
  readonly filterableColumns = computed<CmActionColumnConfig[]>(() =>
    this.availableColumns().filter(column => column.filter !== 'none')
  );

  /** MVP users are identified by the CM action search permission. */
  readonly isMvpUser = computed(() => this.hasSearchPermission() === true);

  /** Translated dropdown options per enum column key. */
  readonly filterOptions = computed<Record<string, FilterOption[]>>(() => {
    this.lang();
    const isMvpUser = this.isMvpUser();
    return Object.fromEntries(
      CM_ACTION_COLUMNS.filter(
        column => column.filter === 'enum' && column.enumValues
      ).map(column => [
        column.key,
        column
          .enumValues!.filter(
            value => !isMvpUser || !this.isRestrictedEnumValue(column, value)
          )
          .map(value => ({
            label: this.translateService.instant(
              `${column.enumTranslationPrefix}${value}`
            ),
            value,
          })),
      ])
    );
  });

  /** Columns rendered through the shared date/time cell template. */
  readonly dateTimeColumns = computed(() =>
    this.availableColumns().filter(column => column.format === 'datetime')
  );

  readonly columns = computed<ColumnDefinition<ConfigManagementAction>[]>(
    () => {
      this.lang();
      const columns = [
        ...this.availableColumns().map(column => ({
          key: column.key,
          label: this.translateService.instant(column.labelKey),
          visible: column.visible ?? false,
          // `enabled` drives the library's native sort button and aria-sort on the <th>.
          // Only columns flagged with `sorting: true` in the config and accessible via the
          // search endpoint (canSort) get a sort control.
          sorting: {
            enabled: column.sorting === true && this.canSort(),
            parameter: column.field,
          },
          value: (cmAction: ConfigManagementAction) =>
            this.formatCellValue(column, cmAction),
        })),
      ];

      if (this.hasCancelPermission()) {
        columns.push({
          key: 'actions',
          label: this.translateService.instant('cmAction.list.fields.action'),
          visible: true,
          sorting: { enabled: false, parameter: 'configManagementActionId' },
          value: (): string => '',
        });
      }

      return this.moveActionColumnToEnd(columns);
    }
  );

  private moveActionColumnToEnd<T extends { key: string }>(columns: T[]): T[] {
    const actions = columns.filter(column => column.key === 'actions');
    const others = columns.filter(column => column.key !== 'actions');
    return [...others, ...actions];
  }

  private formatCellValue(
    column: CmActionColumnConfig,
    cmAction: ConfigManagementAction
  ): string {
    const raw = cmAction[column.field];
    if (raw === undefined || raw === null || raw === '') {
      return '';
    }
    if (Array.isArray(raw)) {
      return raw.join(', ');
    }
    let text: string;
    if (typeof raw === 'string') {
      text = raw;
    } else if (typeof raw === 'number') {
      text = `${raw}`;
    } else {
      text = raw ? 'true' : 'false';
    }
    return column.enumTranslationPrefix
      ? this.translateService.instant(`${column.enumTranslationPrefix}${text}`)
      : text;
  }

  // Only statuses where the action has not yet been processed can be cancelled.
  private static readonly CANCELLABLE_STATUSES = new Set<ConfigActionStatus>([
    ConfigActionStatus.NEW,
    ConfigActionStatus.ACTIVATION_QUEUED,
    ConfigActionStatus.WAITING_FOR_APPROVAL,
  ]);

  public isCancelAllowed(row: ConfigManagementAction): boolean {
    return CmActionTableComponent.CANCELLABLE_STATUSES.has(
      row.status as ConfigActionStatus
    );
  }

  public isRowSelectable(row: ConfigManagementAction): boolean {
    return this.isCancelAllowed(row);
  }

  public isBulkApproveAllowed(): boolean {
    const selectedRows = Array.from(this.selectedRowsState().values());

    return (
      selectedRows.length > 0 &&
      selectedRows.every(
        row => row.status === ConfigActionStatus.WAITING_FOR_APPROVAL
      )
    );
  }

  public cancelCmAction(row: ConfigManagementAction): void {
    if (row.configManagementActionId) {
      this.openConfirmationModal([row.configManagementActionId]);
    }
  }

  public confirmApproveCmActions(): void {
    const cmActionsIds = this.checkedRowIds();
    if (cmActionsIds.length === 0) {
      return;
    }

    this.openApproveConfirmationModal(cmActionsIds);
  }

  private openApproveConfirmationModal(cmActionsIds: string[]): void {
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalRef.componentInstance.okText = this.translateService.instant(
      'cmAction.list.approveAlertModal.okText'
    );
    modalRef.componentInstance.title = this.translateService.instant(
      'cmAction.list.approveAlertModal.title'
    );
    modalRef.componentInstance.text = this.translateService.instant(
      'cmAction.list.approveAlertModal.text',
      { count: cmActionsIds.length }
    );
    modalRef.componentInstance.cancelButton = this.translateService.instant(
      'common.buttons.cancel'
    );

    modalRef.closed
      .pipe(
        take(1),
        filter((confirm: boolean) => confirm),
        switchMap(() =>
          this.cmActionService.approveConfigManagementActions({
            configManagementActions: cmActionsIds,
          })
        ),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: (response: { [key: string]: string }) => {
          this.deselectRows(cmActionsIds);
          const succeeded = Object.values(response || {}).filter(
            value => value === CM_ACTION_APPROVAL_COMPLETED
          ).length;
          const failures = Object.entries(response || {}).filter(
            ([, value]) => value !== CM_ACTION_APPROVAL_COMPLETED
          );

          if (succeeded > 0) {
            this.alertService.success(
              this.translateService.instant(
                'cmAction.list.approveAlertModal.successMessage',
                { count: succeeded }
              ),
              { keepAfterRouteChange: true }
            );
            this.reload$.next();
          }

          if (failures.length > 0) {
            const detail = failures
              .map(([id, message]) => `${id}: ${message}`)
              .join('<br/>');
            const scrollableDetail =
              `<div class="cm-action-alert-height-scroll">` + detail + `</div>`;
            this.alertService.warn(
              this.translateService.instant(
                'cmAction.list.approveAlertModal.partialErrorMessage',
                { count: failures.length }
              ) + scrollableDetail,
              { keepAfterRouteChange: true }
            );
          }
        },
      });
  }

  protected openConfirmationModal(cmActionsIds: string[]): void {
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalRef.componentInstance.okText = this.translateService.instant(
      'cmAction.list.cancelAlertModal.okText'
    );
    modalRef.componentInstance.title = this.translateService.instant(
      'cmAction.list.cancelAlertModal.title'
    );
    modalRef.componentInstance.cancelText = this.translateService.instant(
      'cmAction.list.cancelAlertModal.cancelText'
    );
    modalRef.componentInstance.text = this.translateService.instant(
      'cmAction.list.cancelAlertModal.text'
    );
    modalRef.closed
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        switchMap((confirm: boolean) =>
          confirm
            ? this.cmActionService.cancelConfigManagementActions({
                configManagementActions: cmActionsIds,
              })
            : EMPTY
        )
      )
      .subscribe({
        next: (response: { [key: string]: string }) => {
          this.deselectRows(cmActionsIds);
          const succeeded = Object.values(response).filter(
            v => v === CM_ACTION_CANCELLATION_COMPLETED
          ).length;
          const failures = Object.entries(response).filter(
            ([, v]) => v !== CM_ACTION_CANCELLATION_COMPLETED
          );

          if (succeeded > 0) {
            this.alertService.success(
              this.translateService.instant(
                'cmAction.list.cancelAlertModal.successMessage',
                { count: succeeded }
              ),
              { keepAfterRouteChange: true }
            );
            this.reload$.next();
          }
          if (failures.length > 0) {
            const detail = failures
              .map(([id, msg]) => `${id}: ${msg}`)
              .join('\n');
            this.alertService.warn(
              this.translateService.instant(
                'cmAction.list.cancelAlertModal.partialErrorMessage',
                { count: failures.length }
              ) +
                '\n' +
                detail,
              { keepAfterRouteChange: true }
            );
          }
        },
      });
  }

  leftPane = 60;
  unit: '%' | 'px' = '%';
  minWidth = 20;
  maxWidth = 70;
  step = 2;

  /**
   * The column settings menu opens below its toggle, so 80vh alone would overflow the
   * viewport. The offset covers the toggle position including the header wrapping on
   * narrow screens. The ui-kit forwards this into a nested custom property, so `var()`
   * cannot be used here.
   */
  protected readonly columnSettingsMaxHeight = 'min(80vh, calc(100vh - 310px))';

  private readonly reload$ = new BehaviorSubject<void>(undefined);

  private static readonly DEFAULT_SORT: Sort = {
    parameter: 'createdDate',
    direction: SortDirection.DESC,
  };

  /** Sort lives in the URL like page, pageSize and the filters, so it survives a reload and is shareable. */
  private readonly sort$: Observable<Sort> = combineLatest([
    this.queryParamService.getValueOf('sortBy'),
    this.queryParamService.getValueOf('sortDirection'),
  ]).pipe(
    map(([parameter, direction]) =>
      CmActionTableComponent.parseSort(parameter, direction)
    ),
    distinctUntilChanged(
      (previous, current) =>
        previous.parameter === current.parameter &&
        previous.direction === current.direction
    ),
    shareReplay({ refCount: true, bufferSize: 1 })
  );
  readonly sort = toSignal(this.sort$, {
    initialValue: CmActionTableComponent.DEFAULT_SORT,
  });

  /** Unknown values reaching the backend are rejected, so anything unexpected falls back to the default. */
  private static parseSort(
    parameter: string | null,
    direction: string | null
  ): Sort {
    const isKnownField = CM_ACTION_COLUMNS.some(
      column => column.field === parameter
    );
    const isKnownDirection =
      direction === SortDirection.ASC || direction === SortDirection.DESC;
    return isKnownField && isKnownDirection
      ? {
          parameter: parameter as string,
          direction: direction as SortDirection,
        }
      : CmActionTableComponent.DEFAULT_SORT;
  }

  /** Shared by the list request and the CSV export so both always agree. */
  private static sortParams(sort: Sort): {
    sortBy: string;
    sortDirection: 'ASC' | 'DESC';
  } {
    return {
      sortBy:
        sort.direction === SortDirection.NONE
          ? CmActionTableComponent.DEFAULT_SORT.parameter
          : sort.parameter,
      sortDirection: sort.direction === SortDirection.ASC ? 'ASC' : 'DESC',
    };
  }

  /** The legacy list endpoint always sorts by createdDate, so sorting is offered for the search endpoint only. */
  readonly canSort = computed(() => this.hasSearchPermission() === true);

  /**
   * Sort state per column key. The data table renders its own sort button only for
   * columns without a header template, so it is placed in the filter headers instead.
   * The API sorts by a single column only.
   */
  readonly sortDirections = computed<Record<string, SortDirection>>(() => {
    const current = this.sort();
    return Object.fromEntries(
      this.availableColumns().map(column => [
        column.key,
        column.field === current.parameter
          ? current.direction
          : SortDirection.NONE,
      ])
    );
  });

  /**
   * Accessible name per sort button. VoiceOver does not read the `aria-sort` of the
   * surrounding `<th>` when tabbing, so the state is repeated in the button name.
   */
  readonly sortLabels = computed<Record<string, string>>(() => {
    this.lang();
    const directions = this.sortDirections();
    return Object.fromEntries(
      this.availableColumns().map(column => [
        column.key,
        this.translateService.instant('common.sorting.controlLabel', {
          column: this.translateService.instant(column.labelKey),
          state: this.translateService.instant(
            SORT_STATE_LABEL_KEYS[directions[column.key]]
          ),
        }),
      ])
    );
  });

  readonly page$ = this.queryParamService.getQueryParamAsNumber(
    'page',
    CM_ACTION_DEFAULT_PAGE
  );
  readonly pageSize$ = this.queryParamService.getQueryParamAsNumber(
    'pageSize',
    CM_ACTION_DEFAULT_PAGE_SIZE
  );

  readonly statusFilter$ = this.queryParamService.getValueOf('status');
  readonly operationFilter$ = this.queryParamService.getValueOf('operation');
  readonly loopTypeFilter$ = this.queryParamService.getValueOf('loopType');
  readonly serviceNameFilter$ = this.queryParamService.getValueOf('actorName');
  readonly configTypeFilter$ = this.queryParamService.getValueOf('configType');
  readonly filter$ = this.queryParamService.getValueOf('filter');
  readonly idFilter$ = this.queryParamService.getValueOf('id');
  readonly workflowNameFilter$ =
    this.queryParamService.getValueOf('workflowName');

  readonly taskIdFilter$ = this.queryParamService.getAllValuesOf('taskId');

  private static readonly VALUE_FILTER_COLUMNS = CM_ACTION_COLUMNS.filter(
    column => column.filter === 'text' || column.filter === 'enum'
  );

  private static readonly DATE_RANGE_COLUMNS = CM_ACTION_COLUMNS.filter(
    column => column.filter === 'dateRange'
  );

  /** One shared query param stream per column, consumed by the template and by the request. */
  private readonly rawFilterValues: Record<
    string,
    Observable<string | undefined>
  > = Object.fromEntries(
    CmActionTableComponent.VALUE_FILTER_COLUMNS.map(column => [
      column.key,
      this.createRawFilterValue(column).pipe(
        distinctUntilChanged(),
        shareReplay({ refCount: true, bufferSize: 1 })
      ),
    ])
  );

  /** Undebounced filter values per column key, used to prefill the header filter inputs. */
  readonly filterValues$: Observable<Record<string, string | undefined>> =
    combineLatest(this.rawFilterValues).pipe(
      shareReplay({ refCount: true, bufferSize: 1 })
    );

  /** Debounced filter values feeding the backend request. */
  private readonly filterState$: Observable<CmActionFilterState> =
    combineLatest({
      values: combineLatest(
        Object.fromEntries(
          CmActionTableComponent.VALUE_FILTER_COLUMNS.map(column => [
            column.key,
            this.debouncedFilterValue(column),
          ])
        )
      ),
      ranges: combineLatest(
        Object.fromEntries(
          CmActionTableComponent.DATE_RANGE_COLUMNS.map(column => [
            column.key,
            this.dateRangeValue(column),
          ])
        )
      ),
    }).pipe(shareReplay({ refCount: true, bufferSize: 1 }));

  readonly hasAnyFilter$ = this.filterState$.pipe(
    map(
      state =>
        Object.keys(
          this.buildSearchFields(state, this.hasSearchPermission() !== true)
        ).length > 0
    )
  );

  readonly hasTaskIdFilter$ = this.taskIdFilter$.pipe(
    map(taskIds => taskIds.length > 0)
  );

  readonly cmAction$: Observable<{
    loading: boolean;
    data?: ConfigManagementActionListResponse;
  }> = combineLatest([
    this.page$,
    this.pageSize$,
    this.filterState$,
    this.hasSearchPermission$,
    this.sort$,
    this.reload$,
  ]).pipe(
    switchMap(([page, pageSize, filterState, hasPermission, sort]) => {
      const searchFields = this.buildSearchFields(filterState, !hasPermission);
      const { sortBy, sortDirection } = CmActionTableComponent.sortParams(sort);
      return hasPermission
        ? this.cmActionService
            .searchConfigManagementActions(
              page,
              pageSize,
              sortBy,
              sortDirection,
              searchFields
            )
            .pipe(withLoading())
        : this.cmActionService
            .listConfigManagementActions(page, pageSize, {
              ...searchFields,
              sortDate: 'createdDate',
            })
            .pipe(withLoading());
    }),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  private createRawFilterValue(
    column: CmActionColumnConfig
  ): Observable<string | undefined> {
    const param = getCmActionQueryParam(column);
    const value$ = column.multiValue
      ? this.queryParamService
          .getAllValuesOf(param)
          .pipe(map(values => this.normalizeMultiValue(values)))
      : this.queryParamService
          .getValueOf(param)
          .pipe(map(value => this.normalizeFilterValue(value, column)));
    if (!column.restrictedEnumValues?.length) {
      return value$;
    }
    // Restricted values must not be usable through a deep link either.
    return combineLatest([value$, this.hasSearchPermission$]).pipe(
      map(([value, isMvpUser]) =>
        isMvpUser && this.isRestrictedEnumValue(column, value)
          ? undefined
          : value
      )
    );
  }

  private isRestrictedEnumValue(
    column: CmActionColumnConfig,
    value: string | undefined
  ): boolean {
    return (
      value !== undefined && !!column.restrictedEnumValues?.includes(value)
    );
  }

  private debouncedFilterValue(
    column: CmActionColumnConfig
  ): Observable<string | undefined> {
    const value$ = this.rawFilterValues[column.key];
    // Enum filters come from a dropdown and do not need typing debounce.
    return column.filter === 'enum'
      ? value$
      : value$.pipe(debounceTimeAfterFirst(800), distinctUntilChanged());
  }

  private dateRangeValue(
    column: CmActionColumnConfig
  ): Observable<CmActionDateRange> {
    return this.filter$.pipe(
      map(urlFilter => {
        const parsed = parseFilterFromUrl(urlFilter);
        return {
          start: this.readDateBoundary(parsed, column.key + FROM_SUFFIX),
          end: this.readDateBoundary(parsed, column.key + TO_SUFFIX),
        };
      }),
      debounceTimeAfterFirst(300),
      distinctUntilChanged((a, b) => a.start === b.start && a.end === b.end)
    );
  }

  private readDateBoundary(
    parsed: ReturnType<typeof parseFilterFromUrl>,
    key: string
  ): string | undefined {
    const value = parsed.get(addFieldPrefix(key))?.value;
    return value ? this.stripQuotes(String(value)) : undefined;
  }

  private normalizeFilterValue(
    value: string | null,
    column: CmActionColumnConfig
  ): string | undefined {
    const trimmed = value?.trim();
    if (!trimmed) {
      return undefined;
    }
    // 'all' is the reset sentinel of the enum dropdowns, for text filters it is a real search term.
    return column.filter === 'enum' && trimmed === 'all' ? undefined : trimmed;
  }

  private normalizeMultiValue(values: string[]): string | undefined {
    const joined = values
      .map(value => value.trim())
      .filter(Boolean)
      .join(',');
    return joined || undefined;
  }

  /**
   * Maps the current filter state to the flat `searchFields` map of the BFF.
   * `legacyOnly` restricts the result to the fields supported by
   * `listConfigManagementActions` (see ConfigActionFilterParams).
   */
  private buildSearchFields(
    state: CmActionFilterState,
    legacyOnly: boolean
  ): Record<string, string> {
    const searchFields: Record<string, string> = {};
    for (const column of CM_ACTION_COLUMNS) {
      if (legacyOnly && !column.legacy) {
        continue;
      }
      if (column.filter === 'dateRange' && column.dateRange) {
        const range = state.ranges[column.key];
        if (range?.start) {
          searchFields[column.dateRange.startKey] = range.start + 'Z';
        }
        if (range?.end) {
          searchFields[column.dateRange.endKey] = range.end + 'Z';
        }
        continue;
      }
      const value = state.values[column.key];
      if (value !== undefined) {
        searchFields[getCmActionSearchFieldKey(column)] = value;
      }
    }
    return searchFields;
  }

  readonly detail$ = this.idFilter$.pipe(
    switchMap(id => {
      if (!id) {
        return of(undefined);
      }
      return this.cmActionService
        .listConfigManagementActions(
          undefined,
          undefined,
          { configManagementActionId: id },
          // List responses omit the payload; the detail pane is the only view that renders it.
          true
        )
        .pipe(map(response => response.items[0]));
    })
  );

  // Checkbox selection state
  readonly selectedRowsState = signal<Map<string, ConfigManagementAction>>(
    new Map()
  );

  readonly checkedRowIds = computed(() =>
    Array.from(this.selectedRowsState().entries())
      .filter(([, item]) => item && this.isRowSelectable(item))
      .map(([id]) => id)
  );

  private readonly currentPageItems = toSignal(
    this.cmAction$.pipe(map(state => state?.data?.items ?? [])),
    { initialValue: [] as ConfigManagementAction[] }
  );

  public onCheckAllCheckbox(checked: boolean): void {
    const currentRows = new Map(this.selectedRowsState());
    const items = this.currentPageItems();
    if (checked) {
      items.forEach(item => {
        if (item.configManagementActionId && this.isRowSelectable(item)) {
          currentRows.set(item.configManagementActionId, item);
        }
      });
    } else {
      items.forEach(item => {
        if (item.configManagementActionId) {
          currentRows.delete(item.configManagementActionId);
        }
      });
    }
    this.selectedRowsState.set(currentRows);
  }

  /**
   * The selection spans pages, so ids left behind by a finished bulk request would be sent to
   * cm-action-pgw again with the next one. Refused ids are dropped too: the row keeps the status
   * it was selected with, so it would still pass {@link #isBulkApproveAllowed}.
   */
  private deselectRows(ids: string[]): void {
    const remaining = new Map(this.selectedRowsState());
    ids.forEach(id => remaining.delete(id));
    this.selectedRowsState.set(remaining);
  }

  public onRowCheckedChange(event: {
    row: ConfigManagementAction;
    checked: boolean;
    id: string | number;
  }): void {
    if (!this.isRowSelectable(event.row)) {
      return;
    }
    const currentRows = new Map(this.selectedRowsState());
    const id = event.row.configManagementActionId;
    if (id) {
      if (event.checked) {
        currentRows.set(id, event.row);
      } else {
        currentRows.delete(id);
      }
    }
    this.selectedRowsState.set(currentRows);
  }

  constructor() {
    combineLatest([
      this.statusFilter$,
      this.operationFilter$,
      this.loopTypeFilter$,
      this.serviceNameFilter$,
      this.configTypeFilter$,
    ])
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => {
        this.onChangeFilter({ id: undefined });
      });
  }

  public onChangePage(page: number): void {
    this.paginationService.changePage(page);
  }

  public onChangePageSize(pageSize: number): void {
    this.paginationService.changePageSize(pageSize);
  }

  public onSortChange(sort: Sort): void {
    const isDefault = sort.direction === SortDirection.NONE;
    this.queryParamService.updateQueryParam({
      page: undefined,
      sortBy: isDefault ? undefined : sort.parameter,
      sortDirection: isDefault ? undefined : sort.direction,
    });
  }

  public onChangeFilter(param: { [p: string]: any }): void {
    this.focusRestore.rememberOpener(document.activeElement as HTMLElement);
    const normalizedParams = Object.fromEntries(
      Object.entries(param).map(([key, value]) => [
        key,
        value === 'all' ? null : value,
      ])
    );

    this.queryParamService.updateQueryParam(normalizedParams);
  }

  /**
   * Closing the detail pane only drops the {@code id} query param, which {@link #cmAction$} does not
   * depend on, so the decided row would keep its old status until some other filter changes.
   */
  public onCmActionDecided(): void {
    this.reload$.next();
    this.onChangeFilter({ id: undefined });
  }

  public onFilterChange(
    column: CmActionColumnConfig,
    value: string | undefined
  ): void {
    this.onChangeFilter({
      id: undefined,
      [getCmActionQueryParam(column)]: value?.trim() || undefined,
    });
  }

  public stripQuotes(s: string): string {
    if (!s) return s;
    const first = s[0],
      last = s.at(-1);
    if ((first === "'" || first === '"') && last === first) {
      return s.slice(1, -1);
    }
    return s;
  }

  public onDateFilterChange(event: ColumnFilter | undefined) {
    this.queryParamService.updateQueryParam({ filter: event?.filter });
  }

  //CM action: Export file for MVP users
  public exportCMActions(): void {
    this.filterState$
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        take(1),
        switchMap(filterState => {
          const request: DownloadConfigManagementActionsRequest = {
            visibleColumns: this.getVisibleColumns(),
          };
          const { sortBy, sortDirection } = CmActionTableComponent.sortParams(
            this.sort()
          );
          return this.cmActionService.downloadConfigManagementActions(
            sortBy,
            sortDirection,
            this.buildSearchFields(
              filterState,
              this.hasSearchPermission() !== true
            ),
            request
          );
        })
      )
      .subscribe({
        next: (blob: Blob) => {
          this.fileSaverService.save(blob, 'cm-actions.csv');
        },
      });
  }

  // Creates visible export columns with translated labels
  private getVisibleColumns(): { key: string; label: string }[] {
    const available = this.availableColumns();
    const preferences = this.readColumnPreferences();
    const visibleKeys = preferences
      ? preferences
          .filter(preference => preference.visible !== false)
          .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
          .map(preference => preference.key)
      : available.filter(column => column.visible).map(column => column.key);

    const visibleColumns = visibleKeys
      .map(key => {
        const column = available.find(entry => entry.key === key);
        const definition = this.columns().find(entry => entry.key === key);
        return column
          ? { key: column.field as string, label: definition?.label ?? key }
          : undefined;
      })
      .filter((column): column is { key: string; label: string } => !!column);

    return this.moveActionColumnToEnd(visibleColumns);
  }

  private readColumnPreferences():
    | { key: string; visible?: boolean; order?: number }[]
    | undefined {
    const stored = localStorage.getItem(this.tableStorageKey());
    if (!stored) {
      return undefined;
    }
    try {
      const parsed = JSON.parse(stored);
      return Array.isArray(parsed) ? parsed : undefined;
    } catch {
      return undefined;
    }
  }
}
