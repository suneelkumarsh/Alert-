/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */
import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
} from '@angular/core/testing';
import { CmActionTableComponent } from './cm-action-table.component';
import {
  ConfigActionLoopType,
  ConfigActionService,
  ConfigActionStatus,
  ConfigActionOperation,
  ConfigManagementAction,
  ConfigManagementActionListResponse,
} from 'openapi/output';
import { PaginationService } from 'src/app/services/common-functionalities/pagination.service';
import { QueryParamService } from 'src/app/services/query-param.service';
import { BehaviorSubject, NEVER, of, Subject } from 'rxjs';
import {
  provideHttpClient,
  withInterceptorsFromDi,
} from '@angular/common/http';
import {
  ActivatedRoute,
  convertToParamMap,
  provideRouter,
  Router,
  RouterLink,
} from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import {
  CM_ACTION_DEFAULT_PAGE,
  CM_ACTION_DEFAULT_PAGE_SIZE,
} from '../configuration';
import { ColonPipe } from 'src/app/pipes/colon.pipe';
import { FormsModule } from '@angular/forms';
import {
  addFieldPrefix,
  composeFilter,
  FilterOperator,
  FROM_SUFFIX,
  quote,
  TO_SUFFIX,
} from 'src/app/helpers/filter-helpers';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { Pipe, PipeTransform } from '@angular/core';
import { HasPermissionPipe } from '@portal-mfe/auth';
import { TableConfigService } from '@portal-mfe/data-table';
import {
  DataTableComponent,
  TableCellDefinitionDirective,
  TableHeaderDefinitionDirective,
  TableHeaderActionDefinitionDirective,
} from '@portal-mfe/tnap-ui-kit/components/data-table';
import { FilterTextComponent } from '@portal-mfe/tnap-ui-kit/components/filter-text';
import { FilterDropdownComponent } from '@portal-mfe/tnap-ui-kit/components/filter-dropdown';
import { SortDirection } from '@portal-mfe/tnap-ui-kit/components/sort';
import { FileSaverService } from 'ngx-filesaver';
import {
  NgbModal,
  NgbModalRef,
  NgbNavModule,
} from '@ng-bootstrap/ng-bootstrap';
import {
  CM_ACTION_COLUMNS,
  CM_ACTION_RESERVED_QUERY_PARAMS,
  getCmActionQueryParam,
} from '../cm-action-columns.config';
import { CmActionColumnConfig } from '../cm-action.model';
import {
  CM_ACTION_TABLE_BASIC_STORAGE_KEY,
  CM_ACTION_TABLE_STORAGE_KEY,
} from '../configuration';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

function columnByKey(key: string): CmActionColumnConfig {
  const column = CM_ACTION_COLUMNS.find(entry => entry.key === key);
  if (!column) {
    throw new Error(`Unknown cm-action column: ${key}`);
  }
  return column;
}

/** Builds the URL filter string the date filter component writes for a column. */
function buildDateRangeFilter(
  columnKey: string,
  from: string,
  to: string
): string {
  return composeFilter([
    `${addFieldPrefix(columnKey + FROM_SUFFIX)}${FilterOperator.GREATER_OR_EQUAL}${quote(from)}`,
    `${addFieldPrefix(columnKey + TO_SUFFIX)}${FilterOperator.LESS_OR_EQUAL}${quote(to)}`,
  ]);
}

@Pipe({ name: 'hasPermissionPipe', standalone: false })
class MockHasPermissionPipe implements PipeTransform {
  transform(): unknown {
    return of(true);
  }
}

@Pipe({ name: 'dateTimeFormatter', standalone: false })
class MockDateTimeFormatterPipe implements PipeTransform {
  transform(value: unknown): unknown {
    return of(value);
  }
}
describe('CmActionTableComponent', () => {
  let component: CmActionTableComponent;
  let fixture: ComponentFixture<CmActionTableComponent>;
  let configActionServiceMock:
    | jasmine.SpyObj<ConfigActionService>
    | jasmine.SpyObj<any>;
  let hasPermissionPipeMock: jasmine.SpyObj<HasPermissionPipe>;
  let paginationServiceMock: jasmine.SpyObj<PaginationService>;
  let queryParamServiceMock: jasmine.SpyObj<QueryParamService>;
  let queryParamMapSubject: BehaviorSubject<any>;
  let configActionsListResponse: any;
  const fileSaverMock = jasmine.createSpyObj('FileSaverService', ['save']);
  let modalServiceMock: jasmine.SpyObj<NgbModal>;
  let alertServiceMock: jasmine.SpyObj<TnapAlertService>;

  let statusFilterSubject: BehaviorSubject<string | null>;
  let operationFilterSubject: BehaviorSubject<string | null>;
  let loopTypeFilterSubject: BehaviorSubject<string | null>;
  let configTypeFilterSubject: BehaviorSubject<string | null>;
  let actorNameFilterSubject: BehaviorSubject<string | null>;
  let taskIdSubject: BehaviorSubject<string[]>;
  let sliceIdSubject: BehaviorSubject<string | null>;
  let resourceSubject: BehaviorSubject<string | null>;
  let approvedBySubject: BehaviorSubject<string | null>;
  let workflowNameFilterSubject: BehaviorSubject<string | null>;
  let filterSubject: BehaviorSubject<string | null>;
  let idSubject: BehaviorSubject<string | null>;
  let sortBySubject: BehaviorSubject<string | null>;
  let sortDirectionSubject: BehaviorSubject<string | null>;

  /** Mirrors the router round-trip the component relies on for sorting. */
  function applySortQueryParams(
    parameter: string | null,
    direction: SortDirection | null
  ): void {
    sortBySubject.next(parameter);
    sortDirectionSubject.next(direction);
  }

  beforeEach(() => {
    statusFilterSubject = new BehaviorSubject<string | null>('all');
    operationFilterSubject = new BehaviorSubject<string | null>('all');
    loopTypeFilterSubject = new BehaviorSubject<string | null>('all');
    configTypeFilterSubject = new BehaviorSubject<string | null>(null);
    actorNameFilterSubject = new BehaviorSubject<string | null>(null);
    taskIdSubject = new BehaviorSubject<string[]>([]);
    sliceIdSubject = new BehaviorSubject<string | null>(null);
    resourceSubject = new BehaviorSubject<string | null>(null);
    approvedBySubject = new BehaviorSubject<string | null>(null);
    workflowNameFilterSubject = new BehaviorSubject<string | null>(null);
    filterSubject = new BehaviorSubject<string | null>(null);
    idSubject = new BehaviorSubject<string | null>(null);
    sortBySubject = new BehaviorSubject<string | null>(null);
    sortDirectionSubject = new BehaviorSubject<string | null>(null);

    modalServiceMock = jasmine.createSpyObj('NgbModal', ['open']);
    alertServiceMock = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'warn',
    ]);
    configActionServiceMock = jasmine.createSpyObj('ConfigActionService', [
      'listConfigManagementActions',
      'searchConfigManagementActions',
      'cancelConfigManagementActions',
      'approveConfigManagementActions',
    ]);
    paginationServiceMock = jasmine.createSpyObj('PaginationService', [
      'changePage',
      'changePageSize',
    ]);
    queryParamServiceMock = jasmine.createSpyObj('QueryParamService', [
      'updateQueryParam',
      'getQueryParamAsNumber',
      'getValueOf',
      'getAllValuesOf',
    ]);

    queryParamServiceMock.getAllValuesOf.and.callFake((key: string) => {
      if (key === 'taskId') {
        return taskIdSubject.asObservable();
      }
      return of([] as string[]);
    });

    queryParamServiceMock.getQueryParamAsNumber.and.callFake(
      (key: string, def: number) => {
        if (key === 'page') return of(CM_ACTION_DEFAULT_PAGE);
        if (key === 'pageSize') return of(CM_ACTION_DEFAULT_PAGE_SIZE);
        return of(def);
      }
    );

    queryParamServiceMock.getValueOf
      .withArgs('status')
      .and.returnValue(statusFilterSubject.asObservable());
    queryParamServiceMock.getValueOf
      .withArgs('operation')
      .and.returnValue(operationFilterSubject.asObservable());
    queryParamServiceMock.getValueOf
      .withArgs('loopType')
      .and.returnValue(loopTypeFilterSubject.asObservable());
    queryParamServiceMock.getValueOf
      .withArgs('configType')
      .and.returnValue(configTypeFilterSubject.asObservable());
    queryParamServiceMock.getValueOf
      .withArgs('actorName')
      .and.returnValue(actorNameFilterSubject.asObservable());
    queryParamServiceMock.getValueOf
      .withArgs('aaiServiceReference')
      .and.returnValue(sliceIdSubject.asObservable());
    queryParamServiceMock.getValueOf
      .withArgs('modifiedManagedObjectName')
      .and.returnValue(resourceSubject.asObservable());
    queryParamServiceMock.getValueOf
      .withArgs('approvedBy')
      .and.returnValue(approvedBySubject.asObservable());
    queryParamServiceMock.getValueOf
      .withArgs('workflowName')
      .and.returnValue(workflowNameFilterSubject.asObservable());
    queryParamServiceMock.getValueOf
      .withArgs('filter')
      .and.returnValue(filterSubject.asObservable());
    queryParamServiceMock.getValueOf
      .withArgs('id')
      .and.returnValue(idSubject.asObservable());
    queryParamServiceMock.getValueOf
      .withArgs('sortBy')
      .and.returnValue(sortBySubject.asObservable());
    queryParamServiceMock.getValueOf
      .withArgs('sortDirection')
      .and.returnValue(sortDirectionSubject.asObservable());

    queryParamMapSubject = new BehaviorSubject(
      convertToParamMap({ page: 1, pageSize: 50, sort: 'createdDate' })
    );

    hasPermissionPipeMock = jasmine.createSpyObj('HasPermissionPipe', [
      'transform',
    ]);

    hasPermissionPipeMock.transform.and.returnValue(of(true));

    TestBed.overrideComponent(CmActionTableComponent, {
      set: {
        providers: [
          TableConfigService,
          {
            provide: HasPermissionPipe,
            useValue: hasPermissionPipeMock,
          },
        ],
      },
    });

    TestBed.configureTestingModule({
      declarations: [
        CmActionTableComponent,
        ColonPipe,
        MockHasPermissionPipe,
        MockDateTimeFormatterPipe,
      ],
      imports: [
        TranslateModule.forRoot(),
        FormsModule,
        NgbNavModule,
        DataTableComponent,
        TableCellDefinitionDirective,
        TableHeaderDefinitionDirective,
        TableHeaderActionDefinitionDirective,
        FilterTextComponent,
        FilterDropdownComponent,
        // The slice reference cell's <a> is a RouterLink, and its href plus its click handling
        // are what the "slice reference cell" tests below assert.
        RouterLink,
      ],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            queryParamMap: queryParamMapSubject.asObservable(),
          },
        },
        { provide: ConfigActionService, useValue: configActionServiceMock },
        { provide: PaginationService, useValue: paginationServiceMock },
        { provide: QueryParamService, useValue: queryParamServiceMock },
        provideRouter([]),
        {
          provide: PERMISSIONS_TOKEN,
          useValue: {
            VIEW_CM_ACTION_EXPORT: ['VIEW_CM_ACTION_EXPORT'],
            VIEW_CM_ACTION_SEARCH: ['VIEW_CM_ACTION_SEARCH'],
            ALLOW_CM_ACTION_CANCEL: ['ALLOW_CM_ACTION_CANCEL'],
          },
        },
        { provide: HasPermissionPipe, useValue: hasPermissionPipeMock },
        provideHttpClient(withInterceptorsFromDi()),
        { provide: FileSaverService, useValue: fileSaverMock },
        { provide: NgbModal, useValue: modalServiceMock },
        { provide: TnapAlertService, useValue: alertServiceMock },
      ],
    });
    configActionsListResponse = {
      items: [
        {
          actorName: 'Test User',
          modifiedManagedObjectName: 'Object1',
          loopType: ConfigActionLoopType.CLOSE,
          status: ConfigActionStatus.ACTIVATION_COMPLETED,
          createdDate: new Date().toString(),
          payload: {},
          aaiObjectReference: 'reference1',
          cpsUrl: 'url1',
          workflowName: 'workflow-123',
        },
      ],
      totalCount: 1,
    };

    queryParamServiceMock.getValueOf.and.returnValue(of(null));

    (
      configActionServiceMock.searchConfigManagementActions as unknown as jasmine.Spy
    ).and.returnValue(
      of(configActionsListResponse as ConfigManagementActionListResponse)
    );

    fixture = TestBed.createComponent(CmActionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // The data table persists its column settings, which would leak into the next spec.
  afterEach(() => {
    localStorage.clear();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call paginationService.changePage on onChangePage', () => {
    const page = 2;
    component.onChangePage(page);
    expect(paginationServiceMock.changePage).toHaveBeenCalledWith(page);
  });

  it('should call paginationService.changePageSize on onChangePageSize', () => {
    const pageSize = 10;
    component.onChangePageSize(pageSize);
    expect(paginationServiceMock.changePageSize).toHaveBeenCalledWith(pageSize);
  });

  it('should call searchConfigManagementActions when subscribed', fakeAsync(() => {
    const sub = component.cmAction$.subscribe();
    tick(1100);

    expect(
      configActionServiceMock.searchConfigManagementActions
    ).toHaveBeenCalled();

    const lastArgs = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.mostRecent().args;
    const [page, pageSize, sortBy, sortDirection = {} as any] = lastArgs;

    expect(page).toBe(CM_ACTION_DEFAULT_PAGE);
    expect(pageSize).toBe(CM_ACTION_DEFAULT_PAGE_SIZE);
    expect(sortBy).toBe('createdDate');
    expect(sortDirection).toBe('DESC');
    sub.unsubscribe();
  }));

  it('should call searchConfigManagementActions with the selected column sort', fakeAsync(() => {
    const sub = component.cmAction$.subscribe();

    applySortQueryParams('taskName', SortDirection.ASC);
    tick();

    expect(
      configActionServiceMock.searchConfigManagementActions
    ).toHaveBeenCalledWith(
      CM_ACTION_DEFAULT_PAGE,
      CM_ACTION_DEFAULT_PAGE_SIZE,
      'taskName',
      SortDirection.ASC,
      jasmine.any(Object)
    );
    sub.unsubscribe();
  }));

  it('should fall back to the default sort when the direction is NONE', fakeAsync(() => {
    applySortQueryParams('taskName', SortDirection.ASC);
    const sub = component.cmAction$.subscribe();
    tick();

    const callsBefore = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.count();

    // A third click emits NONE, which clears both params and restores the default order.
    component.onSortChange({
      parameter: 'taskName',
      direction: SortDirection.NONE,
    });
    applySortQueryParams(null, null);
    tick();

    expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
      page: undefined,
      sortBy: undefined,
      sortDirection: undefined,
    });
    expect(
      configActionServiceMock.searchConfigManagementActions
    ).toHaveBeenCalledWith(
      CM_ACTION_DEFAULT_PAGE,
      CM_ACTION_DEFAULT_PAGE_SIZE,
      'createdDate',
      'DESC',
      jasmine.any(Object)
    );
    expect(
      (
        configActionServiceMock.searchConfigManagementActions as jasmine.Spy
      ).calls.count()
    ).toBe(callsBefore + 1);
    sub.unsubscribe();
  }));

  it('should write the selected sort into the query params and reset the page', () => {
    component.onSortChange({
      parameter: 'status',
      direction: SortDirection.ASC,
    });

    expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
      page: undefined,
      sortBy: 'status',
      sortDirection: SortDirection.ASC,
    });
  });

  it('should ignore an unknown sort field from the URL', fakeAsync(() => {
    const sub = component.cmAction$.subscribe();

    applySortQueryParams('dropTable', SortDirection.ASC);
    tick();

    const [, , sortBy, sortDirection] = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.mostRecent().args;
    expect(sortBy).toBe('createdDate');
    expect(sortDirection).toBe('DESC');
    sub.unsubscribe();
  }));

  it('should reload the list and close the detail pane when a cm action was decided', fakeAsync(() => {
    const sub = component.cmAction$.subscribe();
    tick();
    const callsBefore = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.count();

    component.onCmActionDecided();
    tick();

    expect(
      (
        configActionServiceMock.searchConfigManagementActions as jasmine.Spy
      ).calls.count()
    ).toBe(callsBefore + 1);
    expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
      id: undefined,
    });
    sub.unsubscribe();
  }));

  it('should call searchConfigManagementActions with the correct filter parameter when onChangeFilter is called (status)', () => {
    component.onChangeFilter({ status: 'all' as ConfigActionStatus });

    const sub = component.cmAction$.subscribe(() => {
      const lastArgs = (
        configActionServiceMock.searchConfigManagementActions as jasmine.Spy
      ).calls.mostRecent().args;
      const [, , , , filters = {} as any] = lastArgs;
      expect(filters.status).toBeUndefined();
    });
    sub.unsubscribe();
  });

  it('should call searchConfigManagementActions with the correct filter parameter when onChangeFilter is called (operation)', () => {
    component.onChangeFilter({ operation: 'all' as ConfigActionOperation });

    const sub = component.cmAction$.subscribe(() => {
      const lastArgs = (
        configActionServiceMock.searchConfigManagementActions as jasmine.Spy
      ).calls.mostRecent().args;
      const [, , , , filters = {} as any] = lastArgs;
      expect(filters.operation).toBeUndefined();
    });
    sub.unsubscribe();
  });

  it('should call searchConfigManagementActions with the correct filter parameter when onChangeFilter is called (loopType)', () => {
    component.onChangeFilter({ loopType: 'all' as ConfigActionLoopType });

    const sub = component.cmAction$.subscribe(() => {
      const lastArgs = (
        configActionServiceMock.searchConfigManagementActions as jasmine.Spy
      ).calls.mostRecent().args;
      const [, , , , filters = {} as any] = lastArgs;
      expect(filters.loopType).toBeUndefined();
    });
    sub.unsubscribe();
  });

  it('should call searchConfigManagementActions with the correct taskId when provided', () => {
    taskIdSubject.next(['f2234c4f-1e9e-4c4e-b97f-33977168b7a0']);

    fixture = TestBed.createComponent(CmActionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    const sub = component.cmAction$.subscribe();
    const lastArgs = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.mostRecent().args;
    const [, , , , filters = {} as any] = lastArgs;
    expect(filters.taskId).toBe('f2234c4f-1e9e-4c4e-b97f-33977168b7a0');
    sub.unsubscribe();
  });

  it('should call searchConfigManagementActions with undefined taskId when no taskIds', () => {
    taskIdSubject.next([]);

    const sub = component.cmAction$.subscribe(() => {
      const lastArgs = (
        configActionServiceMock.searchConfigManagementActions as jasmine.Spy
      ).calls.mostRecent().args;
      const [, , , , filters = {} as any] = lastArgs;
      expect(filters.taskId).toBeUndefined();
    });
    sub.unsubscribe();
  });

  it('should ignore a restricted status coming from the URL for MVP users', () => {
    statusFilterSubject.next(
      ConfigActionStatus.ACTIVATION_COMPLETED_UNSYNC as string
    );

    fixture = TestBed.createComponent(CmActionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    const sub = component.cmAction$.subscribe();
    const [, , , , filters = {} as any] = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.mostRecent().args;

    expect(filters.status).toBeUndefined();
    sub.unsubscribe();
  });

  it('should call onChangeFilter with cleared values when filterValue is falsy', () => {
    spyOn(component, 'onChangeFilter').and.callThrough();
    statusFilterSubject.next(null);
    expect(component.onChangeFilter).toHaveBeenCalledWith({ id: undefined });
  });

  it('should clear query param when filter value is all', () => {
    component.onChangeFilter({ id: undefined, status: 'all' });

    expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
      id: undefined,
      status: null,
    });
  });

  it('should correctly map column values from ConfigManagementAction', () => {
    const mockAction: ConfigManagementAction = {
      status: 'PENDING',
      modifiedManagedObjectName: 'Node123',
      taskId: 'task789',
      createdDate: '2024-12-31',
      priority: 3,
      approval: true,
      modifiedCellList: ['cell-1', 'cell-2'],
    } as unknown as ConfigManagementAction;

    const valueOf = (key: string) =>
      component
        .columns()
        .find(col => col.key === key)
        ?.value(mockAction);

    expect(valueOf('object')).toBe('Node123');
    expect(valueOf('taskId')).toBe('task789');
    expect(valueOf('createdAt')).toBe('2024-12-31');
    expect(valueOf('priority')).toBe('3');
    expect(valueOf('modifiedCellList')).toBe('cell-1, cell-2');
    expect(valueOf('approval')).toBe('cmAction.list.enum.boolean.true');
    expect(valueOf('nfType')).toBe('');
  });

  it('should translate enum cell values', () => {
    const mockAction = {
      operation: ConfigActionOperation.CREATE,
      loopType: ConfigActionLoopType.CLOSE,
    } as ConfigManagementAction;

    const valueOf = (key: string) =>
      component
        .columns()
        .find(col => col.key === key)
        ?.value(mockAction);

    expect(valueOf('operation')).toBe('cmAction.list.enum.operation.create');
    expect(valueOf('loopType')).toBe('cmAction.list.enum.loopType.close');
  });

  it('should expose a column for every configured field plus the actions column', () => {
    expect(component.columns()).toHaveSize(CM_ACTION_COLUMNS.length + 1);
  });

  it('should apply date filter when filter is provided', () => {
    const mockFilter = {
      parameter: 'testColumn',
      operator: FilterOperator.EQUAL,
      value: 'some-value',
    };

    component.onDateFilterChange({
      parameter: 'testColumn',
      filter: mockFilter,
    });

    expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
      filter: mockFilter,
    });
  });

  it('should reset date filter when onDateFilterChange is called with undefined', () => {
    component.onDateFilterChange(undefined);

    expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
      filter: undefined,
    });
  });

  it('should omit aaiServiceReference when blank or whitespace only', fakeAsync(() => {
    sliceIdSubject.next('   ');
    tick(801);

    const sub = component.cmAction$.subscribe();
    const [, , , , filters] = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.mostRecent().args;

    expect(filters.aaiServiceReference).toBeUndefined();
    sub.unsubscribe();
  }));

  it('should omit modifiedManagedObjectName when blank', fakeAsync(() => {
    resourceSubject.next('');
    tick(801);

    const sub = component.cmAction$.subscribe();
    const [, , , , filters] = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.mostRecent().args;

    expect(filters.modifiedManagedObjectName).toBeUndefined();
    sub.unsubscribe();
  }));

  it('should omit actorName when blank', fakeAsync(() => {
    actorNameFilterSubject.next('');
    tick(801);

    const sub = component.cmAction$.subscribe();
    const [, , , , filters] = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.mostRecent().args;

    expect(filters.actorName).toBeUndefined();
    sub.unsubscribe();
  }));

  it('should omit configType when blank', fakeAsync(() => {
    configTypeFilterSubject.next('');
    tick(801);

    const sub = component.cmAction$.subscribe();
    const [, , , , filters] = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.mostRecent().args;

    expect(filters.configType).toBeUndefined();
    sub.unsubscribe();
  }));

  it('should omit approvedBy when blank', fakeAsync(() => {
    approvedBySubject.next('');
    tick(801);

    const sub = component.cmAction$.subscribe();
    const [, , , , filters] = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.mostRecent().args;

    expect(filters.userId).toBeUndefined();
    sub.unsubscribe();
  }));

  it('should send the approvedBy query param as userId search field', () => {
    approvedBySubject.next('  user-1  ');

    fixture = TestBed.createComponent(CmActionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    const sub = component.cmAction$.subscribe();
    const [, , , , filters] = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.mostRecent().args;

    expect(filters.userId).toBe('user-1');
    expect(filters.approvedBy).toBeUndefined();
    sub.unsubscribe();
  });

  it('should keep "all" as a search term for text filters', () => {
    actorNameFilterSubject.next('all');

    fixture = TestBed.createComponent(CmActionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    const sub = component.cmAction$.subscribe();
    const [, , , , filters] = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.mostRecent().args;

    expect(filters.actorName).toBe('all');
    sub.unsubscribe();
  });

  it('should drop "all" as the reset sentinel of enum filters', () => {
    statusFilterSubject.next('all');

    fixture = TestBed.createComponent(CmActionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    const sub = component.cmAction$.subscribe();
    const [, , , , filters] = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.mostRecent().args;

    expect(filters.status).toBeUndefined();
    sub.unsubscribe();
  });

  it('should trim and join multi value task ids', () => {
    taskIdSubject.next(['  task-1 ', '   ', 'task-2']);

    fixture = TestBed.createComponent(CmActionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    const sub = component.cmAction$.subscribe();
    const [, , , , filters] = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.mostRecent().args;

    expect(filters.taskId).toBe('task-1,task-2');
    sub.unsubscribe();
  });

  it('should omit start/end created dates when filter has none', fakeAsync(() => {
    filterSubject.next(null);
    tick(301);

    const sub = component.cmAction$.subscribe();
    const [, , , , filters] = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.mostRecent().args;

    expect(filters.startCreatedDate).toBeUndefined();
    expect(filters.endCreatedDate).toBeUndefined();
    sub.unsubscribe();
  }));

  it('should map a date range from the filter query param to the search fields', () => {
    filterSubject.next(
      buildDateRangeFilter('createdAt', '2026-01-01T00:00', '2026-01-02T23:59')
    );

    fixture = TestBed.createComponent(CmActionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    const sub = component.cmAction$.subscribe();
    const [, , , , filters] = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.mostRecent().args;

    expect(filters.startCreatedDate).toBe('2026-01-01T00:00Z');
    expect(filters.endCreatedDate).toBe('2026-01-02T23:59Z');
    sub.unsubscribe();
  });

  it('should map the range of an additional date column to its own search fields', () => {
    filterSubject.next(
      buildDateRangeFilter(
        'executedDate',
        '2026-02-01T00:00',
        '2026-02-02T23:59'
      )
    );

    fixture = TestBed.createComponent(CmActionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    const sub = component.cmAction$.subscribe();
    const [, , , , filters] = (
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy
    ).calls.mostRecent().args;

    expect(filters.startExecutedDate).toBe('2026-02-01T00:00Z');
    expect(filters.endExecutedDate).toBe('2026-02-02T23:59Z');
    expect(filters.startCreatedDate).toBeUndefined();
    sub.unsubscribe();
  });

  it('should not re-call service when taskId array content does not change', () => {
    const serviceSpy =
      configActionServiceMock.searchConfigManagementActions as jasmine.Spy;

    taskIdSubject.next(['A', 'B']);
    fixture = TestBed.createComponent(CmActionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.cmAction$.subscribe();

    const countAfterFirst = serviceSpy.calls.count();

    taskIdSubject.next(['A', 'B']);
    fixture = TestBed.createComponent(CmActionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.cmAction$.subscribe();

    const countAfterSame = serviceSpy.calls.count();

    expect(countAfterSame).toBe(countAfterFirst + 1);

    taskIdSubject.next(['A', 'C']);
    fixture = TestBed.createComponent(CmActionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.cmAction$.subscribe();

    const countAfterChange = serviceSpy.calls.count();

    expect(countAfterChange).toBe(countAfterSame + 1);
  });

  it('onFilterChange should trim and update the query param of the column', () => {
    const sliceColumn = columnByKey('aaiServiceReference');

    component.onFilterChange(sliceColumn, '  S-777  ');
    expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
      id: undefined,
      aaiServiceReference: 'S-777',
    });

    component.onFilterChange(sliceColumn, ' ');
    expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
      id: undefined,
      aaiServiceReference: undefined,
    });
  });

  it('onFilterChange should use the dedicated query param of a column', () => {
    component.onFilterChange(columnByKey('approvedBy'), '  A-777  ');
    expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
      id: undefined,
      approvedBy: 'A-777',
    });

    component.onFilterChange(columnByKey('object'), '  MO-777 ');
    expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
      id: undefined,
      modifiedManagedObjectName: 'MO-777',
    });

    component.onFilterChange(columnByKey('actorName'), '');
    expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
      id: undefined,
      actorName: undefined,
    });
  });

  it('onFilterChange should trim and update the configType query param', () => {
    const configTypeColumn = columnByKey('configType');

    component.onFilterChange(configTypeColumn, '  CO-777 ');
    expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
      id: undefined,
      configType: 'CO-777',
    });

    component.onFilterChange(configTypeColumn, '');
    expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
      id: undefined,
      configType: undefined,
    });
  });

  it('onFilterChange should trim and update the workflowName query param', () => {
    const workflowNameColumn = columnByKey('workflowName');

    component.onFilterChange(workflowNameColumn, '  WF-777  ');
    expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
      id: undefined,
      workflowName: 'WF-777',
    });

    component.onFilterChange(workflowNameColumn, ' ');
    expect(queryParamServiceMock.updateQueryParam).toHaveBeenCalledWith({
      id: undefined,
      workflowName: undefined,
    });
  });

  it('detail$ should be undefined when id is falsy', () => {
    idSubject.next(null);

    let result: any;
    const sub = component.detail$.subscribe(v => (result = v));
    expect(result).toBeUndefined();
    sub.unsubscribe();
  });

  it('detail$ should fetch by id and map first item', () => {
    (
      configActionServiceMock.listConfigManagementActions as jasmine.Spy
    ).and.callFake((page?: number, size?: number, params?: any) => {
      if (params?.configManagementActionId === 'ABC') {
        return of({
          items: [{ id: 'ABC', foo: 1 }],
        } as unknown as ConfigManagementActionListResponse);
      }
      return of({ items: [] } as unknown as ConfigManagementActionListResponse);
    });

    idSubject.next('ABC');

    let result: any;
    const sub = component.detail$.subscribe(v => (result = v));
    expect(result).toEqual({ id: 'ABC', foo: 1 });
    sub.unsubscribe();
  });

  it('stripQuotes should remove only matching quotes', () => {
    expect(component.stripQuotes('"abc"')).toBe('abc');
    expect(component.stripQuotes("'abc'")).toBe('abc');
    expect(component.stripQuotes('"ab\'c"')).toBe(`ab'c`);
    expect(component.stripQuotes('abc')).toBe('abc');
    expect(component.stripQuotes('')).toBe('');
  });

  it('should call listConfigManagementActions when permission is false', () => {
    configActionServiceMock.listConfigManagementActions.calls.reset();
    configActionServiceMock.searchConfigManagementActions.calls.reset();

    hasPermissionPipeMock.transform.and.returnValue(of(false));

    (
      configActionServiceMock.listConfigManagementActions as jasmine.Spy
    ).and.returnValue(
      of(configActionsListResponse as ConfigManagementActionListResponse)
    );

    fixture = TestBed.createComponent(CmActionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    component.cmAction$.subscribe();

    expect(
      configActionServiceMock.listConfigManagementActions
    ).toHaveBeenCalled();

    expect(
      configActionServiceMock.searchConfigManagementActions
    ).not.toHaveBeenCalled();
  });

  it('should call downloadConfigManagementActions on export', () => {
    const spy = jasmine.createSpy().and.returnValue(of(new Blob()));
    configActionServiceMock.downloadConfigManagementActions = spy;

    component.exportCMActions();

    expect(spy).toHaveBeenCalled();
  });

  it('should save file when export succeeds', () => {
    const blob = new Blob(['test']);

    configActionServiceMock.downloadConfigManagementActions = jasmine
      .createSpy()
      .and.returnValue(of(blob));

    component.exportCMActions();

    expect(fileSaverMock.save).toHaveBeenCalledWith(blob, 'cm-actions.csv');
  });

  it('should export with the sort currently shown in the table', () => {
    const spy = jasmine.createSpy().and.returnValue(of(new Blob()));
    configActionServiceMock.downloadConfigManagementActions = spy;

    applySortQueryParams('status', SortDirection.ASC);
    component.exportCMActions();

    const [sortBy, sortDirection] = spy.calls.mostRecent().args;
    expect(sortBy).toBe('status');
    expect(sortDirection).toBe('ASC');
  });

  it('should export with the default sort when no column is sorted', () => {
    const spy = jasmine.createSpy().and.returnValue(of(new Blob()));
    configActionServiceMock.downloadConfigManagementActions = spy;

    component.exportCMActions();

    const [sortBy, sortDirection] = spy.calls.mostRecent().args;
    expect(sortBy).toBe('createdDate');
    expect(sortDirection).toBe('DESC');
  });

  it('should pass visible columns from localStorage', () => {
    localStorage.setItem(
      'cm-actions-table',
      JSON.stringify([
        { key: 'status', visible: true },
        { key: 'object', visible: true },
        { key: 'taskId', visible: false },
      ])
    );

    const spy = jasmine.createSpy().and.returnValue(of(new Blob()));
    configActionServiceMock.downloadConfigManagementActions = spy;

    component.exportCMActions();

    const request = spy.calls.mostRecent().args[3];

    expect(request).toEqual({
      visibleColumns: [
        {
          key: 'status',
          label: 'cmAction.list.fields.status',
        },
        {
          key: 'modifiedManagedObjectName',
          label: 'cmAction.list.fields.modifiedManagedObjectName',
        },
      ],
    });
  });

  it('should fall back to the default visible columns when localStorage contains invalid JSON', () => {
    localStorage.setItem(CM_ACTION_TABLE_STORAGE_KEY, 'invalid-json');

    const result = (component as any).getVisibleColumns();
    const expected = (component as any)
      .availableColumns()
      .filter((column: { visible?: boolean }) => column.visible)
      .map((column: { field: string }) => column.field);

    expect(result.map((column: { key: string }) => column.key)).toEqual(
      expected
    );
    localStorage.removeItem(CM_ACTION_TABLE_STORAGE_KEY);
  });

  describe('column configuration', () => {
    it('should expose the requested initial column order before user preferences are stored', () => {
      const keys = component.availableColumns().map(column => column.key);

      expect(keys.slice(0, 5)).toEqual([
        'object',
        'status',
        'executedDate',
        'loopType',
        'activationErrorDescription',
      ]);
    });

    it('should use unique column keys', () => {
      const keys = CM_ACTION_COLUMNS.map(column => column.key);
      expect(new Set(keys).size).toBe(keys.length);
    });

    it('should use unique filter query params', () => {
      const params = CM_ACTION_COLUMNS.filter(
        column => column.filter !== 'none'
      ).map(getCmActionQueryParam);
      expect(new Set(params).size).toBe(params.length);
    });

    it('should not use query params reserved by the page', () => {
      const collisions = CM_ACTION_COLUMNS.filter(column =>
        CM_ACTION_RESERVED_QUERY_PARAMS.includes(getCmActionQueryParam(column))
      );
      expect(collisions).toEqual([]);
    });

    it('should define a date range for every dateRange filter', () => {
      const incomplete = CM_ACTION_COLUMNS.filter(
        column => column.filter === 'dateRange' && !column.dateRange
      );
      expect(incomplete).toEqual([]);
    });

    it('should define enum values and a translation prefix for every enum filter', () => {
      const incomplete = CM_ACTION_COLUMNS.filter(
        column =>
          column.filter === 'enum' &&
          (!column.enumValues?.length || !column.enumTranslationPrefix)
      );
      expect(incomplete).toEqual([]);
    });

    it('should provide dropdown options for every enum column', () => {
      const options = component.filterOptions();
      CM_ACTION_COLUMNS.filter(column => column.filter === 'enum').forEach(
        column => {
          expect(options[column.key]).toHaveSize(
            column.enumValues!.length -
              (column.restrictedEnumValues?.length ?? 0)
          );
        }
      );
    });

    it('should hide restricted enum values from MVP users', () => {
      const options = component.filterOptions();
      const statusOptions = options['status'].map(option => option.value);

      expect(component.isMvpUser()).toBeTrue();
      expect(statusOptions).not.toContain(
        ConfigActionStatus.ACTIVATION_COMPLETED_UNSYNC
      );
    });

    it('should render a header filter for every visible filterable column', () => {
      fixture.detectChanges();
      const host: HTMLElement = fixture.nativeElement;

      CM_ACTION_COLUMNS.filter(
        column => column.visible && column.filter !== 'none'
      ).forEach(column => {
        expect(host.querySelector(`.qa_cm_filter_${column.key}`))
          .withContext(`header filter for column ${column.key}`)
          .toBeTruthy();
      });
    });

    it('should not render a header filter for a hidden column', () => {
      fixture.detectChanges();
      const host: HTMLElement = fixture.nativeElement;

      expect(host.querySelector('.qa_cm_filter_vendorName')).toBeNull();
    });

    it('should render a sort control for every visible sortable column', () => {
      fixture.detectChanges();
      const host: HTMLElement = fixture.nativeElement;

      // Asserted rather than branched on: with sorting disabled there is nothing to find and
      // every expectation below would pass without looking at anything.
      expect(component.canSort()).toBeTrue();

      CM_ACTION_COLUMNS.filter(
        column => column.visible && column.sorting
      ).forEach(column => {
        expect(host.querySelector(`.qa_${column.key}_header tnap-sort`))
          .withContext(`sort control for column ${column.key}`)
          .toBeTruthy();
      });
    });

    it('should not render a sort control for a visible non-sortable column', () => {
      fixture.detectChanges();
      const host: HTMLElement = fixture.nativeElement;

      expect(component.canSort()).toBeTrue();

      CM_ACTION_COLUMNS.filter(
        column => column.visible && !column.sorting
      ).forEach(column => {
        expect(host.querySelector(`.qa_${column.key}_header tnap-sort`))
          .withContext(`no sort control for non-sortable column ${column.key}`)
          .toBeNull();
      });
    });

    it('should name every sort control after its column', () => {
      // The library's tnap-sort sets aria-label = columnLabel only (the sort state is
      // conveyed by aria-sort on the <th>, not the button itself).
      applySortQueryParams('createdDate', SortDirection.ASC);
      fixture.detectChanges();
      const host: HTMLElement = fixture.nativeElement;

      CM_ACTION_COLUMNS.filter(
        column => column.visible && column.sorting
      ).forEach(column => {
        const sortButton = host.querySelector(
          `.qa_${column.key}_header tnap-sort button`
        );

        expect(sortButton)
          .withContext(`sort control for column ${column.key}`)
          .toBeTruthy();
        // aria-label = translated column label (labelKey in tests, since translations are not loaded)
        expect(sortButton?.getAttribute('aria-label'))
          .withContext(`accessible name of sort control ${column.key}`)
          .toBe(column.labelKey);
      });
    });

    it('should mark only the sorted column as active', () => {
      applySortQueryParams('createdDate', SortDirection.ASC);

      expect(component.sortDirections()['createdAt']).toBe(SortDirection.ASC);
      expect(component.sortDirections()['status']).toBe(SortDirection.NONE);
    });

    it('should expose the sort direction as aria-sort on the sorted header', () => {
      applySortQueryParams('createdDate', SortDirection.ASC);
      fixture.detectChanges();
      const host: HTMLElement = fixture.nativeElement;

      expect(
        host.querySelector('.qa_createdAt_header')?.getAttribute('aria-sort')
      ).toBe('ascending');
      expect(
        host.querySelector('.qa_status_header')?.getAttribute('aria-sort')
      ).toBeNull();
    });

    it('should expose descending aria-sort on the sorted header', () => {
      // The sort state is conveyed by aria-sort on the <th>; the button aria-label stays
      // as the column label regardless of direction (library behaviour).
      applySortQueryParams('createdDate', SortDirection.DESC);
      fixture.detectChanges();
      const host: HTMLElement = fixture.nativeElement;

      expect(
        host
          .querySelector('.qa_createdAt_header tnap-sort button')
          ?.getAttribute('aria-label')
      ).toBe('cmAction.list.fields.createdAt');
      expect(
        host.querySelector('.qa_createdAt_header')?.getAttribute('aria-sort')
      ).toBe('descending');
    });

    it('should reset the sort state of the previously sorted column', () => {
      applySortQueryParams('status', SortDirection.ASC);

      expect(component.sortDirections()['status']).toBe(SortDirection.ASC);

      applySortQueryParams('modifiedManagedObjectName', SortDirection.ASC);

      expect(component.sortDirections()['status']).toBe(SortDirection.NONE);
      expect(component.sortDirections()['object']).toBe(SortDirection.ASC);
    });
  });

  describe('the slice reference cell', () => {
    /** Re-renders the table with a single row, since the response feeds it on creation. */
    function renderRowWith(aaiServiceReference?: string): HTMLElement {
      (
        configActionServiceMock.searchConfigManagementActions as jasmine.Spy
      ).and.returnValue(
        of({
          items: [
            { ...configActionsListResponse.items[0], aaiServiceReference },
          ],
          totalCount: 1,
        } as ConfigManagementActionListResponse)
      );

      fixture = TestBed.createComponent(CmActionTableComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();

      return fixture.nativeElement as HTMLElement;
    }

    it('should link to the referenced slice, with an accessible name', () => {
      const link = renderRowWith('S-777').querySelector('a.link-like');

      expect(link).toBeTruthy();
      expect(link?.textContent?.trim()).toBe('S-777');
      expect(link?.getAttribute('href')).toContain(
        '/slice-management/slice-list'
      );

      // WCAG 2.5.3 Label in Name: the accessible name has to *contain* the visible text.
      // Asserted as containment rather than against a composed string so the wording of the
      // label can change without the guard turning into a copy of the template.
      const accessibleName = link?.getAttribute('aria-label') ?? '';
      expect(accessibleName).toContain('S-777');
      expect(accessibleName).toContain('cmAction.ariaLabel.redirectToSlice');
    });

    it('should render no anchor for a row without a slice reference', () => {
      const host = renderRowWith(undefined);

      // An href-less <a> has a generic role, which cannot carry an accessible name - so the
      // aria-label is a prohibited attribute and axe fails the route over it.
      expect(host.querySelector('a.link-like')).toBeNull();
      // The row itself did render, so the assertion above is not passing on an empty table.
      expect(host.textContent).toContain('Object1');
    });

    it('should navigate to the slice list on a plain click', () => {
      const link = renderRowWith('S-777').querySelector(
        'a.link-like'
      ) as HTMLElement;
      const navigateByUrl = spyOn(
        TestBed.inject(Router),
        'navigateByUrl'
      ).and.returnValue(Promise.resolve(true));

      link.dispatchEvent(
        new MouseEvent('click', { bubbles: true, cancelable: true })
      );

      expect(navigateByUrl).toHaveBeenCalled();
    });

    it('should leave a ctrl-click to the browser, so the slice opens in a new tab', () => {
      const link = renderRowWith('S-777').querySelector(
        'a.link-like'
      ) as HTMLElement;
      const navigateByUrl = spyOn(
        TestBed.inject(Router),
        'navigateByUrl'
      ).and.returnValue(Promise.resolve(true));
      const click = new MouseEvent('click', {
        bubbles: true,
        cancelable: true,
        ctrlKey: true,
      });

      // The point of this test is that nothing cancels the click, which means the browser
      // would follow the href for real and navigate the Karma context away. Record the state
      // the app left behind, then cancel it here so the test run survives.
      let preventedByApp: boolean | undefined;
      const stopRealNavigation = (event: Event): void => {
        preventedByApp = event.defaultPrevented;
        event.preventDefault();
      };
      document.addEventListener('click', stopRealNavigation);

      try {
        link.dispatchEvent(click);
      } finally {
        document.removeEventListener('click', stopRealNavigation);
      }

      // RouterLink deliberately hands a modifier click back to the browser instead of routing
      // in place. A handler that cancels the default on every click swallows that, and
      // open-in-new-tab silently does nothing - which is why the cell has none.
      expect(navigateByUrl).not.toHaveBeenCalled();
      expect(preventedByApp).toBeFalse();
    });
  });

  describe('without the search permission', () => {
    beforeEach(() => {
      hasPermissionPipeMock.transform.and.callFake(
        (permission: unknown) =>
          of(
            permission !==
              (TestBed.inject(PERMISSIONS_TOKEN) as any).VIEW_CM_ACTION_SEARCH
          ) as any
      );

      fixture = TestBed.createComponent(CmActionTableComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should only offer columns supported by the list endpoint', () => {
      expect(
        component.availableColumns().every(column => column.legacy)
      ).toBeTrue();
      expect(component.availableColumns()).toHaveSize(
        CM_ACTION_COLUMNS.filter(column => column.legacy).length
      );
    });

    it('should use a separate localStorage key', () => {
      expect(component.tableStorageKey()).toBe(
        CM_ACTION_TABLE_BASIC_STORAGE_KEY
      );
    });

    it('should not render header filters of non legacy columns', () => {
      const host: HTMLElement = fixture.nativeElement;

      expect(host.querySelector('.qa_cm_filter_configType')).toBeNull();
      expect(host.querySelector('.qa_cm_filter_status')).toBeTruthy();
    });

    it('should not offer sorting for the list endpoint', () => {
      const host: HTMLElement = fixture.nativeElement;

      expect(component.canSort()).toBeFalse();
      // With canSort() false, sorting.enabled is false for all columns so the
      // library does not render any tnap-sort inside the column headers.
      expect(host.querySelector('.qa_status_header tnap-sort')).toBeNull();
    });

    it('should still offer the restricted status option', () => {
      const options = component.filterOptions();
      const statusOptions = options['status'].map(option => option.value);

      expect(component.isMvpUser()).toBeFalse();
      expect(statusOptions).toContain(
        ConfigActionStatus.ACTIVATION_COMPLETED_UNSYNC
      );
      expect(statusOptions).toHaveSize(
        Object.values(ConfigActionStatus).length
      );
    });

    it('should send only legacy filter fields to the list endpoint', () => {
      configActionServiceMock.listConfigManagementActions.and.returnValue(
        of(configActionsListResponse as ConfigManagementActionListResponse)
      );
      configTypeFilterSubject.next('central');

      fixture = TestBed.createComponent(CmActionTableComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();

      const sub = component.cmAction$.subscribe();
      const [, , listFilters] = (
        configActionServiceMock.listConfigManagementActions as jasmine.Spy
      ).calls.mostRecent().args;

      expect(listFilters.configType).toBeUndefined();
      expect(listFilters.sortDate).toBe('createdDate');
      sub.unsubscribe();
    });
  });

  describe('detail fetch', () => {
    it('should set includePayload, because list responses omit it', () => {
      configActionServiceMock.listConfigManagementActions.calls.reset();
      configActionServiceMock.listConfigManagementActions.and.returnValue(
        of(configActionsListResponse as ConfigManagementActionListResponse)
      );

      const sub = component.detail$.subscribe();
      idSubject.next('action-11');

      const [, , detailFilters, includePayload] = (
        configActionServiceMock.listConfigManagementActions as jasmine.Spy
      ).calls.mostRecent().args;

      expect(detailFilters.configManagementActionId).toBe('action-11');
      expect(includePayload).toBeTrue();
      sub.unsubscribe();
    });

    it('should not fetch at all without a selected id', () => {
      configActionServiceMock.listConfigManagementActions.calls.reset();

      const sub = component.detail$.subscribe();
      idSubject.next(null);

      expect(
        configActionServiceMock.listConfigManagementActions
      ).not.toHaveBeenCalled();
      sub.unsubscribe();
    });
  });

  it('should use the default localStorage key with the search permission', () => {
    expect(component.tableStorageKey()).toBe(CM_ACTION_TABLE_STORAGE_KEY);
  });

  describe('while permissions are unresolved', () => {
    beforeEach(() => {
      hasPermissionPipeMock.transform.and.returnValue(NEVER);

      fixture = TestBed.createComponent(CmActionTableComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should not render the table before the permissions are known', () => {
      const host: HTMLElement = fixture.nativeElement;

      expect(component.permissionsResolved()).toBeFalse();
      expect(host.querySelector('tnap-data-table')).toBeNull();
    });

    it('should show a loading hint instead of a blank pane', () => {
      const host: HTMLElement = fixture.nativeElement;
      const loading = host.querySelector('.qa_cm_table_loading');

      expect(loading).toBeTruthy();
      expect(loading?.getAttribute('role')).toBe('status');
    });
  });

  describe('isCancelAllowed', () => {
    it('should return true for NEW status', () => {
      const row = { status: ConfigActionStatus.NEW } as ConfigManagementAction;
      expect(component.isCancelAllowed(row)).toBeTrue();
    });

    it('should return true for ACTIVATION_QUEUED status', () => {
      const row = {
        status: ConfigActionStatus.ACTIVATION_QUEUED,
      } as ConfigManagementAction;
      expect(component.isCancelAllowed(row)).toBeTrue();
    });

    it('should return true for WAITING_FOR_APPROVAL status', () => {
      const row = {
        status: ConfigActionStatus.WAITING_FOR_APPROVAL,
      } as ConfigManagementAction;
      expect(component.isCancelAllowed(row)).toBeTrue();
    });

    it('should return false for ACTIVATION_COMPLETED status', () => {
      const row = {
        status: ConfigActionStatus.ACTIVATION_COMPLETED,
      } as ConfigManagementAction;
      expect(component.isCancelAllowed(row)).toBeFalse();
    });

    it('should return false for other statuses', () => {
      const row = {
        status: ConfigActionStatus.ACTIVATION_SEND_FAILED,
      } as ConfigManagementAction;
      expect(component.isCancelAllowed(row)).toBeFalse();
    });
  });

  describe('isRowSelectable', () => {
    it('should delegate to isCancelAllowed and return true for cancellable status', () => {
      const row = { status: ConfigActionStatus.NEW } as ConfigManagementAction;
      spyOn(component, 'isCancelAllowed').and.returnValue(true);
      expect(component.isRowSelectable(row)).toBeTrue();
      expect(component.isCancelAllowed).toHaveBeenCalledWith(row);
    });

    it('should delegate to isCancelAllowed and return false for non-cancellable status', () => {
      const row = {
        status: ConfigActionStatus.ACTIVATION_COMPLETED,
      } as ConfigManagementAction;
      spyOn(component, 'isCancelAllowed').and.returnValue(false);
      expect(component.isRowSelectable(row)).toBeFalse();
    });
  });

  describe('cancelCmAction', () => {
    it('should open confirmation modal when row has configManagementActionId', () => {
      spyOn<any>(component, 'openConfirmationModal');
      const row = {
        configManagementActionId: 'action-123',
      } as ConfigManagementAction;
      component.cancelCmAction(row);
      expect((component as any).openConfirmationModal).toHaveBeenCalledWith([
        'action-123',
      ]);
    });

    it('should not open modal when row has no configManagementActionId', () => {
      spyOn<any>(component, 'openConfirmationModal');
      const row = {} as ConfigManagementAction;
      component.cancelCmAction(row);
      expect((component as any).openConfirmationModal).not.toHaveBeenCalled();
    });
  });

  describe('isBulkApproveAllowed', () => {
    it('should return true when all selected rows are waiting for approval', () => {
      component.selectedRowsState.set(
        new Map([
          [
            'a1',
            {
              configManagementActionId: 'a1',
              status: ConfigActionStatus.WAITING_FOR_APPROVAL,
            } as ConfigManagementAction,
          ],
          [
            'a2',
            {
              configManagementActionId: 'a2',
              status: ConfigActionStatus.WAITING_FOR_APPROVAL,
            } as ConfigManagementAction,
          ],
        ])
      );

      expect(component.isBulkApproveAllowed()).toBeTrue();
    });

    it('should return false when any selected row is not waiting for approval', () => {
      component.selectedRowsState.set(
        new Map([
          [
            'a1',
            {
              configManagementActionId: 'a1',
              status: ConfigActionStatus.WAITING_FOR_APPROVAL,
            } as ConfigManagementAction,
          ],
          [
            'a2',
            {
              configManagementActionId: 'a2',
              status: ConfigActionStatus.NEW,
            } as ConfigManagementAction,
          ],
        ])
      );

      expect(component.isBulkApproveAllowed()).toBeFalse();
    });

    it('should return false when no rows are selected', () => {
      component.selectedRowsState.set(new Map());
      expect(component.isBulkApproveAllowed()).toBeFalse();
    });
  });

  describe('confirmApproveCmActions', () => {
    let closedSubject: Subject<boolean>;
    let modalRefMock: jasmine.SpyObj<NgbModalRef> & {
      componentInstance: any;
      closed: any;
    };

    beforeEach(() => {
      closedSubject = new Subject<boolean>();
      modalRefMock = {
        componentInstance: {},
        closed: closedSubject.asObservable(),
      } as any;
      modalServiceMock.open.and.returnValue(modalRefMock);
    });

    it('should call approveConfigManagementActions when modal is confirmed', () => {
      component.selectedRowsState.set(
        new Map([
          [
            'action-1',
            {
              configManagementActionId: 'action-1',
              status: ConfigActionStatus.WAITING_FOR_APPROVAL,
            } as ConfigManagementAction,
          ],
          [
            'action-2',
            {
              configManagementActionId: 'action-2',
              status: ConfigActionStatus.WAITING_FOR_APPROVAL,
            } as ConfigManagementAction,
          ],
        ])
      );

      (
        configActionServiceMock.approveConfigManagementActions as jasmine.Spy
      ).and.returnValue(
        of({
          'action-1': 'Approval completed',
          'action-2': 'Approval completed',
        })
      );

      component.confirmApproveCmActions();
      closedSubject.next(true);

      expect(
        configActionServiceMock.approveConfigManagementActions
      ).toHaveBeenCalledWith({
        configManagementActions: ['action-1', 'action-2'],
      });
      expect(alertServiceMock.success).toHaveBeenCalled();
      expect(alertServiceMock.warn).not.toHaveBeenCalled();
    });

    it('should call alertService.warn when some approvals fail (partial failure)', () => {
      component.selectedRowsState.set(
        new Map([
          [
            'action-1',
            {
              configManagementActionId: 'action-1',
              status: ConfigActionStatus.WAITING_FOR_APPROVAL,
            } as ConfigManagementAction,
          ],
          [
            'action-2',
            {
              configManagementActionId: 'action-2',
              status: ConfigActionStatus.WAITING_FOR_APPROVAL,
            } as ConfigManagementAction,
          ],
        ])
      );

      (
        configActionServiceMock.approveConfigManagementActions as jasmine.Spy
      ).and.returnValue(
        of({
          'action-1': 'Approval completed',
          'action-2': 'not approved',
        })
      );

      component.confirmApproveCmActions();
      closedSubject.next(true);

      expect(alertServiceMock.success).toHaveBeenCalled();
      expect(alertServiceMock.warn).toHaveBeenCalled();
    });

    it('should not call approveConfigManagementActions when modal is dismissed', () => {
      component.selectedRowsState.set(
        new Map([
          [
            'action-1',
            {
              configManagementActionId: 'action-1',
              status: ConfigActionStatus.WAITING_FOR_APPROVAL,
            } as ConfigManagementAction,
          ],
        ])
      );

      component.confirmApproveCmActions();
      closedSubject.next(false);

      expect(
        configActionServiceMock.approveConfigManagementActions
      ).not.toHaveBeenCalled();
    });

    it('should unselect the approved rows so a later approval does not resend them', () => {
      component.selectedRowsState.set(
        new Map([
          [
            'action-1',
            {
              configManagementActionId: 'action-1',
              status: ConfigActionStatus.WAITING_FOR_APPROVAL,
            } as ConfigManagementAction,
          ],
          [
            'action-2',
            {
              configManagementActionId: 'action-2',
              status: ConfigActionStatus.WAITING_FOR_APPROVAL,
            } as ConfigManagementAction,
          ],
        ])
      );

      (
        configActionServiceMock.approveConfigManagementActions as jasmine.Spy
      ).and.returnValue(
        of({
          'action-1': 'Approval completed',
          'action-2': 'Approval completed',
        })
      );

      component.confirmApproveCmActions();
      closedSubject.next(true);

      expect(component.selectedRowsState().size).toBe(0);
      expect(component.checkedRowIds()).toEqual([]);
    });

    it('should unselect a row that the bulk endpoint refused as well', () => {
      component.selectedRowsState.set(
        new Map([
          [
            'action-1',
            {
              configManagementActionId: 'action-1',
              status: ConfigActionStatus.WAITING_FOR_APPROVAL,
            } as ConfigManagementAction,
          ],
        ])
      );

      (
        configActionServiceMock.approveConfigManagementActions as jasmine.Spy
      ).and.returnValue(of({ 'action-1': 'not approved' }));

      component.confirmApproveCmActions();
      closedSubject.next(true);

      expect(component.selectedRowsState().has('action-1')).toBeFalse();
    });

    it('should keep the selection until the bulk endpoint has answered', () => {
      component.selectedRowsState.set(
        new Map([
          [
            'action-1',
            {
              configManagementActionId: 'action-1',
              status: ConfigActionStatus.WAITING_FOR_APPROVAL,
            } as ConfigManagementAction,
          ],
        ])
      );

      const response = new Subject<{ [key: string]: string }>();
      (
        configActionServiceMock.approveConfigManagementActions as jasmine.Spy
      ).and.returnValue(response.asObservable());

      component.confirmApproveCmActions();
      closedSubject.next(true);

      expect(component.checkedRowIds()).toEqual(['action-1']);

      response.next({ 'action-1': 'Approval completed' });

      expect(component.checkedRowIds()).toEqual([]);
    });
  });

  describe('openConfirmationModal', () => {
    let closedSubject: Subject<boolean>;
    let modalRefMock: jasmine.SpyObj<NgbModalRef> & {
      componentInstance: any;
      closed: any;
    };

    beforeEach(() => {
      closedSubject = new Subject<boolean>();
      modalRefMock = {
        componentInstance: {},
        closed: closedSubject.asObservable(),
      } as any;
      modalServiceMock.open.and.returnValue(modalRefMock);
    });

    it('should call alertService.success when all cancellations succeed', () => {
      (
        configActionServiceMock.cancelConfigManagementActions as jasmine.Spy
      ).and.returnValue(
        of({
          'action-1': 'Cancellation completed',
          'action-2': 'Cancellation completed',
        })
      );

      (component as any).openConfirmationModal(['action-1', 'action-2']);
      closedSubject.next(true);

      expect(alertServiceMock.success).toHaveBeenCalled();
      expect(alertServiceMock.warn).not.toHaveBeenCalled();
    });

    it('should call alertService.warn when some cancellations fail (partial failure)', () => {
      (
        configActionServiceMock.cancelConfigManagementActions as jasmine.Spy
      ).and.returnValue(
        of({ 'action-1': 'Cancellation completed', 'action-2': 'Some error' })
      );

      (component as any).openConfirmationModal(['action-1', 'action-2']);
      closedSubject.next(true);

      expect(alertServiceMock.success).toHaveBeenCalled();
      expect(alertServiceMock.warn).toHaveBeenCalled();
    });

    it('should call only alertService.warn when all cancellations fail', () => {
      (
        configActionServiceMock.cancelConfigManagementActions as jasmine.Spy
      ).and.returnValue(of({ 'action-1': 'Some error' }));

      (component as any).openConfirmationModal(['action-1']);
      closedSubject.next(true);

      expect(alertServiceMock.success).not.toHaveBeenCalled();
      expect(alertServiceMock.warn).toHaveBeenCalled();
    });

    it('should not call cancelConfigManagementActions when modal is dismissed (confirm=false)', () => {
      (component as any).openConfirmationModal(['action-1']);
      closedSubject.next(false);

      expect(
        configActionServiceMock.cancelConfigManagementActions
      ).not.toHaveBeenCalled();
    });

    it('should unselect the cancelled rows and leave the rest selected', () => {
      component.selectedRowsState.set(
        new Map(
          ['action-1', 'action-2', 'action-3'].map(id => [
            id,
            {
              configManagementActionId: id,
              status: ConfigActionStatus.WAITING_FOR_APPROVAL,
            } as ConfigManagementAction,
          ])
        )
      );

      (
        configActionServiceMock.cancelConfigManagementActions as jasmine.Spy
      ).and.returnValue(
        of({
          'action-1': 'Cancellation completed',
          'action-2': 'Cancellation completed',
        })
      );

      (component as any).openConfirmationModal(['action-1', 'action-2']);
      closedSubject.next(true);

      expect(component.checkedRowIds()).toEqual(['action-3']);
    });
  });

  describe('onCheckAllCheckbox', () => {
    const selectableItem: ConfigManagementAction = {
      configManagementActionId: 'sel-1',
      status: ConfigActionStatus.NEW,
    } as ConfigManagementAction;

    const nonSelectableItem: ConfigManagementAction = {
      configManagementActionId: 'non-sel-1',
      status: ConfigActionStatus.ACTIVATION_COMPLETED,
    } as ConfigManagementAction;

    beforeEach(() => {
      (
        configActionServiceMock.searchConfigManagementActions as jasmine.Spy
      ).and.returnValue(
        of({ items: [selectableItem, nonSelectableItem], totalCount: 2 })
      );
      fixture = TestBed.createComponent(CmActionTableComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      component.cmAction$.subscribe();
    });

    it('should add only selectable items when checked=true', () => {
      component.onCheckAllCheckbox(true);
      expect(component.selectedRowsState().has('sel-1')).toBeTrue();
      expect(component.selectedRowsState().has('non-sel-1')).toBeFalse();
    });

    it('should remove all current page items when checked=false', () => {
      component.onCheckAllCheckbox(true);
      component.onCheckAllCheckbox(false);
      expect(component.selectedRowsState().size).toBe(0);
    });
  });

  describe('onRowCheckedChange', () => {
    it('should add item to selectedRowsState when checked and selectable', () => {
      const row = {
        configManagementActionId: 'row-1',
        status: ConfigActionStatus.NEW,
      } as ConfigManagementAction;
      component.onRowCheckedChange({ row, checked: true, id: 'row-1' });
      expect(component.selectedRowsState().has('row-1')).toBeTrue();
    });

    it('should remove item from selectedRowsState when unchecked', () => {
      const row = {
        configManagementActionId: 'row-1',
        status: ConfigActionStatus.NEW,
      } as ConfigManagementAction;
      component.onRowCheckedChange({ row, checked: true, id: 'row-1' });
      component.onRowCheckedChange({ row, checked: false, id: 'row-1' });
      expect(component.selectedRowsState().has('row-1')).toBeFalse();
    });

    it('should not add item when row is not selectable', () => {
      const row = {
        configManagementActionId: 'row-2',
        status: ConfigActionStatus.ACTIVATION_COMPLETED,
      } as ConfigManagementAction;
      component.onRowCheckedChange({ row, checked: true, id: 'row-2' });
      expect(component.selectedRowsState().has('row-2')).toBeFalse();
    });
  });

  describe('checkedRowIds', () => {
    it('should only include selectable items that are on the current page', () => {
      const selectableItem: ConfigManagementAction = {
        configManagementActionId: 'chk-1',
        status: ConfigActionStatus.NEW,
      } as ConfigManagementAction;

      (
        configActionServiceMock.searchConfigManagementActions as jasmine.Spy
      ).and.returnValue(of({ items: [selectableItem], totalCount: 1 }));

      fixture = TestBed.createComponent(CmActionTableComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      component.cmAction$.subscribe();

      component.onRowCheckedChange({
        row: selectableItem,
        checked: true,
        id: 'chk-1',
      });

      expect(component.checkedRowIds()).toContain('chk-1');
    });

    it('should exclude non-selectable items even if in selectedRowsState', () => {
      const nonSelectableItem: ConfigManagementAction = {
        configManagementActionId: 'chk-2',
        status: ConfigActionStatus.ACTIVATION_COMPLETED,
      } as ConfigManagementAction;

      (
        configActionServiceMock.searchConfigManagementActions as jasmine.Spy
      ).and.returnValue(of({ items: [nonSelectableItem], totalCount: 1 }));

      fixture = TestBed.createComponent(CmActionTableComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      component.cmAction$.subscribe();

      component.selectedRowsState.set(new Map([['chk-2', nonSelectableItem]]));

      expect(component.checkedRowIds()).not.toContain('chk-2');
    });
  });
});
