/*
 * Copyright (c) 2025. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmActionDetailComponent } from './cm-action-detail.component';
import { SharedModule } from '../../../shared.module';
import { DateTimeFormatterPipe } from '../../../pipes/date-time-formatter.pipe';
import { TranslateModule } from '@ngx-translate/core';
import { YesNoPipe } from '../../../pipes/yes-no.pipe';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { AuthConfig, OAuthModule, UserInfo } from 'angular-oauth2-oidc';
import { AuthConfigService } from '../../../services/authconfig.service';
import { ACL_CONFIG } from '../../auth/injection-tokens';
import {
  provideHttpClient,
  withInterceptorsFromDi,
} from '@angular/common/http';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { AuthService, HasPermissionPipe } from '@portal-mfe/auth';
import {
  ActionsResponse,
  ConfigActionService,
  ConfigManagementAction,
  S3StorageService,
} from 'openapi/output';
import { HistoryService } from 'src/app/services/history.service';
import { BehaviorSubject, of } from 'rxjs';
import { ActionType, EntityType } from 'src/app/model/user-last-action.model';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { FileSaverService } from 'ngx-filesaver';
import { UserSettingsService } from 'src/app/services/user-settings.service';
import {
  defaultUserSettings,
  UserPreferencesModel,
} from 'src/app/model/user-preferences.model';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

// Mock AuthConfig
const authConfig: AuthConfig = {
  issuer: 'test',
  clientId: 'test',
  scope: 'openid profile email',
  redirectUri: window.location.origin,
};

describe('CmActionDetailComponent', () => {
  let component: CmActionDetailComponent;
  let fixture: ComponentFixture<CmActionDetailComponent>;
  let modalService: jasmine.SpyObj<NgbModal>;
  let authService: jasmine.SpyObj<AuthService>;
  let cmActionService: jasmine.SpyObj<ConfigActionService>;
  let s3StorageService: jasmine.SpyObj<S3StorageService>;
  let historyService: jasmine.SpyObj<HistoryService>;
  const fileSaverMock = jasmine.createSpyObj('FileSaverService', ['save']);
  const hasPermissionPipeMock = jasmine.createSpyObj('HasPermissionPipe', [
    'transform',
  ]);
  let preferences$: BehaviorSubject<UserPreferencesModel>;
  const userSettingsServiceMock = {
    getPreferences$: () => preferences$.asObservable(),
    updatePreferences: jasmine
      .createSpy('updatePreferences')
      .and.returnValue(of({})),
  };

  beforeEach(async () => {
    preferences$ = new BehaviorSubject<UserPreferencesModel>(
      defaultUserSettings
    );
    userSettingsServiceMock.updatePreferences.calls.reset();
    modalService = jasmine.createSpyObj('NgbModal', ['open']);
    authService = jasmine.createSpyObj('AuthService', [
      'getLoggedUserId',
      'getUserProfile',
      'getUserPermissions',
      'loadCachedUserProfile',
    ]);
    authService.getUserProfile.and.returnValue(
      of({ preferred_username: 'test-user-id' } as unknown as UserInfo)
    );
    authService.getUserPermissions.and.returnValue(of([])); // or whatever makes sense for your tests
    cmActionService = jasmine.createSpyObj('ConfigActionService', [
      'approveConfigManagementActions',
    ]);
    s3StorageService = jasmine.createSpyObj('S3StorageService', [
      'downloadS3Object',
    ]);
    historyService = jasmine.createSpyObj('HistoryService', [
      'createCMHistoryAction',
    ]);

    hasPermissionPipeMock.transform.and.returnValue(of(true));
    TestBed.overrideComponent(CmActionDetailComponent, {
      set: {
        providers: [
          {
            provide: HasPermissionPipe,
            useValue: hasPermissionPipeMock,
          },
        ],
      },
    });

    await TestBed.configureTestingModule({
      declarations: [CmActionDetailComponent, DateTimeFormatterPipe, YesNoPipe],
      imports: [SharedModule, TranslateModule.forRoot(), OAuthModule.forRoot()],
      providers: [
        DateTimeFormatterPipe,
        YesNoPipe,
        { provide: AuthConfig, useValue: authConfig },
        AuthConfigService,
        {
          provide: ACL_CONFIG,
          useValue: {},
        },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting(),
        { provide: NgbModal, useValue: modalService },
        { provide: AuthService, useValue: authService },
        { provide: ConfigActionService, useValue: cmActionService },
        { provide: S3StorageService, useValue: s3StorageService },
        { provide: HistoryService, useValue: historyService },
        {
          provide: PERMISSIONS_TOKEN,
          useValue: {
            VIEW_S3_STORAGE_BROWSER: [],
          },
        },
        { provide: FileSaverService, useValue: fileSaverMock },
        { provide: HasPermissionPipe, useValue: hasPermissionPipeMock },
        { provide: UserSettingsService, useValue: userSettingsServiceMock },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(CmActionDetailComponent);
    component = fixture.componentInstance;

    fixture.componentRef.setInput('detail', {
      configManagementActionId: '21ff7414-d8e9-47ef-8c40-b6d314930596',
      actorName: 'pci_rapp',
      payload: {
        attributes: {
          nRPCI: 450,
        },
      },
      modifiedManagedObjectName: 'network/cells/cell/445611193265418240',
      aaiObjectReference: 'network/cells/cell/445611193265418240',
      operation: 'update',
      loopType: 'open',
      status: 'activation_queued',
      createdDate: '2023-11-27T06:15:10Z',
      executedDate: '2023-11-27T12:59:44Z',
      cpsUrl:
        'Ericsson/anchors/MY5034_M-Koeniginstrasse-470510_73599249/nodes?xpath=%2FManagedElement[%40id%3D%27MY5034_M-Koeniginstrasse-470510_73599249%27]%2FGNBDUFunction[%40id%3D%271%27]%2FNRCellDU[%40id%3D%27MY5034_M-Koeniginstrasse-470510_GU1_84108972%27]',
      approval: true,
      userId: 'pci-rapp',
    });
    fixture.detectChanges();
  });

  const confirmedModalRef = () =>
    jasmine.createSpyObj<NgbModalRef>('NgbModalRef', ['close'], {
      componentInstance: {
        title: '',
        okText: '',
        text: '',
        confirmButton: '',
        cancelButton: '',
      },
      closed: of(true),
    });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should populate detailKeyValuesPair computed signal', () => {
    expect(component.detailKeyValuesPair()).toBeTruthy();
    expect(Array.isArray(component.detailKeyValuesPair())).toBeTrue();
  });

  // The persisted `onlyFilled` flag must reach the dictionary panes negated, and sections
  // without a single value have to disappear.
  describe('only filled preference', () => {
    const emitOnlyFilled = (onlyFilled: boolean) =>
      preferences$.next({
        ...defaultUserSettings,
        cmActionSettings: { onlyFilled: onlyFilled },
      });

    it('should show all properties while the switch is off', () => {
      emitOnlyFilled(false);

      expect(component.onlyFilled()).toBeFalse();
      expect(component.showAllProperties()).toBeTrue();
    });

    it('should hide empty properties while the switch is on', () => {
      emitOnlyFilled(true);

      expect(component.onlyFilled()).toBeTrue();
      expect(component.showAllProperties()).toBeFalse();
    });

    it('should keep only sections that still carry a value', () => {
      // No taskId, aaiObjectReference or cpsUrl, so the "other" section is empty.
      fixture.componentRef.setInput('detail', {
        configManagementActionId: 'only-general',
        actorName: 'pci_rapp',
        operation: 'update',
        status: 'activation_queued',
      });

      emitOnlyFilled(false);
      expect(component.visibleSections().map(section => section.name)).toEqual([
        'general',
        'other',
      ]);

      emitOnlyFilled(true);
      expect(component.visibleSections().map(section => section.name)).toEqual([
        'general',
      ]);
    });

    it('should persist the switch state', () => {
      component.changeOnlyFilled(true);

      expect(userSettingsServiceMock.updatePreferences).toHaveBeenCalledWith({
        cmActionSettings: { onlyFilled: true },
      });
    });
  });

  it('should emit close event', () => {
    let emitted = false;
    component.closeDetail.subscribe(() => {
      emitted = true;
    });
    component.closeDetail.emit();
    expect(emitted).toBe(true);
  });

  it('should call confirmApproveCmAction and process approval', () => {
    const modalRefMock = jasmine.createSpyObj<NgbModalRef>(
      'NgbModalRef',
      ['close'],
      {
        componentInstance: {
          title: '',
          okText: '',
          text: '',
          cancelButton: '',
        },
        closed: of(true),
      }
    );

    (
      cmActionService.approveConfigManagementActions as jasmine.Spy
    ).and.returnValue(
      of({
        '21ff7414-d8e9-47ef-8c40-b6d314930596': 'Approval completed',
      })
    );

    modalService.open.and.returnValue(modalRefMock);

    historyService.createCMHistoryAction.and.returnValue(
      of({} as ActionsResponse)
    );

    component.confirmApproveCmAction();

    expect(modalService.open).toHaveBeenCalled();
    expect(modalRefMock.componentInstance.title).toEqual(
      'cmAction.detail.modals.approve.title'
    );
    expect(modalRefMock.componentInstance.okText).toEqual(
      'cmAction.detail.modals.approve.okBtn'
    );
    expect(modalRefMock.componentInstance.text).toEqual(
      'cmAction.detail.modals.approve.text',
      { name: 'network/cells/cell/445611193265418240' }
    );
    expect(modalRefMock.componentInstance.cancelButton).toEqual(
      'common.buttons.cancel'
    );
    expect(cmActionService.approveConfigManagementActions).toHaveBeenCalledWith(
      {
        configManagementActions: ['21ff7414-d8e9-47ef-8c40-b6d314930596'],
        approval: true,
      }
    );
    expect(historyService.createCMHistoryAction).toHaveBeenCalledWith({
      type: ActionType.APPROVE,
      entity: EntityType.CMACTION,
      entityParams: {
        cmActionId: '21ff7414-d8e9-47ef-8c40-b6d314930596',
        cmActionNode: 'network/cells/cell/445611193265418240',
      },
    });
  });

  it('should call confirmRejectCmAction and process rejection', () => {
    const modalRefMock = jasmine.createSpyObj<NgbModalRef>(
      'NgbModalRef',
      ['close'],
      {
        componentInstance: {
          title: '',
          okText: '',
          text: '',
          confirmButton: '',
          cancelButton: '',
        },
        closed: of(true),
      }
    );

    (
      cmActionService.approveConfigManagementActions as jasmine.Spy
    ).and.returnValue(
      of({
        '21ff7414-d8e9-47ef-8c40-b6d314930596': 'Approval denied',
      })
    );

    modalService.open.and.returnValue(modalRefMock);
    historyService.createCMHistoryAction.and.returnValue(
      of({} as ActionsResponse)
    );

    component.confirmRejectCmAction();

    expect(modalService.open).toHaveBeenCalled();
    expect(modalRefMock.componentInstance.title).toEqual(
      'cmAction.detail.modals.reject.title'
    );
    expect(modalRefMock.componentInstance.okText).toEqual(
      'cmAction.detail.modals.reject.okBtn'
    );
    expect(modalRefMock.componentInstance.text).toEqual(
      'cmAction.detail.modals.reject.text',
      { name: 'network/cells/cell/445611193265418240' }
    );
    expect(modalRefMock.componentInstance.confirmButton).toEqual(
      'common.buttons.delete'
    );
    expect(modalRefMock.componentInstance.cancelButton).toEqual(
      'common.buttons.cancel'
    );
    expect(cmActionService.approveConfigManagementActions).toHaveBeenCalledWith(
      {
        configManagementActions: ['21ff7414-d8e9-47ef-8c40-b6d314930596'],
        approval: false,
      }
    );
    expect(historyService.createCMHistoryAction).toHaveBeenCalledWith({
      type: ActionType.REJECT,
      entity: EntityType.CMACTION,
      entityParams: {
        cmActionId: '21ff7414-d8e9-47ef-8c40-b6d314930596',
        cmActionNode: 'network/cells/cell/445611193265418240',
      },
    });
  });

  it('should report an approval and announce the decision after the history entry', () => {
    const success = spyOn(TestBed.inject(TnapAlertService), 'success');
    const calls: string[] = [];
    component.cmActionDecided.subscribe(() => calls.push('decided'));

    (
      cmActionService.approveConfigManagementActions as jasmine.Spy
    ).and.returnValue(
      of({
        '21ff7414-d8e9-47ef-8c40-b6d314930596': 'Approval completed',
      })
    );
    modalService.open.and.returnValue(confirmedModalRef());
    historyService.createCMHistoryAction.and.callFake(() => {
      calls.push('history');
      return of({} as ActionsResponse);
    });

    component.confirmApproveCmAction();

    expect(success).toHaveBeenCalled();
    // Announcing the decision closes the pane and destroys this component, so anything still
    // queued behind it in the pipe — the history POST — would be cancelled by takeUntilDestroyed.
    expect(calls).toEqual(['history', 'decided']);
  });

  it('should warn and keep the detail pane open when the approval is refused', () => {
    const warn = spyOn(TestBed.inject(TnapAlertService), 'warn');
    const cmActionDecided = spyOn(component.cmActionDecided, 'emit');

    (
      cmActionService.approveConfigManagementActions as jasmine.Spy
    ).and.returnValue(
      of({
        '21ff7414-d8e9-47ef-8c40-b6d314930596':
          'ConfigManagementAction is not awaiting approval (status=ACTIVATION_SEND_FAILED)',
      })
    );
    modalService.open.and.returnValue(confirmedModalRef());
    historyService.createCMHistoryAction.and.returnValue(
      of({} as ActionsResponse)
    );

    component.confirmApproveCmAction();

    expect(warn).toHaveBeenCalled();
    expect(cmActionDecided).not.toHaveBeenCalled();
    expect(historyService.createCMHistoryAction).not.toHaveBeenCalled();
  });

  it('should return early if no configManagementActionId in approve', () => {
    fixture.componentRef.setInput('detail', {
      ...component.detail(),
      configManagementActionId: undefined,
    });
    fixture.detectChanges();
    component.confirmApproveCmAction();
    expect(modalService.open).not.toHaveBeenCalled();
  });

  it('should return early if no configManagementActionId in reject', () => {
    fixture.componentRef.setInput('detail', {
      ...component.detail(),
      configManagementActionId: undefined,
    });
    fixture.detectChanges();
    component.confirmRejectCmAction();
    expect(modalService.open).not.toHaveBeenCalled();
  });

  it('should download file when download succeeds', () => {
    const blob = new Blob(['test']);
    (s3StorageService.downloadS3Object as jasmine.Spy).and.returnValue(
      of(blob)
    );
    component.downloadFile('sbi/huawei/payload/mml/test-file.txt');
    expect(s3StorageService.downloadS3Object).toHaveBeenCalledWith(
      'payload',
      'sbi/huawei/payload/mml/test-file.txt'
    );
    expect(fileSaverMock.save).toHaveBeenCalledWith(blob, 'test-file.txt');
  });

  it('should show S3 protected properties when user has S3 permission', () => {
    const config = (component as any).detailConfigWithPermissions();
    const otherSection = config.find((item: any) => item.name === 'other');

    expect(otherSection.properties).toContain(
      jasmine.objectContaining({
        key: 'sbiPayload',
      })
    );
  });

  it('should hide S3 protected properties when user lacks S3 permission', () => {
    hasPermissionPipeMock.transform.calls.reset();
    hasPermissionPipeMock.transform.and.returnValue(of(false));

    fixture = TestBed.createComponent(CmActionDetailComponent);
    component = fixture.componentInstance;

    fixture.componentRef.setInput('detail', {
      configManagementActionId: '21ff7414-d8e9-47ef-8c40-b6d314930596',
      actorName: 'pci_rapp',
      payload: { attributes: { nRPCI: 450 } },
    } as ConfigManagementAction);

    fixture.detectChanges();

    const config = (component as any).detailConfigWithPermissions();

    const otherSection = config.find((item: any) => item.name === 'other');

    expect(
      otherSection.properties.some(
        (p: any) => typeof p === 'object' && p.key === 'sbiPayload'
      )
    ).toBeFalse();
  });
});
