/*
 * Copyright (c) 2025. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  ElementRef,
  HostListener,
  inject,
  input,
  output,
  viewChild,
} from '@angular/core';
import {
  ConfigActionService,
  ConfigManagementAction,
  S3StorageService,
} from '../../../../../openapi/output';
import {
  CM_ACTION_APPROVAL_COMPLETED,
  CM_ACTION_APPROVAL_DENIED,
  CM_ACTION_DETAIL_CONFIG,
} from '../configuration';
import { flatMapObject } from '../../../helpers/flat-map-object';
import { DictionaryAttributePaneCustomRenderer } from '../../../model/dictionary-attribute-panel.model';
import { DictionaryAttributePaneRenderersService } from '../../../components/dictionary-attribute-pane/dictionary-attribute-pane-renderers.service';
import { ConfirmationModalComponent } from '../../../components/shared/confirmation-modal/confirmation-modal.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { filter, map, switchMap, take } from 'rxjs/operators';
import { HasPermissionPipe } from '@portal-mfe/auth';
import { HistoryService } from '../../../services/history.service';
import { ActionType, EntityType } from '../../../model/user-last-action.model';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { FocusRestoreService } from '@portal-mfe/data-table';
import { FileSaverService } from 'ngx-filesaver';
import { UserSettingsService } from '../../../services/user-settings.service';
import { defaultCmActionSettings } from '../../../model/user-preferences.model';
import { visibleDetailSections } from '../../../helpers/detail-sections';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-cm-action-detail',
  templateUrl: './cm-action-detail.component.html',
  styleUrls: ['./cm-action-detail.component.css'],
  standalone: false,
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [HasPermissionPipe],
})
export class CmActionDetailComponent implements AfterViewInit {
  readonly detail = input.required<ConfigManagementAction>();
  readonly closeDetail = output<void>();
  readonly cmActionDecided = output<void>();

  private readonly destroyRef = inject(DestroyRef);
  private readonly renderers = inject(DictionaryAttributePaneRenderersService);
  private readonly modalService = inject(NgbModal);
  private readonly translateService = inject(TranslateService);
  private readonly cmActionService = inject(ConfigActionService);
  private readonly alertService = inject(TnapAlertService);
  private readonly historyService = inject(HistoryService);
  protected readonly permissions = inject(PERMISSIONS_TOKEN);
  private readonly s3StorageService = inject(S3StorageService);
  private readonly fileSaverService = inject(FileSaverService);
  private readonly hasPermissionPipe = inject(HasPermissionPipe);
  private readonly hasS3Permission = toSignal(
    this.hasPermissionPipe.transform(this.permissions.VIEW_S3_STORAGE_BROWSER),
    { initialValue: false }
  );

  // Filters detail configuration properties based on configured permissions.
  protected readonly detailConfigWithPermissions = computed(() =>
    this.detailConfig.map(config => ({
      ...config,
      properties: config.properties.filter(property => {
        if (
          typeof property === 'object' &&
          !Array.isArray(property) &&
          property.requiresS3Permission
        ) {
          return this.hasS3Permission();
        }
        return true;
      }),
    }))
  );
  attributePaneTitle = viewChild<ElementRef>('attributePaneTitle');
  private readonly focusRestore = inject(FocusRestoreService);
  readonly detailKeyValuesPair = computed(() => flatMapObject(this.detail()));

  private readonly userSettingsService = inject(UserSettingsService);

  readonly onlyFilled = toSignal(
    this.userSettingsService.getPreferences$().pipe(
      // A preferences blob stored before this section existed carries no cmActionSettings,
      // and the service replays it unmerged until the GET resolves.
      map(
        preferences =>
          preferences.cmActionSettings?.onlyFilled ??
          defaultCmActionSettings.onlyFilled
      )
    ),
    { initialValue: defaultCmActionSettings.onlyFilled }
  );

  readonly showAllProperties = computed(() => !this.onlyFilled());

  readonly visibleSections = computed(() =>
    visibleDetailSections(
      this.detailConfigWithPermissions(),
      this.detailKeyValuesPair(),
      this.onlyFilled()
    )
  );

  changeOnlyFilled(onlyFilled: boolean): void {
    this.userSettingsService
      .updatePreferences({ cmActionSettings: { onlyFilled: onlyFilled } })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe();
  }

  protected readonly detailConfig = CM_ACTION_DETAIL_CONFIG;
  protected readonly detailPropertiesCustomRenderers: DictionaryAttributePaneCustomRenderer[] =
    [
      {
        key: 'createdDate',
        renderer: this.renderers.timestampToDateStringRenderer,
      },
      {
        key: 'executedDate',
        renderer: this.renderers.timestampToDateStringRenderer,
      },
      {
        key: 'confirmationDate',
        renderer: this.renderers.timestampToDateStringRenderer,
      },
      {
        key: 'status',
        renderer: this.renderers.translationRenderer(
          'cmAction.list.enum.status.'
        ),
      },
      {
        key: 'operation',
        renderer: this.renderers.translationRenderer(
          'cmAction.list.enum.operation.'
        ),
      },
      {
        key: 'loopType',
        renderer: this.renderers.translationRenderer(
          'cmAction.list.enum.loopType.'
        ),
      },
      { key: 'approval', renderer: this.renderers.yesNoRenderer },
    ];

  activeTab = 0;
  /** Only the details tab renders key/value rows, so only there does the switch do anything. */
  protected readonly DETAILS_TAB = 1;

  public confirmApproveCmAction(): void {
    const cmActionId = this.detail().configManagementActionId;
    if (!cmActionId) {
      return;
    }
    const modalApproveRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalApproveRef.componentInstance.title = this.translateService.instant(
      'cmAction.detail.modals.approve.title'
    );
    modalApproveRef.componentInstance.okText = this.translateService.instant(
      'cmAction.detail.modals.approve.okBtn'
    );
    modalApproveRef.componentInstance.text = this.translateService.instant(
      'cmAction.detail.modals.approve.text',
      {
        name: this.detail().modifiedManagedObjectName,
      }
    );
    modalApproveRef.componentInstance.cancelButton =
      this.translateService.instant('common.buttons.cancel');

    modalApproveRef.closed
      .pipe(
        take(1),
        filter((result: boolean) => result),
        switchMap(() =>
          this.cmActionService
            .approveConfigManagementActions({
              configManagementActions: [cmActionId],
              approval: true,
            })
            .pipe(
              map(response => this.reportDecision(response, cmActionId, true)),
              filter(applied => applied),
              switchMap(() =>
                this.historyService.createCMHistoryAction({
                  type: ActionType.APPROVE,
                  entity: EntityType.CMACTION,
                  entityParams: {
                    cmActionId,
                    cmActionNode: this.detail().modifiedManagedObjectName,
                  },
                })
              )
            )
        ),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(() => this.cmActionDecided.emit());
  }

  public confirmRejectCmAction(): void {
    const cmActionId = this.detail().configManagementActionId;
    if (!cmActionId) {
      return;
    }
    const modalConfRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalConfRef.componentInstance.title = this.translateService.instant(
      'cmAction.detail.modals.reject.title'
    );
    modalConfRef.componentInstance.okText = this.translateService.instant(
      'cmAction.detail.modals.reject.okBtn'
    );
    modalConfRef.componentInstance.text = this.translateService.instant(
      'cmAction.detail.modals.reject.text',
      {
        name: this.detail().modifiedManagedObjectName,
      }
    );
    modalConfRef.componentInstance.confirmButton =
      this.translateService.instant('common.buttons.delete');
    modalConfRef.componentInstance.cancelButton = this.translateService.instant(
      'common.buttons.cancel'
    );
    modalConfRef.closed
      .pipe(
        take(1),
        filter((result: boolean) => result),
        switchMap(() =>
          this.cmActionService
            .approveConfigManagementActions({
              configManagementActions: [cmActionId],
              approval: false,
            })
            .pipe(
              map(response => this.reportDecision(response, cmActionId, false)),
              filter(applied => applied),
              switchMap(() =>
                this.historyService.createCMHistoryAction({
                  type: ActionType.REJECT,
                  entity: EntityType.CMACTION,
                  entityParams: {
                    cmActionId,
                    cmActionNode: this.detail().modifiedManagedObjectName,
                  },
                })
              )
            )
        ),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(() => this.cmActionDecided.emit());
  }

  // The bulk endpoint answers 200 with a per-id message even when it refused the action (not
  // awaiting approval, not open-loop, unknown id), so the response has to be read to know whether
  // anything happened. Returns whether the decision was applied.
  private reportDecision(
    response: { [key: string]: string },
    cmActionId: string,
    approved: boolean
  ): boolean {
    const message = (response || {})[cmActionId];
    const scope = approved
      ? 'cmAction.detail.modals.approve'
      : 'cmAction.detail.modals.reject';
    const name = this.detail().modifiedManagedObjectName;

    if (
      message ===
      (approved ? CM_ACTION_APPROVAL_COMPLETED : CM_ACTION_APPROVAL_DENIED)
    ) {
      this.alertService.success(
        this.translateService.instant(`${scope}.successMessage`, { name }),
        { keepAfterRouteChange: true }
      );
      return true;
    }

    this.alertService.warn(
      this.translateService.instant(`${scope}.errorMessage`, { name, message }),
      { keepAfterRouteChange: true }
    );
    return false;
  }

  ngAfterViewInit() {
    this.attributePaneTitle()?.nativeElement.focus();
  }

  // For CM Action file downloads, 'payload' is currently used as a static bucket name.
  public downloadFile(key: string): void {
    const fileName = key.substring(key.lastIndexOf('/') + 1);
    this.s3StorageService
      .downloadS3Object('payload', key)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: blob => this.fileSaverService.save(blob, fileName),
        error: () => {
          // Error handling is performed by the interceptor.
        },
      });
  }

  @HostListener('keydown.escape')
  onEscape() {
    this.closeDetail.emit();
  }
}
