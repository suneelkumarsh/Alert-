/*
 * Copyright (c) 2025. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/* tslint:disable:no-unused-variable */
import { AuthConfigService } from 'src/app/services/authconfig.service';
import { AdministrationService } from 'src/app/services/admin-service/administration.service';
import { ModalConfirmationService } from 'src/app/services/common-functionalities/modal-confirmation.service';
import { Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { DestroyRef } from '@angular/core';
import { HasPermissionPipe, RBAC_BACKENDS } from '@portal-mfe/auth';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';

import { ServiceAreaEnhancementComponent } from './service-area-enhancement.component';
import {
  TranslateModule,
  TranslateService,
  TranslateStore,
} from '@ngx-translate/core';
import { ACL_CONFIG } from '../../auth/injection-tokens';
import { Subject, Observable } from 'rxjs';
import { of } from 'rxjs';
import {
  AuthConfig,
  DateTimeProvider,
  OAuthLogger,
  OAuthService,
  OAuthStorage,
  UrlHelperService,
} from 'angular-oauth2-oidc';
import { HttpClient } from '@angular/common/http';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { KEYCLOAK_HOSTNAME, KEYCLOAK_REALM } from '@portal-mfe/auth';
import {
  SaeConfiguration as OpenApiSaeConfiguration,
  SaeConfigurationVersion as OpenApiSaeConfigurationVersion,
} from 'openapi/output/index';
import { FactorInputComponent } from './factor-input/factor-input.component';
import { FactorGroupComponent } from './factor-group/factor-group.component';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

const mockOpenApiSaeConfiguration: OpenApiSaeConfiguration = {
  enabled: true,
  radius: 10,
  additionalPoints: 5,
  combiningRule: 'avg',
  factors: {
    default: {
      ulPrbShareFactor: 0.5,
      dlPrbShareFactor: 0.6,
    },
    n78: {
      ulPrbShareFactor: 0.7,
      dlPrbShareFactor: 0.8,
    },
  },
};

const mockOpenApiSaeConfigurationVersion: OpenApiSaeConfigurationVersion = {
  version: '1.0.0',
  saeConfiguration: mockOpenApiSaeConfiguration,
};

describe('ServiceAreaEnhancementComponent', () => {
  let component: ServiceAreaEnhancementComponent;
  let fixture: ComponentFixture<ServiceAreaEnhancementComponent>;
  let adminService: jasmine.SpyObj<AdministrationService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let modalConfirmationService: jasmine.SpyObj<ModalConfirmationService>;
  let fb: FormBuilder;
  let destroyRef: DestroyRef;
  let hasPermissionPipe: HasPermissionPipe;

  beforeEach(async () => {
    adminService = jasmine.createSpyObj('AdministrationService', [
      'getSaeData',
      'updateSaeData',
    ]);
    // Default mock for getSaeData to return an observable
    adminService.getSaeData.and.callFake(() =>
      of(mockOpenApiSaeConfigurationVersion)
    );
    alertService = jasmine.createSpyObj('TnapAlertService', [
      'error',
      'success',
    ]);
    modalConfirmationService = jasmine.createSpyObj(
      'ModalConfirmationService',
      ['openConfirmationModal']
    );
    fb = new FormBuilder();
    destroyRef = {} as DestroyRef;
    hasPermissionPipe = {} as HasPermissionPipe;

    await TestBed.configureTestingModule({
      declarations: [
        ServiceAreaEnhancementComponent,
        FactorInputComponent,
        FactorGroupComponent,
      ],
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: HttpClient, useValue: {} },
        {
          provide: TranslateService,
          useValue: {
            instant: () => '',
            get: () => new Subject(),
            onTranslationChange: new Subject(),
            onLangChange: new Subject(),
            onDefaultLangChange: new Subject(),
          },
        },
        { provide: TranslateStore, useValue: {} },
        { provide: ACL_CONFIG, useValue: {} },
        {
          provide: OAuthService,
          useValue: { events: new Subject(), hasValidAccessToken: () => true },
        },
        {
          provide: AuthConfigService,
          useValue: {
            loadCachedUserProfile: () => Promise.resolve({}),
          },
        },
        { provide: AdministrationService, useValue: adminService },
        { provide: TnapAlertService, useValue: alertService },
        {
          provide: ModalConfirmationService,
          useValue: modalConfirmationService,
        },
        { provide: FormBuilder, useValue: fb },
        { provide: DestroyRef, useValue: destroyRef },
        { provide: HasPermissionPipe, useValue: hasPermissionPipe },
        { provide: PERMISSIONS_TOKEN, useValue: [] },
        { provide: OAuthStorage, useValue: localStorage },
        { provide: AuthConfig, useValue: {} },
        { provide: KEYCLOAK_REALM, useValue: '' },
        { provide: KEYCLOAK_HOSTNAME, useValue: '' },
        { provide: RBAC_BACKENDS, useValue: ['portal-bff'] },
        OAuthLogger,
        UrlHelperService,
        DateTimeProvider,
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceAreaEnhancementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('names every toggle by its field heading and its state label', () => {
    fixture.detectChanges();
    const root: HTMLElement = fixture.nativeElement;
    const toggles = root.querySelectorAll<HTMLInputElement>(
      'input[type="checkbox"].form-check-input'
    );
    expect(toggles.length).toBeGreaterThan(0);
    toggles.forEach(toggle => {
      expect(toggle.hasAttribute('aria-label')).toBeFalse();
      const referenced = (toggle.getAttribute('aria-labelledby') ?? '')
        .split(' ')
        .map(id => root.querySelector(`[id="${id}"]`));
      expect(referenced.map(el => el?.tagName)).toEqual(['H2', 'LABEL']);
      expect(referenced[1]?.getAttribute('for')).toBe(toggle.id);
    });
  });

  it('should fetch and patch SAE data on init', () => {
    const patchSpy = spyOn(component as any, 'patchFormWithSAEData');
    adminService.getSaeData.and.returnValue(
      of(mockOpenApiSaeConfigurationVersion)
    );
    (component as any).fetchAndPatchSAEData();
    expect(patchSpy).toHaveBeenCalledWith(mockOpenApiSaeConfiguration, '1.0.0');
  });

  it('should handle error when fetching SAE data', () => {
    adminService.getSaeData.and.returnValue(
      new Observable(subscriber => {
        subscriber.error(new Error('Test error'));
      })
    );
    (component as any).fetchAndPatchSAEData();
    expect(alertService.error).toHaveBeenCalled();
  });

  it('should patch form with SAE data', () => {
    component.saeForm = component['fb'].group({
      enabled: [false],
      radius: [0],
      additionalPoints: [0],
    });
    const data = mockOpenApiSaeConfiguration;
    const version = '1.0.0';
    (component as any).patchFormWithSAEData(data, version);
    expect(component.saeForm.value).toEqual({
      enabled: data.enabled,
      radius: data.radius,
      additionalPoints: data.additionalPoints,
    });
    expect((component as any).initialSnapshot.version).toEqual(version);
    // Verify factors are patched
    expect(component.factorKeys).toEqual(['default', 'n78']);
    expect(component.factorsFormGroup.value).toEqual(data.factors);
  });

  it('should call onSubmit and open confirmation modal', () => {
    component.saeForm = component['fb'].group({
      enabled: [false, []],
      radius: [1, [Validators.required]],
      additionalPoints: [0],
    });
    component.saeForm.markAsDirty();
    spyOn(component as any, 'openConfirmationAndUpdate');
    (component as any).onSubmit();
    expect((component as any).openConfirmationAndUpdate).toHaveBeenCalled();
  });

  it('should update SAE data on confirmation', () => {
    // Spy on updateSAEDataObservable to return an observable
    const updateSpy = spyOn(
      component as any,
      'updateSAEDataObservable'
    ).and.callThrough();
    // Spy on administrationService.updateSaeData to return observable
    adminService.updateSaeData.and.returnValue(
      of(mockOpenApiSaeConfigurationVersion)
    );
    // Simulate confirmation modal returning true
    modalConfirmationService.openConfirmationModal.and.returnValue(of(true));
    // Set up form and mark as dirty
    component.saeForm = component['fb'].group({
      enabled: [true, []],
      radius: [10, [Validators.required]],
      additionalPoints: [5],
    });
    component.saeForm.markAsDirty();
    // Call the method
    (component as any).openConfirmationAndUpdate();
    expect(updateSpy).toHaveBeenCalled();
  });
  it('should validate form and detect changes', () => {
    component.saeForm = component['fb'].group({
      enabled: [false, []],
      radius: [10, [Validators.required]],
      additionalPoints: [0],
    });
    component.factorsFormGroup = component['fb'].group({
      default: component['fb'].group({
        ulPrbShareFactor: [0.5],
        dlPrbShareFactor: [0.6],
      }),
    });
    // Set initialSnapshot to match form values
    (component as any).initialSnapshot = {
      data: {
        enabled: false,
        radius: 10,
        additionalPoints: 0,
        factors: {
          default: { ulPrbShareFactor: 0.5, dlPrbShareFactor: 0.6 },
        },
      },
      version: '1.0.0',
    };
    component.saeForm.markAsPristine();
    component.factorsFormGroup.markAsPristine();
    // Change form
    component.saeForm.patchValue({ enabled: true });
    component.saeForm.markAsDirty();
    expect((component as any).validateForm()).toBe(true); // valid and changed
    component.saeForm.markAsPristine();
    // Update initialSnapshot to match current form values
    (component as any).initialSnapshot = {
      data: {
        enabled: component.saeForm.value.enabled,
        radius: component.saeForm.value.radius,
        additionalPoints: component.saeForm.value.additionalPoints,
        factors: component.factorsFormGroup.value,
      },
      version: '1.0.0',
    };
    expect((component as any).validateForm()).toBe(false); // no change
  });

  it('should detect form changes', () => {
    component.saeForm = component['fb'].group({
      enabled: [true, []],
      radius: [10, [Validators.required]],
      additionalPoints: [5],
    });
    component.factorsFormGroup = component['fb'].group({
      default: component['fb'].group({
        ulPrbShareFactor: [0.5],
        dlPrbShareFactor: [0.6],
      }),
    });
    (component as any).initialSnapshot = {
      data: {
        enabled: false,
        radius: 10,
        additionalPoints: 0,
        factors: {
          default: { ulPrbShareFactor: 0.5, dlPrbShareFactor: 0.6 },
        },
      },
      version: '1.0.0',
    };
    component.saeForm.markAsPristine();
    component.factorsFormGroup.markAsPristine();
    // Change form
    component.saeForm.patchValue({ enabled: true });
    component.saeForm.markAsDirty();
    expect((component as any).hasFormChanged()).toBe(true);
    component.saeForm.markAsPristine();
    // Update initialSnapshot to match current form values
    (component as any).initialSnapshot = {
      data: {
        enabled: component.saeForm.value.enabled,
        radius: component.saeForm.value.radius,
        additionalPoints: component.saeForm.value.additionalPoints,
        factors: component.factorsFormGroup.value,
      },
      version: '1.0.0',
    };
    expect((component as any).hasFormChanged()).toBe(false);
  });

  it('should detect factor changes', () => {
    component.saeForm = component['fb'].group({
      enabled: [false],
      radius: [10],
      additionalPoints: [0],
    });
    component.factorsFormGroup = component['fb'].group({
      default: component['fb'].group({
        ulPrbShareFactor: [0.5],
        dlPrbShareFactor: [0.6],
      }),
    });
    (component as any).initialSnapshot = {
      data: {
        enabled: false,
        radius: 10,
        additionalPoints: 0,
        factors: {
          default: { ulPrbShareFactor: 0.5, dlPrbShareFactor: 0.6 },
        },
      },
      version: '1.0.0',
    };
    component.saeForm.markAsPristine();
    component.factorsFormGroup.markAsPristine();

    // No changes initially
    expect((component as any).hasFormChanged()).toBe(false);

    // Change factor value
    component.factorsFormGroup
      .get('default')
      ?.patchValue({ ulPrbShareFactor: 0.7 });
    component.factorsFormGroup.markAsDirty();
    expect((component as any).hasFormChanged()).toBe(true);
  });

  it('should get factor group by key', () => {
    component.factorsFormGroup = component['fb'].group({
      default: component['fb'].group({
        ulPrbShareFactor: [0.5],
        dlPrbShareFactor: [0.6],
      }),
      n78: component['fb'].group({
        ulPrbShareFactor: [0.7],
        dlPrbShareFactor: [0.8],
      }),
    });

    const defaultGroup = component.getFactorGroup('default');
    expect(defaultGroup.get('ulPrbShareFactor')?.value).toBe(0.5);

    const n78Group = component.getFactorGroup('n78');
    expect(n78Group.get('ulPrbShareFactor')?.value).toBe(0.7);
  });

  it('should reset factors when form is reset', () => {
    const initialData = {
      enabled: false,
      radius: 10,
      additionalPoints: 0,
      factors: {
        default: { ulPrbShareFactor: 0.5, dlPrbShareFactor: 0.6 },
      },
    };

    // Set initial snapshot
    (component as any).initialSnapshot = {
      data: initialData,
      version: '1.0.0',
    };

    // Change form values
    component.saeForm = component['fb'].group({
      enabled: [true],
      radius: [15],
      additionalPoints: [3],
    });
    component.factorsFormGroup = component['fb'].group({
      default: component['fb'].group({
        ulPrbShareFactor: [0.9],
        dlPrbShareFactor: [0.8],
      }),
    });

    component.resetForm();

    expect(component.saeForm.value).toEqual({
      enabled: false,
      radius: 10,
      additionalPoints: 0,
    });
    expect(component.factorsFormGroup.value).toEqual(initialData.factors);
  });

  it('should validate form with invalid factors', () => {
    component.saeForm = component['fb'].group({
      enabled: [true],
      radius: [10, [Validators.required]],
      additionalPoints: [0],
    });
    component.factorsFormGroup = component['fb'].group({
      default: component['fb'].group({
        ulPrbShareFactor: [1.5, [Validators.min(0), Validators.max(1)]],
        dlPrbShareFactor: [0.6],
      }),
    });
    component.saeForm.markAsDirty();

    const result = (component as any).validateForm();
    expect(result).toBe(false);
    expect(alertService.error).toHaveBeenCalled();
  });

  it('should include factors in update payload', () => {
    component.saeForm = component['fb'].group({
      enabled: [true],
      radius: [10],
      additionalPoints: [5],
    });
    component.factorsFormGroup = component['fb'].group({
      default: component['fb'].group({
        ulPrbShareFactor: [0.5],
        dlPrbShareFactor: [0.6],
      }),
    });
    (component as any).initialSnapshot = {
      data: mockOpenApiSaeConfiguration,
      version: '1.0.0',
    };

    adminService.updateSaeData.and.returnValue(
      of(mockOpenApiSaeConfigurationVersion)
    );

    (component as any).updateSAEDataObservable().subscribe();

    expect(adminService.updateSaeData).toHaveBeenCalledWith(
      jasmine.objectContaining({
        version: '1.0.1',
        saeConfiguration: jasmine.objectContaining({
          factors: {
            default: { ulPrbShareFactor: 0.5, dlPrbShareFactor: 0.6 },
          },
        }),
      })
    );
  });
});
