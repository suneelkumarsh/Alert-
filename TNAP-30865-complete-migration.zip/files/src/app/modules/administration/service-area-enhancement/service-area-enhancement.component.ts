/*
 * Copyright (c) 2025. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, OnInit, DestroyRef, inject } from '@angular/core';
import { AdministrationService } from 'src/app/services/admin-service/administration.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ModalConfirmationService } from 'src/app/services/common-functionalities/modal-confirmation.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, map, switchMap } from 'rxjs/operators';
import { EMPTY } from 'rxjs';
import { SAE_FIELDS, RADIUS_RANGE, ALERT_MESSAGES } from '../configuration';
import { HasPermissionPipe } from '@portal-mfe/auth';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { SaeConfiguration } from 'openapi/output/model/saeConfiguration.model';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-service-area-enhancement',
  templateUrl: './service-area-enhancement.component.html',
  styleUrls: ['./service-area-enhancement.component.css'],
  providers: [HasPermissionPipe],
  standalone: false,
})
export class ServiceAreaEnhancementComponent implements OnInit {
  protected readonly confirmationModalService = inject(
    ModalConfirmationService
  );
  protected readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);
  protected readonly fb = inject(FormBuilder);
  protected readonly destroyRef$ = inject(DestroyRef);
  protected readonly hasPermissionPipe = inject(HasPermissionPipe);
  protected readonly administrationService = inject(AdministrationService);
  readonly permissions = inject(PERMISSIONS_TOKEN);

  saeFields = SAE_FIELDS;
  saeForm!: FormGroup;
  factorsFormGroup!: FormGroup;
  factorKeys: string[] = [];
  private initialSnapshot: {
    data: SaeConfiguration | null;
    version: string;
  } = {
    data: null,
    version: '',
  };

  // Observable for disabling form when user lacks permission
  readonly isFormDisabled$ = this.hasPermissionPipe
    .transform(this.permissions.ADMIN_ACTION)
    .pipe(map(hasPermission => !hasPermission));

  ngOnInit(): void {
    this.saeForm = this.fb.group({
      enabled: [false],
      radius: [
        0,
        [
          Validators.required,
          Validators.min(RADIUS_RANGE.min),
          Validators.max(RADIUS_RANGE.max),
        ],
      ],
      additionalPoints: [0],
    });
    this.factorsFormGroup = this.fb.group({});
    this.fetchAndPatchSAEData();
  }

  private fetchAndPatchSAEData(): void {
    this.administrationService
      .getSaeData()
      .pipe(takeUntilDestroyed(this.destroyRef$))
      .subscribe({
        next: data =>
          this.patchFormWithSAEData(data.saeConfiguration, data.version),
        error: () =>
          this.alertService.error(
            this.translateService.instant(ALERT_MESSAGES.getFailedSAE),
            { keepAfterRouteChange: true }
          ),
      });
  }

  private patchFormWithSAEData(
    data: SaeConfiguration | undefined,
    version: string | undefined
  ): void {
    if (data) {
      this.saeForm.patchValue({
        enabled: data.enabled ?? false,
        radius: data.radius ?? 0,
        additionalPoints: data.additionalPoints ?? 0,
      });

      // Handle dynamic factors
      if (data.factors) {
        this.factorKeys = Object.keys(data.factors);
        this.factorsFormGroup = this.fb.group({});

        this.factorKeys.forEach(key => {
          const factorGroup = this.fb.group({
            ulPrbShareFactor: [
              data.factors![key].ulPrbShareFactor ?? 0.1,
              [Validators.required, Validators.min(0.1), Validators.max(1)],
            ],
            dlPrbShareFactor: [
              data.factors![key].dlPrbShareFactor ?? 0.1,
              [Validators.required, Validators.min(0.1), Validators.max(1)],
            ],
          });
          this.factorsFormGroup.addControl(key, factorGroup);
        });
      }

      // Store snapshot and mark forms as pristine
      this.initialSnapshot = {
        data: data,
        version: version ?? '',
      };
      this.saeForm.markAsPristine();
      this.factorsFormGroup.markAsPristine();
    }
  }

  resetForm(): void {
    if (this.initialSnapshot.data) {
      this.patchFormWithSAEData(
        this.initialSnapshot.data,
        this.initialSnapshot.version
      );
    }
  }

  get formControls() {
    return this.saeForm.controls;
  }

  getFactorGroup(key: string): FormGroup {
    return this.factorsFormGroup.get(key) as FormGroup;
  }

  private hasFormChanged(): boolean {
    // Compare current form values with initial snapshot
    const currentSae = this.saeForm.value;
    const currentFactors = this.factorsFormGroup.value;
    const initialSae = this.initialSnapshot.data
      ? {
          enabled: this.initialSnapshot.data.enabled ?? false,
          radius: this.initialSnapshot.data.radius ?? 0,
          additionalPoints: this.initialSnapshot.data.additionalPoints ?? 0,
        }
      : {};
    const initialFactors = this.initialSnapshot.data?.factors ?? {};

    function deepEqual(obj1: any, obj2: any): boolean {
      if (obj1 === obj2) return true;
      if (typeof obj1 !== typeof obj2) return false;
      if (typeof obj1 !== 'object' || obj1 === null || obj2 === null)
        return false;
      const obj1Keys = Object.keys(obj1);
      const obj2Keys = Object.keys(obj2);
      if (obj1Keys.length !== obj2Keys.length) return false;
      for (const key of obj1Keys) {
        if (!obj2Keys.includes(key) || !deepEqual(obj1[key], obj2[key]))
          return false;
      }
      return true;
    }

    return (
      !deepEqual(currentSae, initialSae) ||
      !deepEqual(currentFactors, initialFactors)
    );
  }

  onSubmit(): void {
    if (!this.validateForm()) return;
    this.openConfirmationAndUpdate();
  }

  private validateForm(): boolean {
    if (this.saeForm.invalid || this.factorsFormGroup.invalid) {
      this.saeForm.markAllAsTouched();
      this.factorsFormGroup.markAllAsTouched();
      this.alertService.error(
        this.translateService.instant(ALERT_MESSAGES.invalidForm),
        { keepAfterRouteChange: true }
      );
      return false;
    }
    if (!this.hasFormChanged()) {
      this.alertService.error(
        this.translateService.instant(ALERT_MESSAGES.noChange),
        { keepAfterRouteChange: true }
      );
      return false;
    }
    return true;
  }

  private openConfirmationAndUpdate(): void {
    this.confirmationModalService
      .openConfirmationModal(
        ALERT_MESSAGES.confirmButton,
        ALERT_MESSAGES.confirmTitle,
        ALERT_MESSAGES.confirmWarningSAE
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef$),
        switchMap(confirm => {
          if (!confirm) return EMPTY;
          return this.updateSAEDataObservable();
        }),
        catchError(() => {
          this.alertService.error(
            this.translateService.instant(ALERT_MESSAGES.saveFailedSAE),
            { keepAfterRouteChange: true }
          );
          return EMPTY;
        })
      )
      .subscribe(data => {
        this.alertService.success(
          this.translateService.instant(ALERT_MESSAGES.saveSuccessSAE),
          { keepAfterRouteChange: true }
        );
        this.patchFormWithSAEData(data.saeConfiguration, data.version);
      });
  }

  private increaseSAEVersion(version: string): string | undefined {
    // Accepts versions like 1.2.3, 0.0.1, etc.
    const versionRegex = /^\d+(\.\d+)*$/;
    if (!versionRegex.test(version)) {
      return undefined;
    }
    const parts = version.split('.');
    const lastPart = parseInt(parts[parts.length - 1], 10);
    parts[parts.length - 1] = (lastPart + 1).toString();
    return parts.join('.');
  }

  private updateSAEDataObservable() {
    const updatedVersion = this.initialSnapshot.version
      ? this.increaseSAEVersion(this.initialSnapshot.version)
      : undefined;

    const updatedConfig = {
      ...this.initialSnapshot.data,
      ...this.saeForm.value,
      factors: this.factorsFormGroup.value,
    } as SaeConfiguration;

    return this.administrationService.updateSaeData({
      ...(updatedVersion && { version: updatedVersion }),
      saeConfiguration: updatedConfig,
    });
  }
}
