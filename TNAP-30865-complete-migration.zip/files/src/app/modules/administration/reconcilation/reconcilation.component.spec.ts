/*
 * Copyright (c) 2025. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/* tslint:disable:no-unused-variable */
import { AuthConfigService } from 'src/app/services/authconfig.service';
import {
  OAuthService,
  AuthConfig,
  OAuthModule,
  OAuthStorage,
} from 'angular-oauth2-oidc';
import { authConfig } from '../../auth/auth.config';
import { ACL_CONFIG } from '../../auth/injection-tokens';
import {
  ComponentFixture,
  TestBed,
  fakeAsync,
  tick,
} from '@angular/core/testing';
import { ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import {
  provideHttpClient,
  withInterceptorsFromDi,
} from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { TranslateModule } from '@ngx-translate/core';
import { of, Subject, throwError } from 'rxjs';
import { ReconcilationComponent } from './reconcilation.component';
import { AdministrationService } from 'src/app/services/admin-service/administration.service';
import { ModalConfirmationService } from 'src/app/services/common-functionalities/modal-confirmation.service';
import { HasPermissionPipe, AuthService } from '@portal-mfe/auth';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

class MockAdministrationService {
  getReconciliationData = jasmine
    .createSpy()
    .and.returnValue(of({ flag: true, watchDogTimer: 10 }));
  updateReconciliationData = jasmine.createSpy().and.returnValue(of({}));
}

class MockModalConfirmationService {
  openConfirmationModal = jasmine.createSpy().and.returnValue(of(true));
}

class MockAlertService {
  error = jasmine.createSpy();
  success = jasmine.createSpy();
}

class MockHasPermissionPipe {
  private returnValue = true;

  transform(): any {
    return of(this.returnValue);
  }

  setReturnValue(value: boolean): void {
    this.returnValue = value;
  }
}

class MockOAuthService {
  events = new Subject();
}

class MockAuthService {
  getLoggedUserId = jasmine
    .createSpy('getLoggedUserId')
    .and.returnValue('test-user');
  getUserPermissions = jasmine
    .createSpy('getUserPermissions')
    .and.returnValue(of([]));
}

describe('ReconcilationComponent', () => {
  let component: ReconcilationComponent;
  let fixture: ComponentFixture<ReconcilationComponent>;
  let adminService: MockAdministrationService;
  let alertService: MockAlertService;
  let permissionPipe: MockHasPermissionPipe;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ReconcilationComponent],
      imports: [
        ReactiveFormsModule,
        TranslateModule.forRoot(),
        OAuthModule.forRoot(),
      ],
      providers: [
        FormBuilder,
        { provide: AdministrationService, useClass: MockAdministrationService },
        {
          provide: ModalConfirmationService,
          useClass: MockModalConfirmationService,
        },
        { provide: TnapAlertService, useClass: MockAlertService },
        { provide: HasPermissionPipe, useClass: MockHasPermissionPipe },
        { provide: ACL_CONFIG, useValue: {} },
        { provide: OAuthService, useClass: MockOAuthService },
        { provide: AuthConfig, useValue: authConfig },
        {
          provide: OAuthStorage,
          useValue: {
            getItem: () => '',
            setItem: () => {},
            removeItem: () => {},
          },
        },
        AuthConfigService,
        { provide: AuthService, useClass: MockAuthService },
        { provide: PERMISSIONS_TOKEN, useValue: [] },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting(),
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    TestBed.overrideProvider(HasPermissionPipe, {
      useValue: new MockHasPermissionPipe(),
    });
    fixture = TestBed.createComponent(ReconcilationComponent);
    component = fixture.componentInstance;
    adminService = TestBed.inject(AdministrationService) as any;
    alertService = TestBed.inject(TnapAlertService) as any;
    permissionPipe = TestBed.inject(HasPermissionPipe) as any;
  });

  it('should create', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('names every toggle by its field heading and its state label', () => {
    fixture.detectChanges();
    const root: HTMLElement = fixture.nativeElement;
    const toggles = root.querySelectorAll<HTMLInputElement>(
      'input[type="checkbox"].form-check-input'
    );
    expect(toggles.length).toBeGreaterThan(0);
    toggles.forEach(toggle => {
      expect(toggle.hasAttribute('aria-label')).toBeFalse();
      const referenced = (toggle.getAttribute('aria-labelledby') ?? '')
        .split(' ')
        .map(id => root.querySelector(`[id="${id}"]`));
      expect(referenced.map(el => el?.tagName)).toEqual(['H2', 'LABEL']);
      expect(referenced[1]?.getAttribute('for')).toBe(toggle.id);
    });
  });

  it('should initialize form with fetched data', () => {
    fixture.detectChanges();
    expect(component.reconcilationForm.value.flag).toBe(true);
    expect(component.reconcilationForm.value.watchDogTimer).toBe(10);
  });

  it('should enable form if permission is true', fakeAsync(() => {
    fixture.detectChanges();
    tick();
    expect(component.reconcilationForm.enabled).toBeTrue();
  }));

  it('should disable form if permission is false', fakeAsync(() => {
    permissionPipe.setReturnValue(false);
    fixture.detectChanges();
    tick();
    expect(component.reconcilationForm.enabled).toBeTrue();
  }));

  it('should show error alert if form is invalid on submit', () => {
    fixture.detectChanges();
    component.reconcilationForm.controls['watchDogTimer'].setValue(null);
    component.onSubmit();
    expect(alertService.error).toHaveBeenCalledWith(
      'administration.alert.body.invalidForm',
      { keepAfterRouteChange: true }
    );
  });

  it('should show error alert if no changes detected', fakeAsync(() => {
    fixture.detectChanges();
    spyOn(component as any, 'patchFormWithData');
    component.onSubmit();
    expect(alertService.error).toHaveBeenCalledWith(
      'administration.alert.body.noChange',
      { keepAfterRouteChange: true }
    );
  }));

  it('should call update and fetch data on valid submit with changes', fakeAsync(() => {
    fixture.detectChanges();
    component.reconcilationForm.controls['watchDogTimer'].setValue(20);
    component.reconcilationForm.markAsDirty();
    component.onSubmit();
    tick();
    expect(adminService.updateReconciliationData).toHaveBeenCalled();
    expect(alertService.success).toHaveBeenCalledWith(
      'administration.alert.body.saveReconciliation',
      { keepAfterRouteChange: true }
    );
  }));

  it('should patch form with new data after save', fakeAsync(() => {
    fixture.detectChanges();
    (component as any).initialSnapshot = { flag: true, watchDogTimer: 10 };
    component.reconcilationForm.controls['watchDogTimer'].setValue(20);
    component.reconcilationForm.markAsDirty();
    const updatedData = { flag: true, watchDogTimer: 20 };
    adminService.updateReconciliationData.and.returnValue(of(updatedData));
    spyOn(component as any, 'patchFormWithData').and.callThrough();
    component.onSubmit();
    tick();
    expect((component as any).patchFormWithData).toHaveBeenCalledWith(
      updatedData
    );
  }));

  it('should patch form with fallback values if data properties are undefined', () => {
    fixture.detectChanges();
    (component as any).patchFormWithData({});
    expect(component.reconcilationForm.value).toEqual({
      flag: false,
      watchDogTimer: 0,
    });
  });

  it('should call setupPermissionHandler and toggle form permission', fakeAsync(() => {
    fixture.detectChanges();
    expect(component.isFormDisabled$).toBeDefined();
  }));

  it('should handle API failure in fetchAndPatchReconciliationData', () => {
    fixture.detectChanges();
    (adminService.getReconciliationData as any).and.returnValue({
      pipe: () => ({
        subscribe: ({ error }: any) => error(),
      }),
    });
    (component as any).fetchAndPatchReconciliationData();
    expect(alertService.error).toHaveBeenCalledWith(
      'administration.alert.body.getReconciliationFailed',
      { keepAfterRouteChange: true }
    );
  });

  it('should handle API failure in handleConfirmedSubmit', () => {
    fixture.detectChanges();
    (adminService.updateReconciliationData as any).and.returnValue(
      throwError(() => new Error('API error'))
    );
    (component as any).initialSnapshot = { flag: true, watchDogTimer: 10 };
    component.reconcilationForm.patchValue({ flag: false, watchDogTimer: 20 });
    component.reconcilationForm.markAsDirty();
    (
      component['confirmationModalService'].openConfirmationModal as jasmine.Spy
    ).and.returnValue(of(true));
    component.onSubmit();
    expect(component.reconcilationForm.value).toEqual({
      flag: false,
      watchDogTimer: 20,
    });
    expect(alertService.error).toHaveBeenCalledWith(
      'administration.alert.body.saveReconciliationFailed',
      { keepAfterRouteChange: true }
    );
  });
});
