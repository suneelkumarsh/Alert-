/*
 * Copyright (c) 2025. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, OnInit, DestroyRef, inject } from '@angular/core';
import { AdministrationService } from 'src/app/services/admin-service/administration.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SliceRCSConfig } from 'openapi/output/model/sliceRCSConfig.model';
import { FIELD_TYPES, RC_FIELDS, ALERT_MESSAGES } from '../configuration';
import { ModalConfirmationService } from 'src/app/services/common-functionalities/modal-confirmation.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { EMPTY } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { HasPermissionPipe } from '@portal-mfe/auth';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-reconcilation',
  templateUrl: './reconcilation.component.html',
  styleUrls: ['./reconcilation.component.css'],
  providers: [HasPermissionPipe],
  standalone: false,
})
export class ReconcilationComponent implements OnInit {
  protected readonly confirmationModalService = inject(
    ModalConfirmationService
  );
  protected readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);
  protected readonly fb = inject(FormBuilder);
  protected readonly destroyRef$ = inject(DestroyRef);
  protected readonly hasPermissionPipe = inject(HasPermissionPipe);
  protected readonly administrationService = inject(AdministrationService);
  readonly permissions = inject(PERMISSIONS_TOKEN);

  rcFields = RC_FIELDS;
  fieldTypes = FIELD_TYPES;
  private initialSnapshot: SliceRCSConfig | null = null;
  reconcilationForm!: FormGroup;

  // Observable for disabling form when user lacks permission
  readonly isFormDisabled$ = this.hasPermissionPipe
    .transform(this.permissions.ADMIN_ACTION)
    .pipe(map(hasPermission => !hasPermission));

  ngOnInit(): void {
    this.reconcilationForm = this.fb.group({
      flag: [false],
      watchDogTimer: [0, [Validators.required]],
    });
    this.fetchAndPatchReconciliationData();
  }

  get formControls() {
    return this.reconcilationForm.controls;
  }

  private fetchAndPatchReconciliationData(): void {
    this.administrationService
      .getReconciliationData()
      .pipe(takeUntilDestroyed(this.destroyRef$))
      .subscribe({
        next: data => this.patchFormWithData(data),
        error: () =>
          this.alertService.error(
            this.translateService.instant(ALERT_MESSAGES.getFailedRC),
            { keepAfterRouteChange: true }
          ),
      });
  }

  private patchFormWithData(data: SliceRCSConfig): void {
    if (data) {
      this.reconcilationForm.patchValue({
        flag: data.flag ?? false,
        watchDogTimer: data.watchDogTimer ?? 0,
      });
      this.initialSnapshot = data;
      this.reconcilationForm.markAsPristine();
    }
  }

  resetForm(): void {
    if (this.initialSnapshot) {
      this.patchFormWithData(this.initialSnapshot);
    }
  }

  /**
   * Check if form values have changed compared to initial values
   */
  private hasFormChanged(): boolean {
    return this.reconcilationForm.dirty;
  }

  /**
   * Handle form submission with confirmation and update logic
   */
  onSubmit(): void {
    if (!this.validateForm()) return;
    this.openConfirmationAndUpdate();
  }

  /**
   * Validates the form and shows error alerts if needed
   */
  private validateForm(): boolean {
    if (this.reconcilationForm.invalid) {
      this.reconcilationForm.markAllAsTouched();
      this.alertService.error(
        this.translateService.instant(ALERT_MESSAGES.invalidForm),
        { keepAfterRouteChange: true }
      );
      return false;
    }
    if (!this.hasFormChanged()) {
      this.alertService.error(
        this.translateService.instant(ALERT_MESSAGES.noChange),
        { keepAfterRouteChange: true }
      );
      return false;
    }
    return true;
  }

  /**
   * Opens confirmation modal and updates reconciliation data if confirmed
   */
  private openConfirmationAndUpdate(): void {
    this.confirmationModalService
      .openConfirmationModal(
        ALERT_MESSAGES.confirmButton,
        ALERT_MESSAGES.confirmTitle,
        ALERT_MESSAGES.confirmWarningRC
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef$),
        switchMap(confirm => {
          if (!confirm) return EMPTY;
          return this.updateReconciliationData();
        }),
        catchError(() => {
          this.alertService.error(
            this.translateService.instant(ALERT_MESSAGES.saveFailedRC),
            { keepAfterRouteChange: true }
          );
          return EMPTY;
        })
      )
      .subscribe((data: SliceRCSConfig) => {
        this.alertService.success(
          this.translateService.instant(ALERT_MESSAGES.saveSuccessRC),
          { keepAfterRouteChange: true }
        );
        this.patchFormWithData(data);
      });
  }

  /**
   * Calls the updateReconciliationData service and returns response
   */
  private updateReconciliationData() {
    return this.administrationService.updateReconciliationData({
      ...this.initialSnapshot,
      ...this.reconcilationForm.value,
    });
  }
}
