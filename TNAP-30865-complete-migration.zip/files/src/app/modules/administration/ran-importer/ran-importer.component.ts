/*
 * Copyright (c) 2025. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, inject, DestroyRef } from '@angular/core';
import { AdministrationService } from 'src/app/services/admin-service/administration.service';
import { ModalConfirmationService } from 'src/app/services/common-functionalities/modal-confirmation.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ALERT_MESSAGES } from '../configuration';
import { switchMap, catchError } from 'rxjs/operators';
import { EMPTY } from 'rxjs';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { ButtonType } from '@portal-mfe/tnap-ui-kit/components/button';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-ran-importer',
  templateUrl: './ran-importer.component.html',
  styleUrls: ['./ran-importer.component.css'],
  standalone: false,
})
export class RanImporterComponent {
  readonly importTypes: {
    key: string;
    variant: ButtonType;
    forceMode: boolean;
  }[] = [
    {
      key: 'fullInitialImport',
      variant: 'warning',
      forceMode: true,
    },
    {
      key: 'deltaImport',
      variant: 'secondary',
      forceMode: false,
    },
  ];
  protected readonly confirmationModalService = inject(
    ModalConfirmationService
  );
  protected readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);
  protected readonly destroyRef$ = inject(DestroyRef);
  protected readonly administrationService = inject(AdministrationService);
  readonly permissions = inject(PERMISSIONS_TOKEN);

  private readonly MESSAGES = {
    forceMode: {
      warning: ALERT_MESSAGES.confirmWarningRan1,
      success: ALERT_MESSAGES.saveSuccessRan1,
      error: ALERT_MESSAGES.saveFailedRan1,
    },
    normalMode: {
      warning: ALERT_MESSAGES.confirmWarningRan2,
      success: ALERT_MESSAGES.saveSuccessRan2,
      error: ALERT_MESSAGES.saveFailedRan2,
    },
  } as const;

  onImport(forceMode: boolean): void {
    const messages = forceMode
      ? this.MESSAGES.forceMode
      : this.MESSAGES.normalMode;

    this.confirmationModalService
      .openConfirmationModal(
        ALERT_MESSAGES.confirmButton,
        ALERT_MESSAGES.confirmTitle,
        messages.warning
      )
      .pipe(
        takeUntilDestroyed(this.destroyRef$),
        switchMap(confirm => {
          if (!confirm) return EMPTY;
          return this.administrationService.ranImport(forceMode).pipe(
            catchError(() => {
              this.alertService.error(
                this.translateService.instant(messages.error),
                { keepAfterRouteChange: true }
              );
              return EMPTY;
            })
          );
        })
      )
      .subscribe(() => {
        this.alertService.success(
          this.translateService.instant(messages.success),
          { keepAfterRouteChange: true }
        );
      });
  }
}
