/*
 * Copyright (c) 2025. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RanImporterComponent } from './ran-importer.component';
import {
  HasPermissionPipe,
  KEYCLOAK_HOSTNAME,
  KEYCLOAK_REALM,
  RBAC_BACKENDS,
} from '@portal-mfe/auth';
import {
  TranslateModule,
  TranslateService,
  TranslateStore,
} from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { ACL_CONFIG } from '../../auth/injection-tokens';
import { Subject, of } from 'rxjs';
import {
  AuthConfig,
  DateTimeProvider,
  OAuthLogger,
  OAuthService,
  OAuthStorage,
  UrlHelperService,
} from 'angular-oauth2-oidc';
import { AuthConfigService } from 'src/app/services/authconfig.service';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { AdministrationService } from 'src/app/services/admin-service/administration.service';

describe('RanImporterComponent', () => {
  let component: RanImporterComponent;
  let fixture: ComponentFixture<RanImporterComponent>;

  beforeEach(async () => {
    const mockAdministrationService = jasmine.createSpyObj(
      'AdministrationService',
      ['ranImport']
    );

    await TestBed.configureTestingModule({
      declarations: [RanImporterComponent],
      imports: [TranslateModule.forRoot(), HasPermissionPipe],
      providers: [
        { provide: HasPermissionPipe, useValue: { transform: () => true } },
        {
          provide: TranslateService,
          useValue: {
            instant: () => '',
            get: () => new Subject(),
            onTranslationChange: new Subject(),
            onLangChange: new Subject(),
            onDefaultLangChange: new Subject(),
          },
        },
        { provide: TranslateStore, useValue: {} },
        {
          provide: HttpClient,
          useValue: { request: jasmine.createSpy('request') },
        },
        {
          provide: OAuthService,
          useValue: { events: new Subject(), hasValidAccessToken: () => true },
        },
        { provide: AuthConfigService, useValue: {} },
        { provide: ACL_CONFIG, useValue: {} },
        { provide: PERMISSIONS_TOKEN, useValue: [] },
        { provide: OAuthStorage, useValue: localStorage },
        { provide: AuthConfig, useValue: {} },
        { provide: KEYCLOAK_REALM, useValue: '' },
        { provide: KEYCLOAK_HOSTNAME, useValue: '' },
        { provide: RBAC_BACKENDS, useValue: ['portal-bff'] },
        { provide: AdministrationService, useValue: mockAdministrationService },
        OAuthService,
        OAuthLogger,
        UrlHelperService,
        DateTimeProvider,
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RanImporterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call modal, ranImport, and alert on forceMode true and confirmation', () => {
    const modalService = {
      openConfirmationModal: jasmine
        .createSpy('openConfirmationModal')
        .and.returnValue(of(true)),
    };
    const alertService = {
      success: jasmine.createSpy('success'),
    };
    const adminService = {
      ranImport: jasmine.createSpy('ranImport').and.returnValue(of({})),
    };
    (component as any).confirmationModalService = modalService;
    (component as any).alertService = alertService;
    (component as any).translateService = { instant: (key: string) => key };
    (component as any).administrationService = adminService;
    (component as any).destroyRef$ = { onDestroy: () => {} };
    component.onImport(true);
    expect(modalService.openConfirmationModal).toHaveBeenCalled();
    expect(adminService.ranImport).toHaveBeenCalledWith(true);
    expect(alertService.success).toHaveBeenCalledWith(
      'administration.alert.body.saveRan',
      {
        keepAfterRouteChange: true,
      }
    );
  });

  it('should call modal, ranImport, and alert on forceMode false and confirmation', () => {
    const modalService = {
      openConfirmationModal: jasmine
        .createSpy('openConfirmationModal')
        .and.returnValue(of(true)),
    };
    const alertService = {
      success: jasmine.createSpy('success'),
    };
    const adminService = {
      ranImport: jasmine.createSpy('ranImport').and.returnValue(of({})),
    };
    (component as any).confirmationModalService = modalService;
    (component as any).alertService = alertService;
    (component as any).translateService = { instant: (key: string) => key };
    (component as any).administrationService = adminService;
    (component as any).destroyRef$ = { onDestroy: () => {} };
    component.onImport(false);
    expect(modalService.openConfirmationModal).toHaveBeenCalled();
    expect(adminService.ranImport).toHaveBeenCalledWith(false);
    expect(alertService.success).toHaveBeenCalledWith(
      'administration.alert.body.saveRan2',
      {
        keepAfterRouteChange: true,
      }
    );
  });

  it('should not call ranImport or alert if not confirmed', () => {
    const modalService = {
      openConfirmationModal: jasmine
        .createSpy('openConfirmationModal')
        .and.returnValue(of(false)),
    };
    const alertService = {
      success: jasmine.createSpy('success'),
    };
    const adminService = {
      ranImport: jasmine.createSpy('ranImport').and.returnValue(of({})),
    };
    (component as any).confirmationModalService = modalService;
    (component as any).alertService = alertService;
    (component as any).translateService = { instant: (key: string) => key };
    (component as any).administrationService = adminService;
    (component as any).destroyRef$ = { onDestroy: () => {} };
    component.onImport(true);
    expect(modalService.openConfirmationModal).toHaveBeenCalled();
    expect(adminService.ranImport).not.toHaveBeenCalled();
    expect(alertService.success).not.toHaveBeenCalled();
  });
});
