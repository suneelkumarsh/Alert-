/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ChangeDetectionStrategy,
  Component,
  computed,
  DestroyRef,
  inject,
  signal,
} from '@angular/core';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { ColumnDefinition } from '@portal-mfe/tnap-ui-kit/components/data-table';
import { PaginationService } from '../../../services/common-functionalities/pagination.service';
import { QueryParamService } from '../../../services/query-param.service';
import { SelectOption } from '@portal-mfe/tnap-ui-kit/components/select';
import { catchError, combineLatest, EMPTY, of, Subject, switchMap } from 'rxjs';
import { map } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { ALERT_MESSAGES } from '../configuration';
import { RanDataImporterDraftService } from '../../../services/ran-data-importer-service/ran-data-importer-draft.service';
import {
  BadgeMode,
  BadgeType,
} from '@portal-mfe/tnap-ui-kit/model/badge.model';
import { SharedModule } from '../../../shared.module';
import {
  DataTableComponent,
  TableCellDefinitionDirective,
  TableHeaderDefinitionDirective,
} from '@portal-mfe/tnap-ui-kit/components/data-table';
import { LayoutComponent } from '@portal-mfe/tnap-ui-kit/components/layout-wrapper';
import { TitleComponent } from '@portal-mfe/tnap-ui-kit/components/title';
import { ResizerComponent } from '../../../components/shared/resizer/resizer.component';
import { TnapSelectComponent } from '@portal-mfe/tnap-ui-kit/components/select';
import { TnapButtonComponent } from '@portal-mfe/tnap-ui-kit/components/button';
import { BadgeComponent } from '@portal-mfe/tnap-ui-kit/components/badge';
import { CheckboxComponent } from '@portal-mfe/tnap-ui-kit/components/checkbox';
import { RanDataImporterDetailsComponent } from './ran-data-importer-details/ran-data-importer-details.component';
import {
  ImportType,
  RanDataImporterService,
  WorkflowListType,
  WorkflowItem,
  WorkflowListState,
} from '../../../services/ran-data-importer-service/ran-data-importer.service';
import {
  getRanDataImporterStatusBadgeMode,
  getRanDataImporterStatusBadgeType,
  getRanDataImporterStatusLabel,
} from './ran-data-importer-details/ran-data-importer-status.util';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-ran-data-importer',
  templateUrl: './ran-data-importer.component.html',
  styleUrl: './ran-data-importer.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [
    SharedModule,
    DataTableComponent,
    TableCellDefinitionDirective,
    TableHeaderDefinitionDirective,
    LayoutComponent,
    TitleComponent,
    ResizerComponent,
    TnapSelectComponent,
    TnapButtonComponent,
    BadgeComponent,
    CheckboxComponent,
    RanDataImporterDetailsComponent,
  ],
})
export class RanDataImporterComponent {
  readonly filterDataHelpUrl = signal<string>('');

  readonly importTypes = [
    {
      key: 'planningDataImport',
      variant: 'secondary',
      showVendor: false,
    },
    {
      key: 'runtimeDataImport',
      variant: 'warning',
      showVendor: true,
    },
    {
      key: 'backupDataImport',
      variant: 'primary',
      showVendor: true,
    },
  ] as const;

  private readonly destroyRef = inject(DestroyRef);
  private readonly translateService = inject(TranslateService);
  private readonly lang = toSignal(this.translateService.onLangChange);
  private readonly paginationService = inject(PaginationService);
  private readonly queryParamService = inject(QueryParamService);
  private readonly ranDataImporterService = inject(RanDataImporterService);
  private readonly alertService = inject(TnapAlertService);
  private readonly ranDataImporterDraftService = inject(
    RanDataImporterDraftService
  );

  readonly manualReviewSteps = [1, 2, 3, 4] as const;

  readonly selectedVendor = signal<Record<string, string | null>>({});
  readonly vendorErrors = signal<Record<string, boolean>>({});
  readonly selectedImportType = signal<string | null>(null);
  readonly showImportPopup = signal(false);
  readonly selectedImportMode = signal<'automatic' | 'manual'>('automatic');
  readonly selectedFilterData = signal(false);

  readonly selectedOperation = signal<string | null>(null);

  readonly tableState = signal<WorkflowListState>({ loading: false });

  private readonly loadTrigger$ = new Subject<string>();
  private readonly operationToWorkflowListType: Record<
    string,
    WorkflowListType
  > = {
    'planning-data-import': 'planning-data',
    'runtime-data-import': 'runtime-config',
    'backup-data-import': 'backup-data',
    all: 'all',
  };

  readonly selectedId = signal<string | null>(null);
  readonly selectedWorkflow = signal<WorkflowItem | null>(null);
  readonly selectedWorkflowId = signal<string | null>(null);
  leftPane = 60;
  unit: '%' | 'px' = '%';
  minWidth = 20;
  maxWidth = 70;
  step = 2;

  readonly DEFAULT_PAGE = 1;
  readonly DEFAULT_PAGE_SIZE = 10;
  readonly page$ = this.paginationService.page$;
  readonly pageSize$ = this.paginationService.pageSize$;

  readonly selectedKey = signal<keyof WorkflowItem>('workflowId');

  private toAdminConfigsUrl(sourceUrl: string | undefined | null): string {
    if (!sourceUrl) {
      return '';
    }
    return sourceUrl.replace(
      /\/[^/]+(?:\/-\/tree\/[^/]+)?$/,
      '/ran-do-admin-configs'
    );
  }

  private readonly cardKeyToImportType: Record<string, ImportType> = {
    planningDataImport: 'planning-data',
    runtimeDataImport: 'runtime-config',
    backupDataImport: 'backup-data',
  };

  private readonly importTypeToMessages: Record<
    ImportType,
    { success: string; error: string }
  > = {
    'planning-data': {
      success: ALERT_MESSAGES.saveSuccessRanPlanning,
      error: ALERT_MESSAGES.saveFailedRanPlanning,
    },
    'runtime-config': {
      success: ALERT_MESSAGES.saveSuccessRanRuntime,
      error: ALERT_MESSAGES.saveFailedRanRuntime,
    },
    'backup-data': {
      success: ALERT_MESSAGES.saveSuccessRanBackup,
      error: ALERT_MESSAGES.saveFailedRanBackup,
    },
  };

  constructor() {
    this.destroyRef.onDestroy(() => this.loadTrigger$.complete());

    this.ranDataImporterDraftService.defaultAdminConfigurationDraft$
      .pipe(
        map(sourceDraft => this.toAdminConfigsUrl(sourceDraft?.url)),
        catchError(() => of('')),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(url => this.filterDataHelpUrl.set(url));

    this.loadTrigger$
      .pipe(
        switchMap(operation => {
          const workflowListType = this.operationToWorkflowListType[operation];
          if (!workflowListType) {
            return of<WorkflowListState>({
              loading: false,
              data: { items: [], totalCount: 0 },
            });
          }

          return combineLatest([this.page$, this.pageSize$]).pipe(
            switchMap(([page, pageSize]) =>
              this.ranDataImporterService.getWorkflows(
                workflowListType,
                page,
                pageSize
              )
            )
          );
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(state => {
        this.tableState.set(state);

        if (this.selectedId() && state.data?.items) {
          const selectedWorkflow = this.findSelectedWorkflow(state.data.items);
          this.selectedWorkflow.set(selectedWorkflow);
          this.selectedWorkflowId.set(selectedWorkflow?.workflowId ?? null);
        }
      });

    combineLatest([
      this.queryParamService.getValueOf('operation'),
      this.queryParamService.getValueOf('runId'),
      this.queryParamService.getValueOf('workflowId'),
    ])
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(
        ([operationFromQuery, runIdFromQuery, workflowIdFromQuery]) => {
          const effectiveOperation = operationFromQuery || 'all';

          if (effectiveOperation !== this.selectedOperation()) {
            this.selectedOperation.set(effectiveOperation);
            this.selectedId.set(null);
            this.selectedWorkflow.set(null);
            this.selectedWorkflowId.set(null);
            this.selectedKey.set('workflowId');
            this.loadTrigger$.next(effectiveOperation);
          }

          const runId = runIdFromQuery?.trim() || null;
          const workflowId = workflowIdFromQuery?.trim() || null;

          if (!runId && !workflowId) {
            if (this.selectedId() !== null) {
              this.selectedId.set(null);
              this.selectedWorkflow.set(null);
              this.selectedWorkflowId.set(null);
              this.selectedKey.set('workflowId');
            }
            return;
          }

          if (runId) {
            if (this.selectedKey() === 'runId' && this.selectedId() === runId) {
              return;
            }

            this.selectedKey.set('runId');
            this.selectedId.set(runId);
            const selectedWorkflow =
              this.tableState().data?.items.find(
                item => item.runId === runId
              ) ?? null;
            this.selectedWorkflow.set(selectedWorkflow);
            this.selectedWorkflowId.set(selectedWorkflow?.workflowId ?? null);
            return;
          }

          if (
            this.selectedWorkflowId() === workflowId &&
            this.selectedWorkflow() !== null
          ) {
            return;
          }

          this.selectedKey.set('workflowId');
          this.selectedId.set(workflowId);
          this.selectedWorkflowId.set(workflowId);
          const selectedWorkflow =
            this.tableState().data?.items.find(
              item => item.workflowId === workflowId
            ) ?? null;
          this.selectedWorkflow.set(selectedWorkflow);
        }
      );
  }

  public onOperationChange(operation: string | undefined): void {
    if (!operation) {
      return;
    }
    this.selectedOperation.set(operation);
    this.selectedId.set(null);
    this.selectedWorkflow.set(null);
    this.selectedWorkflowId.set(null);
    this.selectedKey.set('workflowId');
    this.loadTrigger$.next(operation);
    this.paginationService.changePage(1, {
      operation,
      runId: null,
      workflowId: null,
    });
  }

  readonly operationOptions = computed<SelectOption<string>[]>(() => {
    this.lang();
    return [
      {
        value: 'all',
        label: this.translateService.instant(
          'administration.template.ranDataImporter.form.label.allDataImports'
        ),
      },
      {
        value: 'planning-data-import',
        label: this.translateService.instant(
          'administration.template.ranDataImporter.form.field.planningDataImport'
        ),
      },
      {
        value: 'runtime-data-import',
        label: this.translateService.instant(
          'administration.template.ranDataImporter.form.field.runtimeDataImport'
        ),
      },
      {
        value: 'backup-data-import',
        label: this.translateService.instant(
          'administration.template.ranDataImporter.form.field.backupDataImport'
        ),
      },
    ];
  });

  readonly importTypeOptions = computed<SelectOption<string>[]>(() => {
    this.lang();
    return this.importTypes.map(importType => ({
      value: importType.key,
      label: this.translateService.instant(
        'administration.template.ranDataImporter.form.field.' + importType.key
      ),
    }));
  });

  public getImportTypeLabel(importTypeKey: string | null): string {
    if (!importTypeKey) {
      return this.translateService.instant('common.filters.noOptions');
    }

    return this.translateService.instant(
      'administration.template.ranDataImporter.form.field.' + importTypeKey
    );
  }

  readonly selectedImportConfig = computed(() => {
    const selectedImportType = this.selectedImportType();
    if (!selectedImportType) {
      return null;
    }

    return (
      this.importTypes.find(
        importType => importType.key === selectedImportType
      ) ?? null
    );
  });

  public onImportTypeSelect(
    importType: string | SelectOption<string> | undefined
  ): void {
    const selectedValue =
      typeof importType === 'string' ? importType : importType?.value;

    if (!selectedValue) {
      return;
    }

    this.selectedImportType.set(selectedValue);
    this.selectedImportMode.set('automatic');
    this.selectedFilterData.set(false);
    this.showImportPopup.set(true);
  }

  public openSelectedImportPopup(): void {
    if (!this.selectedImportType()) {
      return;
    }

    this.selectedImportMode.set('automatic');
    this.selectedFilterData.set(false);
    this.showImportPopup.set(true);
  }

  public closeImportPopup(): void {
    this.showImportPopup.set(false);
    this.selectedImportType.set(null);
    this.selectedImportMode.set('automatic');
    this.selectedFilterData.set(false);
  }

  public onImportModeChange(mode: 'automatic' | 'manual'): void {
    this.selectedImportMode.set(mode);
  }

  public onFilterDataChange(filterData: boolean): void {
    this.selectedFilterData.set(filterData);
  }

  public onStartImportFromPopup(): void {
    const importType = this.selectedImportType();
    if (!importType) {
      return;
    }

    this.onImport(importType, true, this.selectedFilterData());
  }

  public getVendorOptions(importTypeKey: string): SelectOption<string>[] {
    this.lang();

    const options: SelectOption<string>[] = [
      {
        value: 'Huawei',
        label: this.translateService.instant(
          'administration.template.ranDataImporter.form.vendor.huawei'
        ),
      },
      {
        value: 'Ericsson',
        label: this.translateService.instant(
          'administration.template.ranDataImporter.form.vendor.ericsson'
        ),
      },
    ];

    return importTypeKey === 'backupDataImport'
      ? options.filter(option => option.value !== 'Ericsson')
      : options;
  }

  public onVendorChange(importType: string, vendor: string | undefined): void {
    this.selectedVendor.update(current => ({
      ...current,
      [importType]: vendor ?? null,
    }));
    this.vendorErrors.update(current => ({
      ...current,
      [importType]: false,
    }));
  }

  readonly TASK_COLUMNS = computed<ColumnDefinition<WorkflowItem>[]>(() => {
    this.lang();
    return [
      {
        key: 'workflowType',
        label: this.translateService.instant(
          'administration.template.ranDataImporter.liveTasks.fields.workflowType'
        ),
        value: row => String(row.workflowType ?? ''),
      },
      {
        key: 'workflowId',
        label: this.translateService.instant(
          'administration.template.ranDataImporter.liveTasks.fields.workflowId'
        ),
        value: row => String(row.workflowId ?? ''),
      },
      {
        key: 'startTime',
        label: this.translateService.instant(
          'administration.template.ranDataImporter.liveTasks.fields.startTime'
        ),
        value: row => String(row.startTime ?? ''),
      },
      {
        key: 'endTime',
        label: this.translateService.instant(
          'administration.template.ranDataImporter.liveTasks.fields.endTime'
        ),
        value: row => String(row.endTime ?? ''),
      },
      {
        key: 'status',
        label: this.translateService.instant(
          'administration.template.ranDataImporter.liveTasks.fields.status'
        ),
        value: row => String(row.status ?? ''),
      },
    ];
  });

  public onChangePage(page: number): void {
    this.paginationService.changePage(page, { orderId: null });
  }

  public onChangePageSize(pageSize: number): void {
    this.paginationService.changePageSize(pageSize, { orderId: null });
  }

  public getStatusLabel(status: unknown): string {
    return getRanDataImporterStatusLabel(status);
  }

  public getStatusBadgeType(status: unknown): BadgeType {
    return getRanDataImporterStatusBadgeType(status);
  }

  public getStatusBadgeMode(status: unknown): BadgeMode {
    return getRanDataImporterStatusBadgeMode(status);
  }

  private findSelectedWorkflow(items?: WorkflowItem[]): WorkflowItem | null {
    const id = this.selectedId();
    const key = this.selectedKey();

    if (!id || !items?.length) {
      return null;
    }

    return items.find(item => String(item[key] ?? '') === id) ?? null;
  }

  public openDetail(
    id: string | undefined | null,
    key?: keyof WorkflowItem,
    workflow?: WorkflowItem
  ): void {
    const runId = workflow?.runId ?? (key === 'runId' ? (id ?? null) : null);
    const workflowId =
      workflow?.workflowId ?? (key === 'workflowId' ? (id ?? null) : null);

    this.selectedId.set(id ?? null);
    this.selectedWorkflow.set(workflow ?? null);
    this.selectedWorkflowId.set(workflowId);
    if (key) {
      this.selectedKey.set(key);
    }

    this.queryParamService.updateQueryParam({
      operation: this.selectedOperation(),
      runId,
      workflowId: runId ? null : workflowId,
    });
  }

  public onDetailOpenFromTable(event: WorkflowItem): void {
    const selectedKey: keyof WorkflowItem = event.runId
      ? 'runId'
      : 'workflowId';
    const selectedId =
      selectedKey === 'runId' ? (event.runId ?? null) : event.workflowId;

    if (
      this.selectedKey() === selectedKey &&
      this.selectedId() === selectedId
    ) {
      this.openDetail(undefined);
    } else {
      this.openDetail(selectedId, selectedKey, event);
    }
  }

  public onLeftPaneChange(value: number): void {
    this.leftPane = value;
  }

  public refreshSelectedOperation(): void {
    const operation = this.selectedOperation();

    if (!operation) {
      return;
    }

    this.loadTrigger$.next(operation);
  }

  onImport(
    importType: string,
    closePopupOnSuccess = false,
    toFilterData = false
  ): void {
    const vendor = this.selectedVendor()[importType] || null;
    const mappedImportType = this.cardKeyToImportType[importType];
    if (!mappedImportType) {
      return;
    }
    const messages = this.importTypeToMessages[mappedImportType];
    const manualVerification =
      mappedImportType === 'planning-data'
        ? this.selectedImportMode() === 'manual'
        : undefined;

    if (mappedImportType !== 'planning-data' && !vendor) {
      this.vendorErrors.update(current => ({
        ...current,
        [importType]: true,
      }));
      return;
    }

    this.vendorErrors.update(current => ({
      ...current,
      [importType]: false,
    }));

    this.ranDataImporterService
      .startImport(mappedImportType, vendor, manualVerification, toFilterData)
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        catchError(() => {
          this.alertService.error(
            this.translateService.instant(messages.error),
            { keepAfterRouteChange: true }
          );
          return EMPTY;
        })
      )
      .subscribe(() => {
        this.selectedVendor.update(current => ({
          ...current,
          [importType]: null,
        }));
        this.refreshSelectedOperation();
        if (closePopupOnSuccess && this.selectedImportType() === importType) {
          this.closeImportPopup();
        }
        this.alertService.success(
          this.translateService.instant(messages.success),
          { keepAfterRouteChange: true }
        );
      });
  }
}
