/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { of, Subject, throwError } from 'rxjs';

import { TranslateModule, TranslateService } from '@ngx-translate/core';

import { RanDataImporterComponent } from './ran-data-importer.component';
import { PaginationService } from '../../../services/common-functionalities/pagination.service';
import {
  RanDataImporterService,
  WorkflowListResponse,
  WorkflowListType,
} from '../../../services/ran-data-importer-service/ran-data-importer.service';
import { QueryParamService } from '../../../services/query-param.service';
import { ALERT_MESSAGES } from '../configuration';
import { RanDataImporterDraftService } from '../../../services/ran-data-importer-service/ran-data-importer-draft.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

const planningTasksData: WorkflowListResponse = {
  totalCount: 2,
  items: [
    {
      workflowId: 'planning-123',
      runId: 'run-001',
      status: 'COMPLETED',
      startTime: '2024-05-02T12:17:44Z',
      endTime: '2024-05-02T12:19:24Z',
      workflowType: 'ImportPlanningDataWorkflow',
    },
    {
      workflowId: 'planning-124',
      runId: 'run-002',
      status: 'RUNNING',
      startTime: '2024-05-02T12:20:44Z',
      endTime: '',
      workflowType: 'ImportPlanningDataWorkflow',
    },
  ],
};

const runtimeTasksData: WorkflowListResponse = {
  totalCount: 1,
  items: [
    {
      workflowId: 'runtime-123',
      runId: 'run-003',
      status: 'COMPLETED',
      startTime: '2024-05-03T10:00:00Z',
      endTime: '2024-05-03T10:05:00Z',
      workflowType: 'ImportRuntimeDataWorkflow',
    },
  ],
};

const backupTasksData: WorkflowListResponse = {
  totalCount: 1,
  items: [
    {
      workflowId: 'backup-123',
      runId: 'run-004',
      status: 'FAILED',
      startTime: '2024-05-04T08:00:00Z',
      endTime: '2024-05-04T08:02:00Z',
      workflowType: 'ImportBackupDataWorkflow',
    },
  ],
};

const allTasksData: WorkflowListResponse = {
  totalCount: 4,
  items: [
    ...planningTasksData.items,
    ...runtimeTasksData.items,
    ...backupTasksData.items,
  ],
};

describe('RanDataImporterComponent', () => {
  let component: RanDataImporterComponent;
  let fixture: ComponentFixture<RanDataImporterComponent>;
  let mockPaginationService: jasmine.SpyObj<PaginationService>;
  let mockRanDataImporterService: jasmine.SpyObj<RanDataImporterService>;
  let mockQueryParamService: jasmine.SpyObj<QueryParamService>;
  let mockAlertService: jasmine.SpyObj<TnapAlertService>;
  let operationParam$: Subject<string | null>;
  let runIdParam$: Subject<string | null>;
  let workflowIdParam$: Subject<string | null>;

  beforeEach(async () => {
    mockPaginationService = jasmine.createSpyObj(
      'PaginationService',
      ['changePage', 'changePageSize'],
      {
        page$: of(1),
        pageSize$: of(10),
      }
    );

    mockRanDataImporterService = jasmine.createSpyObj(
      'RanDataImporterService',
      ['getWorkflows', 'getWorkflowDetail', 'startImport']
    );
    mockRanDataImporterService.getWorkflows.and.callFake(
      (type: WorkflowListType, page: number, size: number) => {
        expect(page).toBeGreaterThan(0);
        expect(size).toBeGreaterThan(0);
        if (type === 'all') {
          return of({ loading: false, data: allTasksData });
        }
        if (type === 'runtime-config') {
          return of({ loading: false, data: runtimeTasksData });
        }
        if (type === 'backup-data') {
          return of({ loading: false, data: backupTasksData });
        }
        return of({ loading: false, data: planningTasksData });
      }
    );
    mockRanDataImporterService.getWorkflowDetail.and.returnValue(
      of({ loading: false, data: planningTasksData.items[0] })
    );
    mockRanDataImporterService.startImport.and.returnValue(of(void 0));

    mockAlertService = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
    ]);

    operationParam$ = new Subject<string | null>();
    runIdParam$ = new Subject<string | null>();
    workflowIdParam$ = new Subject<string | null>();
    mockQueryParamService = jasmine.createSpyObj('QueryParamService', [
      'getValueOf',
      'updateQueryParam',
    ]);
    mockQueryParamService.getValueOf.and.callFake(param => {
      if (param === 'operation') {
        return operationParam$.asObservable();
      }
      if (param === 'runId') {
        return runIdParam$.asObservable();
      }
      if (param === 'workflowId') {
        return workflowIdParam$.asObservable();
      }
      return of(null);
    });

    await TestBed.configureTestingModule({
      imports: [RanDataImporterComponent, TranslateModule.forRoot()],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [
        { provide: PaginationService, useValue: mockPaginationService },
        { provide: QueryParamService, useValue: mockQueryParamService },
        {
          provide: RanDataImporterService,
          useValue: mockRanDataImporterService,
        },
        { provide: TnapAlertService, useValue: mockAlertService },
        {
          provide: RanDataImporterDraftService,
          useValue: { defaultAdminConfigurationDraft$: of(null) },
        },
      ],
    }).compileComponents();

    const translateService = TestBed.inject(TranslateService);
    translateService.setTranslation('en', {}, true);
    translateService.use('en');

    fixture = TestBed.createComponent(RanDataImporterComponent);
    component = fixture.componentInstance;
    operationParam$.next(null);
    runIdParam$.next(null);
    workflowIdParam$.next(null);
    fixture.detectChanges();
  });

  describe('Component Creation', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should have default properties initialized', () => {
      expect(component.selectedId()).toBeNull();
      expect(component.leftPane).toBe(60);
      expect(component.unit).toBe('%');
      expect(component.minWidth).toBe(20);
      expect(component.maxWidth).toBe(70);
      expect(component.step).toBe(2);
      expect(component.DEFAULT_PAGE).toBe(1);
      expect(component.DEFAULT_PAGE_SIZE).toBe(10);
    });

    it('should have default selectedOperation as "all"', () => {
      expect(component.selectedOperation()).toBe('all');
    });

    it('should have default selectedKey as workflowId', () => {
      expect(component.selectedKey()).toBe('workflowId');
    });
  });

  describe('initial state', () => {
    it('should fetch all workflows on init', () => {
      expect(mockRanDataImporterService.getWorkflows).toHaveBeenCalledWith(
        'all',
        component.DEFAULT_PAGE,
        component.DEFAULT_PAGE_SIZE
      );
    });

    it('should populate tableState with all workflows on init', () => {
      expect(component.tableState().loading).toBeFalse();
      expect(component.tableState().data).toEqual(allTasksData);
    });
  });

  describe('popup filter state', () => {
    it('should reset filter data when selecting an import type', () => {
      component.selectedFilterData.set(true);

      component.onImportTypeSelect('planningDataImport');

      expect(component.selectedFilterData()).toBeFalse();
      expect(component.showImportPopup()).toBeTrue();
    });

    it('should reset filter data when reopening the selected import popup', () => {
      component.selectedImportType.set('runtimeDataImport');
      component.selectedFilterData.set(true);

      component.openSelectedImportPopup();

      expect(component.selectedFilterData()).toBeFalse();
      expect(component.showImportPopup()).toBeTrue();
    });

    it('should reset filter data when closing the popup', () => {
      component.selectedFilterData.set(true);

      component.closeImportPopup();

      expect(component.selectedFilterData()).toBeFalse();
      expect(component.selectedImportType()).toBeNull();
      expect(component.showImportPopup()).toBeFalse();
    });

    it('should hide filter checkbox for backup imports', () => {
      component.selectedImportType.set('backupDataImport');
      component.showImportPopup.set(true);
      fixture.detectChanges();

      expect(
        fixture.nativeElement.querySelector(
          '#filterDataCheckbox-backupDataImport'
        )
      ).toBeNull();
      expect(
        fixture.nativeElement.querySelector('.qa_ran_import_filter_data')
      ).toBeNull();
    });

    it('should render filter checkbox wrapper for planning imports', () => {
      component.selectedImportType.set('planningDataImport');
      component.showImportPopup.set(true);
      fixture.detectChanges();

      expect(
        fixture.nativeElement.querySelector('.qa_ran_import_filter_data')
      ).not.toBeNull();
    });
  });

  describe('onOperationChange', () => {
    it('should update selectedOperation and load all workflows', () => {
      component.onOperationChange('all');
      expect(component.selectedOperation()).toBe('all');
      expect(component.tableState().data).toEqual(allTasksData);
      expect(mockPaginationService.changePage).toHaveBeenCalledWith(1, {
        operation: 'all',
        runId: null,
        workflowId: null,
      });
    });

    it('should update selectedOperation and load runtime dummy workflows', () => {
      component.onOperationChange('runtime-data-import');
      expect(component.selectedOperation()).toBe('runtime-data-import');
      expect(component.tableState().data).toEqual(runtimeTasksData);
      expect(mockPaginationService.changePage).toHaveBeenCalledWith(1, {
        operation: 'runtime-data-import',
        runId: null,
        workflowId: null,
      });
    });

    it('should update selectedOperation and load backup dummy workflows', () => {
      component.onOperationChange('backup-data-import');
      expect(component.selectedOperation()).toBe('backup-data-import');
      expect(component.tableState().data).toEqual(backupTasksData);
      expect(mockPaginationService.changePage).toHaveBeenCalledWith(1, {
        operation: 'backup-data-import',
        runId: null,
        workflowId: null,
      });
    });

    it('should update selectedOperation and load planning dummy workflows', () => {
      component.onOperationChange('planning-data-import');
      expect(component.selectedOperation()).toBe('planning-data-import');
      expect(component.tableState().data).toEqual(planningTasksData);
      expect(mockPaginationService.changePage).toHaveBeenCalledWith(1, {
        operation: 'planning-data-import',
        runId: null,
        workflowId: null,
      });
    });

    it('should ignore undefined operation', () => {
      const previousOperation = component.selectedOperation();
      component.onOperationChange(undefined);
      expect(component.selectedOperation()).toBe(previousOperation);
    });

    it('should clear selectedId when operation changes', () => {
      component.selectedId.set('some-id');
      component.onOperationChange('backup-data-import');
      expect(component.selectedId()).toBeNull();
      expect(component.selectedWorkflowId()).toBeNull();
    });
  });

  describe('openDetail', () => {
    it('should set selectedId and selectedKey', () => {
      component.openDetail('planning-123', 'workflowId');
      expect(component.selectedId()).toBe('planning-123');
      expect(component.selectedKey()).toBe('workflowId');
      expect(component.selectedWorkflowId()).toBe('planning-123');
    });

    it('should set selectedId with runId key', () => {
      component.openDetail('run-001', 'runId');
      expect(component.selectedId()).toBe('run-001');
      expect(component.selectedKey()).toBe('runId');
    });

    it('should clear selectedId when receiving undefined', () => {
      component.selectedId.set('planning-123');
      component.openDetail(undefined);
      expect(component.selectedId()).toBeNull();
      expect(component.selectedWorkflowId()).toBeNull();
    });

    it('should clear selectedId when receiving null', () => {
      component.selectedId.set('planning-123');
      component.openDetail(null);
      expect(component.selectedId()).toBeNull();
      expect(component.selectedWorkflowId()).toBeNull();
    });

    it('should keep existing selectedKey when key is not provided', () => {
      component.selectedKey.set('runId');
      component.openDetail('some-id');
      expect(component.selectedKey()).toBe('runId');
    });

    it('should persist open detail in query params', () => {
      component.onOperationChange('planning-data-import');
      component.openDetail(
        'planning-123',
        'workflowId',
        planningTasksData.items[0]
      );
      expect(mockQueryParamService.updateQueryParam).toHaveBeenCalledWith({
        operation: 'planning-data-import',
        runId: 'run-001',
        workflowId: null,
      });
    });

    it('should prefer runId for table detail selection', () => {
      const firstRow = {
        workflowId: 'shared-workflow',
        runId: 'run-001',
        status: 'COMPLETED',
      } as any;
      const secondRow = {
        workflowId: 'shared-workflow',
        runId: 'run-002',
        status: 'RUNNING',
      } as any;

      component.onDetailOpenFromTable(firstRow);
      component.onDetailOpenFromTable(secondRow);

      expect(component.selectedKey()).toBe('runId');
      expect(component.selectedId()).toBe('run-002');
      expect(component.selectedWorkflow()).toEqual(secondRow);
      expect(component.selectedWorkflowId()).toBe('shared-workflow');
      expect(mockQueryParamService.updateQueryParam).toHaveBeenCalledWith({
        operation: component.selectedOperation(),
        runId: 'run-002',
        workflowId: null,
      });
    });

    it('should resolve selection by runId when query param sync emits runId', () => {
      component.selectedOperation.set('planning-data-import');
      component.tableState.set({
        loading: false,
        data: {
          items: [
            {
              workflowId: 'planning-123',
              runId: 'run-001',
              status: 'COMPLETED',
            },
            {
              workflowId: 'planning-124',
              runId: 'run-002',
              status: 'RUNNING',
            },
          ],
          totalCount: 2,
        },
      });

      operationParam$.next('planning-data-import');
      runIdParam$.next('run-001');
      workflowIdParam$.next(null);

      expect(component.selectedKey()).toBe('runId');
      expect(component.selectedId()).toBe('run-001');
      expect(component.selectedWorkflow()).toEqual(
        component.tableState().data!.items[0]
      );
      expect(component.selectedWorkflowId()).toBe('planning-123');
    });

    it('should resolve selection by workflowId for backward-compatible query param', () => {
      component.tableState.set({
        loading: false,
        data: {
          items: [
            {
              workflowId: 'shared-workflow',
              runId: 'run-001',
              status: 'COMPLETED',
            },
            {
              workflowId: 'shared-workflow',
              runId: 'run-002',
              status: 'RUNNING',
            },
          ],
          totalCount: 2,
        },
      });

      operationParam$.next('planning-data-import');
      runIdParam$.next(null);
      workflowIdParam$.next('shared-workflow');

      expect(component.selectedKey()).toBe('workflowId');
      expect(component.selectedId()).toBe('shared-workflow');
      expect(component.selectedWorkflow()).toBeNull();
      expect(component.selectedWorkflowId()).toBe('shared-workflow');
    });
  });

  describe('query param sync', () => {
    it('should load runtime data when operation query param changes', () => {
      operationParam$.next('runtime-data-import');
      runIdParam$.next(null);
      workflowIdParam$.next(null);

      expect(component.selectedOperation()).toBe('runtime-data-import');
      expect(component.tableState().data).toEqual(runtimeTasksData);
    });

    it('should clear selected detail when operation query param is removed', () => {
      component.selectedOperation.set('planning-data-import');
      component.selectedId.set('planning-123');
      component.selectedWorkflow.set(planningTasksData.items[0]);

      operationParam$.next(null);
      runIdParam$.next(null);
      workflowIdParam$.next(null);

      expect(component.selectedId()).toBeNull();
      expect(component.selectedWorkflow()).toBeNull();
    });
  });

  describe('onChangePage', () => {
    it('should call paginationService.changePage with correct arguments', () => {
      component.onChangePage(2);
      expect(mockPaginationService.changePage).toHaveBeenCalledWith(2, {
        orderId: null,
      });
    });

    it('should call paginationService.changePage with page 1', () => {
      component.onChangePage(1);
      expect(mockPaginationService.changePage).toHaveBeenCalledWith(1, {
        orderId: null,
      });
    });
  });

  describe('onChangePageSize', () => {
    it('should call paginationService.changePageSize with correct arguments', () => {
      component.onChangePageSize(20);
      expect(mockPaginationService.changePageSize).toHaveBeenCalledWith(20, {
        orderId: null,
      });
    });

    it('should call paginationService.changePageSize with size 50', () => {
      component.onChangePageSize(50);
      expect(mockPaginationService.changePageSize).toHaveBeenCalledWith(50, {
        orderId: null,
      });
    });
  });

  describe('onImport', () => {
    it('should start planning import without vendor', () => {
      component.onImport('planningDataImport');

      expect(mockRanDataImporterService.startImport).toHaveBeenCalledWith(
        'planning-data',
        null,
        false,
        false
      );
      expect(mockAlertService.success).toHaveBeenCalledWith(
        ALERT_MESSAGES.saveSuccessRanPlanning,
        { keepAfterRouteChange: true }
      );
    });

    it('should start planning import with manual verification when manual mode selected', () => {
      component.onImportModeChange('manual');
      component.onImport('planningDataImport');

      expect(mockRanDataImporterService.startImport).toHaveBeenCalledWith(
        'planning-data',
        null,
        true,
        false
      );
    });

    it('should start planning import with filter data from popup', () => {
      component.selectedImportType.set('planningDataImport');
      component.onFilterDataChange(true);

      component.onStartImportFromPopup();

      expect(mockRanDataImporterService.startImport).toHaveBeenCalledWith(
        'planning-data',
        null,
        false,
        true
      );
    });

    it('should start runtime import with selected vendor', () => {
      component.selectedVendor.set({ runtimeDataImport: 'Ericsson' });
      component.onImport('runtimeDataImport');

      expect(mockRanDataImporterService.startImport).toHaveBeenCalledWith(
        'runtime-config',
        'Ericsson',
        undefined,
        false
      );
      expect(mockAlertService.success).toHaveBeenCalledWith(
        ALERT_MESSAGES.saveSuccessRanRuntime,
        { keepAfterRouteChange: true }
      );
      expect(component.selectedVendor()['runtimeDataImport']).toBeNull();
    });

    it('should show error alert when import fails', () => {
      mockRanDataImporterService.startImport.and.returnValue(
        throwError(() => new Error('import failed'))
      );

      component.onImport('planningDataImport');

      expect(mockAlertService.error).toHaveBeenCalledWith(
        ALERT_MESSAGES.saveFailedRanPlanning,
        { keepAfterRouteChange: true }
      );
      expect(mockAlertService.success).not.toHaveBeenCalled();
    });

    it('should not start runtime import when vendor is missing', () => {
      component.selectedVendor.set({ runtimeDataImport: null });
      component.onImport('runtimeDataImport');
      expect(mockRanDataImporterService.startImport).not.toHaveBeenCalled();
      expect(component.vendorErrors()['runtimeDataImport']).toBeTrue();
    });

    it('should not start backup import when vendor is missing', () => {
      component.selectedVendor.set({ backupDataImport: null });
      component.onImport('backupDataImport');
      expect(mockRanDataImporterService.startImport).not.toHaveBeenCalled();
      expect(component.vendorErrors()['backupDataImport']).toBeTrue();
    });

    it('should ignore unknown import type key', () => {
      component.onImport('unknownImportType');
      expect(mockRanDataImporterService.startImport).not.toHaveBeenCalled();
    });
  });

  describe('Options', () => {
    it('should have 4 operation options', () => {
      expect(component.operationOptions()).toBeDefined();
      expect(component.operationOptions().length).toBe(4);
    });

    it('should have correct operation option values', () => {
      const values = component.operationOptions().map(opt => opt.value);
      expect(values).toContain('all');
      expect(values).toContain('planning-data-import');
      expect(values).toContain('runtime-data-import');
      expect(values).toContain('backup-data-import');
    });

    it('should return both vendors for non-backup import type', () => {
      const values = component
        .getVendorOptions('runtimeDataImport')
        .map(opt => opt.value);

      expect(values).toContain('Huawei');
      expect(values).toContain('Ericsson');
      expect(values.length).toBe(2);
    });

    it('should filter out Ericsson for backup import type', () => {
      const values = component
        .getVendorOptions('backupDataImport')
        .map(opt => opt.value);

      expect(values).toContain('Huawei');
      expect(values).not.toContain('Ericsson');
      expect(values.length).toBe(1);
    });

    it('should return full vendor list for unknown import type key', () => {
      const values = component
        .getVendorOptions('unknownImportType')
        .map(opt => opt.value);

      expect(values).toContain('Huawei');
      expect(values).toContain('Ericsson');
      expect(values.length).toBe(2);
    });
  });

  describe('TASK_COLUMNS', () => {
    it('should have TASK_COLUMNS computed signal defined', () => {
      const columns = component.TASK_COLUMNS();
      expect(columns).toBeDefined();
      expect(columns.length).toBe(5);
    });

    it('should have correct column keys', () => {
      const columns = component.TASK_COLUMNS();
      const keys = columns.map(col => col.key);
      expect(keys).toEqual([
        'workflowType',
        'workflowId',
        'startTime',
        'endTime',
        'status',
      ]);
    });

    it('should extract workflowId value correctly', () => {
      const columns = component.TASK_COLUMNS();
      const workflowIdCol = columns.find(col => col.key === 'workflowId');
      const testRow = planningTasksData.items[0];
      expect(workflowIdCol?.value(testRow)).toBe('planning-123');
    });

    it('should extract workflowType value correctly', () => {
      const columns = component.TASK_COLUMNS();
      const typeCol = columns.find(col => col.key === 'workflowType');
      const testRow = planningTasksData.items[0];
      expect(typeCol?.value(testRow)).toBe('ImportPlanningDataWorkflow');
    });

    it('should extract startTime value correctly', () => {
      const columns = component.TASK_COLUMNS();
      const startTimeCol = columns.find(col => col.key === 'startTime');
      const testRow = planningTasksData.items[0];
      expect(startTimeCol?.value(testRow)).toBe('2024-05-02T12:17:44Z');
    });

    it('should extract endTime value correctly', () => {
      const columns = component.TASK_COLUMNS();
      const endTimeCol = columns.find(col => col.key === 'endTime');
      const testRow = planningTasksData.items[0];
      expect(endTimeCol?.value(testRow)).toBe('2024-05-02T12:19:24Z');
    });

    it('should extract status value correctly', () => {
      const columns = component.TASK_COLUMNS();
      const statusCol = columns.find(col => col.key === 'status');
      const testRow = planningTasksData.items[0];
      expect(statusCol?.value(testRow)).toBe('COMPLETED');
    });
  });

  describe('Task Data', () => {
    it('should have planningTasksData with 2 items', () => {
      expect(planningTasksData.totalCount).toBe(2);
      expect(planningTasksData.items.length).toBe(2);
    });

    it('should have runtimeTasksData with 1 item', () => {
      expect(runtimeTasksData.totalCount).toBe(1);
      expect(runtimeTasksData.items.length).toBe(1);
    });

    it('should have backupTasksData with 1 item', () => {
      expect(backupTasksData.totalCount).toBe(1);
      expect(backupTasksData.items.length).toBe(1);
    });

    it('should have correct status in planning tasks', () => {
      expect(planningTasksData.items[0].status).toBe('COMPLETED');
      expect(planningTasksData.items[1].status).toBe('RUNNING');
    });

    it('should have FAILED status in backup task', () => {
      expect(backupTasksData.items[0].status).toBe('FAILED');
    });
  });

  describe('getStatusBadgeType', () => {
    it('should return danger for FAILED', () => {
      expect(component.getStatusBadgeType('FAILED')).toBe('danger');
    });

    it('should return success for COMPLETED', () => {
      expect(component.getStatusBadgeType('COMPLETED')).toBe('success');
    });

    it('should return mapped types for the remaining workflow statuses', () => {
      expect(component.getStatusBadgeType('RUNNING')).toBe('info');
      expect(component.getStatusBadgeType('AWAITING_MANUAL_VERIFICATION')).toBe(
        'info'
      );
      expect(component.getStatusBadgeType('CANCELED')).toBe('secondary');
      expect(component.getStatusBadgeType('TERMINATED')).toBe('secondary');
      expect(component.getStatusBadgeType('TIMED_OUT')).toBe('secondary');
      expect(component.getStatusBadgeType('CONTINUED_AS_NEW')).toBe(
        'secondary'
      );
      expect(component.getStatusBadgeType('UNSPECIFIED')).toBe('secondary');
    });

    it('should return info light for unknown status', () => {
      expect(component.getStatusBadgeType('PENDING')).toBe('info');
      expect(component.getStatusBadgeMode('PENDING')).toBe('light');
    });

    it('should return info light for null', () => {
      expect(component.getStatusBadgeType(null)).toBe('info');
      expect(component.getStatusBadgeMode(null)).toBe('light');
    });

    it('should be case-insensitive', () => {
      expect(component.getStatusBadgeType('failed')).toBe('danger');
      expect(component.getStatusBadgeType('completed')).toBe('success');
    });
  });

  describe('getStatusLabel', () => {
    it('should return mapped label for FAILED', () => {
      expect(component.getStatusLabel('FAILED')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.failed'
      );
    });

    it('should return mapped label for COMPLETED', () => {
      expect(component.getStatusLabel('COMPLETED')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.completed'
      );
    });

    it('should return mapped labels for the remaining workflow statuses', () => {
      expect(component.getStatusLabel('RUNNING')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.running'
      );
      expect(component.getStatusLabel('AWAITING_MANUAL_VERIFICATION')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.awaitingManualVerification'
      );
      expect(component.getStatusLabel('CANCELED')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.canceled'
      );
      expect(component.getStatusLabel('TERMINATED')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.terminated'
      );
      expect(component.getStatusLabel('TIMED_OUT')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.timedOut'
      );
      expect(component.getStatusLabel('CONTINUED_AS_NEW')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.continuedAsNew'
      );
      expect(component.getStatusLabel('UNSPECIFIED')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.unspecified'
      );
    });

    it('should return raw value for unknown status', () => {
      expect(component.getStatusLabel('PENDING')).toBe('PENDING');
    });

    it('should return empty string for null', () => {
      expect(component.getStatusLabel(null)).toBe('');
    });

    it('should be case-insensitive for lookup', () => {
      expect(component.getStatusLabel('failed')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.failed'
      );
    });
  });

  describe('manualReviewSteps', () => {
    it('should contain steps 1 through 4', () => {
      expect(component.manualReviewSteps).toEqual([1, 2, 3, 4]);
    });

    it('should have 4 steps', () => {
      expect(component.manualReviewSteps.length).toBe(4);
    });
  });
});
