/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { of, Subject, throwError } from 'rxjs';
import { FileSaverService } from 'ngx-filesaver';

import { TranslateModule } from '@ngx-translate/core';

import { ALERT_MESSAGES } from '../../configuration';

import { RanDataImporterService } from '../../../../services/ran-data-importer-service/ran-data-importer.service';
import { RanDataImporterDetailsComponent } from './ran-data-importer-details.component';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

function createFileList(names: string[]): FileList {
  const files = names.map(name => new File(['content'], name));
  const fileList = {
    length: files.length,
    item: (index: number) => files[index] ?? null,
  } as FileList;

  files.forEach((file, index) => {
    (fileList as Record<number, File>)[index] = file;
  });

  return fileList;
}

function createFiles(names: string[]): File[] {
  return names.map(name => new File(['content'], name));
}

describe('RanDataImporterDetailsComponent', () => {
  let component: RanDataImporterDetailsComponent;
  let fixture: ComponentFixture<RanDataImporterDetailsComponent>;
  let serviceSpy: jasmine.SpyObj<RanDataImporterService>;
  let alertServiceSpy: jasmine.SpyObj<TnapAlertService>;
  let fileSaverSpy: jasmine.SpyObj<FileSaverService>;

  beforeEach(async () => {
    serviceSpy = jasmine.createSpyObj<RanDataImporterService>(
      'RanDataImporterService',
      [
        'getWorkflowDetail',
        'resumeWorkflow',
        'downloadWorkflowArtifact',
        'uploadWorkflowArtifact',
        'getObjectsByBucket',
      ]
    );
    alertServiceSpy = jasmine.createSpyObj<TnapAlertService>(
      'TnapAlertService',
      ['success', 'error']
    );
    fileSaverSpy = jasmine.createSpyObj<FileSaverService>('FileSaverService', [
      'save',
    ]);

    serviceSpy.getWorkflowDetail.and.returnValue(
      of({
        loading: false,
        data: {
          workflowId: 'wf-123',
          runId: 'run-456',
          workflowType: 'runtime-config',
          status: 'COMPLETED',
          startTime: '2026-06-30T08:00:00Z',
          endTime: '2026-06-30T08:05:00Z',
          region: 'eu-central-1',
        },
      })
    );
    serviceSpy.resumeWorkflow.and.returnValue(of(void 0));
    serviceSpy.uploadWorkflowArtifact.and.returnValue(of({} as any));
    serviceSpy.getObjectsByBucket.and.returnValue(
      of({ objects: [], nextContinuationToken: undefined } as any)
    );
    await TestBed.configureTestingModule({
      imports: [RanDataImporterDetailsComponent, TranslateModule.forRoot()],
      providers: [
        { provide: RanDataImporterService, useValue: serviceSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
        { provide: FileSaverService, useValue: fileSaverSpy },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(RanDataImporterDetailsComponent);
    component = fixture.componentInstance;
  });

  it('loads workflow details for the selected workflow and operation', () => {
    fixture.componentRef.setInput('workflowId', 'wf-123');
    fixture.componentRef.setInput('importOperation', 'runtime-data-import');

    fixture.detectChanges();

    expect(serviceSpy.getWorkflowDetail).toHaveBeenCalledWith(
      'runtime-config',
      'wf-123',
      undefined
    );
    expect(component.detail()).toEqual(
      jasmine.objectContaining({
        workflowId: 'wf-123',
        region: 'eu-central-1',
      })
    );
    expect(component.detailKeyValueData()).toContain([
      'region',
      'eu-central-1',
    ]);
  });

  it('resolves the import type from workflow data when operation is all', () => {
    fixture.componentRef.setInput('workflowId', 'wf-123');
    fixture.componentRef.setInput('importOperation', 'all');
    fixture.componentRef.setInput('workflow', {
      workflowId: 'wf-123',
      runId: 'run-456',
      workflowType: 'ImportRuntimeDataWorkflow',
      status: 'COMPLETED',
    } as any);

    fixture.detectChanges();

    expect(serviceSpy.getWorkflowDetail).toHaveBeenCalledWith(
      'runtime-config',
      'wf-123',
      'run-456'
    );
  });

  it('shows dash placeholders in summary data for empty values', () => {
    serviceSpy.getWorkflowDetail.and.returnValue(
      of({
        loading: false,
        data: {
          workflowId: '',
          runId: null,
          workflowType: undefined,
          status: 'COMPLETED',
          startTime: '',
          endTime: null,
        },
      } as any)
    );

    fixture.componentRef.setInput('workflowId', 'wf-123');
    fixture.componentRef.setInput('importOperation', 'runtime-data-import');
    fixture.detectChanges();

    expect(component.summaryKeyValueData()).toEqual([
      ['workflowId', '-'],
      ['runId', '-'],
      ['status', 'COMPLETED'],
      ['workflowType', '-'],
      ['startTime', '-'],
      ['endTime', '-'],
    ]);
  });

  it('should mark path rows as custom link cells', () => {
    const pathColumn = component.DETAIL_COLUMNS.find(
      column => typeof column !== 'string' && column.key === 'path'
    ) as { custom?: boolean };

    expect(pathColumn.custom).toBeTrue();
  });

  it('should use planning bucket for planning data and network for other imports', () => {
    fixture.componentRef.setInput('workflowId', 'wf-123');

    fixture.componentRef.setInput('importOperation', 'planning-data-import');
    fixture.detectChanges();
    expect(component.pathBucketName()).toBe('planning');

    fixture.componentRef.setInput('importOperation', 'runtime-data-import');
    fixture.detectChanges();
    expect(component.pathBucketName()).toBe('network');

    fixture.componentRef.setInput('importOperation', 'backup-data-import');
    fixture.detectChanges();
    expect(component.pathBucketName()).toBe('network');
  });

  it('emits closeDetail when the close button is clicked', () => {
    const closeSpy = jasmine.createSpy('closeDetail');
    component.closeDetail.subscribe(closeSpy);

    fixture.detectChanges();

    fixture.debugElement.query(By.css('button')).nativeElement.click();

    expect(closeSpy).toHaveBeenCalled();
  });

  describe('status badge mapping', () => {
    it('should return danger and mapped label for FAILED', () => {
      expect(component.getStatusBadgeType('FAILED')).toBe('danger');
      expect(component.getStatusLabel('FAILED')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.failed'
      );
    });

    it('should return success and mapped label for COMPLETED', () => {
      expect(component.getStatusBadgeType('COMPLETED')).toBe('success');
      expect(component.getStatusLabel('COMPLETED')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.completed'
      );
    });

    it('should return warning and mapped label for PARTIAL_SUCCESS', () => {
      expect(component.getStatusBadgeType('PARTIAL_SUCCESS')).toBe('warning');
      expect(component.getStatusLabel('PARTIAL_SUCCESS')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.partialSuccess'
      );
    });

    it('should return info and mapped label for AWAITING_MANUAL_VERIFICATION', () => {
      expect(component.getStatusBadgeType('AWAITING_MANUAL_VERIFICATION')).toBe(
        'info'
      );
      expect(component.getStatusLabel('AWAITING_MANUAL_VERIFICATION')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.awaitingManualVerification'
      );
    });

    it('should return mapped types and labels for the remaining workflow statuses', () => {
      expect(component.getStatusBadgeType('RUNNING')).toBe('info');
      expect(component.getStatusLabel('RUNNING')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.running'
      );
      expect(component.getStatusBadgeType('CANCELED')).toBe('secondary');
      expect(component.getStatusLabel('CANCELED')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.canceled'
      );
      expect(component.getStatusBadgeType('TERMINATED')).toBe('secondary');
      expect(component.getStatusLabel('TERMINATED')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.terminated'
      );
      expect(component.getStatusBadgeType('TIMED_OUT')).toBe('secondary');
      expect(component.getStatusLabel('TIMED_OUT')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.timedOut'
      );
      expect(component.getStatusBadgeType('CONTINUED_AS_NEW')).toBe(
        'secondary'
      );
      expect(component.getStatusLabel('CONTINUED_AS_NEW')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.continuedAsNew'
      );
      expect(component.getStatusBadgeType('UNSPECIFIED')).toBe('secondary');
      expect(component.getStatusLabel('UNSPECIFIED')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.unspecified'
      );
    });

    it('should return info and raw value for unknown status', () => {
      expect(component.getStatusBadgeType('PENDING')).toBe('info');
      expect(component.getStatusBadgeMode('PENDING')).toBe('light');
      expect(component.getStatusLabel('PENDING')).toBe('PENDING');
    });

    it('should normalize unknown status label casing', () => {
      expect(component.getStatusLabel('running')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.running'
      );
    });

    it('should be case-insensitive for status lookup', () => {
      expect(component.getStatusBadgeType('failed')).toBe('danger');
      expect(component.getStatusLabel('failed')).toBe(
        'administration.template.ranDataImporter.liveTasks.statusLabels.failed'
      );
    });
  });

  describe('isAwaitingManualVerification', () => {
    it('should return true only for AWAITING_MANUAL_VERIFICATION with manual verification requested', () => {
      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: {
            workflowId: 'wf-123',
            runId: 'run-456',
            status: 'AWAITING_MANUAL_VERIFICATION',
            isManualVerificationRequested: true,
          },
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-124');
      fixture.componentRef.setInput('importOperation', 'planning-data-import');
      fixture.detectChanges();

      expect(component.isAwaitingManualVerification()).toBeTrue();
    });

    it('should return false for AWAITING_MANUAL_VERIFICATION when manual verification is not requested', () => {
      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: {
            workflowId: 'wf-123',
            runId: 'run-456',
            status: 'AWAITING_MANUAL_VERIFICATION',
            isManualVerificationRequested: false,
          },
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-124');
      fixture.componentRef.setInput('importOperation', 'planning-data-import');
      fixture.detectChanges();

      expect(component.isAwaitingManualVerification()).toBeFalse();
    });

    it('should return false for FAILED even when manual verification is requested', () => {
      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: {
            workflowId: 'wf-123',
            runId: 'run-456',
            status: 'FAILED',
            isManualVerificationRequested: true,
          },
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-124');
      fixture.componentRef.setInput('importOperation', 'planning-data-import');
      fixture.detectChanges();

      expect(component.isAwaitingManualVerification()).toBeFalse();
    });

    it('should return false for RUNNING even when manual verification is requested', () => {
      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: {
            workflowId: 'wf-123',
            runId: 'run-456',
            status: 'RUNNING',
            isManualVerificationRequested: true,
          },
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-123');
      fixture.componentRef.setInput('importOperation', 'planning-data-import');
      fixture.detectChanges();

      expect(component.isAwaitingManualVerification()).toBeFalse();
    });

    it('should return false for COMPLETED even when manual verification is requested', () => {
      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: {
            workflowId: 'wf-123',
            runId: 'run-456',
            status: 'COMPLETED',
            isManualVerificationRequested: true,
          },
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-123');
      fixture.componentRef.setInput('importOperation', 'planning-data-import');
      fixture.detectChanges();

      expect(component.isAwaitingManualVerification()).toBeFalse();
    });

    it('should render manual review headers as native buttons with linked panels', () => {
      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: {
            workflowId: 'wf-123',
            runId: 'run-456',
            status: 'AWAITING_MANUAL_VERIFICATION',
            isManualVerificationRequested: true,
          },
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-123');
      fixture.componentRef.setInput('importOperation', 'planning-data-import');
      fixture.detectChanges();

      const stepHeader = fixture.nativeElement.querySelector(
        'button[aria-controls="workflow-step-1-panel"]'
      ) as HTMLButtonElement | null;
      const stepPanel = fixture.nativeElement.querySelector(
        '#workflow-step-1-panel'
      ) as HTMLElement | null;

      expect(stepHeader).not.toBeNull();
      expect(stepPanel).not.toBeNull();

      if (!stepHeader || !stepPanel) {
        return;
      }

      expect(stepHeader.tagName).toBe('BUTTON');
      expect(stepHeader.getAttribute('type')).toBe('button');
      expect(stepHeader.getAttribute('aria-controls')).toBe(
        'workflow-step-1-panel'
      );
      expect(stepHeader.getAttribute('aria-expanded')).toBe('true');
      expect(stepPanel.getAttribute('role')).toBe('region');
      expect(stepPanel.getAttribute('aria-labelledby')).toBe(
        'workflow-step-1-header'
      );

      stepHeader.click();
      fixture.detectChanges();

      expect(stepHeader.getAttribute('aria-expanded')).toBe('false');
      expect(stepPanel.hidden).toBeTrue();
    });
  });

  describe('manual review actions', () => {
    beforeEach(() => {
      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: {
            workflowId: 'wf-123',
            runId: 'run-456',
            status: 'AWAITING_MANUAL_VERIFICATION',
            isManualVerificationRequested: true,
            manualVerificationRequested: true,
            dataArtifacts: [
              {
                storageType: 'S3',
                bucketName: 'planning',
                path: 'do4/planning-data/pif/2026-08-24T13.13.26/',
              },
            ],
          },
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-123');
      fixture.componentRef.setInput('importOperation', 'planning-data-import');
      fixture.detectChanges();
    });

    it('should toggle step expansion state', () => {
      expect(component.expandedStep()).toBe(1);

      component.toggleStep(2);

      expect(component.expandedStep()).toBe(2);

      component.toggleStep(2);

      expect(component.expandedStep()).toBe(-1);
    });

    it('should prevent drag over and accept dropped files', () => {
      const preventDefaultSpy = jasmine.createSpy('preventDefault');
      const event = {
        preventDefault: preventDefaultSpy,
        dataTransfer: {
          files: createFileList(['drop-a.csv', 'drop-b.csv']),
        },
      } as unknown as DragEvent;

      component.onDragOver(event);
      component.onFileDrop(event);

      expect(preventDefaultSpy).toHaveBeenCalledTimes(2);
      expect(serviceSpy.uploadWorkflowArtifact).not.toHaveBeenCalled();
      expect(component.uploadedFiles().map(file => file.name)).toEqual([
        'drop-a.csv',
        'drop-b.csv',
      ]);
    });

    it('should accept selected files and clear the input value', () => {
      const input = {
        files: createFileList(['selected-a.csv', 'selected-b.csv']),
        value: 'keep-me',
      } as unknown as HTMLInputElement;
      const event = { target: input } as unknown as Event;

      component.onFilesSelected(event);

      expect(serviceSpy.uploadWorkflowArtifact).not.toHaveBeenCalled();
      expect(component.uploadedFiles().map(file => file.name)).toEqual([
        'selected-a.csv',
        'selected-b.csv',
      ]);
      expect(input.value).toBe('');
    });

    it('should remove uploaded files by index', () => {
      component.uploadedFiles.set(
        createFiles(['first.csv', 'second.csv', 'third.csv'])
      );

      component.removeFile(1);

      expect(component.uploadedFiles().map(file => file.name)).toEqual([
        'first.csv',
        'third.csv',
      ]);
    });

    it('should load downloadable files from the artifact folder using the planning bucket and a key filter', () => {
      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: {
            workflowId: 'wf-123',
            runId: 'run-456',
            status: 'COMPLETED',
            isManualVerificationRequested: true,
            dataArtifacts: [
              {
                storageType: 'S3',
                bucketName: 'result-bucket',
                path: 'do4/planning-data/pif/2026-08-24T13.13.26/',
              },
            ],
          },
        })
      );
      serviceSpy.getObjectsByBucket.and.returnValue(
        of({
          objects: [
            {
              bucket: 'result-bucket',
              key: 'do4/planning-data/pif/2026-08-24T13.13.26/file-a.csv',
              size: 12,
              acl: 'private',
              lastModifiedAt: '2026-08-24T13:13:26Z',
            },
            {
              bucket: 'result-bucket',
              key: 'do4/planning-data/pif/2026-08-24T13.13.26/file-b.csv',
              size: 24,
              acl: 'private',
              lastModifiedAt: '2026-08-24T13:14:26Z',
            },
          ],
          nextContinuationToken: undefined,
        } as any)
      );

      (component as any).loadDownloadObjects({
        dataArtifacts: [
          {
            storageType: 'S3',
            bucketName: 'result-bucket',
            path: 'do4/planning-data/pif/2026-08-24T13.13.26/',
          },
        ],
      });

      expect(serviceSpy.getObjectsByBucket).toHaveBeenCalledWith(
        'planning',
        1000,
        undefined,
        'do4/planning-data/pif/2026-08-24T13.13.26/'
      );
      expect(component.downloadObjects()).toEqual([
        jasmine.objectContaining({
          bucket: 'result-bucket',
          key: 'do4/planning-data/pif/2026-08-24T13.13.26/file-a.csv',
        }),
        jasmine.objectContaining({
          bucket: 'result-bucket',
          key: 'do4/planning-data/pif/2026-08-24T13.13.26/file-b.csv',
        }),
      ]);
    });

    it('should load downloadable files from the detail path when no artifact list exists', () => {
      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: {
            workflowId: 'wf-123',
            runId: 'run-456',
            status: 'COMPLETED',
            isManualVerificationRequested: true,
            path: 'do4/planning-data/pif/2026-08-24T13.13.26/',
          },
        })
      );
      serviceSpy.getObjectsByBucket.and.returnValue(
        of({
          objects: [
            {
              bucket: 'result-bucket',
              key: 'do4/planning-data/pif/2026-08-24T13.13.26/file-a.csv',
              size: 12,
              acl: 'private',
              lastModifiedAt: '2026-08-24T13:13:26Z',
            },
          ],
          nextContinuationToken: undefined,
        } as any)
      );

      (component as any).loadDownloadObjects({
        path: 'do4/planning-data/pif/2026-08-24T13.13.26/',
        status: 'COMPLETED',
      });

      expect(serviceSpy.getObjectsByBucket).toHaveBeenCalledWith(
        'planning',
        1000,
        undefined,
        'do4/planning-data/pif/2026-08-24T13.13.26/'
      );
      expect(component.downloadObjectsView()).toEqual([
        jasmine.objectContaining({
          displayName: 'file-a.csv',
        }),
      ]);
    });

    it('should expose planning as the step 2 bucket name', () => {
      expect(component.planningBucketName()).toBe('planning');
    });

    it('should render only the filename for downloaded objects', () => {
      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: {
            workflowId: 'wf-123',
            runId: 'run-456',
            status: 'COMPLETED',
            isManualVerificationRequested: true,
            dataArtifacts: [
              {
                storageType: 'S3',
                bucketName: 'result-bucket',
                path: 'do4/planning-data/pif/2026-08-24T13.13.26/',
              },
            ],
          },
        })
      );
      serviceSpy.getObjectsByBucket.and.returnValue(
        of({
          objects: [
            {
              bucket: 'result-bucket',
              key: 'do4/planning-data/pif/2026-08-24T13.13.26/cell-lte.csv',
              size: 12,
              acl: 'private',
              lastModifiedAt: '2026-08-24T13:13:26Z',
            },
          ],
          nextContinuationToken: undefined,
        } as any)
      );

      (component as any).loadDownloadObjects({
        dataArtifacts: [
          {
            storageType: 'S3',
            bucketName: 'result-bucket',
            path: 'do4/planning-data/pif/2026-08-24T13.13.26/',
          },
        ],
      });

      expect(component.downloadObjectsView()).toEqual([
        jasmine.objectContaining({
          displayName: 'cell-lte.csv',
        }),
      ]);
    });

    it('should show the step 2 loading indicator while downloadable files are still loading', () => {
      component.expandedStep.set(2);
      component.downloadObjectsState.set({ loading: true, items: [] });

      fixture.detectChanges();

      expect(
        fixture.nativeElement.querySelector('.qa_step2_downloaded_files')
      ).toBeNull();
      expect(
        fixture.nativeElement.querySelector('.qa_step2_no_files')
      ).toBeNull();
      expect(fixture.nativeElement.textContent).toContain('common.loading');
    });

    it('should show the no-results state when no downloadable files are available', () => {
      component.expandedStep.set(2);
      component.downloadObjectsState.set({ loading: false, items: [] });

      fixture.detectChanges();

      expect(
        fixture.nativeElement.querySelector('.qa_step2_downloaded_files')
      ).toBeNull();
      expect(
        fixture.nativeElement.querySelector('.qa_step2_no_files')
      ).not.toBeNull();
      expect(fixture.nativeElement.textContent).toContain(
        'common.filters.noResults'
      );
    });

    it('should download a listed file by bucket and key', () => {
      serviceSpy.downloadWorkflowArtifact.and.returnValue(
        of(new Blob(['downloaded content']))
      );

      component.onDownloadObject({
        bucket: 'result-bucket',
        key: 'do4/planning-data/pif/2026-08-24T13.13.26/file-a.csv',
      } as any);

      expect(serviceSpy.downloadWorkflowArtifact).toHaveBeenCalledWith(
        'result-bucket',
        'do4/planning-data/pif/2026-08-24T13.13.26/file-a.csv'
      );
      expect(fileSaverSpy.save).toHaveBeenCalledWith(
        jasmine.any(Blob),
        'file-a.csv'
      );
    });

    it('should ignore download requests without a bucket or key', () => {
      component.onDownloadObject({ bucket: '', key: 'file.csv' } as any);
      component.onDownloadObject({ bucket: 'result-bucket', key: '' } as any);
      component.onDownloadObject({} as any);

      expect(serviceSpy.downloadWorkflowArtifact).not.toHaveBeenCalled();
      expect(fileSaverSpy.save).not.toHaveBeenCalled();
    });

    it('should filter hidden internal fields from detail data', () => {
      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: {
            workflowId: 'wf-123',
            runId: 'run-456',
            status: 'RUNNING',
            workflowType: 'runtime-config',
            startTime: '2026-06-30T08:00:00Z',
            endTime: '2026-06-30T08:05:00Z',
            isManualVerificationRequested: true,
            manualVerificationRequested: true,
            errorMessage: 'Should stay hidden for running status',
          },
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-124');
      fixture.detectChanges();

      const entryKeys = component.detailKeyValueData().map(entry => entry[0]);
      expect(entryKeys).not.toContain('isManualVerificationRequested');
      expect(entryKeys).toContain('manualVerificationRequested');
      expect(entryKeys).not.toContain('errorMessage');
    });
  });

  describe('RUNNING manual verification state', () => {
    beforeEach(() => {
      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: {
            workflowId: 'wf-123',
            runId: 'run-456',
            status: 'RUNNING',
            isManualVerificationRequested: true,
          },
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-123');
      fixture.componentRef.setInput('importOperation', 'planning-data-import');
      fixture.detectChanges();
    });

    it('should show manual verification steps for RUNNING when manual verification is requested', () => {
      expect(component.isRunningManualVerification()).toBeTrue();
      expect(component.shouldShowManualVerificationSteps()).toBeTrue();
      expect(component.isAwaitingManualVerification()).toBeFalse();
    });

    it('should disable upload, remove and resume actions', () => {
      component.uploadedFiles.set(createFiles(['file-1.csv']));
      fixture.detectChanges();

      const resumeButton = fixture.debugElement.query(
        By.css('.qa_resume_import')
      )?.nativeElement as HTMLButtonElement;
      expect(resumeButton?.disabled).toBeTrue();

      component.expandedStep.set(3);
      fixture.detectChanges();
      const browseButton = fixture.debugElement.query(
        By.css('.qa_browse_files')
      )?.nativeElement as HTMLButtonElement;
      const removeButton = fixture.debugElement.query(By.css('.qa_remove_file'))
        ?.nativeElement as HTMLButtonElement;
      expect(browseButton?.disabled).toBeTrue();
      expect(removeButton?.disabled).toBeTrue();
    });

    it('should ignore file removal while controls are disabled', () => {
      component.uploadedFiles.set(createFiles(['file-1.csv']));
      component.removeFile(0);

      expect(component.uploadedFiles().map(file => file.name)).toEqual([
        'file-1.csv',
      ]);
    });

    it('should still prevent default drag and drop behavior while controls are disabled', () => {
      const preventDefaultSpy = jasmine.createSpy('preventDefault');
      const event = {
        preventDefault: preventDefaultSpy,
        dataTransfer: {
          files: createFileList(['blocked.csv']),
        },
      } as unknown as DragEvent;

      component.onDragOver(event);
      component.onFileDrop(event);

      expect(preventDefaultSpy).toHaveBeenCalledTimes(2);
      expect(component.uploadedFiles()).toEqual([]);
    });

    it('should not resume while controls are disabled', () => {
      component.onResumeImport();

      expect(serviceSpy.resumeWorkflow).not.toHaveBeenCalled();
    });
  });

  describe('AWAITING manual verification state', () => {
    beforeEach(() => {
      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: {
            workflowId: 'wf-123',
            runId: 'run-456',
            status: 'AWAITING_MANUAL_VERIFICATION',
            isManualVerificationRequested: true,
            dataArtifacts: [
              {
                storageType: 'S3',
                bucketName: 'planning',
                path: 'do4/planning-data/pif/2026-08-24T13.13.26/',
              },
            ],
          },
        })
      );
      serviceSpy.getObjectsByBucket.and.returnValue(
        of({
          objects: [
            {
              bucket: 'planning',
              key: 'do4/planning-data/pif/2026-08-24T13.13.26/upload-a.csv',
            },
            {
              bucket: 'planning',
              key: 'do4/planning-data/pif/2026-08-24T13.13.26/upload-b.csv',
            },
          ],
        } as any)
      );

      fixture.componentRef.setInput('workflowId', 'wf-123');
      fixture.componentRef.setInput('importOperation', 'planning-data-import');
      fixture.detectChanges();
    });

    it('should show manual verification steps', () => {
      expect(component.isAwaitingManualVerification()).toBeTrue();
      expect(component.isRunningManualVerification()).toBeFalse();
      expect(component.shouldShowManualVerificationSteps()).toBeTrue();
    });

    it('should keep upload, remove and resume actions enabled', () => {
      component.uploadedFiles.set(createFiles(['file-1.csv']));
      fixture.detectChanges();

      const resumeButton = fixture.debugElement.query(
        By.css('.qa_resume_import')
      )?.nativeElement as HTMLButtonElement;
      expect(resumeButton?.disabled).toBeFalse();

      component.expandedStep.set(3);
      fixture.detectChanges();
      const browseButton = fixture.debugElement.query(
        By.css('.qa_browse_files')
      )?.nativeElement as HTMLButtonElement;
      const removeButton = fixture.debugElement.query(By.css('.qa_remove_file'))
        ?.nativeElement as HTMLButtonElement;
      expect(browseButton?.disabled).toBeFalse();
      expect(removeButton?.disabled).toBeFalse();
    });

    it('should switch the resume button label when files are staged', () => {
      component.uploadedFiles.set(createFiles(['file-1.csv']));
      fixture.detectChanges();

      const resumeButton = fixture.debugElement.query(
        By.css('.qa_resume_import')
      )?.nativeElement as HTMLButtonElement;

      expect(component.resumeImportButtonLabel()).toBe(
        'administration.template.ranDataImporter.liveTasks.step4.uploadAndResumeImport'
      );
      expect(resumeButton.textContent).toContain(
        'administration.template.ranDataImporter.liveTasks.step4.uploadAndResumeImport'
      );
    });

    it('should block file actions while uploads are in progress', () => {
      component.isUploadingFiles.set(true);
      fixture.detectChanges();

      const resumeButton = fixture.debugElement.query(
        By.css('.qa_resume_import')
      )?.nativeElement as HTMLButtonElement;
      expect(resumeButton?.disabled).toBeTrue();

      component.expandedStep.set(3);
      fixture.detectChanges();
      const browseButton = fixture.debugElement.query(
        By.css('.qa_browse_files')
      )?.nativeElement as HTMLButtonElement;
      expect(browseButton?.disabled).toBeTrue();
    });

    it('should resume the planning workflow run, show success and close details', () => {
      const uploadedFiles = createFiles(['upload-a.csv', 'upload-b.csv']);
      component.uploadedFiles.set(uploadedFiles);
      component.downloadObjectsState.set({
        loading: false,
        items: [
          {
            bucket: 'planning',
            key: 'do4/planning-data/pif/2026-08-24T13.13.26/upload-a.csv',
          },
          {
            bucket: 'planning',
            key: 'do4/planning-data/pif/2026-08-24T13.13.26/upload-b.csv',
          },
        ] as any,
      });
      serviceSpy.uploadWorkflowArtifact.and.returnValue(of({} as any));
      const closeSpy = jasmine.createSpy('closeDetail');
      component.closeDetail.subscribe(closeSpy);

      component.onResumeImport();

      expect(serviceSpy.uploadWorkflowArtifact).toHaveBeenCalledWith(
        'planning',
        'do4/planning-data/pif/2026-08-24T13.13.26/upload-a.csv',
        uploadedFiles[0]
      );
      expect(serviceSpy.uploadWorkflowArtifact).toHaveBeenCalledWith(
        'planning',
        'do4/planning-data/pif/2026-08-24T13.13.26/upload-b.csv',
        uploadedFiles[1]
      );

      expect(serviceSpy.resumeWorkflow).toHaveBeenCalledWith(
        'planning-data',
        'wf-123',
        'run-456'
      );
      expect(alertServiceSpy.success).toHaveBeenCalledWith(
        ALERT_MESSAGES.uploadAndResumeSuccessRanPlanning,
        { keepAfterRouteChange: true }
      );
      expect(closeSpy).toHaveBeenCalled();
    });

    it('should resume the planning workflow run without uploads and show resume success', () => {
      const closeSpy = jasmine.createSpy('closeDetail');
      component.closeDetail.subscribe(closeSpy);

      component.onResumeImport();

      expect(serviceSpy.uploadWorkflowArtifact).not.toHaveBeenCalled();
      expect(serviceSpy.resumeWorkflow).toHaveBeenCalledWith(
        'planning-data',
        'wf-123',
        'run-456'
      );
      expect(alertServiceSpy.success).toHaveBeenCalledWith(
        ALERT_MESSAGES.resumeSuccessRanPlanning,
        { keepAfterRouteChange: true }
      );
      expect(closeSpy).toHaveBeenCalled();
    });

    it('should show error when resume is attempted for a non-planning workflow', () => {
      serviceSpy.resumeWorkflow.and.returnValue(
        throwError(() => new Error('unsupported resume type'))
      );

      fixture.componentRef.setInput('importOperation', 'runtime-data-import');
      fixture.detectChanges();

      const closeSpy = jasmine.createSpy('closeDetail');
      component.closeDetail.subscribe(closeSpy);

      component.onResumeImport();

      expect(serviceSpy.resumeWorkflow).toHaveBeenCalledWith(
        'runtime-config',
        'wf-123',
        'run-456'
      );
      expect(alertServiceSpy.success).not.toHaveBeenCalled();
      expect(alertServiceSpy.error).toHaveBeenCalledWith(
        'unsupported resume type',
        { keepAfterRouteChange: true }
      );
      expect(closeSpy).not.toHaveBeenCalled();
    });

    it('should ignore duplicate resume clicks while request is in progress', () => {
      const resumeSubject = new Subject<void>();
      serviceSpy.resumeWorkflow.and.returnValue(resumeSubject.asObservable());
      serviceSpy.uploadWorkflowArtifact.and.returnValue(of({} as any));
      component.uploadedFiles.set(createFiles(['upload-a.csv']));

      component.onResumeImport();
      component.onResumeImport();

      expect(serviceSpy.resumeWorkflow).toHaveBeenCalledTimes(1);
    });

    it('should show error alert and keep details open when resume fails', () => {
      const closeSpy = jasmine.createSpy('closeDetail');
      component.closeDetail.subscribe(closeSpy);
      serviceSpy.resumeWorkflow.and.returnValue(
        throwError(() => new Error('resume failed'))
      );
      serviceSpy.uploadWorkflowArtifact.and.returnValue(of({} as any));
      component.uploadedFiles.set(createFiles(['upload-a.csv']));
      component.downloadObjectsState.set({
        loading: false,
        items: [
          {
            bucket: 'planning',
            key: 'do4/planning-data/pif/2026-08-24T13.13.26/upload-a.csv',
          },
        ] as any,
      });

      component.onResumeImport();

      expect(alertServiceSpy.error).toHaveBeenCalledWith('resume failed', {
        keepAfterRouteChange: true,
      });
      expect(closeSpy).not.toHaveBeenCalled();
    });

    it('should stop resume when a staged file does not match s3 filename', () => {
      component.uploadedFiles.set(createFiles(['wrong-name.csv']));
      component.downloadObjectsState.set({
        loading: false,
        items: [
          {
            bucket: 'planning',
            key: 'do4/planning-data/pif/2026-08-24T13.13.26/upload-a.csv',
          },
        ] as any,
      });

      component.onResumeImport();

      expect(serviceSpy.uploadWorkflowArtifact).not.toHaveBeenCalled();
      expect(serviceSpy.resumeWorkflow).not.toHaveBeenCalled();
      expect(alertServiceSpy.error).toHaveBeenCalledWith(
        'administration.alert.body.uploadRanDataImporterFileNameMismatch',
        { keepAfterRouteChange: true }
      );
    });

    it('should upload only the basename when a staged file has a generated prefix', () => {
      const prefixedFileName =
        'do4_planning-data_pif_2026-08-28T10.51.30_cell-lte.csv';
      component.detailState.set({
        loading: false,
        data: {
          workflowId: 'wf-123',
          runId: 'run-456',
          status: 'AWAITING_MANUAL_VERIFICATION',
          isManualVerificationRequested: true,
          dataArtifacts: [
            {
              storageType: 'S3',
              bucketName: 'planning',
              path: 'do4/planning-data/pif/2026-08-28T10.51.30/',
            },
          ],
        } as any,
      });
      component.uploadedFiles.set(createFiles([prefixedFileName]));
      component.downloadObjectsState.set({
        loading: false,
        items: [
          {
            bucket: 'planning',
            key: 'do4/planning-data/pif/2026-08-28T10.51.30/cell-lte.csv',
          },
        ] as any,
      });
      serviceSpy.uploadWorkflowArtifact.and.returnValue(of({} as any));

      component.onResumeImport();

      expect(serviceSpy.uploadWorkflowArtifact).toHaveBeenCalledWith(
        'planning',
        'do4/planning-data/pif/2026-08-28T10.51.30/do4_planning-data_pif_2026-08-28T10.51.30_cell-lte.csv',
        jasmine.any(File)
      );
      expect(serviceSpy.resumeWorkflow).toHaveBeenCalledWith(
        'planning-data',
        'wf-123',
        'run-456'
      );
      expect(alertServiceSpy.error).not.toHaveBeenCalledWith(
        'administration.alert.body.uploadRanDataImporterFileNameMismatch',
        { keepAfterRouteChange: true }
      );
    });
  });

  describe('detailKeyValueData - completed workflow with artifacts', () => {
    it('should expand dataArtifacts into individual rows for COMPLETED status', () => {
      const completedDetail = {
        workflowId: 'wf-123',
        runId: 'run-456',
        status: 'COMPLETED',
        workflowType: 'runtime-config',
        startTime: '2026-06-30T08:00:00Z',
        endTime: '2026-06-30T08:05:00Z',
        totalZipFilesToProcess: 8,
        totalFilesProduced: 40,
        dataArtifacts: [
          {
            storageType: 'S3',
            bucketName: 'test-bucket',
            path: 'test/path',
          },
        ],
      };

      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: completedDetail,
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-123');
      fixture.componentRef.setInput('importOperation', 'runtime-data-import');
      fixture.detectChanges();

      const entries = component.detailKeyValueData();
      expect(entries).toContain(['totalZipFilesToProcess', 8]);
      expect(entries).toContain(['totalFilesProduced', 40]);
      expect(entries).toContain(['storageType', 'S3']);
      expect(entries).toContain(['bucketName', 'test-bucket']);
      expect(entries).toContain(['path', 'test/path']);
    });

    it('should not show artifact fields for RUNNING status', () => {
      const runningDetail = {
        workflowId: 'wf-123',
        runId: 'run-456',
        status: 'RUNNING',
        workflowType: 'runtime-config',
        startTime: '2026-06-30T08:00:00Z',
        totalZipFilesToProcess: 8,
        totalFilesProduced: 40,
        dataArtifacts: [
          {
            storageType: 'S3',
            bucketName: 'test-bucket',
            path: 'test/path',
          },
        ],
      };

      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: runningDetail,
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-123');
      fixture.componentRef.setInput('importOperation', 'runtime-data-import');
      fixture.detectChanges();

      const entries = component.detailKeyValueData();
      const entryKeys = entries.map(e => e[0]);
      expect(entryKeys).not.toContain('totalZipFilesToProcess');
      expect(entryKeys).not.toContain('totalFilesProduced');
      expect(entryKeys).not.toContain('storageType');
    });

    it('should not show artifact fields for FAILED status', () => {
      const failedDetail = {
        workflowId: 'wf-123',
        runId: 'run-456',
        status: 'FAILED',
        workflowType: 'runtime-config',
        startTime: '2026-06-30T08:00:00Z',
        errorMessage: 'Adapter is disabled for BACKUP',
        totalZipFilesToProcess: 5,
        totalFilesProduced: 20,
        dataArtifacts: [
          {
            storageType: 'S3',
            bucketName: 'test-bucket',
            path: 'test/path',
          },
        ],
      };

      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: failedDetail,
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-123');
      fixture.componentRef.setInput('importOperation', 'runtime-data-import');
      fixture.detectChanges();

      const entries = component.detailKeyValueData();
      const entryKeys = entries.map(e => e[0]);
      expect(entryKeys).not.toContain('totalZipFilesToProcess');
      expect(entryKeys).not.toContain('dataArtifacts');
      expect(entries).toContain(['errorMessage', failedDetail.errorMessage]);
    });

    it('should show errorMessage field for PARTIAL_SUCCESS status', () => {
      const partialSuccessDetail = {
        workflowId: 'wf-123',
        runId: 'run-456',
        status: 'PARTIAL_SUCCESS',
        workflowType: 'runtime-config',
        startTime: '2026-06-30T08:00:00Z',
        errorMessage: 'Some records failed to import',
      };

      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: partialSuccessDetail,
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-123');
      fixture.componentRef.setInput('importOperation', 'runtime-data-import');
      fixture.detectChanges();

      const entries = component.detailKeyValueData();
      expect(entries).toContain([
        'errorMessage',
        partialSuccessDetail.errorMessage,
      ]);
    });

    it('should not show errorMessage field for success status', () => {
      const completedDetail = {
        workflowId: 'wf-123',
        runId: 'run-456',
        status: 'COMPLETED',
        workflowType: 'runtime-config',
        startTime: '2026-06-30T08:00:00Z',
        endTime: '2026-06-30T08:05:00Z',
        errorMessage: 'Should not be shown',
      };

      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: completedDetail,
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-123');
      fixture.componentRef.setInput('importOperation', 'runtime-data-import');
      fixture.detectChanges();

      const entryKeys = component.detailKeyValueData().map(e => e[0]);
      expect(entryKeys).not.toContain('errorMessage');
    });

    it('should handle multiple dataArtifacts', () => {
      const completedDetail = {
        workflowId: 'wf-123',
        runId: 'run-456',
        status: 'COMPLETED',
        workflowType: 'runtime-config',
        startTime: '2026-06-30T08:00:00Z',
        endTime: '2026-06-30T08:05:00Z',
        totalZipFilesToProcess: 8,
        totalFilesProduced: 40,
        dataArtifacts: [
          {
            storageType: 'S3',
            bucketName: 'bucket1',
            path: 'path1',
          },
          {
            storageType: 'S3',
            bucketName: 'bucket2',
            path: 'path2',
          },
        ],
      };

      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: completedDetail,
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-123');
      fixture.componentRef.setInput('importOperation', 'runtime-data-import');
      fixture.detectChanges();

      const entries = component.detailKeyValueData();
      const storageTypeEntries = entries.filter(e => e[0] === 'storageType');
      const bucketNameEntries = entries.filter(e => e[0] === 'bucketName');
      const pathEntries = entries.filter(e => e[0] === 'path');

      expect(storageTypeEntries.length).toBe(2);
      expect(bucketNameEntries.length).toBe(2);
      expect(pathEntries.length).toBe(2);
      expect(bucketNameEntries[0][1]).toBe('bucket1');
      expect(bucketNameEntries[1][1]).toBe('bucket2');
    });

    it('should handle empty dataArtifacts array', () => {
      const completedDetail = {
        workflowId: 'wf-123',
        runId: 'run-456',
        status: 'COMPLETED',
        workflowType: 'runtime-config',
        startTime: '2026-06-30T08:00:00Z',
        endTime: '2026-06-30T08:05:00Z',
        totalZipFilesToProcess: 0,
        totalFilesProduced: 0,
        dataArtifacts: [],
      };

      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: completedDetail,
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-123');
      fixture.componentRef.setInput('importOperation', 'runtime-data-import');
      fixture.detectChanges();

      const entries = component.detailKeyValueData();
      const storageTypeEntries = entries.filter(e => e[0] === 'storageType');
      expect(storageTypeEntries.length).toBe(0);
    });

    it('should show totalFoldersToProcess instead of totalZipFilesToProcess for backup import', () => {
      const completedBackupDetail = {
        workflowId: 'wf-123',
        runId: 'run-456',
        status: 'COMPLETED',
        workflowType: 'backup-data',
        startTime: '2026-06-30T08:00:00Z',
        endTime: '2026-06-30T08:05:00Z',
        totalZipFilesToProcess: 12,
        totalFoldersToProcess: 9,
        totalFilesProduced: 40,
        dataArtifacts: [],
      };

      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: completedBackupDetail,
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-123');
      fixture.componentRef.setInput('importOperation', 'backup-data-import');
      fixture.detectChanges();

      const entries = component.detailKeyValueData();
      expect(entries).toContain(['totalFoldersToProcess', 9]);
      expect(entries).not.toContain(['totalZipFilesToProcess', 12]);
    });

    it('should display base fields regardless of status', () => {
      const detail = {
        workflowId: 'wf-123',
        runId: 'run-456',
        status: 'RUNNING',
        workflowType: 'runtime-config',
        startTime: '2026-06-30T08:00:00Z',
        endTime: '2026-06-30T08:05:00Z',
      };

      serviceSpy.getWorkflowDetail.and.returnValue(
        of({
          loading: false,
          data: detail,
        })
      );

      fixture.componentRef.setInput('workflowId', 'wf-123');
      fixture.componentRef.setInput('importOperation', 'runtime-data-import');
      fixture.detectChanges();

      const entries = component.detailKeyValueData();
      const entryKeys = entries.map(e => e[0]);
      expect(entryKeys).toContain('workflowId');
      expect(entryKeys).toContain('runId');
      expect(entryKeys).toContain('status');
      expect(entryKeys).toContain('workflowType');
      expect(entryKeys).toContain('startTime');
      expect(entryKeys).toContain('endTime');
    });
  });
});
