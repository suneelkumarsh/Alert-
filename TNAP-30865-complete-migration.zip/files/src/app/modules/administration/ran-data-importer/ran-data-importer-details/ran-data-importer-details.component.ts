/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { FileSaverService } from 'ngx-filesaver';
import { forkJoin, finalize, of, switchMap, map } from 'rxjs';
import { catchError } from 'rxjs/operators';
import {
  ImportType,
  OPERATION_TO_IMPORT_TYPE,
  RanDataImporterService,
  WorkflowItem,
  WorkflowDetailState,
} from '../../../../services/ran-data-importer-service/ran-data-importer.service';
import { ColumnDef } from '../../../../components/shared/key-value-list/key-value-list.component';
import { SharedModule } from '../../../../shared.module';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { BadgeComponent } from '@portal-mfe/tnap-ui-kit/components/badge';
import { TnapButtonComponent } from '@portal-mfe/tnap-ui-kit/components/button';
import { BadgeType } from '@portal-mfe/tnap-ui-kit/model/badge.model';
import { BadgeMode } from '@portal-mfe/tnap-ui-kit/model';
import { ALERT_MESSAGES } from '../../configuration';
import { BucketObjectInfo } from '../../../../../../openapi/output/model/bucketObjectInfo.model';
import { WorkflowStatus as RanImportManagerWorkflowStatus } from '../../../../../../openapi/output/model/workflowStatus.model';
import {
  getRanDataImporterStatusBadgeMode,
  getRanDataImporterStatusBadgeType,
  getRanDataImporterStatusLabel,
  normalizeRanDataImporterStatus,
} from './ran-data-importer-status.util';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

const AWAITING_MANUAL_VERIFICATION_STATUS =
  RanImportManagerWorkflowStatus.AWAITING_MANUAL_VERIFICATION;
const PLANNING_BUCKET_NAME = 'planning';
const WORKFLOW_TYPE_KEYWORDS = {
  planning: 'planning',
  runtime: 'runtime',
  backup: 'backup',
} as const;
const ERROR_MESSAGE_STATUSES = new Set<string>([
  RanImportManagerWorkflowStatus.FAILED,
  RanImportManagerWorkflowStatus.PARTIAL_SUCCESS,
]);

@Component({
  selector: 'app-ran-data-importer-details',
  templateUrl: './ran-data-importer-details.component.html',
  styleUrl: './ran-data-importer-details.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [
    CommonModule,
    TranslateModule,
    BadgeComponent,
    TnapButtonComponent,
    SharedModule,
  ],
})
export class RanDataImporterDetailsComponent {
  private readonly service = inject(RanDataImporterService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);
  private readonly fileSaverService = inject(FileSaverService);

  readonly workflowId = input<string | null>(null);

  readonly importOperation = input<string | null>(null);

  readonly workflow = input<WorkflowItem | null>(null);

  readonly closeDetail = output<void>();
  readonly importResumed = output<void>();

  readonly detailState = signal<WorkflowDetailState>({ loading: false });

  readonly detail = computed(() => this.detailState().data ?? null);
  readonly isLoading = computed(() => this.detailState().loading);

  readonly manualReviewSteps = [1, 2, 3, 4] as const;
  readonly expandedStep = signal<number>(1);
  readonly uploadedFiles = signal<File[]>([]);
  readonly isResumeImporting = signal(false);
  readonly isUploadingFiles = signal(false);
  readonly resumeImportButtonLabel = computed(() =>
    this.uploadedFiles().length > 0
      ? 'administration.template.ranDataImporter.liveTasks.step4.uploadAndResumeImport'
      : 'administration.template.ranDataImporter.liveTasks.step4.resumeImport'
  );
  readonly downloadObjectsState = signal<{
    loading: boolean;
    items: BucketObjectInfo[];
  }>({ loading: false, items: [] });

  readonly downloadObjects = computed(() => this.downloadObjectsState().items);

  readonly downloadObjectsView = computed(() =>
    this.downloadObjects().map(file => ({
      ...file,
      displayName: this.getFileName(file.key),
    }))
  );

  readonly planningBucketName = computed(() => PLANNING_BUCKET_NAME);

  readonly pathBucketName = computed(() => {
    const importType = this.detailRequest().importType;

    return importType === 'planning-data' ? 'planning' : 'network';
  });

  readonly isAwaitingManualVerification = computed(
    () =>
      normalizeRanDataImporterStatus(this.detail()?.['status']) ===
        AWAITING_MANUAL_VERIFICATION_STATUS &&
      this.detail()?.['isManualVerificationRequested'] === true
  );

  readonly isRunningManualVerification = computed(
    () =>
      normalizeRanDataImporterStatus(this.detail()?.['status']) ===
        RanImportManagerWorkflowStatus.RUNNING &&
      this.detail()?.['isManualVerificationRequested'] === true
  );

  readonly shouldShowManualVerificationSteps = computed(
    () =>
      this.isAwaitingManualVerification() || this.isRunningManualVerification()
  );

  private resolveImportType(): ImportType {
    const operation = this.importOperation();
    const selectedWorkflow = this.workflow();

    const importTypeFromOperation = OPERATION_TO_IMPORT_TYPE[operation ?? ''];
    if (importTypeFromOperation) {
      return importTypeFromOperation;
    }

    const workflowType = selectedWorkflow?.workflowType?.toLowerCase() ?? '';
    if (workflowType.includes(WORKFLOW_TYPE_KEYWORDS.planning)) {
      return 'planning-data';
    }

    if (workflowType.includes(WORKFLOW_TYPE_KEYWORDS.runtime)) {
      return 'runtime-config';
    }

    if (workflowType.includes(WORKFLOW_TYPE_KEYWORDS.backup)) {
      return 'backup-data';
    }

    return 'planning-data';
  }

  readonly detailRequest = computed(() => {
    const id = this.workflowId();

    if (!id) {
      return {
        mode: 'empty' as const,
      };
    }

    const importType = this.resolveImportType();

    return {
      mode: 'remote' as const,
      importType,
      workflowId: id,
      runId: this.workflow()?.runId ?? null,
    };
  });

  readonly DETAIL_COLUMNS: ColumnDef[] = [
    {
      key: 'workflowId',
      header:
        'administration.template.ranDataImporter.liveTasks.fields.workflowId',
    },
    {
      key: 'runId',
      header: 'administration.template.ranDataImporter.liveTasks.fields.runId',
    },
    {
      key: 'status',
      header: 'administration.template.ranDataImporter.liveTasks.fields.status',
    },
    {
      key: 'workflowType',
      header:
        'administration.template.ranDataImporter.liveTasks.fields.workflowType',
    },
    {
      key: 'startTime',
      header:
        'administration.template.ranDataImporter.liveTasks.fields.startTime',
    },
    {
      key: 'endTime',
      header:
        'administration.template.ranDataImporter.liveTasks.fields.endTime',
    },
    {
      key: 'totalZipFilesToProcess',
      header:
        'administration.template.ranDataImporter.liveTasks.fields.totalZipFilesToProcess',
    },
    {
      key: 'totalFoldersToProcess',
      header:
        'administration.template.ranDataImporter.liveTasks.fields.totalFoldersToProcess',
    },
    {
      key: 'totalFilesProduced',
      header:
        'administration.template.ranDataImporter.liveTasks.fields.totalFilesProduced',
    },
    {
      key: 'storageType',
      header:
        'administration.template.ranDataImporter.liveTasks.fields.storageType',
    },
    {
      key: 'bucketName',
      header:
        'administration.template.ranDataImporter.liveTasks.fields.bucketName',
    },
    {
      key: 'path',
      header: 'administration.template.ranDataImporter.liveTasks.fields.path',
      custom: true,
    },
    {
      key: 'errorMessage',
      header:
        'administration.template.ranDataImporter.liveTasks.fields.errorMessage',
    },
  ];

  readonly SUMMARY_COLUMNS: ColumnDef[] = [
    {
      key: 'workflowId',
      header:
        'administration.template.ranDataImporter.liveTasks.fields.workflowId',
    },
    {
      key: 'runId',
      header: 'administration.template.ranDataImporter.liveTasks.fields.runId',
    },
    {
      key: 'status',
      header: 'administration.template.ranDataImporter.liveTasks.fields.status',
    },
    {
      key: 'workflowType',
      header:
        'administration.template.ranDataImporter.liveTasks.fields.workflowType',
    },
    {
      key: 'startTime',
      header:
        'administration.template.ranDataImporter.liveTasks.fields.startTime',
    },
    {
      key: 'endTime',
      header:
        'administration.template.ranDataImporter.liveTasks.fields.endTime',
    },
  ];

  readonly summaryKeyValueData = computed<[string, unknown][]>(() => {
    const detail = this.detail();
    if (!detail) {
      return [];
    }

    return [
      ['workflowId', this.toDisplayValue(detail['workflowId'])],
      ['runId', this.toDisplayValue(detail['runId'])],
      ['status', this.toDisplayValue(detail['status'])],
      ['workflowType', this.toDisplayValue(detail['workflowType'])],
      ['startTime', this.toDisplayValue(detail['startTime'])],
      ['endTime', this.toDisplayValue(detail['endTime'])],
    ];
  });

  readonly detailKeyValueData = computed<[string, unknown][]>(() => {
    const detail = this.detail();
    if (!detail) {
      return [];
    }

    const detailRequest = this.detailRequest();
    const totalToProcessFieldKey =
      detailRequest.mode === 'remote' &&
      detailRequest.importType === 'backup-data'
        ? 'totalFoldersToProcess'
        : 'totalZipFilesToProcess';

    const preferredOrder = [
      'workflowId',
      'runId',
      'status',
      'workflowType',
      'startTime',
      'endTime',
    ];

    const completedOnlyFields = [
      'totalZipFilesToProcess',
      'totalFoldersToProcess',
      'totalFilesProduced',
      'dataArtifacts',
    ];
    const hiddenInternalFields = ['isManualVerificationRequested'];
    const normalizedStatus = normalizeRanDataImporterStatus(detail['status']);
    if (normalizedStatus === RanImportManagerWorkflowStatus.COMPLETED) {
      preferredOrder.push(totalToProcessFieldKey, 'totalFilesProduced');
    } else if (ERROR_MESSAGE_STATUSES.has(normalizedStatus)) {
      preferredOrder.push('errorMessage');
    }

    const entriesByKey = new Map(Object.entries(detail));
    const orderedEntries: [string, unknown][] = [];

    preferredOrder.forEach(key => {
      if (entriesByKey.has(key)) {
        orderedEntries.push([key, this.toDisplayValue(entriesByKey.get(key))]);
        entriesByKey.delete(key);
      }
    });

    if (normalizedStatus === RanImportManagerWorkflowStatus.COMPLETED) {
      const artifacts = detail['dataArtifacts'];
      if (Array.isArray(artifacts)) {
        artifacts.forEach((artifact: Record<string, unknown>) => {
          orderedEntries.push([
            'storageType',
            this.toDisplayValue(artifact['storageType']),
          ]);
          orderedEntries.push([
            'bucketName',
            this.toDisplayValue(artifact['bucketName']),
          ]);
          orderedEntries.push(['path', this.toDisplayValue(artifact['path'])]);
        });
      }
    }

    entriesByKey.forEach((value, key) => {
      const isErrorMessageForNonError =
        key === 'errorMessage' && !ERROR_MESSAGE_STATUSES.has(normalizedStatus);

      if (
        !completedOnlyFields.includes(key) &&
        !hiddenInternalFields.includes(key) &&
        !isErrorMessageForNonError
      ) {
        orderedEntries.push([key, this.toDisplayValue(value)]);
      }
    });

    return orderedEntries;
  });

  private toDisplayValue(value: unknown): unknown {
    return value === null || value === undefined || value === '' ? '-' : value;
  }

  private getBaseFileName(fileName: string): string {
    const trimmedFileName = fileName.trim();

    if (!trimmedFileName) {
      return '';
    }

    const segments = trimmedFileName.split(/[\\/]/).filter(Boolean);
    return segments[segments.length - 1] ?? trimmedFileName;
  }

  private getDownloadArtifacts(detail: WorkflowItem): {
    bucketName: string;
    path: string;
  }[] {
    const artifacts = detail['dataArtifacts'];
    if (Array.isArray(artifacts) && artifacts.length > 0) {
      return artifacts
        .filter(
          (artifact): artifact is Record<string, unknown> =>
            !!artifact && typeof artifact === 'object'
        )
        .map(artifact => ({
          bucketName: PLANNING_BUCKET_NAME,
          path: String(artifact['path'] ?? '').trim(),
        }))
        .filter(artifact => !!artifact.path);
    }

    const path = String(detail['path'] ?? '').trim();

    if (path) {
      return [{ bucketName: PLANNING_BUCKET_NAME, path }];
    }

    return [];
  }

  private loadDownloadObjects(detail: WorkflowItem | null): void {
    const artifacts = detail ? this.getDownloadArtifacts(detail) : [];

    if (!artifacts.length) {
      this.downloadObjectsState.set({ loading: false, items: [] });
      return;
    }

    this.downloadObjectsState.update(state => ({ ...state, loading: true }));

    forkJoin(
      artifacts.map(artifact =>
        this.service
          .getObjectsByBucket(
            PLANNING_BUCKET_NAME,
            1000,
            undefined,
            artifact.path || undefined
          )
          .pipe(
            map(response => response.objects ?? []),
            catchError(() => of([] as BucketObjectInfo[]))
          )
      )
    )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: results => {
          const items = results
            .flat()
            .filter((item): item is BucketObjectInfo => !!item?.key)
            .sort((left, right) => {
              const leftKey = `${left.bucket ?? ''}/${left.key ?? ''}`;
              const rightKey = `${right.bucket ?? ''}/${right.key ?? ''}`;
              return leftKey.localeCompare(rightKey);
            });

          this.downloadObjectsState.set({ loading: false, items });
        },
        error: () => {
          this.downloadObjectsState.set({ loading: false, items: [] });
          this.alertService.error(
            this.translateService.instant(
              'administration.alert.body.loadRanDataImporterDownloadFailed'
            ),
            { keepAfterRouteChange: true }
          );
        },
      });
  }

  public onDownloadObject(file: BucketObjectInfo): void {
    const bucketName = file.bucket?.trim();
    const key = file.key?.trim();

    if (!bucketName || !key) {
      return;
    }

    this.service
      .downloadWorkflowArtifact(bucketName, key)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: blob => {
          this.fileSaverService.save(blob, this.getBaseFileName(key));
        },
        error: () => {
          this.alertService.error(
            this.translateService.instant(
              'administration.alert.body.downloadRanDataImporterFileFailed'
            ),
            { keepAfterRouteChange: true }
          );
        },
      });
  }

  public getFileName(key: string | null | undefined): string {
    const trimmedKey = key?.trim() ?? '';

    if (!trimmedKey) {
      return '-';
    }

    const segments = trimmedKey.split('/').filter(Boolean);
    return segments[segments.length - 1] ?? trimmedKey;
  }

  public toggleStep(step: number): void {
    this.expandedStep.set(this.expandedStep() === step ? -1 : step);
  }

  public onDragOver(event: DragEvent): void {
    event.preventDefault();

    if (this.isRunningManualVerification() || this.isUploadingFiles()) {
      return;
    }
  }

  public onFileDrop(event: DragEvent): void {
    event.preventDefault();

    if (this.isRunningManualVerification() || this.isUploadingFiles()) {
      return;
    }

    this.addFiles(event.dataTransfer?.files ?? null);
  }

  public onFilesSelected(event: Event): void {
    if (this.isRunningManualVerification() || this.isUploadingFiles()) {
      return;
    }

    const input = event.target as HTMLInputElement;
    this.addFiles(input.files);
    input.value = '';
  }

  public removeFile(index: number): void {
    if (this.isRunningManualVerification() || this.isUploadingFiles()) {
      return;
    }

    this.uploadedFiles.update(files => files.filter((_, i) => i !== index));
  }

  public onResumeImport(): void {
    if (
      this.isRunningManualVerification() ||
      this.isResumeImporting() ||
      this.isUploadingFiles() ||
      this.downloadObjectsState().loading
    ) {
      return;
    }

    const request = this.detailRequest();
    const detail = this.detail();
    if (request.mode !== 'remote' || !detail) {
      return;
    }

    const workflowId = String(
      detail['workflowId'] ?? request.workflowId
    ).trim();
    const runId = String(detail['runId'] ?? request.runId ?? '').trim();
    if (!workflowId || !runId) {
      return;
    }

    const hasQueuedFiles = this.uploadedFiles().length > 0;

    this.isResumeImporting.set(true);
    this.uploadQueuedFiles()
      .pipe(
        switchMap(uploaded =>
          uploaded
            ? this.service
                .resumeWorkflow(request.importType, workflowId, runId)
                .pipe(map(() => true))
            : of(false)
        ),
        finalize(() => this.isResumeImporting.set(false)),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: resumed => {
          if (!resumed) {
            return;
          }

          this.alertService.success(
            this.translateService.instant(
              hasQueuedFiles
                ? ALERT_MESSAGES.uploadAndResumeSuccessRanPlanning
                : ALERT_MESSAGES.resumeSuccessRanPlanning
            ),
            { keepAfterRouteChange: true }
          );
          this.importResumed.emit();
          this.closeDetail.emit();
        },
        error: error => {
          this.alertService.error(
            this.translateService.instant(
              error instanceof Error && error.message
                ? error.message
                : hasQueuedFiles
                  ? ALERT_MESSAGES.uploadAndResumeFailedRanPlanning
                  : ALERT_MESSAGES.resumeFailedRanPlanning
            ),
            { keepAfterRouteChange: true }
          );
        },
      });
  }

  private uploadQueuedFiles() {
    const queuedFiles = this.uploadedFiles();

    if (!queuedFiles.length) {
      return of(true);
    }

    const detail = this.detail();
    const uploadPath = this.getUploadPath(detail);
    if (!detail || !uploadPath) {
      this.alertService.error(
        this.translateService.instant(
          'administration.alert.body.uploadRanDataImporterFileFailed'
        ),
        { keepAfterRouteChange: true }
      );
      return of(false);
    }

    if (!this.areQueuedFilesMatchingS3Objects(queuedFiles)) {
      this.alertService.error(
        this.translateService.instant(
          'administration.alert.body.uploadRanDataImporterFileNameMismatch'
        ),
        { keepAfterRouteChange: true }
      );
      return of(false);
    }

    this.isUploadingFiles.set(true);

    return forkJoin(
      queuedFiles.map(file => {
        return this.service.uploadWorkflowArtifact(
          PLANNING_BUCKET_NAME,
          this.buildUploadKey(uploadPath, file.name),
          file
        );
      })
    ).pipe(
      map(() => true),
      catchError(error => {
        this.alertService.error(
          this.translateService.instant(
            error instanceof Error && error.message
              ? error.message
              : 'administration.alert.body.uploadRanDataImporterFileFailed'
          ),
          { keepAfterRouteChange: true }
        );
        return of(false);
      }),
      finalize(() => this.isUploadingFiles.set(false))
    );
  }

  private getUploadPath(detail: WorkflowItem | null): string | null {
    if (!detail) {
      return null;
    }

    const artifacts = detail['dataArtifacts'];
    if (Array.isArray(artifacts)) {
      const firstArtifact = artifacts.find(
        (artifact): artifact is Record<string, unknown> =>
          !!artifact && typeof artifact === 'object'
      );
      const artifactPath = String(firstArtifact?.['path'] ?? '').trim();

      if (artifactPath) {
        return artifactPath;
      }
    }

    const fallbackPath = String(detail['path'] ?? '').trim();
    return fallbackPath || null;
  }

  private addFiles(files: FileList | null): void {
    if (this.isRunningManualVerification()) {
      return;
    }

    if (!files?.length) {
      return;
    }

    this.uploadedFiles.update(current => [...current, ...Array.from(files)]);
  }

  private normalizeFileName(fileName: string): string {
    return this.getBaseFileName(fileName);
  }

  private areQueuedFilesMatchingS3Objects(queuedFiles: File[]): boolean {
    const expectedFileNames = this.downloadObjectsView().map(file =>
      this.normalizeFileName(file.displayName)
    );

    if (!expectedFileNames.length) {
      return false;
    }

    return queuedFiles.every(file =>
      expectedFileNames.some(expectedFileName =>
        this.matchesExpectedFileName(file.name, expectedFileName)
      )
    );
  }

  private matchesExpectedFileName(
    fileName: string,
    expectedFileName: string
  ): boolean {
    const normalizedFileName = this.normalizeFileName(fileName);
    const normalizedExpectedFileName = this.normalizeFileName(expectedFileName);

    return (
      normalizedFileName === normalizedExpectedFileName ||
      normalizedFileName.endsWith(`_${normalizedExpectedFileName}`)
    );
  }

  private buildUploadKey(path: string, fileName: string): string {
    const trimmedPath = path.trim().replace(/\/+$/, '');
    const trimmedFileName = this.getBaseFileName(fileName);

    return trimmedPath ? `${trimmedPath}/${trimmedFileName}` : trimmedFileName;
  }

  public getStatusLabel(status: unknown): string {
    return getRanDataImporterStatusLabel(status);
  }

  public getStatusBadgeType(status: unknown): BadgeType {
    return getRanDataImporterStatusBadgeType(status);
  }

  public getStatusBadgeMode(status: unknown): BadgeMode {
    return getRanDataImporterStatusBadgeMode(status);
  }

  constructor() {
    toObservable(this.detailRequest)
      .pipe(
        switchMap(request => {
          if (request.mode === 'empty') {
            return of<WorkflowDetailState>({ loading: false, data: null });
          }

          return this.service.getWorkflowDetail(
            request.importType,
            request.workflowId,
            request.runId ?? undefined
          );
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(state => {
        this.detailState.set(state);
        this.loadDownloadObjects(state.data ?? null);
      });
  }
}
