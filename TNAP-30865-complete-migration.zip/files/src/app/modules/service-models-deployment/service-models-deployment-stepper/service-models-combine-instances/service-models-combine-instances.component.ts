/*
 * Copyright (c) 2022. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import {
  UntypedFormArray,
  UntypedFormControl,
  UntypedFormGroup,
} from '@angular/forms';
import { BehaviorSubject, combineLatest, EMPTY, Observable, of } from 'rxjs';
import {
  CloudRegion,
  CustomersService,
  LinesOfBusinessService,
  NetworkService,
  OwningEntitiesService,
  PlatformsService,
  ProjectsService,
  ServiceDesignAndCreationService,
  ServiceModelResponse,
  ServiceModelsService,
  ServiceSubscriptionsService,
} from 'openapi/output';
import {
  debounceTime,
  distinctUntilChanged,
  filter,
  map,
  shareReplay,
  startWith,
  switchMap,
  takeUntil,
} from 'rxjs/operators';
import { InstanceType } from 'src/app/model/service-model.model';
import { TranslateService } from '@ngx-translate/core';
import { UnsubscribeService } from 'src/app/services/unsubscribe/unsubscribe.service';
import { isNotNullOrUndefined } from '../../../../helpers/helpers';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-service-models-combine-instances',
  templateUrl: './service-models-combine-instances.component.html',
  providers: [UnsubscribeService],
  standalone: false,
})
export class ServiceModelsCombineInstancesComponent
  implements OnInit, OnDestroy
{
  InstanceType = InstanceType;
  @Input() readonly formGroup: UntypedFormGroup | undefined;
  @Input() readonly uuid: string = '';

  public selectedEntity:
    | { form: UntypedFormGroup | null; type: InstanceType; rowId: number }
    | undefined = undefined;
  serviceModel$: Observable<ServiceModelResponse> | undefined = undefined;

  gnbNamesOptions$: Observable<string[] | undefined> = this.networkService
    .listSiteResourceNames('gnb')
    .pipe(map(rsp => rsp.names));
  // data for forms
  customerId$ = new BehaviorSubject<string | null>(null);
  readonly customerOptions$ = this.customersService.listCustomers().pipe(
    map(customers => customers.items),
    shareReplay({ refCount: true, bufferSize: 1 })
  );
  serviceTypeId$ = new BehaviorSubject<string | null>(null);
  cloudRegion$ = new BehaviorSubject<CloudRegion | null>(null);
  readonly serviceTypeOptions$ = this.customerId$.pipe(
    switchMap(customerId =>
      customerId
        ? this.serviceSubscriptionsService
            .listServiceSubscriptions(customerId)
            .pipe(map(serviceSubscriptions => serviceSubscriptions.items))
        : EMPTY
    ),
    shareReplay({ refCount: true, bufferSize: 1 })
  );
  private alreadySelectedResourceNames$: BehaviorSubject<string[] | undefined> =
    new BehaviorSubject<string[] | undefined>(undefined);
  private selectedInstanceName$: BehaviorSubject<string | undefined> =
    new BehaviorSubject<string | undefined>(undefined);
  xnfNamesOptions$: Observable<string[] | undefined> =
    this.selectedInstanceName$.pipe(
      takeUntil(this.unsubscribeService.unsubscribe$),
      filter(isNotNullOrUndefined),
      switchMap(selectedInstanceName =>
        this.networkService.listSiteResourceNamesByGnb(selectedInstanceName)
      ),
      map(rsp => rsp.names),
      switchMap(names => {
        return combineLatest([
          of(names),
          this.alreadySelectedResourceNames$,
        ]).pipe(
          map(([allNames, alreadySelectedNames]) => {
            if (!alreadySelectedNames) {
              return allNames;
            }
            return allNames.filter(
              name => !alreadySelectedNames.includes(name)
            );
          })
        );
      }),
      shareReplay({ refCount: true, bufferSize: 1 })
    );

  readonly cloudRegionOptions$ = this.serviceTypeId$.pipe(
    switchMap(serviceTypeId =>
      serviceTypeId
        ? this.serviceTypeOptions$.pipe(
            map(
              serviceTypeOptions =>
                serviceTypeOptions.find(
                  serviceSubscription =>
                    serviceSubscription.serviceType === serviceTypeId
                )?.cloudRegions
            )
          )
        : EMPTY
    ),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  readonly tenantOptions$ = this.cloudRegion$.pipe(
    map(cloudRegion => (cloudRegion ? cloudRegion.id : null)),
    switchMap(cloudRegionId =>
      cloudRegionId
        ? this.cloudRegionOptions$.pipe(
            map(cloudRegionOptions =>
              cloudRegionOptions
                ? cloudRegionOptions.find(
                    (item: CloudRegion) => item.id === cloudRegionId
                  )?.tenants
                : []
            )
          )
        : EMPTY
    ),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  readonly lineOfBusinessOptions$ = this.lineOfBusinessService
    .listLinesOfBusiness()
    .pipe(
      map(options => options.items),
      shareReplay({ refCount: true, bufferSize: 1 })
    );

  readonly resourcePlatformOptions$ = this.platformsService
    .listPlatforms()
    .pipe(
      map(options => options.items),
      shareReplay({ refCount: true, bufferSize: 1 })
    );

  readonly projectOptions$ = this.projectService.listProjects().pipe(
    map(projects => projects.items),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  readonly owningEntityOptions$ = this.owningEntitiesService
    .listOwningEntities()
    .pipe(
      map(owningEntities => owningEntities.items),
      shareReplay({ refCount: true, bufferSize: 1 })
    );

  readonly serviceOptions$ = this.serviceDesignAndCreationService
    .listSdcServices()
    .pipe(
      map(service => service.items),
      shareReplay({ refCount: true, bufferSize: 1 })
    );

  private hintMessage?: string;

  constructor(
    private serviceModelsService: ServiceModelsService,
    private customersService: CustomersService,
    private serviceSubscriptionsService: ServiceSubscriptionsService,
    private lineOfBusinessService: LinesOfBusinessService,
    private platformsService: PlatformsService,
    private projectService: ProjectsService,
    private owningEntitiesService: OwningEntitiesService,
    private serviceDesignAndCreationService: ServiceDesignAndCreationService,
    private alertService: TnapAlertService,
    private translateService: TranslateService,
    private unsubscribeService: UnsubscribeService,
    private networkService: NetworkService
  ) {}

  ngOnDestroy() {
    // Remove only the hint shown by this step; other alerts stay visible.
    this.alertService
      .alerts()
      .filter(alert => alert.message === this.hintMessage)
      .forEach(alert => this.alertService.remove(alert.id));
  }

  get instanceName(): UntypedFormControl {
    return this.service.get('instanceName') as UntypedFormControl;
  }

  get selectedEntityForm(): UntypedFormGroup | undefined {
    if (!this.selectedEntity) {
      return undefined;
    }
    return this.selectedEntity?.form as UntypedFormGroup;
  }

  get resources(): UntypedFormArray {
    return this.formGroup?.get('service.resources') as UntypedFormArray;
  }

  get service(): UntypedFormGroup {
    return this.formGroup?.get('service') as UntypedFormGroup;
  }

  get customer(): UntypedFormControl {
    return this.service.get('customer') as UntypedFormControl;
  }

  get serviceType(): UntypedFormControl {
    return this.service.get('serviceType') as UntypedFormControl;
  }

  ngOnInit() {
    const hintMessage: string = this.translateService.instant(
      'serviceModels.list.labels.hint'
    );
    this.hintMessage = hintMessage;
    this.alertService.info(hintMessage, { autoClose: true });
    this.serviceModel$ = this.serviceModelsService.getServiceModel(this.uuid);
    this.selectedEntity = {
      type: InstanceType.SERVICE,
      form: this.service,
      rowId: this.service.get('rowId')?.value,
    };
    this.serviceTypeId$.next(this.serviceType.value);
    this.cloudRegion$.next(this.cloudRegion.value);
    this.customer.valueChanges
      .pipe(
        startWith(this.customer.value),
        filter(value => value !== null),
        debounceTime(100),
        distinctUntilChanged(),
        takeUntil(this.unsubscribeService.unsubscribe$)
      )
      .subscribe(customer => {
        this.customerId$.next(customer);
        this.serviceTypeId$.next(null);

        this.serviceType.reset(null);
        this.cloudRegion.reset();
        this.tenant.reset();

        this.serviceType.enable({ emitEvent: false });
        this.cloudRegion.disable({ emitEvent: false });
        this.tenant.disable({ emitEvent: false });

        this.resetVnfs(this.resources, true);
      });

    this.serviceType.valueChanges
      .pipe(
        distinctUntilChanged(),
        filter(value => value !== null),
        debounceTime(100),
        takeUntil(this.unsubscribeService.unsubscribe$)
      )
      .subscribe(serviceType => {
        this.serviceTypeId$.next(serviceType);
        this.cloudRegion.reset();
        this.tenant.reset();

        this.cloudRegion.enable({ emitEvent: false });
        this.resetVnfs(this.resources);
      });

    this.instanceName.valueChanges
      .pipe(debounceTime(100), takeUntil(this.unsubscribeService.unsubscribe$))
      .subscribe(instanceName => {
        this.selectedInstanceName$.next(instanceName);
      });

    this.resources.valueChanges
      .pipe(
        debounceTime(100),
        takeUntil(this.unsubscribeService.unsubscribe$),
        map(() => {
          return this.resources.controls
            .map(control => control.get('instanceName')?.value)
            .filter(name => name);
        })
      )
      .subscribe(alreadyUsedNames =>
        this.alreadySelectedResourceNames$.next(alreadyUsedNames)
      );

    this.cloudRegion.valueChanges
      .pipe(debounceTime(100), takeUntil(this.unsubscribeService.unsubscribe$))
      .subscribe(cloudRegion => {
        this.tenant.reset();
        if (!cloudRegion) {
          this.tenant.disable();
          return;
        }
        this.cloudRegion$.next(cloudRegion);
        this.tenant.setValue(null);
        this.tenant.enable({ emitEvent: false });
      });
  }

  get cloudRegion(): UntypedFormControl {
    return this.service.get('cloudRegion') as UntypedFormControl;
  }

  get tenant(): UntypedFormControl {
    return this.service.get('tenant') as UntypedFormControl;
  }

  onSelectedEntityChange(
    entity:
      | { form: UntypedFormGroup | null; type: InstanceType; rowId: number }
      | undefined
  ): void {
    this.selectedEntity = entity;
  }

  private resetVnfs(vnfs: UntypedFormArray, disableCloudRegion = false): void {
    vnfs.controls.forEach(formGroup => {
      const cloudRegion = formGroup?.get('cloudRegion') as UntypedFormControl;
      const tenant = formGroup?.get('tenant') as UntypedFormControl;
      cloudRegion.reset();
      tenant.reset();
      if (disableCloudRegion) {
        cloudRegion.disable();
      } else {
        cloudRegion.enable();
      }
    });
  }
}
