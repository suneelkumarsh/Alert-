/*
 * Copyright (c) 2022. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Component,
  HostListener,
  isDevMode,
  OnInit,
  ViewChild,
} from '@angular/core';
import {
  CreateOrchestrationRequestRequest,
  OrchestrationService,
  ServiceInstancesService,
} from 'openapi/output';
import {
  AbstractControl,
  AsyncValidatorFn,
  UntypedFormArray,
  UntypedFormControl,
  UntypedFormGroup,
  ValidationErrors,
  Validators,
} from '@angular/forms';
import { NgbAlertConfig } from '@ng-bootstrap/ng-bootstrap';
import {
  catchError,
  debounceTime,
  map,
  switchMap,
  takeUntil,
} from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { EMPTY, Observable, of, Subject, timer } from 'rxjs';
import { getRandomNumber } from 'src/app/helpers/helpers';
import { UnsubscribeService } from 'src/app/services/unsubscribe/unsubscribe.service';
import { ComponentCanDeactivate } from 'src/app/guards/pending-changes.guard';
import { HistoryService } from 'src/app/services/history.service';
import { ActionType, EntityType } from 'src/app/model/user-last-action.model';
import { FormValidators } from 'src/app/helpers/form-validators';
import { ModelDeploymentPrefillStateService } from '../model-deployment-prefill-state.service';
import { generatePnfFormGroup, generateVnfFormGroup } from '../helpers';
import { ServiceModelRowComponent } from './service-models-combine-instances/service-model-row/service-model-row.component';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

// The way this is set up with a wrapper component, may cause issues with passing data between the sub components (because objects could be undefined).
// For instance for the deployment status a more cleaner way would be by providing the id via the url
// instead of passing the orchestrationRequest object to the component just for the id
@Component({
  selector: 'app-service-models-deployment-stepper',
  templateUrl: './service-models-deployment-stepper.component.html',
  styleUrls: ['./service-models-deployment-stepper.component.css'],
  providers: [NgbAlertConfig, UnsubscribeService],
  standalone: false,
})
export class ServiceModelsDeploymentStepperComponent
  implements ComponentCanDeactivate, OnInit
{
  @ViewChild('app-service-model-row') serviceModelRow:
    | ServiceModelRowComponent
    | undefined;
  orchestrationRequest: CreateOrchestrationRequestRequest | undefined;
  form: UntypedFormGroup | null = null;
  selectedModelUuid: string | undefined = undefined;
  actualStep = 1;
  deploymentTriggered = false;
  deploymentRequestId: string | undefined = undefined;
  private deploymentRequestId$ = new Subject<{
    uuid: string;
    requestId: string;
  }>();

  constructor(
    alertConfig: NgbAlertConfig,
    private orchestrationService: OrchestrationService,
    private alertService: TnapAlertService,
    private translateService: TranslateService,
    private readonly unsubscribeService: UnsubscribeService,
    private historyService: HistoryService,
    private serviceInstanceService: ServiceInstancesService,
    private modelDeploymentPrefillStateService: ModelDeploymentPrefillStateService
  ) {
    alertConfig.type = 'secondary';
    alertConfig.dismissible = true;
  }

  // @HostListener allows us to also guard against browser refresh, close, etc.
  @HostListener('window:beforeunload')
  canDeactivate(): boolean {
    if (this.actualStep === 4) {
      return true;
    }
    // insert logic to check if there are pending changes here;
    // returning true will navigate without confirmation
    // returning false will show a confirm dialog before navigating away
    if (this.form === null || this.hasServiceFormGroupDefaultValues()) {
      return true;
    }
    // allow live reloading in development mode
    return isDevMode();
  }

  ngOnInit() {
    this.deploymentRequestId$
      .pipe(
        switchMap(({ uuid, requestId }) =>
          this.historyService.createServiceModelHistoryAction({
            type: ActionType.DEPLOY,
            entity: EntityType.SERVICEMODEL,
            entityParams: { uuid, requestId },
          })
        )
      )
      .pipe(takeUntil(this.unsubscribeService.unsubscribe$))
      .subscribe();

    const toPrefill =
      this.modelDeploymentPrefillStateService.getPlannedResource();
    if (!toPrefill.instance) {
      return;
    }
    this.selectedModelUuid = toPrefill.instance.modelCustomizationId;
    if (!this.selectedModelUuid) {
      this.alertService.warn(
        this.translateService.instant(
          'serviceModels.plannedResources.warnings.instanceModelIdMissing'
        )
      );
      return;
    }
    this.changeStep(2);
    this.form?.patchValue({
      service: {
        instanceName: toPrefill.instance.serviceInstanceName,
      },
    });

    if (toPrefill.instance && toPrefill.children) {
      let processingPriority = 0;
      const resourcesFormArray = this.form
        ?.get('service')
        ?.get('resources') as UntypedFormArray;
      toPrefill.children.forEach(child => {
        if (!child.modelCustomizationId) {
          this.alertService.warn(
            this.translateService.instant(
              'serviceModels.plannedResources.warnings.nfModelIdMissing'
            )
          );
          return;
        }
        if (child.networkFunctionType.toLowerCase() === 'ru') {
          resourcesFormArray.push(
            generatePnfFormGroup(child.modelCustomizationId, '', '', '', '')
          );
          return;
        }
        resourcesFormArray.push(
          generateVnfFormGroup(
            child.modelCustomizationId,
            '',
            '',
            '',
            '',
            ++processingPriority
          )
        );
      });
      this.form?.patchValue({
        service: {
          resources: toPrefill.children.map(child => ({
            instanceName: child.networkFunctionName,
          })),
        },
      });
      if (this.serviceModelRow) {
        this.serviceModelRow.processingPriority = processingPriority;
      }
    }
  }

  changeStep(stepNumber: number): void {
    if (stepNumber === 1 && (this.actualStep === 2 || this.actualStep === 3)) {
      if (!this.canDeactivate()) {
        if (
          !confirm(
            this.translateService.instant(
              'serviceModels.warningMessage.warning'
            )
          )
        ) {
          return;
        }
        this.form = this.generateServiceFormGroup();
      }
    }
    // we need to re-create form when going from step 1 to step 2
    // in case that user changed step from 2 to 1 and selected another service model
    if (this.actualStep === 1 && stepNumber === 2) {
      this.form = this.generateServiceFormGroup();
      this.actualStep = 2;
      return;
    }
    if (this.actualStep === 2 && stepNumber === 3) {
      if (this.form) {
        this.form.markAllAsTouched();
        if (this.form.valid) {
          this.actualStep = 3;
        }
      }
      return;
    }
    this.actualStep = stepNumber;
  }

  updateOrchestrationRequest(
    orchestrationRequest: CreateOrchestrationRequestRequest
  ): void {
    this.orchestrationRequest = orchestrationRequest;
  }

  deploy() {
    this.orchestrationService
      .createOrchestrationRequest(this.orchestrationRequest)
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        catchError(() => {
          this.alertService.error(
            this.translateService.instant(
              'serviceModels.deployment.deploymentFailed'
            ),
            { keepAfterRouteChange: true }
          );
          return EMPTY;
        })
      )
      .subscribe(response => {
        let uuid = '';
        this.alertService.success(
          this.translateService.instant(
            'serviceModels.deployment.deploymentStarted'
          ),
          { keepAfterRouteChange: true }
        );
        this.deploymentTriggered = true;
        this.deploymentRequestId = response.requestId;
        if (this.orchestrationRequest !== undefined) {
          uuid = this.orchestrationRequest.serviceModelUuid;
        }
        this.deploymentRequestId$.next({
          uuid: uuid,
          requestId: response.requestId,
        });
        this.changeStep(4);
      });
  }

  onStartDeployment(uuid: string): void {
    this.selectedModelUuid = uuid;
    this.changeStep(2);
  }

  private generateServiceFormGroup(): UntypedFormGroup {
    return new UntypedFormGroup({
      service: new UntypedFormGroup({
        cloudRegion: new UntypedFormControl(
          { value: null, disabled: true },
          Validators.required
        ),
        customer: new UntypedFormControl(null, Validators.required),
        instanceName: new UntypedFormControl(
          null,
          [Validators.required, FormValidators.noWhiteSpace],
          this.serviceInstanceUniqueName()
        ),
        instanceParameters: new UntypedFormControl(null),
        lineOfBusiness: new UntypedFormControl(null, Validators.required),
        owningEntity: new UntypedFormControl(null, Validators.required),
        project: new UntypedFormControl(null, Validators.required),
        resourcePlatform: new UntypedFormControl(null, Validators.required),
        day0Version: new UntypedFormControl(null),
        day1Version: new UntypedFormControl(null),
        resources: new UntypedFormArray(
          [],
          [Validators.required, FormValidators.checkUniqueProcessingPriority]
        ),
        rowId: new UntypedFormControl(getRandomNumber(1, 10000000)),
        sdcService: new UntypedFormControl(null, Validators.required),
        serviceModelUuid: new UntypedFormControl(this.selectedModelUuid),
        serviceType: new UntypedFormControl(
          { value: null, disabled: true },
          Validators.required
        ),
        tenant: new UntypedFormControl(
          { value: null, disabled: true },
          Validators.required
        ),
      }),
    });
  }

  private hasServiceFormGroupDefaultValues(): boolean {
    if (this.form?.value.service.cloudRegion) {
      return false;
    }
    if (this.form?.value.service.customer) {
      return false;
    }
    if (this.form?.value.service.instanceName) {
      return false;
    }
    if (this.form?.value.service.instanceParameters) {
      return false;
    }
    if (this.form?.value.service.lineOfBusiness) {
      return false;
    }
    if (this.form?.value.service.owningEntity) {
      return false;
    }
    if (this.form?.value.service.project) {
      return false;
    }
    if (this.form?.value.service.resourcePlatform) {
      return false;
    }
    if (this.form?.value.service.day0Version) {
      return false;
    }
    if (this.form?.value.service.day1Version) {
      return false;
    }
    if (this.form?.value.service.sdcService) {
      return false;
    }
    if (this.form?.value.service.serviceType) {
      return false;
    }
    if (this.form?.value.service.tenant) {
      return false;
    }
    return true;
  }

  private serviceInstanceUniqueName(): AsyncValidatorFn {
    return (control: AbstractControl): Observable<ValidationErrors | null> => {
      if (control.value) {
        return timer(500).pipe(
          switchMap(() =>
            this.serviceInstanceService
              .checkServiceInstanceExistsByName(control.value)
              .pipe(
                debounceTime(500),
                map(isExists => (!isExists ? null : { uniqueName: true }))
              )
          )
        );
      }
      return of(null);
    };
  }
}
