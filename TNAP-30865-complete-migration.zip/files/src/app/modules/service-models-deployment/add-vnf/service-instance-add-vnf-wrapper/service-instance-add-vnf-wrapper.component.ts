/*
 * Copyright (c) 2023. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormGroup, Validators } from '@angular/forms';
import { map, shareReplay, switchMap, take } from 'rxjs/operators';
import {
  AddVnfRequest,
  CustomersService,
  ServiceInstanceDetailResponse,
  ServiceInstancesService,
  ServiceSubscriptionsService,
  VnfOrchestrationResource,
} from '../../../../../../openapi/output';
import { BehaviorSubject, combineLatest, Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import {
  ActionType,
  CreateActionModel,
  EntityType,
  EntityVnfHistoryActionModel,
} from 'src/app/model/user-last-action.model';
import { HistoryService } from 'src/app/services/history.service';
import { ServiceInstanceAddVnfPrefillStateService } from '../../service-instance-add-vnf-prefill-state.service';
import { generateResourceModuleFormGroup } from '../../helpers';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-service-instance-add-vnf-wrapper',
  templateUrl: './service-instance-add-vnf-wrapper.component.html',
  styleUrls: ['./service-instance-add-vnf-wrapper.component.css'],
  standalone: false,
})
export class ServiceInstanceAddVnfWrapperComponent implements OnInit {
  serviceInstanceId: string | null = null;
  customer: string | null = null;
  serviceType: string | null = null;
  deploymentRequestId: string | undefined;
  serviceInstanceName!: string;
  customerId$ = new BehaviorSubject<string | null>(null);
  serviceTypeId$ = new BehaviorSubject<string | null>(null);
  readonly cloudRegions$ = combineLatest([
    this.customerId$,
    this.serviceTypeId$,
    this.customersService.listCustomers(),
  ]).pipe(
    switchMap(([customerId, serviceType]) => {
      return this.serviceSubscriptionsService
        .listServiceSubscriptions(customerId || '')
        .pipe(
          map(subscriptions => {
            return subscriptions.items.find(
              item => item.serviceType === serviceType
            );
          }),
          map(subscription => {
            return subscription?.cloudRegions;
          })
        );
    }),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  form = new UntypedFormGroup({
    resourceModules: new UntypedFormArray([], Validators.required),
  });
  step: number = 1;

  serviceInstance$: Observable<ServiceInstanceDetailResponse> | undefined;

  constructor(
    private serviceInstancesService: ServiceInstancesService,
    private route: ActivatedRoute,
    private translateService: TranslateService,
    private serviceSubscriptionsService: ServiceSubscriptionsService,
    private customersService: CustomersService,
    private alertService: TnapAlertService,
    private historyService: HistoryService,
    private addVnfPrefillStateService: ServiceInstanceAddVnfPrefillStateService
  ) {}

  ngOnInit(): void {
    this.serviceInstanceId =
      this.route.snapshot.paramMap.get('serviceInstanceId');
    this.customer = this.route.snapshot.paramMap.get('customer');
    this.serviceType = this.route.snapshot.paramMap.get('serviceType');
    this.customerId$.next(this.customer);
    this.serviceTypeId$.next(this.serviceType);

    if (this.serviceInstanceId && this.customer && this.serviceType) {
      this.serviceInstance$ = this.serviceInstancesService
        .getServiceInstanceDetails(
          this.customer,
          this.serviceType,
          this.serviceInstanceId
        )
        .pipe(
          shareReplay({
            refCount: true,
            bufferSize: 1,
          })
        );
    }
    const toPrefill =
      this.addVnfPrefillStateService.getPlannedNetworkFunction();
    if (toPrefill) {
      if (!toPrefill.modelCustomizationId) {
        this.alertService.warn(
          this.translateService.instant(
            'serviceModels.plannedResources.warnings.nfModelIdMissing'
          )
        );
        return;
      }
      this.resourceModules.push(
        generateResourceModuleFormGroup(
          toPrefill.modelCustomizationId,
          toPrefill.networkFunctionType.toLowerCase() !== 'ru' ? 'VNF' : 'PNF',
          toPrefill.networkFunctionName
        )
      );
    }
  }

  get resourceModules() {
    return this.form.get('resourceModules') as UntypedFormArray;
  }

  get addedVnfName() {
    return this.resourceModules.controls[0].get('instanceName')?.value;
  }

  get addedVnfId() {
    return this.resourceModules.controls[0].get('uuid')?.value;
  }

  vnfParentName() {
    return this.serviceInstance$?.pipe(
      map(name => {
        return name.serviceInstanceName;
      })
    );
  }

  makeAddVnfRequest(request: AddVnfRequest) {
    return this.serviceInstance$?.pipe(
      switchMap(instance => {
        return this.serviceInstancesService.addVnf(
          instance.serviceInstanceId,
          request
        );
      })
    );
  }

  public addVnfAddingToHistory(
    vnfName: string,
    serviceInstanceName: string,
    vnfId: string
  ) {
    const action: CreateActionModel<EntityVnfHistoryActionModel> = {
      type: ActionType.CREATE,
      entity: EntityType.VNF,
      entityParams: {
        vnfName,
        vnfId,
        parentInstanceName: serviceInstanceName,
      },
    };
    this.historyService
      .createVnfHistoryAction(action)
      .pipe(take(1))
      .subscribe();
  }

  onFormSubmit() {
    // @ts-ignore
    this.makeAddVnfRequest(this.getRequestFromForm()).subscribe(rsp => {
      this.alertService.success(
        this.translateService.instant('serviceModels.addVnf.creationStarted', {
          nfName: this.addedVnfName,
        }),
        { keepAfterRouteChange: true }
      );
      this.deploymentRequestId = rsp.requestId;
      this.step = 2;
    });

    this.vnfParentName()
      ?.pipe(take(1))
      .subscribe(serviceInstanceName =>
        this.addVnfAddingToHistory(
          this.addedVnfName,
          serviceInstanceName,
          this.addedVnfId
        )
      );
  }

  getRequestFromForm(): AddVnfRequest {
    return {
      serviceType: this.serviceType || '',
      resource: this.resourceModules
        .getRawValue()
        .map((resourceModule): VnfOrchestrationResource => {
          return {
            tenant: resourceModule.tenant.id,
            cloudRegionId: resourceModule.cloudRegion.id,
            cloudRegionOwner: resourceModule.cloudRegion.owner,
            resourceUuid: resourceModule.uuid,
            modules: resourceModule.modules.map((module: any) => ({
              ...module,
              resourceUuid: module.uuid,
            })),
            instanceName: resourceModule.instanceName,
            instanceParams: resourceModule.instanceParams,
            resourceType: resourceModule.resourceType,
          };
        })[0] as any,
    };
  }
}
