/*
 * Copyright (c) 2023. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormArray, UntypedFormGroup } from '@angular/forms';
import { BehaviorSubject, combineLatest, Observable } from 'rxjs';
import {
  CloudRegion,
  CustomersService,
  LinesOfBusinessService,
  OwningEntitiesService,
  PlatformsService,
  ProjectsService,
  ServiceDesignAndCreationService,
  ServiceInstanceDetailResponse,
  ServiceInstanceResponse,
  ServiceInstancesService,
  ServiceModelConfiguration,
  ServiceModelResponse,
  ServiceModelsService,
  ServiceSubscriptionsService,
} from '../../../../../../openapi/output';
import { map, shareReplay, switchMap } from 'rxjs/operators';
import { UnsubscribeService } from '../../../../services/unsubscribe/unsubscribe.service';
import { InstanceType } from 'src/app/model/service-model.model';
import { ActivatedRoute } from '@angular/router';
import { markAsDirtyAndValidate } from '../../../../helpers/helpers';
import { generateResourceModuleFormGroup } from '../../helpers';

@Component({
  selector: 'app-service-instance-add-vnf',
  templateUrl: './service-instance-add-vnf.component.html',
  styleUrls: ['./service-instance-add-vnf.component.css'],
  providers: [UnsubscribeService],
  standalone: false,
})
export class ServiceInstanceAddVnfComponent implements OnInit {
  serviceInstanceId: string | null = null;
  customer: string | null = null;
  serviceType: string | null = null;
  InstanceType = InstanceType;
  @Input() form!: UntypedFormGroup;
  @Input() cloudRegions$!: Observable<CloudRegion[] | undefined>;
  @Output() submitEvent: EventEmitter<undefined> = new EventEmitter();
  public selectedEntity:
    | { form: UntypedFormGroup | null; type: InstanceType; rowId: number }
    | undefined = undefined;
  serviceModel$: Observable<ServiceModelResponse> | undefined = undefined;
  @Input() serviceInstance$!:
    | Observable<ServiceInstanceDetailResponse>
    | undefined;
  serviceInstanceWithChildren$:
    | Observable<ServiceInstanceResponse | undefined>
    | undefined;
  serviceModelConfigurationOptions$:
    | Observable<ServiceModelConfiguration[]>
    | undefined = undefined;
  // data for forms
  cloudRegion$ = new BehaviorSubject<CloudRegion | null>(null);

  readonly tenants$ = combineLatest([
    this.cloudRegions$,
    this.cloudRegion$,
  ]).pipe(
    map(([cloudRegions, selectedCloudRegion]) => {
      return cloudRegions?.find(
        cloudRegion => cloudRegion.id === selectedCloudRegion?.id
      );
    })
  );

  constructor(
    private serviceModelsService: ServiceModelsService,
    private customersService: CustomersService,
    private serviceSubscriptionsService: ServiceSubscriptionsService,
    private lineOfBusinessService: LinesOfBusinessService,
    private platformsService: PlatformsService,
    private projectService: ProjectsService,
    private owningEntitiesService: OwningEntitiesService,
    private serviceDesignAndCreationService: ServiceDesignAndCreationService,
    private route: ActivatedRoute,
    private serviceInstancesService: ServiceInstancesService
  ) {}

  ngOnInit() {
    this.serviceInstanceId =
      this.route.snapshot.paramMap.get('serviceInstanceId');
    this.customer = this.route.snapshot.paramMap.get('customer');
    this.serviceType = this.route.snapshot.paramMap.get('serviceType');

    if (this.serviceInstanceId && this.customer && this.serviceType) {
      this.serviceInstanceWithChildren$ = this.serviceInstancesService
        .listServiceInstances(
          this.customer,
          this.serviceType,
          1,
          1,
          this.serviceInstanceId
        )
        .pipe(map(rsp => rsp.items[0]));
    }

    this.serviceModel$ = this.serviceInstance$
      ?.pipe(
        switchMap(instance => {
          return this.serviceModelsService.getServiceModel(
            instance.modelVersionId
          );
        })
      )
      .pipe(shareReplay({ refCount: true, bufferSize: 1 }));
  }
  readonly lineOfBusinessOptions$ = this.lineOfBusinessService
    .listLinesOfBusiness()
    .pipe(
      map(options => options.items),
      shareReplay({ refCount: true, bufferSize: 1 })
    );

  readonly resourcePlatformOptions$ = this.platformsService
    .listPlatforms()
    .pipe(
      map(options => options.items),
      shareReplay({ refCount: true, bufferSize: 1 })
    );
  onSelectedEntityChange(
    entity:
      | { form: UntypedFormGroup | null; type: InstanceType; rowId: number }
      | undefined
  ): void {
    this.selectedEntity = entity;
  }
  get resourceModules(): UntypedFormArray {
    return this.form.get('resourceModules') as UntypedFormArray;
  }
  get resourceModulesControls(): UntypedFormGroup[] {
    return this.resourceModules.controls as UntypedFormGroup[];
  }
  get selectedEntityForm(): UntypedFormGroup | null | undefined {
    return this.selectedEntity?.form;
  }
  stopPropagation(event: any) {
    event.stopPropagation();
  }
  addResource(uuid: string, type: string, event: any) {
    this.stopPropagation(event);
    const newResource = generateResourceModuleFormGroup(uuid, type);
    this.resourceModules.push(newResource);

    this.onSelectedEntityChange({
      type: type as InstanceType,
      form: newResource,
      rowId: newResource.get('rowId')?.value,
    });
  }

  removeResource(i: number) {
    this.resourceModules.removeAt(i);
  }

  submitForm() {
    this.form.markAllAsTouched();
    markAsDirtyAndValidate(this.form);
    if (!this.form.valid) {
      return;
    }
    this.submitEvent.emit();
  }
}
