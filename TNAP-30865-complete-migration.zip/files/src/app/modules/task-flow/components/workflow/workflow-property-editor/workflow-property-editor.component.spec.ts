/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SimpleChange, NO_ERRORS_SCHEMA } from '@angular/core';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { of, throwError } from 'rxjs';
import { TaskFlowSharedService } from '../../../services/shared/task-flow-shared.service';
import { WorkflowPropertyEditorComponent } from './workflow-property-editor.component';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('WorkflowPropertyEditorComponent', () => {
  let component: WorkflowPropertyEditorComponent;
  let fixture: ComponentFixture<WorkflowPropertyEditorComponent>;
  let taskFlowSharedService: jasmine.SpyObj<TaskFlowSharedService>;
  let translateService: TranslateService;
  beforeEach(async () => {
    const sharedServiceSpy = jasmine.createSpyObj('TaskFlowSharedService', [
      'getResourceById',
    ]);
    const alertServiceSpy = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
    ]);

    await TestBed.configureTestingModule({
      declarations: [WorkflowPropertyEditorComponent],
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: TaskFlowSharedService, useValue: sharedServiceSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(WorkflowPropertyEditorComponent);
    component = fixture.componentInstance;
    taskFlowSharedService = TestBed.inject(
      TaskFlowSharedService
    ) as jasmine.SpyObj<TaskFlowSharedService>;
    translateService = TestBed.inject(TranslateService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should default schedule section to expanded', () => {
    expect(component.showSchedule()).toBeTrue();
  });

  it('should return workflow title when no task is focused', () => {
    component.focusedTask = null;

    expect(component.propertiesTitleKey()).toBe(
      'taskFlow.createWorkflow.editor.workflowTitle'
    );
  });

  it('should return task title when a task is focused', () => {
    component.focusedTask = {
      instanceId: 'instance-1',
      taskName: 'Task One',
      order: 1,
      properties: {},
      task: { uniqueId: 'resource-1' },
    } as any;

    expect(component.propertiesTitleKey()).toBe(
      'taskFlow.createWorkflow.editor.taskTitle'
    );
  });

  it('should show palette multi-select hint when more than one palette task is selected', () => {
    translateService.setTranslation(
      'en',
      {
        taskFlow: {
          createWorkflow: {
            editor: {
              taskTitle: 'Task Properties',
              basicDetails: 'Basic Details',
              properties: 'Properties',
              multiTaskSelectionHint:
                '{{count}} tasks selected, showing last selected task details',
            },
          },
        },
      },
      true
    );
    translateService.use('en');
    component.focusedTask = {
      instanceId: 'instance-1',
      taskName: 'Task One',
      order: 1,
      properties: {},
      task: {
        uniqueId: 'resource-1',
        name: 'Task One',
        description: 'Task description',
        vendorName: 'Vendor One',
        version: '1.0',
      },
    } as any;
    component.paletteSelectionCount = 3;
    taskFlowSharedService.getResourceById.and.returnValue(
      of({ inputs: [] } as any)
    );

    component.ngOnChanges({
      focusedTask: new SimpleChange(null, component.focusedTask, false),
    });
    fixture.detectChanges();

    expect(component.showPaletteSelectionHint()).toBeTrue();
    expect(fixture.nativeElement.textContent).toContain(
      '3 tasks selected, showing last selected task details'
    );
  });

  it('should load task properties from getResourceById and prepare key-value data', () => {
    component.focusedTask = {
      instanceId: 'instance-1',
      taskName: 'Task One',
      order: 1,
      properties: {},
      task: {
        uniqueId: 'resource-1',
        name: 'Task One',
        vendorName: 'Vendor One',
        type: 'RANTemplateExecutionTask',
      },
    } as any;

    taskFlowSharedService.getResourceById.and.returnValue(
      of({
        description: 'Fetched task description',
        vendorName: 'Fetched vendor',
        inputs: [
          { name: 'simpleInput', value: 'value-1', hidden: false },
          { name: 'inventoryFilterList', value: '["A","B"]', hidden: false },
          { name: 'hiddenInput', value: 'secret', hidden: true },
        ],
      } as any)
    );

    component.showProperties.set(true);
    component.loadProperties();

    expect(taskFlowSharedService.getResourceById).toHaveBeenCalledWith(
      'resource-1',
      true
    );
    expect(component.showProperties()).toBeTrue();
    expect(component.isLoadingProperties()).toBeFalse();
    expect(component.propertiesLoadError()).toBeFalse();
    expect(component.taskInputs().length).toBe(2);
    expect(component.taskInputs()[0].name).toBe('simpleInput');
    expect(component.taskInputs()[1].value).toBe('A, B');
    expect(component.propertyDetails()['simpleInput']).toBe('value-1');
    expect(component.propertyDetails()['inventoryFilterList']).toBe('A, B');
    expect(component.propertyDetailColumns().length).toBe(2);
    expect(component.basicTaskDetails()['description']).toBe(
      'Fetched task description'
    );
    expect(component.basicTaskDetails()['vendorName']).toBe('Fetched vendor');
    expect(component.propertyDetailColumns()[0]).toEqual({
      key: 'simpleInput',
      header: 'Simple Input',
    });
  });

  it('should toggle properties panel visibility without reloading data', () => {
    component.focusedTask = {
      instanceId: 'instance-1',
      taskName: 'Task One',
      order: 1,
      properties: {},
      task: { uniqueId: 'resource-1' },
    } as any;
    component.showProperties.set(true);
    component.taskInputs.set([{ name: 'field' } as any]);
    component.propertyDetails.set({ field: 'value' });
    component.propertyDetailColumns.set([{ key: 'field', header: 'Field' }]);

    component.toggleProperties();

    expect(taskFlowSharedService.getResourceById).not.toHaveBeenCalled();
    expect(component.showProperties()).toBeFalse();
    expect(component.taskInputs()).toEqual([{ name: 'field' } as any]);
    expect(component.propertyDetails()).toEqual({ field: 'value' });
    expect(component.propertyDetailColumns()).toEqual([
      { key: 'field', header: 'Field' },
    ]);
  });

  it('should set error state when getResourceById fails', () => {
    component.focusedTask = {
      instanceId: 'instance-1',
      taskName: 'Task One',
      order: 1,
      properties: {},
      task: {
        uniqueId: 'resource-1',
      },
    } as any;

    taskFlowSharedService.getResourceById.and.returnValue(
      throwError(() => new Error('load failed'))
    );

    component.loadProperties();

    expect(component.isLoadingProperties()).toBeFalse();
    expect(component.propertiesLoadError()).toBeTrue();
    expect(component.taskInputs()).toEqual([]);
  });

  it('should reset loaded property state when focused task changes', () => {
    component.showProperties.set(true);
    component.taskInputs.set([{ name: 'field' } as any]);
    component.propertyDetails.set({ field: 'value' });
    component.propertyDetailColumns.set([{ key: 'field', header: 'Field' }]);

    component.focusedTask = {
      instanceId: 'instance-2',
      taskName: 'Task Two',
      order: 2,
      properties: {},
      task: { uniqueId: 'resource-2' },
    } as any;
    taskFlowSharedService.getResourceById.and.returnValue(
      of({ inputs: [] } as any)
    );

    component.ngOnChanges({
      focusedTask: new SimpleChange(null, component.focusedTask, false),
    });

    expect(component.showProperties()).toBeTrue();
    expect(component.taskInputs()).toEqual([]);
    expect(component.propertyDetails()).toEqual({});
    expect(component.propertyDetailColumns()).toEqual([]);
    expect(taskFlowSharedService.getResourceById).toHaveBeenCalledWith(
      'resource-2',
      true
    );
  });

  it('should keep basic task details empty when focused task has no task payload', () => {
    component.focusedTask = {
      instanceId: 'instance-2',
      taskName: 'Task Two',
      order: 2,
      properties: {},
    } as any;

    component.ngOnChanges({
      focusedTask: new SimpleChange(null, component.focusedTask, false),
    });

    expect(component.taskForm.get('taskName')?.value).toBe('Task Two');
    expect(component.basicTaskDetails()).toEqual({});
    expect(component.basicTaskDetailsColumns()).toEqual([]);
  });

  it('should include description in basic task details before and after loading properties', () => {
    component.focusedTask = {
      instanceId: 'instance-1',
      taskName: 'Task One',
      order: 1,
      properties: {},
      task: {
        uniqueId: 'resource-1',
        name: 'Task One',
        description: 'Task description from selection',
        vendorName: 'Vendor One',
        version: '1.0',
      },
    } as any;
    taskFlowSharedService.getResourceById.and.returnValue(
      of({
        description: 'Task description from API',
        vendorName: 'Vendor from API',
        inputs: [],
      } as any)
    );

    component.ngOnChanges({
      focusedTask: new SimpleChange(null, component.focusedTask, false),
    });

    expect(component.basicTaskDetailsColumns()).toEqual([
      { key: 'name', header: 'taskFlow.common.fields.name' },
      {
        key: 'description',
        header: 'taskFlow.createWorkflow.editor.description',
      },
      { key: 'vendorName', header: 'taskFlow.tasks.fields.vendor' },
      { key: 'version', header: 'taskFlow.common.fields.version' },
      { key: 'order', header: 'taskFlow.createWorkflow.editor.order' },
    ]);
    expect(component.basicTaskDetails()['description']).toBe(
      'Task description from API'
    );
    expect(component.basicTaskDetails()['vendorName']).toBe('Vendor from API');
  });

  it('should use fallback vendor when task vendor is missing', () => {
    component.focusedTask = {
      instanceId: 'instance-1',
      taskName: 'Task One',
      order: 1,
      properties: {},
      task: {
        uniqueId: 'resource-1',
        name: 'Task One',
        description: 'Task description from selection',
        version: '1.0',
      },
    } as any;
    taskFlowSharedService.getResourceById.and.returnValue(
      of({ inputs: [] } as any)
    );

    component.ngOnChanges({
      focusedTask: new SimpleChange(null, component.focusedTask, false),
    });

    expect(component.basicTaskDetails()['vendorName']).toBe('-');
  });

  it('should reuse cached task properties for the same resource on this page', () => {
    const focusedTask = {
      instanceId: 'instance-1',
      taskName: 'Task One',
      order: 1,
      properties: {},
      task: {
        uniqueId: 'resource-1',
        name: 'Task One',
        description: 'Task description from selection',
        vendorName: 'Vendor One',
        version: '1.0',
      },
    } as any;
    taskFlowSharedService.getResourceById.and.returnValue(
      of({
        description: 'Task description from API',
        vendorName: 'Vendor from API',
        inputs: [{ name: 'simpleInput', value: 'value-1', hidden: false }],
      } as any)
    );

    component.focusedTask = focusedTask;
    component.ngOnChanges({
      focusedTask: new SimpleChange(null, component.focusedTask, false),
    });

    component.focusedTask = { ...focusedTask, instanceId: 'instance-2' };
    component.ngOnChanges({
      focusedTask: new SimpleChange(focusedTask, component.focusedTask, false),
    });

    expect(taskFlowSharedService.getResourceById).toHaveBeenCalledTimes(1);
    expect(component.basicTaskDetails()['description']).toBe(
      'Task description from API'
    );
    expect(component.basicTaskDetails()['vendorName']).toBe('Vendor from API');
    expect(component.propertyDetails()['simpleInput']).toBe('value-1');
  });

  it('should expose workflow details columns for key-value summary', () => {
    const keys = component.workflowDetailsColumns
      .filter(
        (c): c is { key: string; header?: string } => typeof c !== 'string'
      )
      .map(c => c.key);

    expect(keys).toEqual([
      'name',
      'description',
      'version',
      'lifecycleState',
      'distributionStatus',
    ]);
  });

  it('should map currentWorkflow into workflowDetails with fallback values', () => {
    component.currentWorkflow = {
      name: 'wf-name',
      description: 'wf-description',
      version: '1.0',
      lifecycleState: 'NOT_CERTIFIED',
      distributionStatus: 'DISTRIBUTION_PENDING',
    } as any;

    expect(component.workflowDetails()).toEqual({
      name: 'wf-name',
      description: 'wf-description',
      version: '1.0',
      lifecycleState: 'NOT_CERTIFIED',
      distributionStatus: 'DISTRIBUTION_PENDING',
    });

    component.currentWorkflow = null;
    expect(component.workflowDetails()).toEqual({
      name: '-',
      description: '-',
      version: '-',
      lifecycleState: '-',
      distributionStatus: '-',
    });
  });

  it('should use translated lifecycle and distribution labels when available', () => {
    translateService.setTranslation(
      'en',
      {
        taskFlow: {
          common: { states: { CERTIFIED: 'Certified Label' } },
          workflow: {
            distributionStates: { DISTRIBUTED: 'Distributed Label' },
          },
        },
      },
      true
    );
    translateService.use('en');
    component.currentWorkflow = {
      name: 'wf-name',
      description: 'wf-description',
      version: '1.0',
      lifecycleState: 'CERTIFIED',
      distributionStatus: 'DISTRIBUTED',
    } as any;

    expect(component.workflowDetails()).toEqual({
      name: 'wf-name',
      description: 'wf-description',
      version: '1.0',
      lifecycleState: 'Certified Label',
      distributionStatus: 'Distributed Label',
    });
  });

  it('should not load properties when there is no focused task', () => {
    component.focusedTask = null;

    component.loadProperties();

    expect(taskFlowSharedService.getResourceById).not.toHaveBeenCalled();
    expect(component.showProperties()).toBeFalse();
  });

  it('should toggle properties panel open when a task is focused', () => {
    component.focusedTask = {
      instanceId: 'instance-1',
      taskName: 'Task One',
      order: 1,
      properties: {},
      task: { uniqueId: 'resource-1' },
    } as any;

    component.toggleProperties();

    expect(component.showProperties()).toBeTrue();
    expect(taskFlowSharedService.getResourceById).not.toHaveBeenCalled();
  });

  it('should auto-open and load properties when focused task changes', () => {
    component.focusedTask = {
      instanceId: 'instance-1',
      taskName: 'Task One',
      order: 1,
      properties: {},
      task: { uniqueId: 'resource-1' },
    } as any;
    taskFlowSharedService.getResourceById.and.returnValue(
      of({ inputs: [] } as any)
    );

    component.ngOnChanges({
      focusedTask: new SimpleChange(null, component.focusedTask, false),
    });

    expect(component.showProperties()).toBeTrue();
    expect(taskFlowSharedService.getResourceById).toHaveBeenCalledWith(
      'resource-1',
      true
    );
  });

  it('should set error state when focused task has no resource id', () => {
    component.focusedTask = {
      instanceId: 'instance-1',
      taskName: 'Task One',
      order: 1,
      properties: {},
      task: { uniqueId: '   ' },
    } as any;

    component.loadProperties();

    expect(taskFlowSharedService.getResourceById).not.toHaveBeenCalled();
    expect(component.isLoadingProperties()).toBeFalse();
    expect(component.propertiesLoadError()).toBeTrue();
  });

  it('should handle resource responses with non-array inputs', () => {
    component.focusedTask = {
      instanceId: 'instance-1',
      taskName: 'Task One',
      order: 1,
      properties: {},
      task: { uniqueId: 'resource-1' },
    } as any;
    taskFlowSharedService.getResourceById.and.returnValue(
      of({ inputs: null } as any)
    );

    component.loadProperties();

    expect(component.propertiesLoadError()).toBeFalse();
    expect(component.taskInputs()).toEqual([]);
    expect(component.propertyDetails()).toEqual({});
    expect(component.propertyDetailColumns()).toEqual([]);
  });

  it('should skip property detail columns for blank input names', () => {
    component.focusedTask = {
      instanceId: 'instance-1',
      taskName: 'Task One',
      order: 1,
      properties: {},
      task: { uniqueId: 'resource-1' },
    } as any;
    taskFlowSharedService.getResourceById.and.returnValue(
      of({
        inputs: [{ name: '   ', value: 'value-1', hidden: false }],
      } as any)
    );

    component.loadProperties();

    expect(component.taskInputs().length).toBe(1);
    expect(component.propertyDetails()).toEqual({});
    expect(component.propertyDetailColumns()).toEqual([]);
  });
});
