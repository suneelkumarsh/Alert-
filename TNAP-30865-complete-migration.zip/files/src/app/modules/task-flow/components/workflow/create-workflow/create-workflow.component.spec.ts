/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { NO_ERRORS_SCHEMA } from '@angular/core';
import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
} from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { of, throwError } from 'rxjs';
import { PaneStateManagerService } from '../../../services/shared/pane-state-manager.service';
import { TaskFlowSharedService } from '../../../services/shared/task-flow-shared.service';
import { TasksService } from '../../../services/task/tasks.service';
import { WorkflowService } from '../../../services/workflow/workflow.service';
import { UpgradeWorkflowsModalLauncherService } from '../../../services/shared/upgrade-workflows-modal-launcher.service';
import { CreateWorkflowComponent } from './create-workflow.component';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('CreateWorkflowComponent', () => {
  let component: CreateWorkflowComponent;
  let fixture: ComponentFixture<CreateWorkflowComponent>;
  let workflowService: jasmine.SpyObj<WorkflowService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let taskFlowSharedService: jasmine.SpyObj<TaskFlowSharedService>;

  beforeEach(async () => {
    const workflowServiceSpy = jasmine.createSpyObj('WorkflowService', [
      'createWorkflowAndFetch',
      'validateTaskName',
    ]);
    const alertServiceSpy = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
    ]);
    const translateServiceSpy = jasmine.createSpyObj(
      'TranslateService',
      ['instant', 'get'],
      {
        onTranslationChange: of({}),
        onLangChange: of({}),
        onDefaultLangChange: of({}),
      }
    );
    const stateManagerSpy = jasmine.createSpyObj('PaneStateManagerService', [
      'getPersistedPaneWidth',
      'persistPaneWidth',
    ]);
    const modalServiceSpy = jasmine.createSpyObj('NgbModal', ['open']);
    const tasksServiceSpy = jasmine.createSpyObj('TasksService', [
      'saveInputs',
      'certifyResource',
    ]);
    const taskFlowSharedServiceSpy = jasmine.createSpyObj(
      'TaskFlowSharedService',
      ['navigateToWorkflowEdit']
    );
    const upgradeWorkflowsModalLauncherSpy = jasmine.createSpyObj(
      'UpgradeWorkflowsModalLauncherService',
      ['open']
    );

    workflowServiceSpy.validateTaskName.and.returnValue(of(true));

    await TestBed.configureTestingModule({
      declarations: [CreateWorkflowComponent],
      imports: [TranslateModule.forRoot(), ReactiveFormsModule],
      providers: [
        { provide: ActivatedRoute, useValue: {} },
        { provide: WorkflowService, useValue: workflowServiceSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
        { provide: PaneStateManagerService, useValue: stateManagerSpy },
        { provide: NgbModal, useValue: modalServiceSpy },
        { provide: TasksService, useValue: tasksServiceSpy },
        {
          provide: TaskFlowSharedService,
          useValue: taskFlowSharedServiceSpy,
        },
        {
          provide: UpgradeWorkflowsModalLauncherService,
          useValue: upgradeWorkflowsModalLauncherSpy,
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    })
      .overrideTemplate(CreateWorkflowComponent, '')
      .compileComponents();

    fixture = TestBed.createComponent(CreateWorkflowComponent);
    component = fixture.componentInstance;
    workflowService = TestBed.inject(
      WorkflowService
    ) as jasmine.SpyObj<WorkflowService>;
    alertService = TestBed.inject(
      TnapAlertService
    ) as jasmine.SpyObj<TnapAlertService>;
    taskFlowSharedService = TestBed.inject(
      TaskFlowSharedService
    ) as jasmine.SpyObj<TaskFlowSharedService>;

    (
      TestBed.inject(TranslateService) as jasmine.SpyObj<TranslateService>
    ).instant.and.callFake((key: string) => key);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should start with an empty, required name/description form', () => {
    expect(component.workflowForm.value).toEqual({
      workflowName: '',
      description: '',
    });
    expect(component.workflowForm.valid).toBeFalse();
  });

  it('should not submit while the form is invalid', () => {
    component.onCreateWorkflowSubmit();

    expect(workflowService.createWorkflowAndFetch).not.toHaveBeenCalled();
  });

  it('should create the workflow and navigate to edit on success', fakeAsync(() => {
    component.workflowForm.setValue({
      workflowName: 'my-workflow',
      description: 'a description',
    });
    workflowService.createWorkflowAndFetch.and.returnValue(
      of({ serviceId: 'new-id' } as any)
    );

    tick(500);

    component.onCreateWorkflowSubmit();

    expect(workflowService.createWorkflowAndFetch).toHaveBeenCalledWith({
      workflowName: 'my-workflow',
      description: 'a description',
    });
    expect(taskFlowSharedService.navigateToWorkflowEdit).toHaveBeenCalledWith(
      'new-id'
    );
    expect(alertService.success).toHaveBeenCalled();
    expect(component.isCreating()).toBeFalse();
  }));

  it('should show an error when the response has no serviceId', fakeAsync(() => {
    component.workflowForm.setValue({
      workflowName: 'my-workflow',
      description: 'a description',
    });
    workflowService.createWorkflowAndFetch.and.returnValue(of({} as any));

    tick(500);

    component.onCreateWorkflowSubmit();

    expect(taskFlowSharedService.navigateToWorkflowEdit).not.toHaveBeenCalled();
    expect(alertService.error).toHaveBeenCalledWith(
      'taskFlow.createWorkflow.notifications.createUidMissingError',
      { keepAfterRouteChange: true }
    );
  }));

  it('should show an error notification when creation fails', fakeAsync(() => {
    component.workflowForm.setValue({
      workflowName: 'my-workflow',
      description: 'a description',
    });
    workflowService.createWorkflowAndFetch.and.returnValue(
      throwError(() => new Error('create failed'))
    );

    tick(500);

    component.onCreateWorkflowSubmit();

    expect(alertService.error).toHaveBeenCalledWith(
      'taskFlow.createWorkflow.notifications.createError',
      { keepAfterRouteChange: true }
    );
    expect(component.isCreating()).toBeFalse();
  }));

  it('should reset the form to empty values', () => {
    component.workflowForm.setValue({
      workflowName: 'my-workflow',
      description: 'a description',
    });

    component.onResetWorkflowForm();

    expect(component.workflowForm.value).toEqual({
      workflowName: '',
      description: '',
    });
  });

  it('should flag an already-existing workflow name as invalid', done => {
    workflowService.validateTaskName.and.returnValue(of(false));

    component.workflowForm.get('workflowName')?.setValue('taken-name');

    setTimeout(() => {
      expect(
        component.workflowForm.get('workflowName')?.errors?.[
          'workflowNameExists'
        ]
      ).toBeTrue();
      done();
    }, 600);
  });
});
