/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  computed,
  inject,
  OnInit,
  signal,
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { EMPTY, from } from 'rxjs';
import { catchError, concatMap, finalize, tap } from 'rxjs/operators';
import { Service } from 'openapi/output';
import { TaskItem, WorkflowTaskInstance } from '../../../models';
import { WorkflowService } from '../../../services/workflow/workflow.service';
import { WorkflowEditorStateService } from '../../../services/workflow/workflow-editor-state.service';
import { TaskFlowOperationBaseComponent } from '../../taskflow-operation-base.component';

/**
 * `EDIT`  — workflow is checked out (`NOT_CERTIFIED_CHECKOUT`): tasks can be
 *           added/removed via the task palette and canvas.
 * `VIEW`  — workflow is certified (or checked in under someone else's
 *           session, `NOT_CERTIFIED_CHECKIN`): read-only, no task palette.
 *
 * Creating a brand-new workflow is handled entirely by the separate
 * `CreateWorkflowComponent` (`workflow/create` route) — this component only
 * ever deals with an existing workflow loaded via `workflow/edit/:id`.
 */
export type WorkflowEditorMode = 'EDIT' | 'VIEW';

const EDITABLE_LIFECYCLE_STATE = 'NOT_CERTIFIED_CHECKOUT';

@Component({
  selector: 'app-workflow-editor',
  templateUrl: './workflow-editor.component.html',
  styleUrls: ['./workflow-editor.component.css'],
  standalone: false,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkflowEditorComponent
  extends TaskFlowOperationBaseComponent
  implements OnInit
{
  private readonly route = inject(ActivatedRoute);
  private readonly workflowService = inject(WorkflowService);
  private readonly workflowEditorStateService = inject(
    WorkflowEditorStateService
  );
  private readonly destroyRef = inject(DestroyRef);
  private readonly MAX_COMBINED_PANE_WIDTH = 65;

  isAddingTasks = signal(false);
  isExecuting = signal(false);
  canCertify = signal(false);
  canExecute = signal(false);

  workflowId = signal<string | null>(null);
  currentWorkflow = signal<Service | null>(null);

  workflowName = signal('');
  workflowDescription = signal('');
  workflowStatus = signal('');

  workflowTasks = signal<WorkflowTaskInstance[]>([]);
  focusedTask = signal<WorkflowTaskInstance | null>(null);
  palettePreviewTask = signal<WorkflowTaskInstance | null>(null);
  paletteSelectionCount = signal(0);

  leftPaneWidth = signal(22);
  rightPaneWidth = signal(32);

  readonly mode = computed<WorkflowEditorMode>(() =>
    this.currentWorkflow()?.lifecycleState === EDITABLE_LIFECYCLE_STATE
      ? 'EDIT'
      : 'VIEW'
  );

  readonly workflowBreadcrumbLabel = computed<string>(() => {
    const name = String(this.workflowName() ?? '').trim();
    const pageTitle = this.translateService.instant(
      'taskFlow.workflowEdit.title'
    );
    return name ? `${pageTitle} (${name})` : pageTitle;
  });

  readonly propertyPaneTask = computed<WorkflowTaskInstance | null>(() => {
    if (this.paletteSelectionCount() > 0) {
      return this.palettePreviewTask();
    }

    return this.focusedTask();
  });

  ngOnInit(): void {
    this.route.paramMap
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(params => {
        const workflowId = params.get('id');
        if (workflowId) {
          this.workflowId.set(workflowId);
          this.loadWorkflowForEdit(workflowId);
        } else {
          this.navigateToWorkflowList();
        }
      });
  }

  checkIfCanCertify(): void {
    const lifecycleState =
      this.workflowEditorStateService.resolveLifecycleState(
        this.currentWorkflow(),
        this.workflowTasks()
      );
    this.canCertify.set(lifecycleState.canCertify);
  }

  checkIfCanExecute(): void {
    const lifecycleState =
      this.workflowEditorStateService.resolveLifecycleState(
        this.currentWorkflow(),
        this.workflowTasks()
      );
    this.canExecute.set(lifecycleState.canExecute);
  }

  private loadWorkflowForEdit(workflowId: string): void {
    this.workflowService
      .getWorkflowById(workflowId)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(workflow => {
        if (workflow) {
          this.applyWorkflowState(workflow, workflowId);
        } else {
          this.navigateToWorkflowList();
        }
      });
  }

  private applyWorkflowState(workflow: Service, workflowId: string): void {
    const snapshot = this.workflowEditorStateService.hydrateWorkflow(
      workflow,
      workflowId,
      this.workflowService.getWorkflowTaskInstances(workflow)
    );

    this.currentWorkflow.set(snapshot.currentWorkflow);
    this.workflowId.set(snapshot.workflowId);
    this.workflowName.set(snapshot.workflowName);
    this.workflowDescription.set(snapshot.workflowDescription);
    this.workflowStatus.set(snapshot.workflowStatus);
    this.workflowTasks.set(snapshot.workflowTasks);
    this.refreshWorkflowLifecycleState();
  }

  private refreshWorkflowLifecycleState(): void {
    this.checkIfCanCertify();
    this.checkIfCanExecute();
  }

  onAddTask(tasks: TaskItem[]): void {
    if (
      this.mode() !== 'EDIT' ||
      this.isAddingTasks() ||
      !this.workflowId() ||
      !Array.isArray(tasks) ||
      tasks.length === 0
    ) {
      return;
    }

    this.isAddingTasks.set(true);

    from(tasks)
      .pipe(
        concatMap(task =>
          this.workflowService.addTaskToWorkflow(this.workflowId()!, task).pipe(
            tap(addedTask => this.appendWorkflowTask(addedTask)),
            catchError(error => {
              this.handleTaskError(
                error,
                'taskFlow.createWorkflow.notifications.addTaskError',
                'WorkflowEditorComponent'
              );
              return EMPTY;
            })
          )
        ),
        finalize(() => {
          this.isAddingTasks.set(false);
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe();
  }

  private appendWorkflowTask(addedTask: WorkflowTaskInstance): void {
    const workflowTask = this.workflowEditorStateService.appendTask(
      this.workflowTasks(),
      addedTask
    );
    const latestTask = workflowTask.at(-1);

    this.workflowTasks.set(workflowTask);
    this.refreshWorkflowLifecycleState();
    this.focusedTask.set(latestTask ?? null);
  }

  onTaskRemoved(instanceId: string): void {
    this.workflowService
      .deleteTaskFromWorkflow(this.workflowId()!, instanceId)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          this.workflowTasks.set(
            this.workflowTasks()
              .filter(t => t.instanceId !== instanceId)
              .map((t, i) => ({ ...t, order: i + 1 }))
          );
          this.refreshWorkflowLifecycleState();
          if (this.focusedTask()?.instanceId === instanceId) {
            this.focusedTask.set(null);
          }
        },
        error: error => {
          this.handleTaskError(
            error,
            'taskFlow.createWorkflow.notifications.deleteTaskError',
            'WorkflowEditorComponent'
          );
        },
      });
  }

  onTaskDropped(task: TaskItem): void {
    this.onAddTask([task]);
  }

  onTaskDropError(errorMessage: string): void {
    const message = String(errorMessage ?? '').trim();
    const translatedMessage = this.translateService.instant(
      'taskFlow.createWorkflow.notifications.dropParseError',
      {
        details: message ? `: ${message}` : '',
      }
    );

    this.alertService.error(translatedMessage, { keepAfterRouteChange: false });
  }

  onTaskFocused(task: WorkflowTaskInstance): void {
    this.focusedTask.set(task);
  }

  onWorkflowFocused(): void {
    this.focusedTask.set(null);
  }

  onPaletteSelectionChanged(tasks: TaskItem[]): void {
    const selectedTasks = Array.isArray(tasks) ? tasks : [];
    this.paletteSelectionCount.set(selectedTasks.length);

    const latestTask = selectedTasks.at(-1);
    if (latestTask !== undefined) {
      this.palettePreviewTask.set(this.buildPalettePreviewTask(latestTask));
      return;
    }

    this.palettePreviewTask.set(null);
  }

  onDiscard() {
    this.navigateToWorkflowList();
  }

  onCheckout(): void {
    if (!this.workflowId() || this.isCertifying) {
      return;
    }

    this.isCertifying = true;
    this.workflowService
      .changeWorkflowState(
        this.workflowId()!,
        'CHECKOUT',
        'Checked out from task-flow workflow canvas'
      )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: response => {
          this.isCertifying = false;
          const newUniqueId = response?.uniqueId;
          if (newUniqueId) {
            this.alertService.success(
              this.translateService.instant(
                'taskFlow.createWorkflow.notifications.checkoutSuccess'
              ),
              { keepAfterRouteChange: true }
            );
            this.navigateToWorkflowEdit(newUniqueId);
          } else {
            this.alertService.success(
              this.translateService.instant(
                'taskFlow.createWorkflow.notifications.checkoutSuccess'
              ),
              { keepAfterRouteChange: false }
            );
          }
        },
        error: error => {
          this.isCertifying = false;
          this.handleTaskError(
            error,
            'taskFlow.createWorkflow.notifications.checkoutError',
            'WorkflowEditorComponent'
          );
        },
      });
  }

  onCertifyAndDistribute(): void {
    if (
      !this.workflowId() ||
      this.isCertifying ||
      this.workflowTasks().length === 0
    ) {
      return;
    }

    this.isCertifying = true;
    this.workflowService
      .certifyAndDistributeWorkflow(
        this.workflowId()!,
        'Certified and distributed from task-flow workflow canvas'
      )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: response => {
          this.isCertifying = false;
          this.alertService.success(
            this.translateService.instant(
              'taskFlow.createWorkflow.notifications.certifySuccess'
            ),
            { keepAfterRouteChange: true }
          );
          const newUniqueId = response?.uniqueId;
          if (newUniqueId) {
            this.navigateToWorkflowEdit(newUniqueId);
          } else {
            this.navigateToWorkflowList();
          }
        },
        error: () => {
          this.isCertifying = false;
          this.alertService.error(
            this.translateService.instant(
              'taskFlow.createWorkflow.notifications.certifyError'
            ),
            { keepAfterRouteChange: false }
          );
        },
      });
  }

  onExecute(): void {
    const directWorkflowId = this.currentWorkflow()?.uniqueId || '';
    const distributedWorkflowId = this.currentWorkflow()?.uuid || '';

    if (!directWorkflowId || !distributedWorkflowId || this.isExecuting()) {
      return;
    }

    this.isExecuting.set(true);
    this.workflowService
      .executeWorkflowDirect(directWorkflowId)
      .pipe(
        catchError(() =>
          this.workflowService.executeWorkflowDistributed(distributedWorkflowId)
        ),
        finalize(() => this.isExecuting.set(false)),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: () => {
          this.alertService.success(
            this.translateService.instant(
              'taskFlow.createWorkflow.notifications.executeSuccess'
            ),
            { keepAfterRouteChange: false }
          );
        },
        error: () => {
          this.alertService.error(
            this.translateService.instant(
              'taskFlow.createWorkflow.notifications.executeError'
            ),
            { keepAfterRouteChange: false }
          );
        },
      });
  }

  onTaskPropertiesApplied(event: {
    instanceId: string;
    taskName: string;
    properties: { [key: string]: any };
  }): void {
    this.workflowTasks.update(tasks =>
      tasks.map(t =>
        t.instanceId === event.instanceId
          ? { ...t, taskName: event.taskName, properties: event.properties }
          : t
      )
    );
    // Update focused task reference
    const updated =
      this.workflowTasks().find(t => t.instanceId === event.instanceId) || null;
    this.focusedTask.set(updated);
  }

  onLeftPaneResize(value: number): void {
    const maxLeft = this.MAX_COMBINED_PANE_WIDTH - this.rightPaneWidth();
    this.leftPaneWidth.set(Math.min(value, Math.max(15, maxLeft)));
  }

  onRightPaneResize(value: number): void {
    const maxRight = this.MAX_COMBINED_PANE_WIDTH - this.leftPaneWidth();
    this.rightPaneWidth.set(Math.min(value, Math.max(15, maxRight)));
  }

  private buildPalettePreviewTask(task: TaskItem): WorkflowTaskInstance {
    return this.workflowEditorStateService.createPalettePreviewTask(task);
  }

  private navigateToWorkflowList(): void {
    this.taskFlowSharedService.navigateToWorkflowList();
  }

  private navigateToWorkflowEdit(id: string): void {
    this.taskFlowSharedService.navigateToWorkflowEdit(id);
  }
}
