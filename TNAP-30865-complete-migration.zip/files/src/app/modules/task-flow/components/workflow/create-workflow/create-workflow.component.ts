/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  inject,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import {
  AbstractControl,
  AsyncValidatorFn,
  FormBuilder,
  FormGroup,
  ValidationErrors,
  Validators,
} from '@angular/forms';
import {
  catchError,
  map,
  Observable,
  of,
  switchMap,
  timeout,
  timer,
} from 'rxjs';
import { WorkflowService } from '../../../services/workflow/workflow.service';
import { TaskFlowOperationBaseComponent } from '../../taskflow-operation-base.component';

/**
 * Dedicated "create a brand-new workflow" page: just a name/description form.
 * On success it hands off to `WorkflowEditorComponent` (`workflow/edit/:id`),
 * which is where task editing actually happens.
 */
@Component({
  selector: 'app-create-workflow',
  templateUrl: './create-workflow.component.html',
  styleUrls: ['./create-workflow.component.css'],
  standalone: false,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CreateWorkflowComponent extends TaskFlowOperationBaseComponent {
  private readonly workflowService = inject(WorkflowService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly fb = inject(FormBuilder);

  readonly isCreating = signal(false);

  readonly workflowForm: FormGroup = this.fb.group({
    workflowName: [
      '',
      [Validators.required],
      [this.createDebouncedWorkflowNameValidator()],
    ],
    description: ['', Validators.required],
  });

  private createDebouncedWorkflowNameValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Observable<ValidationErrors | null> => {
      const trimmedValue = String(control.value ?? '').trim();
      if (!trimmedValue) {
        return of(null);
      }

      return timer(500).pipe(
        switchMap(() =>
          this.workflowService.validateTaskName(trimmedValue).pipe(
            timeout(5000),
            map((isValid: boolean) =>
              isValid ? null : { workflowNameExists: true }
            ),
            catchError(() =>
              of<ValidationErrors>({ workflowNameValidationFailed: true })
            )
          )
        )
      );
    };
  }

  onResetWorkflowForm(): void {
    this.workflowForm.reset({ workflowName: '', description: '' });
  }

  onCreateWorkflowSubmit(): void {
    // `!valid` rather than `invalid` — a PENDING async validator is neither,
    // so `invalid` would let an incomplete form through while it's running.
    if (!this.workflowForm.valid) return;

    this.isCreating.set(true);
    this.workflowService
      .createWorkflowAndFetch(this.workflowForm.value)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: response => {
          this.isCreating.set(false);
          const serviceId = response?.serviceId;
          if (serviceId) {
            this.taskFlowSharedService.navigateToWorkflowEdit(serviceId);
            this.alertService.success(
              this.translateService.instant(
                'taskFlow.createWorkflow.notifications.createSuccess'
              ),
              { keepAfterRouteChange: true }
            );
          } else {
            this.alertService.error(
              this.translateService.instant(
                'taskFlow.createWorkflow.notifications.createUidMissingError'
              ),
              { keepAfterRouteChange: true }
            );
          }
        },
        error: () => {
          this.isCreating.set(false);
          this.alertService.error(
            this.translateService.instant(
              'taskFlow.createWorkflow.notifications.createError'
            ),
            { keepAfterRouteChange: true }
          );
        },
      });
  }
}
