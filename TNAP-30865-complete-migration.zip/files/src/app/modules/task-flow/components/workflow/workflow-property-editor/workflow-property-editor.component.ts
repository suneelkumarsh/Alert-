/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ChangeDetectionStrategy,
  Component,
  DestroyRef,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  SimpleChanges,
  inject,
  signal,
  computed,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { WorkflowTaskInstance } from '../../../models';
import { TranslateService } from '@ngx-translate/core';
import { TaskFlowSharedService } from '../../../services/shared/task-flow-shared.service';
import { TaskFormInputDefinitionService } from '../../../services/task/task-form-input-definition.service';
import { InputDefinition, Resource, Service } from 'openapi/output';
import { ColumnDef } from 'src/app/components/shared/key-value-list/key-value-list.component';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-workflow-property-editor',
  templateUrl: './workflow-property-editor.component.html',
  styleUrls: ['./workflow-property-editor.component.css'],
  host: {
    '[class.compact-mode]': 'compactMode',
  },
  standalone: false,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkflowPropertyEditorComponent implements OnChanges {
  private readonly taskFlowSharedService = inject(TaskFlowSharedService);
  private readonly inputDefinitionService = inject(
    TaskFormInputDefinitionService
  );
  private readonly translate = inject(TranslateService);
  private readonly fb = inject(FormBuilder);
  private readonly destroyRef = inject(DestroyRef);
  private readonly alertService = inject(TnapAlertService);
  private readonly taskResourceCache = new Map<string, Resource>();

  @Input() focusedTask: WorkflowTaskInstance | null = null;
  @Input() currentWorkflow: Service | null = null;
  @Input() compactMode = false;
  @Input() paletteSelectionCount = 0;

  @Output() readonly taskPropertiesApplied = new EventEmitter<{
    instanceId: string;
    taskName: string;
    properties: { [key: string]: unknown };
  }>();

  taskForm: FormGroup;

  readonly showBasicDetails = signal(true);
  readonly showProperties = signal(false);
  readonly showWorkflowDetails = signal(true);
  readonly showSchedule = signal(true);
  readonly taskInputs = signal<Array<InputDefinition>>([]);
  readonly propertyDetails = signal<Record<string, unknown>>({});
  readonly propertyDetailColumns = signal<ColumnDef[]>([]);
  readonly basicTaskDetails = signal<Record<string, unknown>>({});
  readonly basicTaskDetailsColumns = signal<ColumnDef[]>([]);
  readonly isLoadingProperties = signal(false);
  readonly propertiesLoadError = signal(false);

  readonly workflowDetailsColumns: ColumnDef[] = [
    { key: 'name', header: 'taskFlow.createWorkflow.editor.workflowName' },
    {
      key: 'description',
      header: 'taskFlow.createWorkflow.editor.description',
    },
    { key: 'version', header: 'taskFlow.createWorkflow.details.version' },
    { key: 'lifecycleState', header: 'taskFlow.createWorkflow.details.status' },
    {
      key: 'distributionStatus',
      header: 'taskFlow.createWorkflow.details.distributionStatus',
    },
  ];

  readonly isPropertyDataAvailable = computed(
    () => this.taskInputs().length > 0 && !this.propertiesLoadError()
  );

  constructor() {
    this.taskForm = this.fb.group({});
  }

  propertiesTitleKey(): string {
    return this.focusedTask
      ? 'taskFlow.createWorkflow.editor.taskTitle'
      : 'taskFlow.createWorkflow.editor.workflowTitle';
  }

  showPaletteSelectionHint(): boolean {
    return !!this.focusedTask && this.paletteSelectionCount > 1;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['focusedTask']) {
      this.showBasicDetails.set(true);
      this.resetPropertiesState();

      if (this.focusedTask) {
        this.buildTaskForm();
        this.prepareBasicTaskDetails();
        this.showProperties.set(true);
        this.loadProperties();
      }
    }
  }

  toggleProperties(): void {
    if (!this.focusedTask) {
      return;
    }

    this.showProperties.set(!this.showProperties());
  }

  private resetPropertiesState(): void {
    this.showProperties.set(false);
    this.taskInputs.set([]);
    this.propertyDetails.set({});
    this.propertyDetailColumns.set([]);
    this.isLoadingProperties.set(false);
    this.propertiesLoadError.set(false);
  }

  private buildTaskForm(): void {
    if (!this.focusedTask) return;
    const formControls: { [key: string]: unknown } = {};
    formControls['taskName'] = [this.focusedTask.taskName, Validators.required];
    this.taskForm = this.fb.group(formControls);
  }

  private prepareBasicTaskDetails(): void {
    if (!this.focusedTask?.task) return;

    const details: Record<string, unknown> = {
      name: this.focusedTask.task.name,
      description: this.focusedTask.task.description || '-',
      vendorName: this.focusedTask.task.vendorName || '-',
      version: this.focusedTask.task.version,
    };
    const columns: ColumnDef[] = [
      { key: 'name', header: 'taskFlow.common.fields.name' },
      {
        key: 'description',
        header: 'taskFlow.createWorkflow.editor.description',
      },
      { key: 'vendorName', header: 'taskFlow.tasks.fields.vendor' },
      { key: 'version', header: 'taskFlow.common.fields.version' },
    ];

    if (Number.isFinite(this.focusedTask.order) && this.focusedTask.order > 0) {
      details['order'] = this.focusedTask.order;
      columns.push({
        key: 'order',
        header: 'taskFlow.createWorkflow.editor.order',
      });
    }

    this.basicTaskDetails.set(details);
    this.basicTaskDetailsColumns.set(columns);
  }

  workflowDetails(): Record<string, unknown> {
    const lifecycleState = String(
      this.currentWorkflow?.lifecycleState ?? ''
    ).trim();
    const distributionStatus = String(
      this.currentWorkflow?.distributionStatus ?? ''
    ).trim();

    return {
      name: this.currentWorkflow?.name || '-',
      description: this.currentWorkflow?.description || '-',
      version: this.currentWorkflow?.version || '-',
      lifecycleState: lifecycleState
        ? this.translateWithFallback(
            `taskFlow.common.states.${lifecycleState}`,
            lifecycleState
          )
        : '-',
      distributionStatus: distributionStatus
        ? this.translateWithFallback(
            `taskFlow.workflow.distributionStates.${distributionStatus}`,
            distributionStatus
          )
        : '-',
    };
  }

  private translateWithFallback(key: string, fallback: string): string {
    const translated = this.translate.instant(key);
    return translated === key ? fallback : translated;
  }

  loadProperties(): void {
    if (!this.focusedTask) {
      return;
    }

    if (this.focusedTask?.task && this.basicTaskDetailsColumns().length === 0) {
      this.prepareBasicTaskDetails();
    }

    this.isLoadingProperties.set(true);
    this.propertiesLoadError.set(false);
    this.taskInputs.set([]);
    this.propertyDetails.set({});
    this.propertyDetailColumns.set([]);

    const taskResourceId = String(this.focusedTask.task?.uniqueId ?? '').trim();
    if (!taskResourceId) {
      this.isLoadingProperties.set(false);
      this.propertiesLoadError.set(true);
      return;
    }

    const cachedResource = this.taskResourceCache.get(taskResourceId);
    if (cachedResource) {
      this.applyTaskResource(cachedResource);
      return;
    }

    this.taskFlowSharedService
      .getResourceById(taskResourceId, true)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (resource: Resource) => {
          this.taskResourceCache.set(taskResourceId, resource);
          this.applyTaskResource(resource);
        },
        error: () => {
          this.isLoadingProperties.set(false);
          this.propertiesLoadError.set(true);
          this.taskInputs.set([]);
        },
      });
  }

  private applyTaskResource(resource: Resource): void {
    this.basicTaskDetails.update(details => ({
      ...details,
      description:
        this.inputDefinitionService.normalizeValue(
          resource?.description,
          '-'
        ) || '-',
      vendorName:
        this.inputDefinitionService.normalizeValue(resource?.vendorName, '-') ||
        '-',
    }));

    const inputs = Array.isArray(resource?.inputs)
      ? (resource?.inputs as Array<InputDefinition>)
      : [];

    const processedInputs: Array<InputDefinition> = [];
    const details: Record<string, unknown> = {};
    const columns: ColumnDef[] = [];

    inputs
      .filter(input => !!input && !input?.hidden)
      .forEach(input => {
        const isInventoryFilterInput =
          this.inputDefinitionService.isInventoryFilterListInput(input) ||
          this.inputDefinitionService.isInventoryFilterPatternInput(input);
        const sourceValue = input?.value ?? input?.defaultValue;
        const isSpecialList =
          isInventoryFilterInput ||
          this.inputDefinitionService.isRanTemplateNameListInput(input);

        const displayValue = isSpecialList
          ? this.inputDefinitionService.parseListValues(sourceValue).join(', ')
          : this.inputDefinitionService.normalizeValue(sourceValue, '-');

        processedInputs.push({
          ...input,
          value: displayValue || '-',
        });

        const inputName = String(input?.name ?? '').trim();
        if (inputName) {
          details[inputName] = displayValue || '-';
          columns.push({
            key: inputName,
            header: this.inputDefinitionService.toDisplayLabel(inputName),
          });
        }
      });

    this.taskInputs.set(processedInputs);
    this.propertyDetails.set(details);
    this.propertyDetailColumns.set(columns);
    this.isLoadingProperties.set(false);
  }
}
