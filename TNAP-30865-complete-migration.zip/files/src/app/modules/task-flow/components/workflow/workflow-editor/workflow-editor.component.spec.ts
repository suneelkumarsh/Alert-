/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap, Router } from '@angular/router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { of, throwError } from 'rxjs';
import { PaneStateManagerService } from '../../../services/shared/pane-state-manager.service';
import { TaskFlowSharedService } from '../../../services/shared/task-flow-shared.service';
import { TasksService } from '../../../services/task/tasks.service';
import { WorkflowService } from '../../../services/workflow/workflow.service';
import { WorkflowEditorComponent } from './workflow-editor.component';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';
import { UpgradeWorkflowsModalLauncherService } from '../../../services/shared/upgrade-workflows-modal-launcher.service';

describe('WorkflowEditorComponent', () => {
  let component: WorkflowEditorComponent;
  let fixture: ComponentFixture<WorkflowEditorComponent>;
  let workflowService: jasmine.SpyObj<WorkflowService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let translateService: jasmine.SpyObj<TranslateService>;
  let taskFlowSharedService: jasmine.SpyObj<TaskFlowSharedService>;

  beforeEach(async () => {
    const routeStub = {
      snapshot: {
        paramMap: {
          get: () => null,
        },
      },
      paramMap: of(convertToParamMap({})),
    };

    const workflowServiceSpy = jasmine.createSpyObj('WorkflowService', [
      'getWorkflowById',
      'getWorkflowTaskInstances',
      'addTaskToWorkflow',
      'deleteTaskFromWorkflow',
      'certifyAndDistributeWorkflow',
      'executeWorkflowDirect',
      'executeWorkflowDistributed',
      'changeWorkflowState',
    ]);
    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);
    const alertServiceSpy = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
    ]);
    const translateServiceSpy = jasmine.createSpyObj(
      'TranslateService',
      ['instant', 'get'],
      {
        onTranslationChange: of({}),
        onLangChange: of({}),
        onDefaultLangChange: of({}),
      }
    );
    const stateManagerSpy = jasmine.createSpyObj('PaneStateManagerService', [
      'getPersistedPaneWidth',
      'persistPaneWidth',
    ]);
    const modalServiceSpy = jasmine.createSpyObj('NgbModal', ['open']);
    const tasksServiceSpy = jasmine.createSpyObj('TasksService', [
      'saveInputs',
      'certifyResource',
    ]);
    const taskFlowSharedServiceSpy = jasmine.createSpyObj(
      'TaskFlowSharedService',
      ['navigateToWorkflowEdit']
    );

    await TestBed.configureTestingModule({
      declarations: [WorkflowEditorComponent],
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: ActivatedRoute, useValue: routeStub },
        { provide: WorkflowService, useValue: workflowServiceSpy },
        { provide: Router, useValue: routerSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
        { provide: PaneStateManagerService, useValue: stateManagerSpy },
        { provide: NgbModal, useValue: modalServiceSpy },
        { provide: TasksService, useValue: tasksServiceSpy },
        {
          provide: TaskFlowSharedService,
          useValue: taskFlowSharedServiceSpy,
        },
        {
          provide: UpgradeWorkflowsModalLauncherService,
          useValue: jasmine.createSpyObj(
            'UpgradeWorkflowsModalLauncherService',
            ['open']
          ),
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    })
      .overrideTemplate(WorkflowEditorComponent, '')
      .compileComponents();

    fixture = TestBed.createComponent(WorkflowEditorComponent);
    component = fixture.componentInstance;
    workflowService = TestBed.inject(
      WorkflowService
    ) as jasmine.SpyObj<WorkflowService>;
    alertService = TestBed.inject(
      TnapAlertService
    ) as jasmine.SpyObj<TnapAlertService>;
    translateService = TestBed.inject(
      TranslateService
    ) as jasmine.SpyObj<TranslateService>;
    taskFlowSharedService = TestBed.inject(
      TaskFlowSharedService
    ) as jasmine.SpyObj<TaskFlowSharedService>;

    translateService.instant.and.callFake((key: string) => key);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should resolve mode to VIEW when no workflow is loaded', () => {
    component.currentWorkflow.set(null);

    expect(component.mode()).toBe('VIEW');
  });

  it('should resolve mode to EDIT when workflow is checked out', () => {
    component.currentWorkflow.set({
      lifecycleState: 'NOT_CERTIFIED_CHECKOUT',
    } as any);

    expect(component.mode()).toBe('EDIT');
  });

  it('should resolve mode to VIEW when workflow is certified', () => {
    component.currentWorkflow.set({
      lifecycleState: 'CERTIFIED',
    } as any);

    expect(component.mode()).toBe('VIEW');
  });

  it('should resolve mode to VIEW when workflow is checked in (not checked out by current session)', () => {
    component.currentWorkflow.set({
      lifecycleState: 'NOT_CERTIFIED_CHECKIN',
    } as any);

    expect(component.mode()).toBe('VIEW');
  });

  it('should not add tasks when not in EDIT mode', () => {
    component.workflowId.set('workflow-1');
    component.currentWorkflow.set({
      lifecycleState: 'CERTIFIED',
    } as any);

    component.onAddTask([{ uniqueId: 'task-1' } as any]);

    expect(workflowService.addTaskToWorkflow).not.toHaveBeenCalled();
  });

  describe('onCheckout', () => {
    it('should do nothing when workflowId is not set', () => {
      component.onCheckout();

      expect(workflowService.changeWorkflowState).not.toHaveBeenCalled();
    });

    it('should checkout the workflow and navigate to the new revision', () => {
      component.workflowId.set('workflow-1');
      workflowService.changeWorkflowState.and.returnValue(
        of({ uniqueId: 'workflow-2' } as any)
      );

      component.onCheckout();

      expect(workflowService.changeWorkflowState).toHaveBeenCalledWith(
        'workflow-1',
        'CHECKOUT',
        'Checked out from task-flow workflow canvas'
      );
      expect(alertService.success).toHaveBeenCalled();
      expect(taskFlowSharedService.navigateToWorkflowEdit).toHaveBeenCalledWith(
        'workflow-2'
      );
    });

    it('should show an error notification when checkout fails', () => {
      component.workflowId.set('workflow-1');
      workflowService.changeWorkflowState.and.returnValue(
        throwError(() => new Error('checkout failed'))
      );

      component.onCheckout();

      expect(alertService.error).toHaveBeenCalledWith(
        'taskFlow.createWorkflow.notifications.checkoutError',
        { keepAfterRouteChange: false }
      );
    });
  });

  it('should enable certify only when workflow is not certified and tasks exist', () => {
    component.currentWorkflow.set({
      lifecycleState: 'NOT_CERTIFIED_CHECKIN',
    } as any);
    component.workflowTasks.set([
      {
        instanceId: 'i-1',
        taskName: 'Task One',
        order: 1,
        properties: {},
        task: { uniqueId: 'resource-1' },
      } as any,
    ]);

    component.checkIfCanCertify();
    expect(component.canCertify()).toBeTrue();

    component.workflowTasks.set([]);
    component.checkIfCanCertify();
    expect(component.canCertify()).toBeFalse();
  });

  it('should enable execute only when workflow is certified', () => {
    component.currentWorkflow.set(null);

    component.checkIfCanExecute();
    expect(component.canExecute()).toBeFalse();

    component.currentWorkflow.set({
      lifecycleState: 'CERTIFIED',
    } as any);

    component.checkIfCanExecute();
    expect(component.canExecute()).toBeTrue();

    component.currentWorkflow.set({
      lifecycleState: 'NOT_CERTIFIED_CHECKIN',
    } as any);

    component.checkIfCanExecute();
    expect(component.canExecute()).toBeFalse();
  });

  it('should not call certify API when workflow has no tasks', () => {
    component.workflowId.set('workflow-1');
    component.workflowTasks.set([]);

    component.onCertifyAndDistribute();

    expect(workflowService.certifyAndDistributeWorkflow).not.toHaveBeenCalled();
  });

  it('should certify and distribute workflow and navigate on success', () => {
    component.workflowId.set('workflow-1');
    component.workflowTasks.set([
      {
        instanceId: 'i-1',
        taskName: 'Task One',
        order: 1,
        properties: {},
        task: { uniqueId: 'resource-1' },
      } as any,
    ]);
    component.currentWorkflow.set({
      lifecycleState: 'NOT_CERTIFIED_CHECKIN',
      distributionStatus: 'DISTRIBUTION_NOT_APPROVED',
    } as any);

    workflowService.certifyAndDistributeWorkflow.and.returnValue(
      of({
        uniqueId: 'workflow-new',
        lifecycleState: 'CERTIFIED',
        distributionStatus: 'DISTRIBUTED',
      } as any)
    );

    component.onCertifyAndDistribute();

    expect(workflowService.certifyAndDistributeWorkflow).toHaveBeenCalledWith(
      'workflow-1',
      'Certified and distributed from task-flow workflow canvas'
    );
    expect(alertService.success).toHaveBeenCalled();
    expect(taskFlowSharedService.navigateToWorkflowEdit).toHaveBeenCalledWith(
      'workflow-new'
    );
  });

  it('should show error when certify and distribute fails', () => {
    component.workflowId.set('workflow-1');
    component.workflowTasks.set([
      {
        instanceId: 'i-1',
        taskName: 'Task One',
        order: 1,
        properties: {},
        task: { uniqueId: 'resource-1' },
      } as any,
    ]);

    workflowService.certifyAndDistributeWorkflow.and.returnValue(
      throwError(() => new Error('certify failed'))
    );

    component.onCertifyAndDistribute();

    expect(component.isCertifying).toBeFalse();
    expect(alertService.error).toHaveBeenCalledWith(
      'taskFlow.createWorkflow.notifications.certifyError',
      { keepAfterRouteChange: false }
    );
  });

  it('should show drop parse error from workflow canvas', () => {
    component.onTaskDropError('Failed to parse dropped task');

    expect(translateService.instant).toHaveBeenCalledWith(
      'taskFlow.createWorkflow.notifications.dropParseError',
      { details: ': Failed to parse dropped task' }
    );
    expect(alertService.error).toHaveBeenCalledWith(
      'taskFlow.createWorkflow.notifications.dropParseError',
      { keepAfterRouteChange: false }
    );
  });

  it('should recheck certify and clear focus when removed task is focused', () => {
    component.workflowId.set('workflow-1');
    component.workflowTasks.set([
      {
        instanceId: 'i-1',
        taskName: 'Task One',
        order: 1,
        properties: {},
        task: { uniqueId: 'resource-1' },
      } as any,
      {
        instanceId: 'i-2',
        taskName: 'Task Two',
        order: 2,
        properties: {},
        task: { uniqueId: 'resource-2' },
      } as any,
    ]);
    component.focusedTask.set(component.workflowTasks()[0]);
    spyOn(component, 'checkIfCanCertify');
    workflowService.deleteTaskFromWorkflow.and.returnValue(of({} as any));

    component.onTaskRemoved('i-1');

    expect(workflowService.deleteTaskFromWorkflow).toHaveBeenCalledWith(
      'workflow-1',
      'i-1'
    );
    expect(component.checkIfCanCertify).toHaveBeenCalled();
    expect(component.workflowTasks().length).toBe(1);
    expect(component.workflowTasks()[0].instanceId).toBe('i-2');
    expect(component.workflowTasks()[0].order).toBe(1);
    expect(component.focusedTask()).toBeNull();
  });

  it('should not clear focus when task removal fails', () => {
    component.workflowId.set('workflow-1');
    const focusedTask = {
      instanceId: 'i-1',
      taskName: 'Task One',
      order: 1,
      properties: {},
      task: { uniqueId: 'resource-1' },
    } as any;
    component.workflowTasks.set([focusedTask]);
    component.focusedTask.set(focusedTask);
    spyOn(component, 'checkIfCanCertify');
    workflowService.deleteTaskFromWorkflow.and.returnValue(
      throwError(() => new Error('delete failed'))
    );

    component.onTaskRemoved('i-1');

    expect(component.checkIfCanCertify).not.toHaveBeenCalled();
    expect(component.focusedTask()?.instanceId).toBe('i-1');
  });

  it('should show palette task in property pane when exactly one palette task is selected', () => {
    const paletteTask = {
      uniqueId: 'resource-1',
      name: 'Palette Task',
      description: 'Palette Description',
      version: '1.0',
      type: 'RANTemplateExecutionTask',
      vendorName: 'Vendor',
      lifecycleState: 'CERTIFIED',
    } as any;

    component.onPaletteSelectionChanged([paletteTask]);

    expect(component.paletteSelectionCount()).toBe(1);
    expect(component.propertyPaneTask()?.task.uniqueId).toBe('resource-1');
    expect(component.propertyPaneTask()?.instanceId).toBe('palette-resource-1');
  });

  it('should show last selected palette task when multiple palette tasks are selected', () => {
    component.focusedTask.set({
      instanceId: 'i-1',
      taskName: 'Canvas Task',
      order: 1,
      properties: {},
      task: { uniqueId: 'resource-1' },
    } as any);

    component.onPaletteSelectionChanged([
      {
        uniqueId: 'resource-1',
        name: 'Palette Task One',
      },
      {
        uniqueId: 'resource-2',
        name: 'Palette Task Two',
      },
    ] as any);

    expect(component.paletteSelectionCount()).toBe(2);
    expect(component.propertyPaneTask()?.task.uniqueId).toBe('resource-2');
    expect(component.propertyPaneTask()?.task.name).toBe('Palette Task Two');
  });

  it('should fall back to canvas focused task when palette selection is cleared', () => {
    const focusedTask = {
      instanceId: 'i-1',
      taskName: 'Canvas Task',
      order: 1,
      properties: {},
      task: { uniqueId: 'resource-1' },
    } as any;
    component.focusedTask.set(focusedTask);
    component.onPaletteSelectionChanged([
      {
        uniqueId: 'resource-2',
        name: 'Palette Task',
      } as any,
    ]);

    component.onPaletteSelectionChanged([]);

    expect(component.paletteSelectionCount()).toBe(0);
    expect(component.propertyPaneTask()).toBe(focusedTask);
  });

  describe('onExecute (Execute with fallback)', () => {
    beforeEach(() => {
      component.currentWorkflow.set({
        uuid: 'uuid-1',
        uniqueId: 'unique-id-1',
        lifecycleState: 'CERTIFIED',
      } as any);
      workflowService.executeWorkflowDirect = jasmine
        .createSpy('executeWorkflowDirect')
        .and.returnValue(of({}));
      workflowService.executeWorkflowDistributed = jasmine
        .createSpy('executeWorkflowDistributed')
        .and.returnValue(of({}));
    });

    it('should do nothing when direct workflow id is not set', () => {
      component.currentWorkflow.set({
        ...component.currentWorkflow(),
        uniqueId: '',
      } as any);

      component.onExecute();

      expect(workflowService.executeWorkflowDirect).not.toHaveBeenCalled();
      expect(workflowService.executeWorkflowDistributed).not.toHaveBeenCalled();
    });

    it('should do nothing when distributed workflow id is not set', () => {
      component.currentWorkflow.set({
        ...component.currentWorkflow(),
        uuid: '',
      } as any);

      component.onExecute();

      expect(workflowService.executeWorkflowDirect).not.toHaveBeenCalled();
      expect(workflowService.executeWorkflowDistributed).not.toHaveBeenCalled();
    });

    it('should do nothing when already executing', () => {
      component.isExecuting.set(true);

      component.onExecute();

      expect(workflowService.executeWorkflowDirect).not.toHaveBeenCalled();
      expect(workflowService.executeWorkflowDistributed).not.toHaveBeenCalled();
    });

    it('should call executeWorkflowDirect first', () => {
      component.onExecute();

      expect(workflowService.executeWorkflowDirect).toHaveBeenCalledWith(
        'unique-id-1'
      );
      expect(workflowService.executeWorkflowDistributed).not.toHaveBeenCalled();
    });

    it('should fall back to executeWorkflowDistributed when direct execution fails', () => {
      workflowService.executeWorkflowDirect.and.returnValue(
        throwError(() => new Error('fail'))
      );

      component.onExecute();

      expect(workflowService.executeWorkflowDistributed).toHaveBeenCalledWith(
        'uuid-1'
      );
    });

    it('should show success notification on successful execution', () => {
      component.onExecute();

      expect(alertService.success).toHaveBeenCalledWith(
        'taskFlow.createWorkflow.notifications.executeSuccess',
        { keepAfterRouteChange: false }
      );
      expect(component.isExecuting()).toBeFalse();
    });

    it('should show error notification when direct and distributed execution fail', () => {
      workflowService.executeWorkflowDirect.and.returnValue(
        throwError(() => new Error('fail'))
      );
      workflowService.executeWorkflowDistributed.and.returnValue(
        throwError(() => new Error('fail'))
      );

      component.onExecute();

      expect(alertService.error).toHaveBeenCalledWith(
        'taskFlow.createWorkflow.notifications.executeError',
        { keepAfterRouteChange: false }
      );
      expect(component.isExecuting()).toBeFalse();
    });
  });
});
