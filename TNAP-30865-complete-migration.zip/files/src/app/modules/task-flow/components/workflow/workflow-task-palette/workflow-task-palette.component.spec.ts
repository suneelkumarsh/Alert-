/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { of, throwError } from 'rxjs';
import { TaskFlowSharedService } from '../../../services/shared/task-flow-shared.service';
import { ModalConfirmationService } from 'src/app/services/common-functionalities/modal-confirmation.service';
import { WorkflowTaskPaletteComponent } from './workflow-task-palette.component';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('WorkflowTaskPaletteComponent', () => {
  let component: WorkflowTaskPaletteComponent;
  let fixture: ComponentFixture<WorkflowTaskPaletteComponent>;
  let taskFlowSharedService: jasmine.SpyObj<TaskFlowSharedService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;

  beforeEach(async () => {
    const sharedServiceSpy = jasmine.createSpyObj('TaskFlowSharedService', [
      'loadTasks',
    ]);
    const modalServiceSpy = jasmine.createSpyObj('ModalConfirmationService', [
      'openConfirmationModal',
    ]);
    const alertServiceSpy = jasmine.createSpyObj('TnapAlertService', ['error']);
    modalServiceSpy.openConfirmationModal.and.returnValue(of(true));

    await TestBed.configureTestingModule({
      declarations: [WorkflowTaskPaletteComponent],
      imports: [TranslateModule.forRoot()],
      providers: [
        { provide: TaskFlowSharedService, useValue: sharedServiceSpy },
        { provide: ModalConfirmationService, useValue: modalServiceSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(WorkflowTaskPaletteComponent);
    component = fixture.componentInstance;
    taskFlowSharedService = TestBed.inject(
      TaskFlowSharedService
    ) as jasmine.SpyObj<TaskFlowSharedService>;
    alertService = TestBed.inject(
      TnapAlertService
    ) as jasmine.SpyObj<TnapAlertService>;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load tasks once when loadTaskList changes to true', () => {
    taskFlowSharedService.loadTasks.and.returnValue(
      of([
        { uniqueId: '1', name: 'Task One', lifecycleState: 'CERTIFIED' },
        {
          uniqueId: '2',
          name: 'Task Two',
          lifecycleState: 'NOT_CERTIFIED_CHECKIN',
        },
      ] as any)
    );

    fixture.componentRef.setInput('loadTaskList', true);
    fixture.detectChanges();

    expect(taskFlowSharedService.loadTasks).toHaveBeenCalledTimes(1);
    expect(component.tasks().length).toBe(1);
    expect(component.tasks()[0].uniqueId).toBe('1');

    fixture.componentRef.setInput('loadTaskList', true);
    fixture.detectChanges();

    expect(taskFlowSharedService.loadTasks).toHaveBeenCalledTimes(1);
  });

  it('should clear loading state and show an alert when loadTasks fails', () => {
    taskFlowSharedService.loadTasks.and.returnValue(
      throwError(() => new Error('load failed'))
    );

    fixture.componentRef.setInput('loadTaskList', true);
    fixture.detectChanges();

    expect(component.isFetchingTask()).toBeFalse();
    expect(component.tasks()).toEqual([]);
    expect(alertService.error).toHaveBeenCalledWith(
      'taskFlow.createWorkflow.palette.loadTasksError',
      { keepAfterRouteChange: true }
    );
  });

  it('should toggle task selection when not readonly', () => {
    const task = { uniqueId: 'task-1', name: 'Task One' } as any;
    component.tasks.set([task]);
    spyOn(component.selectionChanged, 'emit');

    component.selectTask(task);
    expect(component.isSelected(task)).toBeTrue();
    expect(component.selectionChanged.emit).toHaveBeenCalledWith([task]);

    component.selectTask(task);
    expect(component.isSelected(task)).toBeFalse();
    expect(component.selectionChanged.emit).toHaveBeenCalledWith([]);
  });

  it('should clear selection when clicking outside the palette', () => {
    component.tasks.set([
      { uniqueId: 'task-1', name: 'Task One' },
      { uniqueId: 'task-2', name: 'Task Two' },
    ] as any);
    component.selectedTaskIds.set(new Set(['task-1', 'task-2']));
    spyOn(component.selectionChanged, 'emit');

    component.onDocumentClick({
      target: document.createElement('div'),
    } as unknown as MouseEvent);

    expect(component.selectedTaskIds().size).toBe(0);
    expect(component.selectionChanged.emit).toHaveBeenCalledWith([]);
  });

  it('should keep selection when clicking inside the palette host', () => {
    component.selectedTaskIds.set(new Set(['task-1']));

    component.onDocumentClick({
      target: fixture.nativeElement,
    } as unknown as MouseEvent);

    expect(component.selectedTaskIds().size).toBe(1);
  });

  it('should keep selection when clicking inside the property editor', () => {
    component.selectedTaskIds.set(new Set(['task-1']));
    const propertyEditor = document.createElement(
      'app-workflow-property-editor'
    );
    const propertyContent = document.createElement('div');
    propertyEditor.appendChild(propertyContent);

    component.onDocumentClick({
      target: propertyContent,
    } as unknown as MouseEvent);

    expect(component.selectedTaskIds().size).toBe(1);
  });

  it('should emit selected tasks on add and clear selection', () => {
    spyOn(component.addTask, 'emit');
    spyOn(component.selectionChanged, 'emit');
    component.tasks.set([
      { uniqueId: 'task-1', name: 'Task One' },
      { uniqueId: 'task-2', name: 'Task Two' },
    ] as any);
    component.selectedTaskIds.set(new Set(['task-1', 'task-2']));

    component.onAddTask();

    expect(component.addTask.emit).toHaveBeenCalledWith([
      { uniqueId: 'task-1', name: 'Task One' },
      { uniqueId: 'task-2', name: 'Task Two' },
    ] as any);
    expect(component.selectedTaskIds().size).toBe(0);
    expect(component.selectionChanged.emit).toHaveBeenCalledWith([]);
  });

  it('should emit direct add task when not readonly', () => {
    spyOn(component.addTask, 'emit');
    const task = { uniqueId: 'task-1', name: 'Task One' } as any;
    const event = {
      stopPropagation: jasmine.createSpy('stopPropagation'),
    } as any;

    component.onAddTaskDirect(task, event);

    expect(event.stopPropagation).toHaveBeenCalled();
    expect(component.addTask.emit).toHaveBeenCalledWith([task]);
  });

  it('should set drag data and clear selection on drag end', () => {
    component.tasks.set([
      { uniqueId: 'task-1', name: 'Task One' },
      { uniqueId: 'task-2', name: 'Task Two' },
    ] as any);
    component.selectedTaskIds.set(new Set(['task-1']));
    spyOn(component.selectionChanged, 'emit');

    const setData = jasmine.createSpy('setData');
    const setDragImage = jasmine.createSpy('setDragImage');
    const event = {
      dataTransfer: {
        effectAllowed: '',
        setData,
        setDragImage,
      },
    } as any;

    component.onDragStart(event, component.tasks()[0] as any);

    expect(setData).toHaveBeenCalled();
    expect(setDragImage).toHaveBeenCalled();

    component.onDragEnd();

    expect(component.selectedTaskIds().size).toBe(0);
    expect(component.selectionChanged.emit).toHaveBeenCalledWith([]);
  });

  it('should emit all selected tasks when multiple palette tasks are selected', () => {
    const taskOne = { uniqueId: 'task-1', name: 'Task One' } as any;
    const taskTwo = { uniqueId: 'task-2', name: 'Task Two' } as any;
    component.tasks.set([taskOne, taskTwo]);
    spyOn(component.selectionChanged, 'emit');

    component.selectTask(taskOne);
    component.selectTask(taskTwo);

    expect(component.selectionChanged.emit).toHaveBeenCalledWith([
      taskOne,
      taskTwo,
    ]);
  });

  it('should emit selected tasks in selection order for multi-select', () => {
    const taskOne = { uniqueId: 'task-1', name: 'Task One' } as any;
    const taskTwo = { uniqueId: 'task-2', name: 'Task Two' } as any;
    component.tasks.set([taskOne, taskTwo]);
    spyOn(component.selectionChanged, 'emit');

    component.selectTask(taskTwo);
    component.selectTask(taskOne);

    expect(component.selectionChanged.emit).toHaveBeenCalledWith([
      taskTwo,
      taskOne,
    ]);
  });
});
