/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { NgSelectModule } from '@ng-select/ng-select';
import moment from 'moment';
import { of, throwError } from 'rxjs';
import { SdcComponentType } from 'openapi/output';

import { WorkflowSchedulePanelComponent } from './workflow-schedule-panel.component';
import { TaskFlowSharedService } from '../../../services/shared/task-flow-shared.service';
import { ModalConfirmationService } from 'src/app/services/common-functionalities/modal-confirmation.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('WorkflowSchedulePanelComponent', () => {
  let component: WorkflowSchedulePanelComponent;
  let fixture: ComponentFixture<WorkflowSchedulePanelComponent>;
  let taskFlowSharedService: jasmine.SpyObj<TaskFlowSharedService>;
  let modalConfirmationService: jasmine.SpyObj<ModalConfirmationService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;

  const makeWorkflow = (inputs: unknown[] = []) => ({
    uniqueId: 'wf-1',
    name: 'Test Workflow',
    inputs,
  });

  beforeEach(async () => {
    const sharedSpy = jasmine.createSpyObj('TaskFlowSharedService', [
      'updateComponentInputs',
    ]);
    sharedSpy.updateComponentInputs.and.returnValue(of([]));

    const modalSpy = jasmine.createSpyObj('ModalConfirmationService', [
      'openConfirmationModal',
    ]);
    modalSpy.openConfirmationModal.and.returnValue(of(true));

    const alertSpy = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
    ]);

    await TestBed.configureTestingModule({
      declarations: [WorkflowSchedulePanelComponent],
      imports: [ReactiveFormsModule, TranslateModule.forRoot(), NgSelectModule],
      providers: [
        { provide: TaskFlowSharedService, useValue: sharedSpy },
        { provide: ModalConfirmationService, useValue: modalSpy },
        { provide: TnapAlertService, useValue: alertSpy },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(WorkflowSchedulePanelComponent);
    component = fixture.componentInstance;
    taskFlowSharedService = TestBed.inject(
      TaskFlowSharedService
    ) as jasmine.SpyObj<TaskFlowSharedService>;
    modalConfirmationService = TestBed.inject(
      ModalConfirmationService
    ) as jasmine.SpyObj<ModalConfirmationService>;
    alertService = TestBed.inject(
      TnapAlertService
    ) as jasmine.SpyObj<TnapAlertService>;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('initial state', () => {
    it('defaults scheduleType to oneTime', () => {
      expect(component.scheduleType()).toBe('oneTime');
    });

    it('isOneTimeSchedule() is true initially', () => {
      expect(component.isOneTimeSchedule()).toBeTrue();
    });

    it('isDailySchedule() is false initially', () => {
      expect(component.isDailySchedule()).toBeFalse();
    });

    it('isWeeklySchedule() is false initially', () => {
      expect(component.isWeeklySchedule()).toBeFalse();
    });

    it('isEveryXHoursSchedule() is false initially', () => {
      expect(component.isEveryXHoursSchedule()).toBeFalse();
    });

    it('isEveryYDaysSchedule() is false initially', () => {
      expect(component.isEveryYDaysSchedule()).toBeFalse();
    });

    it('scheduleForm is valid by default (no required fields yet)', () => {
      // oneTime requires startDate and startTime, form is initially empty → invalid
      expect(component.scheduleForm.invalid).toBeTrue();
    });
  });

  describe('onScheduleTypeChange', () => {
    it('updates scheduleType signal', () => {
      component.onScheduleTypeChange('daily');
      expect(component.scheduleType()).toBe('daily');
    });

    it('resets form fields on type change', () => {
      component.scheduleForm.patchValue({
        startDate: '2026-01-01',
        startTime: '10:00',
      });
      component.onScheduleTypeChange('weekly');
      expect(component.scheduleForm.get('startDate')?.value).toBe('');
      expect(component.scheduleForm.get('startTime')?.value).toBe('');
    });

    it('sets isDailySchedule computed after changing to daily', () => {
      component.onScheduleTypeChange('daily');
      expect(component.isDailySchedule()).toBeTrue();
      expect(component.isOneTimeSchedule()).toBeFalse();
    });

    it('handles null/undefined by defaulting to oneTime', () => {
      component.onScheduleTypeChange(null);
      expect(component.scheduleType()).toBe('oneTime');
    });
  });

  describe('computed schedule type signals', () => {
    const types = [
      { type: 'oneTime', signal: 'isOneTimeSchedule' },
      { type: 'daily', signal: 'isDailySchedule' },
      { type: 'weekly', signal: 'isWeeklySchedule' },
      { type: 'everyXHours', signal: 'isEveryXHoursSchedule' },
      { type: 'everyYDays', signal: 'isEveryYDaysSchedule' },
    ] as const;

    for (const { type, signal } of types) {
      it(`${signal}() is true only when schedule type is ${type}`, () => {
        component.onScheduleTypeChange(type);
        expect(component[signal]()).toBeTrue();

        const others = types.filter(t => t.type !== type);
        for (const other of others) {
          expect(component[other.signal]()).toBeFalse();
        }
      });
    }
  });

  describe('form validators per schedule type', () => {
    it('oneTime: startDate and startTime are required', () => {
      component.onScheduleTypeChange('oneTime');
      component.scheduleForm.patchValue({
        startDate: '2026-01-01',
        startTime: '10:00',
      });
      expect(component.scheduleForm.get('startDate')?.valid).toBeTrue();
      expect(component.scheduleForm.get('startTime')?.valid).toBeTrue();

      component.scheduleForm.patchValue({ startDate: '', startTime: '' });
      expect(component.scheduleForm.get('startDate')?.invalid).toBeTrue();
      expect(component.scheduleForm.get('startTime')?.invalid).toBeTrue();
    });

    it('daily: only startTime is required', () => {
      component.onScheduleTypeChange('daily');
      component.scheduleForm.patchValue({ startTime: '08:00' });
      expect(component.scheduleForm.get('startTime')?.valid).toBeTrue();
      expect(component.scheduleForm.get('startDate')?.valid).toBeTrue();
    });

    it('weekly: startTime required and dayOfWeek must have at least one entry', () => {
      component.onScheduleTypeChange('weekly');
      expect(component.scheduleForm.invalid).toBeTrue();

      component.scheduleForm.patchValue({ startTime: '08:00', dayOfWeek: [1] });
      expect(component.scheduleForm.invalid).toBeFalse();
    });

    it('weekly: startDate is optional', () => {
      component.onScheduleTypeChange('weekly');
      component.scheduleForm.patchValue({
        startDate: '',
        startTime: '08:00',
        dayOfWeek: [1],
      });
      expect(component.scheduleForm.get('startDate')?.valid).toBeTrue();
    });

    it('weekly: dayOfWeek with empty array is invalid', () => {
      component.onScheduleTypeChange('weekly');
      component.scheduleForm.patchValue({ startTime: '08:00', dayOfWeek: [] });
      expect(component.scheduleForm.get('dayOfWeek')?.invalid).toBeTrue();
    });

    it('everyXHours: startDate and intervalHours are required', () => {
      component.onScheduleTypeChange('everyXHours');
      component.scheduleForm.patchValue({
        startDate: '2026-01-01',
        intervalHours: 2,
      });
      expect(component.scheduleForm.get('startDate')?.valid).toBeTrue();
      expect(component.scheduleForm.get('intervalHours')?.valid).toBeTrue();
    });

    it('everyXHours: intervalHours below 1 is invalid', () => {
      component.onScheduleTypeChange('everyXHours');
      component.scheduleForm.patchValue({
        startDate: '2026-01-01',
        intervalHours: 0,
      });
      expect(component.scheduleForm.get('intervalHours')?.invalid).toBeTrue();
    });

    it('everyXHours: intervalHours above 23 is invalid', () => {
      component.onScheduleTypeChange('everyXHours');
      component.scheduleForm.patchValue({
        startDate: '2026-01-01',
        intervalHours: 24,
      });
      expect(component.scheduleForm.get('intervalHours')?.invalid).toBeTrue();
    });

    it('everyYDays: startDate and intervalDays are required', () => {
      component.onScheduleTypeChange('everyYDays');
      component.scheduleForm.patchValue({
        startDate: '2026-01-01',
        intervalDays: 3,
      });
      expect(component.scheduleForm.get('startDate')?.valid).toBeTrue();
      expect(component.scheduleForm.get('intervalDays')?.valid).toBeTrue();
    });
  });

  describe('onResetSchedule', () => {
    it('resets to oneTime defaults when no workflow is set', () => {
      component.onScheduleTypeChange('daily');
      component.onResetSchedule();
      expect(component.scheduleType()).toBe('oneTime');
    });
  });

  describe('onApplySchedule', () => {
    it('does not open modal when form is invalid', () => {
      component.onScheduleTypeChange('oneTime');
      // form is invalid (no startDate/startTime)
      component.onApplySchedule();
      expect(
        modalConfirmationService.openConfirmationModal
      ).not.toHaveBeenCalled();
    });

    it('weekly with no selected day shows validation alert and does not open modal', () => {
      component.onScheduleTypeChange('weekly');
      component.scheduleForm.patchValue({
        startTime: '08:00',
        dayOfWeek: [],
      });

      component.onApplySchedule();

      expect(alertService.error).toHaveBeenCalledWith(
        'taskFlow.createWorkflow.editor.schedule.fields.dayOfWeekRequired',
        { keepAfterRouteChange: true }
      );
      expect(component.scheduleForm.get('dayOfWeek')?.touched).toBeTrue();
      expect(
        modalConfirmationService.openConfirmationModal
      ).not.toHaveBeenCalled();
    });

    it('opens confirmation modal when form is valid', () => {
      component.onScheduleTypeChange('everyXHours');
      component.scheduleForm.patchValue({
        startDate: '2026-01-01',
        intervalHours: 3,
      });
      fixture.componentRef.setInput(
        'workflow',
        makeWorkflow([{ name: 'interval_schedule', defaultValue: '' }])
      );

      component.onApplySchedule();

      expect(
        modalConfirmationService.openConfirmationModal
      ).toHaveBeenCalledWith(
        'taskFlow.createWorkflow.editor.schedule.fields.applySchedule',
        'taskFlow.createWorkflow.editor.schedule.confirmApplyTitle',
        'taskFlow.createWorkflow.editor.schedule.confirmApplyText'
      );
    });

    it('calls updateComponentInputs after confirmation', () => {
      component.onScheduleTypeChange('everyXHours');
      component.scheduleForm.patchValue({
        startDate: '2026-01-01',
        intervalHours: 4,
      });
      fixture.componentRef.setInput(
        'workflow',
        makeWorkflow([{ name: 'interval_schedule', defaultValue: '' }])
      );

      component.onApplySchedule();

      expect(taskFlowSharedService.updateComponentInputs).toHaveBeenCalledWith(
        SdcComponentType.SERVICES,
        'wf-1',
        jasmine.anything()
      );
    });

    it('shows success alert after successful apply', () => {
      component.onScheduleTypeChange('everyXHours');
      component.scheduleForm.patchValue({
        startDate: '2026-01-01',
        intervalHours: 4,
      });
      fixture.componentRef.setInput(
        'workflow',
        makeWorkflow([{ name: 'interval_schedule', defaultValue: '' }])
      );

      component.onApplySchedule();

      expect(alertService.success).toHaveBeenCalledWith(
        'taskFlow.createWorkflow.editor.schedule.applyScheduleSuccess',
        { keepAfterRouteChange: true }
      );
    });

    it('shows error alert when updateComponentInputs fails', () => {
      taskFlowSharedService.updateComponentInputs.and.returnValue(
        throwError(() => new Error('network error'))
      );

      component.onScheduleTypeChange('everyXHours');
      component.scheduleForm.patchValue({
        startDate: '2026-01-01',
        intervalHours: 4,
      });
      fixture.componentRef.setInput(
        'workflow',
        makeWorkflow([{ name: 'interval_schedule', defaultValue: '' }])
      );

      component.onApplySchedule();

      expect(alertService.error).toHaveBeenCalledWith(
        'taskFlow.createWorkflow.editor.schedule.applyScheduleError',
        { keepAfterRouteChange: true }
      );
    });

    it('does not call updateComponentInputs when no schedule inputs exist', () => {
      component.onScheduleTypeChange('everyXHours');
      component.scheduleForm.patchValue({
        startDate: '2026-01-01',
        intervalHours: 4,
      });
      fixture.componentRef.setInput('workflow', makeWorkflow([])); // no schedule props

      component.onApplySchedule();

      expect(
        taskFlowSharedService.updateComponentInputs
      ).not.toHaveBeenCalled();
    });
  });

  describe('populateScheduleFormFromWorkflow via workflow input', () => {
    it('populates oneTime from execTime timestamp payload', () => {
      const payload = '2026-06-01T12:34:56.700Z';
      fixture.componentRef.setInput(
        'workflow',
        makeWorkflow([{ name: 'execTime', defaultValue: payload }])
      );
      fixture.detectChanges();

      expect(component.scheduleType()).toBe('oneTime');
      expect(component.scheduleForm.get('startDate')?.value).toBeTruthy();
      expect(component.scheduleForm.get('startTime')?.value).toBeTruthy();
      expect(component.scheduleForm.get('endDate')?.value).toBe('');
    });

    it('populates everyXHours from interval_schedule payload', () => {
      const payload = JSON.stringify({
        startDateTime: '2026-06-01T08:00:00.000Z',
        endDate: '2026-12-31',
        interval: 2 * 3600,
      });
      fixture.componentRef.setInput(
        'workflow',
        makeWorkflow([{ name: 'interval_schedule', defaultValue: payload }])
      );
      fixture.detectChanges();

      expect(component.scheduleType()).toBe('everyXHours');
      expect(component.scheduleForm.get('intervalHours')?.value).toBe(2);
      expect(component.scheduleForm.get('startDate')?.value).toBe('2026-06-01');
    });

    it('populates daily from calendar_schedule payload (no dayOfWeek)', () => {
      const payload = JSON.stringify({
        startDate: '2026-06-01',
        endDate: '2026-12-31',
        hour: [9],
        minute: [30],
      });
      fixture.componentRef.setInput(
        'workflow',
        makeWorkflow([{ name: 'calendar_schedule', defaultValue: payload }])
      );
      fixture.detectChanges();

      const expectedLocal = moment
        .utc('2026-06-01 09:30', 'YYYY-MM-DD HH:mm', true)
        .local();
      expect(component.scheduleType()).toBe('daily');
      expect(component.scheduleForm.get('startDate')?.value).toBe(
        expectedLocal.format('YYYY-MM-DD')
      );
      expect(component.scheduleForm.get('startTime')?.value).toBe(
        expectedLocal.format('HH:mm')
      );
    });

    it('populates weekly from calendar_schedule payload (with dayOfWeek)', () => {
      const payload = JSON.stringify({
        startDate: '2026-06-01',
        endDate: '2026-12-31',
        dayOfWeek: [1, 3],
        hour: [10],
        minute: [0],
      });
      fixture.componentRef.setInput(
        'workflow',
        makeWorkflow([{ name: 'calendar_schedule', defaultValue: payload }])
      );
      fixture.detectChanges();

      expect(component.scheduleType()).toBe('weekly');
      expect(component.scheduleForm.get('dayOfWeek')?.value).toEqual([1, 3]);
    });

    it('resets to oneTime defaults when workflow has no recognizable schedule', () => {
      fixture.componentRef.setInput('workflow', makeWorkflow([]));
      fixture.detectChanges();

      expect(component.scheduleType()).toBe('oneTime');
    });

    it('clears form when workflow input changes to null', () => {
      fixture.componentRef.setInput('workflow', null);
      fixture.detectChanges();

      expect(component.scheduleType()).toBe('oneTime');
      expect(component.scheduleForm.get('startDate')?.value).toBe('');
    });
  });

  describe('applySchedule — calendar schedule path', () => {
    it('for oneTime sends execTime timestamp and clears calendar/interval schedules', () => {
      const workflow = makeWorkflow([
        { name: 'execTime', defaultValue: '' },
        { name: 'calendar_schedule', defaultValue: '' },
        { name: 'interval_schedule', defaultValue: '' },
      ]);
      fixture.componentRef.setInput('workflow', workflow);
      fixture.detectChanges();

      component.onScheduleTypeChange('oneTime');
      component.scheduleForm.patchValue({
        startDate: '2026-06-01',
        startTime: '09:15',
        endDate: '2026-06-02',
      });

      component.onApplySchedule();

      const [, , inputs] =
        taskFlowSharedService.updateComponentInputs.calls.mostRecent().args;
      const execTimeInput = (inputs as any[]).find(
        (i: any) => i.name === 'execTime'
      );
      const calendarInput = (inputs as any[]).find(
        (i: any) => i.name === 'calendar_schedule'
      );
      const intervalInput = (inputs as any[]).find(
        (i: any) => i.name === 'interval_schedule'
      );

      expect(execTimeInput.defaultValue).toContain('2026-06-01T');
      expect(calendarInput.defaultValue).toBeUndefined();
      expect(intervalInput.defaultValue).toBeUndefined();
    });

    it('updates calendarProp and clears intervalProp defaultValue', () => {
      const calendarPayload = JSON.stringify({
        startDate: '2026-06-01',
        endDate: '2026-12-31',
        hour: [8],
        minute: [0],
      });
      const workflow = makeWorkflow([
        { name: 'interval_schedule', defaultValue: '' },
        { name: 'calendar_schedule', defaultValue: calendarPayload },
      ]);
      fixture.componentRef.setInput('workflow', workflow);
      fixture.detectChanges();

      expect(component.scheduleType()).toBe('daily');
      component.scheduleForm.patchValue({ startTime: '09:00' });

      component.onApplySchedule();

      const [, , inputs] =
        taskFlowSharedService.updateComponentInputs.calls.mostRecent().args;

      const calendarInput = (inputs as any[]).find(
        (i: any) => i.name === 'calendar_schedule'
      );
      expect(calendarInput).toBeDefined();
      expect(calendarInput.defaultValue).toBeTruthy();

      const intervalInput = (inputs as any[]).find(
        (i: any) => i.name === 'interval_schedule'
      );
      expect(intervalInput).toBeDefined();
      expect(intervalInput.defaultValue).toBeUndefined();
    });

    it('updates only calendarProp when intervalProp has no defaultValue', () => {
      const calendarPayload = JSON.stringify({
        startDate: '2026-06-01',
        endDate: '2026-12-31',
        hour: [8],
        minute: [0],
      });
      const workflow = makeWorkflow([
        { name: 'interval_schedule' },
        { name: 'calendar_schedule', defaultValue: calendarPayload },
      ]);
      fixture.componentRef.setInput('workflow', workflow);
      fixture.detectChanges();

      expect(component.scheduleType()).toBe('daily');
      component.scheduleForm.patchValue({ startTime: '09:00' });

      component.onApplySchedule();

      const [, , inputs] =
        taskFlowSharedService.updateComponentInputs.calls.mostRecent().args;

      expect((inputs as any[]).length).toBe(1);
      expect((inputs as any[])[0].name).toBe('calendar_schedule');
    });
  });

  describe('applySchedule — interval schedule path', () => {
    it('updates intervalProp and clears calendarProp defaultValue', () => {
      const workflow = makeWorkflow([
        {
          name: 'interval_schedule',
          defaultValue: JSON.stringify({
            startDateTime: '2026-06-01T08:00:00.000Z',
            endDate: '',
            interval: 3600,
          }),
        },
        { name: 'calendar_schedule', defaultValue: '' },
      ]);
      fixture.componentRef.setInput('workflow', workflow);
      fixture.detectChanges();

      expect(component.scheduleType()).toBe('everyXHours');
      component.scheduleForm.patchValue({
        startDate: '2026-06-01',
        intervalHours: 2,
      });

      component.onApplySchedule();

      const [, , inputs] =
        taskFlowSharedService.updateComponentInputs.calls.mostRecent().args;

      const intervalInput = (inputs as any[]).find(
        (i: any) => i.name === 'interval_schedule'
      );
      expect(intervalInput.defaultValue).toBeTruthy();

      const calendarInput = (inputs as any[]).find(
        (i: any) => i.name === 'calendar_schedule'
      );
      expect(calendarInput.defaultValue).toBeUndefined();
    });

    it('updates only intervalProp when calendarProp has no defaultValue', () => {
      const workflow = makeWorkflow([
        {
          name: 'interval_schedule',
          defaultValue: JSON.stringify({
            startDateTime: '2026-06-01T08:00:00.000Z',
            endDate: '',
            interval: 3600,
          }),
        },
        { name: 'calendar_schedule' },
      ]);
      fixture.componentRef.setInput('workflow', workflow);
      fixture.detectChanges();

      expect(component.scheduleType()).toBe('everyXHours');
      component.scheduleForm.patchValue({
        startDate: '2026-06-01',
        intervalHours: 2,
      });

      component.onApplySchedule();

      const [, , inputs] =
        taskFlowSharedService.updateComponentInputs.calls.mostRecent().args;

      expect((inputs as any[]).length).toBe(1);
      expect((inputs as any[])[0].name).toBe('interval_schedule');
    });
  });

  describe('scheduleTypeSelectOptions', () => {
    it('returns an option for each schedule type', () => {
      const options = component.scheduleTypeSelectOptions();
      const values = options.map(o => o.value);
      expect(values).toContain('oneTime');
      expect(values).toContain('daily');
      expect(values).toContain('weekly');
      expect(values).toContain('everyXHours');
      expect(values).toContain('everyYDays');
    });
  });

  describe('weekDaySelectOptions', () => {
    it('returns 7 day options', () => {
      expect(component.weekDaySelectOptions().length).toBe(7);
    });

    it('each option has a numeric value and a label', () => {
      for (const opt of component.weekDaySelectOptions()) {
        expect(typeof opt.value).toBe('number');
        expect(typeof opt.label).toBe('string');
      }
    });
  });
});
