/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  DestroyRef,
  computed,
  inject,
  input,
  signal,
} from '@angular/core';
import {
  takeUntilDestroyed,
  toObservable,
  toSignal,
} from '@angular/core/rxjs-interop';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  ValidationErrors,
  Validators,
} from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { InputDefinition, SdcComponentType, Service } from 'openapi/output';
import { SelectOption } from '@portal-mfe/tnap-ui-kit/components/select';
import { TaskFlowSharedService } from '../../../services/shared/task-flow-shared.service';
import { ModalConfirmationService } from 'src/app/services/common-functionalities/modal-confirmation.service';

import {
  buildCalendarSchedulePayload,
  buildIntervalSchedulePayload,
  extractScheduleProperties,
  getStartDateTime,
  inferCalendarScheduleForm,
  inferIntervalScheduleForm,
  inferOneTimeScheduleForm,
  isIntervalScheduleType,
  parseScheduleJson,
} from './workflow-schedule.utils';
import {
  CalendarSchedulePayload,
  IntervalSchedulePayload,
  SCHEDULE_TYPE_OPTIONS,
  ScheduleFormValue,
  WEEK_DAY_OPTIONS,
  WorkflowScheduleType,
} from '../../../models/workflow-schedule.models';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-workflow-schedule-panel',
  templateUrl: './workflow-schedule-panel.component.html',
  styleUrls: ['./workflow-schedule-panel.component.css'],
  standalone: false,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WorkflowSchedulePanelComponent {
  private readonly taskFlowSharedService = inject(TaskFlowSharedService);
  private readonly modalConfirmationService = inject(ModalConfirmationService);
  private readonly alertService = inject(TnapAlertService);
  private readonly translate = inject(TranslateService);
  private readonly fb = inject(FormBuilder);
  private readonly destroyRef = inject(DestroyRef);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly workflow = input<Service | null>(null);

  readonly scheduleForm: FormGroup;

  private readonly _scheduleType = signal<WorkflowScheduleType>('oneTime');

  readonly isEveryXHoursSchedule = computed(
    () => this._scheduleType() === 'everyXHours'
  );
  readonly isEveryYDaysSchedule = computed(
    () => this._scheduleType() === 'everyYDays'
  );
  readonly isWeeklySchedule = computed(() => this._scheduleType() === 'weekly');
  readonly isOneTimeSchedule = computed(
    () => this._scheduleType() === 'oneTime'
  );
  readonly isDailySchedule = computed(() => this._scheduleType() === 'daily');

  private readonly languageChange = toSignal(this.translate.onLangChange, {
    initialValue: null,
  });

  readonly scheduleTypeSelectOptions = computed<SelectOption<string>[]>(() => {
    this.languageChange();
    return SCHEDULE_TYPE_OPTIONS.map(option => ({
      value: option.value,
      label: this.translate.instant(option.label),
    }));
  });

  readonly weekDaySelectOptions = computed(() => {
    this.languageChange();
    return WEEK_DAY_OPTIONS.map(day => ({
      value: day.value,
      label: this.translate.instant(day.i18nKey),
    }));
  });

  constructor() {
    this.scheduleForm = this.fb.group({
      scheduleType: ['oneTime' as WorkflowScheduleType, Validators.required],
      startDate: [''],
      startTime: [''],
      intervalHours: [1],
      intervalDays: [1],
      endDate: [''],
      dayOfWeek: [[1] as number[]],
    });

    toObservable(this.workflow)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(workflow => this.populateScheduleFormFromWorkflow(workflow));
  }

  scheduleType(): WorkflowScheduleType {
    return this._scheduleType();
  }

  onScheduleTypeChange(value: string | null | undefined): void {
    const type = (value ?? 'oneTime') as WorkflowScheduleType;
    this._scheduleType.set(type);
    this.scheduleForm.patchValue({
      scheduleType: type,
      startDate: '',
      startTime: '',
      intervalHours: 1,
      intervalDays: 1,
      endDate: '',
      dayOfWeek: [1],
    });
    this.updateScheduleValidators();
    this.cdr.markForCheck();
  }

  onResetSchedule(): void {
    this.populateScheduleFormFromWorkflow(this.workflow());
  }

  onApplySchedule(): void {
    if (this.scheduleForm.invalid) {
      this.scheduleForm.markAllAsTouched();
      if (
        this._scheduleType() === 'weekly' &&
        this.scheduleForm.get('dayOfWeek')?.invalid
      ) {
        this.alertService.error(
          this.translate.instant(
            'taskFlow.createWorkflow.editor.schedule.fields.dayOfWeekRequired'
          ),
          { keepAfterRouteChange: true }
        );
      }
      return;
    }

    this.modalConfirmationService
      .openConfirmationModal(
        'taskFlow.createWorkflow.editor.schedule.fields.applySchedule',
        'taskFlow.createWorkflow.editor.schedule.confirmApplyTitle',
        'taskFlow.createWorkflow.editor.schedule.confirmApplyText'
      )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(confirmed => {
        if (confirmed) this.applySchedule();
      });
  }

  private applySchedule(): void {
    if (this.scheduleForm.invalid) return;

    const workflowId = this.workflow()?.uniqueId?.trim();
    if (!workflowId) return;

    const props = extractScheduleProperties(this.workflow()?.inputs);
    const execTimeProp = props.get('execTime');
    const intervalProp = props.get('interval_schedule');
    const calendarProp = props.get('calendar_schedule');

    if (!execTimeProp && !intervalProp && !calendarProp) return;

    const inputsToUpdate = this.getInputsToUpdate(
      execTimeProp,
      intervalProp,
      calendarProp
    );

    this.taskFlowSharedService
      .updateComponentInputs(
        SdcComponentType.SERVICES,
        workflowId,
        inputsToUpdate
      )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () =>
          this.alertService.success(
            this.translate.instant(
              'taskFlow.createWorkflow.editor.schedule.applyScheduleSuccess'
            ),
            { keepAfterRouteChange: true }
          ),
        error: () =>
          this.alertService.error(
            this.translate.instant(
              'taskFlow.createWorkflow.editor.schedule.applyScheduleError'
            ),
            { keepAfterRouteChange: true }
          ),
      });
  }

  private getInputsToUpdate(
    execTimeProp?: InputDefinition,
    intervalProp?: InputDefinition,
    calendarProp?: InputDefinition
  ): InputDefinition[] {
    const formValue = this.scheduleForm.value as ScheduleFormValue;

    if (formValue.scheduleType === 'oneTime') {
      const execTimestamp = getStartDateTime(formValue);
      const activeInput = this.updateInputDefaultValue(
        execTimeProp,
        execTimestamp
      );
      const inactiveCalendar = this.removeDefaultValue(calendarProp);
      const inactiveInterval = this.removeDefaultValue(intervalProp);

      return [activeInput, inactiveCalendar, inactiveInterval].filter(
        (input): input is InputDefinition => !!input
      );
    }

    const isInterval = isIntervalScheduleType(formValue.scheduleType);

    const activeInput = isInterval
      ? this.updateInputDefaultValue(
          intervalProp,
          JSON.stringify(buildIntervalSchedulePayload(formValue))
        )
      : this.updateInputDefaultValue(
          calendarProp,
          JSON.stringify(buildCalendarSchedulePayload(formValue))
        );

    const inactiveInput = isInterval
      ? this.removeDefaultValue(calendarProp)
      : this.removeDefaultValue(intervalProp);

    const clearedExecTime = this.removeDefaultValue(execTimeProp);

    return [activeInput, inactiveInput, clearedExecTime].filter(
      (input): input is InputDefinition => !!input
    );
  }

  private updateInputDefaultValue(
    input: InputDefinition | undefined,
    defaultValue: string
  ): InputDefinition | undefined {
    return input
      ? {
          ...input,
          defaultValue,
        }
      : undefined;
  }

  private removeDefaultValue(
    input: InputDefinition | undefined
  ): InputDefinition | undefined {
    if (!input || !('defaultValue' in input)) return undefined;
    const cleared = { ...input };
    delete cleared.defaultValue;
    return cleared;
  }

  private populateScheduleFormFromWorkflow(workflow: Service | null): void {
    const props = extractScheduleProperties(workflow?.inputs);
    const execTimeProp = props.get('execTime');
    const intervalProp = props.get('interval_schedule');
    const calendarProp = props.get('calendar_schedule');

    const execTimeValue = String(execTimeProp?.defaultValue ?? '').trim();
    if (execTimeValue) {
      const oneTimeForm = inferOneTimeScheduleForm(execTimeValue);
      this.scheduleForm.patchValue(
        {
          scheduleType: 'oneTime',
          startDate: oneTimeForm.startDate,
          startTime: oneTimeForm.startTime,
          intervalHours: 1,
          intervalDays: 1,
          endDate: '',
          dayOfWeek: [],
        },
        { emitEvent: false }
      );
      this._scheduleType.set('oneTime');
      this.updateScheduleValidators();
      this.cdr.markForCheck();
      return;
    }

    const calendarPayload = parseScheduleJson<CalendarSchedulePayload>(
      String(calendarProp?.defaultValue ?? '')
    );
    if (calendarPayload) {
      const calendarForm = inferCalendarScheduleForm(calendarPayload);
      this.scheduleForm.patchValue(calendarForm, { emitEvent: false });
      this._scheduleType.set(calendarForm.scheduleType);
      this.updateScheduleValidators();
      this.cdr.markForCheck();
      return;
    }

    const intervalPayload = parseScheduleJson<IntervalSchedulePayload>(
      String(intervalProp?.defaultValue ?? '')
    );
    if (intervalPayload) {
      const intervalForm = inferIntervalScheduleForm(intervalPayload);
      this.scheduleForm.patchValue(intervalForm, { emitEvent: false });
      this._scheduleType.set(intervalForm.scheduleType);
      this.updateScheduleValidators();
      this.cdr.markForCheck();
      return;
    }

    this._scheduleType.set('oneTime');
    this.scheduleForm.patchValue(
      {
        scheduleType: 'oneTime',
        startDate: '',
        startTime: '',
        intervalHours: 1,
        intervalDays: 1,
        endDate: '',
        dayOfWeek: [1],
      },
      { emitEvent: false }
    );
    this.updateScheduleValidators();
    this.cdr.markForCheck();
  }

  private readonly atLeastOneDayValidator = (
    control: AbstractControl
  ): ValidationErrors | null => {
    const value = control.value;
    if (Array.isArray(value) && value.length > 0) return null;
    return { dayOfWeekRequired: true };
  };

  private updateScheduleValidators(): void {
    const type = this._scheduleType();
    const ctrl = (key: string) => this.scheduleForm.get(key);
    const keys = [
      'startDate',
      'startTime',
      'intervalHours',
      'intervalDays',
      'endDate',
      'dayOfWeek',
    ];

    for (const key of keys) {
      const control = ctrl(key);
      if (control) {
        control.clearValidators();
        control.setErrors(null);
        control.markAsUntouched();
      }
    }

    if (type === 'oneTime') {
      ctrl('startDate')?.setValidators([Validators.required]);
      ctrl('startTime')?.setValidators([Validators.required]);
    }
    if (type === 'everyXHours' || type === 'everyYDays') {
      ctrl('startDate')?.setValidators([Validators.required]);
    }
    if (type === 'daily' || type === 'weekly') {
      ctrl('startTime')?.setValidators([Validators.required]);
    }
    if (type === 'everyXHours') {
      ctrl('intervalHours')?.setValidators([
        Validators.required,
        Validators.min(1),
        Validators.max(23),
      ]);
    }
    if (type === 'everyYDays') {
      ctrl('intervalDays')?.setValidators([
        Validators.required,
        Validators.min(1),
      ]);
    }
    if (type === 'weekly') {
      ctrl('dayOfWeek')?.setValidators([this.atLeastOneDayValidator]);
    }

    for (const key of keys) {
      ctrl(key)?.updateValueAndValidity({ emitEvent: false });
    }
  }
}
