/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  DestroyRef,
  computed,
  effect,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { catchError, finalize, of } from 'rxjs';
import { TaskFlowSharedService } from '../../../services/shared/task-flow-shared.service';
import { TaskItem } from '../../../models';
import { ModalConfirmationService } from 'src/app/services/common-functionalities/modal-confirmation.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-workflow-task-palette',
  templateUrl: './workflow-task-palette.component.html',
  styleUrls: ['./workflow-task-palette.component.css'],
  standalone: false,
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '(document:click)': 'onDocumentClick($event)',
  },
})
export class WorkflowTaskPaletteComponent {
  private readonly TaskFlowService = inject(TaskFlowSharedService);
  private readonly destroyRef = inject(DestroyRef);
  private readonly hostElement = inject(ElementRef<HTMLElement>);
  private readonly modalConfirmationService = inject(ModalConfirmationService);
  private readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);

  readonly loadTaskList = input<boolean>(false);
  readonly isFetchingTask = signal(false);

  readonly addTask = output<TaskItem[]>();
  readonly selectionChanged = output<TaskItem[]>();

  tasks = signal<TaskItem[]>([]);
  selectedTaskIds = signal<Set<string>>(new Set());
  private readonly hasLoadedTasks = signal(false);

  readonly isDragDisabled = computed(() => this.selectedTaskIds().size > 1);

  constructor() {
    effect(() => {
      if (this.loadTaskList() && !this.hasLoadedTasks()) {
        this.loadTasks();
      }
    });
  }

  onDocumentClick(event: MouseEvent): void {
    if (this.selectedTaskIds().size === 0) {
      return;
    }

    const target = event.target;
    if (target instanceof Node && this.shouldKeepSelection(target)) {
      return;
    }

    this.selectedTaskIds.set(new Set());
    this.emitSelectionChanged();
  }

  private shouldKeepSelection(target: Node): boolean {
    if (this.hostElement.nativeElement.contains(target)) {
      return true;
    }

    return (
      target instanceof Element &&
      !!target.closest('app-workflow-property-editor')
    );
  }

  private loadTasks(): void {
    this.isFetchingTask.set(true);
    this.TaskFlowService.loadTasks()
      .pipe(
        catchError(() => {
          this.alertService.error(
            this.translateService.instant(
              'taskFlow.createWorkflow.palette.loadTasksError'
            ),
            { keepAfterRouteChange: true }
          );
          this.hasLoadedTasks.set(true);
          return of([] as TaskItem[]);
        }),
        finalize(() => {
          this.isFetchingTask.set(false);
        })
      )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(tasks => {
        this.hasLoadedTasks.set(true);
        this.tasks.set(
          tasks.filter(task => task.lifecycleState === 'CERTIFIED')
        );
      });
  }

  isSelected(task: TaskItem): boolean {
    return this.selectedTaskIds().has(task.uniqueId);
  }

  selectTask(task: TaskItem): void {
    this.selectedTaskIds.update(selected => {
      const newSet = new Set(selected);
      if (newSet.has(task.uniqueId)) {
        newSet.delete(task.uniqueId);
      } else {
        newSet.add(task.uniqueId);
      }
      return newSet;
    });
    this.emitSelectionChanged();
  }

  onAddTask(): void {
    const selected = this.tasks().filter(t =>
      this.selectedTaskIds().has(t.uniqueId)
    );
    if (selected.length === 0) {
      return;
    }
    if (selected.length === 1) {
      this.addTask.emit(selected);
      this.selectedTaskIds.set(new Set());
      this.emitSelectionChanged();
      return;
    }
    this.modalConfirmationService
      .openConfirmationModal(
        'common.buttons.add',
        'taskFlow.createWorkflow.palette.confirmAddTitle',
        'taskFlow.createWorkflow.palette.confirmAddText',
        { count: selected.length }
      )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(confirmed => {
        if (confirmed) {
          this.addTask.emit(selected);
          this.selectedTaskIds.set(new Set());
          this.emitSelectionChanged();
        }
      });
  }

  onAddTaskDirect(task: TaskItem, event: Event): void {
    event.stopPropagation();
    this.removeTaskFromSelection(task.uniqueId);
    this.emitSelectionChanged();
    this.addTask.emit([task]);
  }

  private removeTaskFromSelection(taskId: string): void {
    this.selectedTaskIds.update(selected => {
      const newSet = new Set(selected);
      newSet.delete(taskId);
      return newSet;
    });
  }

  onDragStart(event: DragEvent, task: TaskItem): void {
    if (this.isDragDisabled()) {
      event.preventDefault();
      return;
    }
    if (event.dataTransfer) {
      event.dataTransfer.effectAllowed = 'copy';
      event.dataTransfer.setData('task', JSON.stringify(task));
      const label = task.name;

      const ghost = document.createElement('div');
      ghost.textContent = label;
      Object.assign(ghost.style, {
        position: 'fixed',
        top: '-200px',
        left: '-200px',
        padding: '0.4rem 0.85rem',
        background: '#ffffff',
        border: '1.5px solid var(--primary)',
        borderRadius: '0.375rem',
        fontSize: '0.8rem',
        fontWeight: '600',
        color: '#212529',
        boxShadow: '0 4px 12px rgba(0,0,0,0.18)',
        whiteSpace: 'nowrap',
        pointerEvents: 'none',
      });
      document.body.appendChild(ghost);
      event.dataTransfer.setDragImage(ghost, -1, -1);
      setTimeout(() => ghost.remove(), 0);
    }
  }

  onDragEnd(): void {
    this.selectedTaskIds.set(new Set());
    this.emitSelectionChanged();
  }

  private emitSelectionChanged(): void {
    const tasksById = new Map(
      this.tasks().map(task => [task.uniqueId, task] as const)
    );
    const selectedTasks = Array.from(this.selectedTaskIds())
      .map(taskId => tasksById.get(taskId))
      .filter((task): task is TaskItem => !!task);
    this.selectionChanged.emit(selectedTasks);
  }
}
