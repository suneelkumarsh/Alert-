/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { EMPTY, of } from 'rxjs';
import { TaskFlowOperationBaseComponent } from './taskflow-operation-base.component';
import { TasksService } from '../services/task/tasks.service';
import { PaneStateManagerService } from '../services/shared/pane-state-manager.service';
import { TaskFlowSharedService } from '../services/shared/task-flow-shared.service';
import { UpgradeWorkflowsModalComponent } from './task/upgrade-workflows-modal/upgrade-workflows-modal.component';
import { UpgradeWorkflowsModalLauncherService } from '../services/shared/upgrade-workflows-modal-launcher.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-test-operation-base',
  template: '<div></div>',
  standalone: false,
})
class TestTaskFlowOperationBaseComponent extends TaskFlowOperationBaseComponent {}

describe('TaskFlowOperationBaseComponent', () => {
  let component: TestTaskFlowOperationBaseComponent;
  let fixture: ComponentFixture<TestTaskFlowOperationBaseComponent>;
  let taskFlowSharedService: jasmine.SpyObj<TaskFlowSharedService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let translateService: jasmine.SpyObj<TranslateService>;
  let tasksService: jasmine.SpyObj<TasksService>;
  let modalService: jasmine.SpyObj<NgbModal>;
  let upgradeWorkflowsModalLauncher: jasmine.SpyObj<UpgradeWorkflowsModalLauncherService>;

  beforeEach(async () => {
    const alertServiceSpy = jasmine.createSpyObj('TnapAlertService', [
      'error',
      'success',
    ]);
    const translateServiceSpy = jasmine.createSpyObj('TranslateService', [
      'instant',
    ]);
    const tasksServiceSpy = jasmine.createSpyObj('TasksService', [
      'saveInputs',
      'certifyResource',
    ]);
    const paneStateManagerSpy = jasmine.createSpyObj(
      'PaneStateManagerService',
      ['getPersistedPaneWidth', 'persistPaneWidth']
    );
    const upgradeWorkflowsModalLauncherSpy = jasmine.createSpyObj(
      'UpgradeWorkflowsModalLauncherService',
      ['open']
    );
    const taskFlowSharedServiceSpy = jasmine.createSpyObj(
      'TaskFlowSharedService',
      ['navigateToTaskList']
    );
    const modalServiceSpy = jasmine.createSpyObj('NgbModal', ['open']);

    await TestBed.configureTestingModule({
      declarations: [TestTaskFlowOperationBaseComponent],
      providers: [
        { provide: TnapAlertService, useValue: alertServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
        { provide: TasksService, useValue: tasksServiceSpy },
        { provide: PaneStateManagerService, useValue: paneStateManagerSpy },
        {
          provide: UpgradeWorkflowsModalLauncherService,
          useValue: upgradeWorkflowsModalLauncherSpy,
        },
        {
          provide: TaskFlowSharedService,
          useValue: taskFlowSharedServiceSpy,
        },
        { provide: NgbModal, useValue: modalServiceSpy },
      ],
    }).compileComponents();

    taskFlowSharedService = TestBed.inject(
      TaskFlowSharedService
    ) as jasmine.SpyObj<TaskFlowSharedService>;
    alertService = TestBed.inject(
      TnapAlertService
    ) as jasmine.SpyObj<TnapAlertService>;
    translateService = TestBed.inject(
      TranslateService
    ) as jasmine.SpyObj<TranslateService>;
    tasksService = TestBed.inject(TasksService) as jasmine.SpyObj<TasksService>;
    modalService = TestBed.inject(NgbModal) as jasmine.SpyObj<NgbModal>;
    upgradeWorkflowsModalLauncher = TestBed.inject(
      UpgradeWorkflowsModalLauncherService
    ) as jasmine.SpyObj<UpgradeWorkflowsModalLauncherService>;

    translateService.instant.and.returnValue('Translated text');
    upgradeWorkflowsModalLauncher.open.and.returnValue(of(void 0));

    fixture = TestBed.createComponent(TestTaskFlowOperationBaseComponent);
    component = fixture.componentInstance;
  });

  describe('State Management', () => {
    it('should initialize with clean state', () => {
      expect(component.isFormDirty).toBe(false);
      expect(component.isSaving).toBe(false);
      expect(component.isCertifying).toBe(false);
    });

    it('should update form dirty state', () => {
      component.onFormDirtyChange(true);
      expect(component.isFormDirty).toBe(true);

      component.onFormDirtyChange(false);
      expect(component.isFormDirty).toBe(false);
    });
  });

  describe('canDeactivate - PendingChangesGuard', () => {
    it('should allow deactivation when no unsaved changes', () => {
      component.isFormDirty = false;
      expect(component.canDeactivate()).toBe(true);
    });

    it('should allow deactivation when navigating on success', () => {
      component.isFormDirty = true;
      component['isNavigatingOnSuccess'] = true;
      expect(component.canDeactivate()).toBe(true);
    });

    it('should block deactivation with unsaved changes', () => {
      component.isFormDirty = true;
      component['isNavigatingOnSuccess'] = false;

      expect(component.canDeactivate()).toBe(false);
    });
  });

  describe('Confirmation Dialogs', () => {
    it('should show confirmation modal', done => {
      const mockModalRef = jasmine.createSpyObj('NgbModalRef', [], {
        componentInstance: {},
        closed: {
          subscribe: jasmine
            .createSpy('subscribe')
            .and.callFake((cb: any) => cb(true)),
        },
        dismissed: { subscribe: () => {} },
      }) as any;

      modalService.open.and.returnValue(mockModalRef);
      mockModalRef.closed.subscribe = jasmine
        .createSpy('subscribe')
        .and.callFake((cb: any) => cb(true));
      mockModalRef.dismissed.subscribe = jasmine
        .createSpy('subscribe')
        .and.returnValue(undefined);

      component['showConfirmation']('test.title', 'test.message').then(
        result => {
          expect(result).toBe(true);
          expect(modalService.open).toHaveBeenCalled();
          done();
        }
      );
    });

    it('should handle modal dismissal as false', done => {
      const mockModalRef = jasmine.createSpyObj('NgbModalRef', [], {
        componentInstance: {},
        closed: { subscribe: () => {} },
        dismissed: {
          subscribe: jasmine
            .createSpy('subscribe')
            .and.callFake((cb: any) => cb()),
        },
      }) as any;

      modalService.open.and.returnValue(mockModalRef);
      mockModalRef.closed.subscribe = jasmine
        .createSpy('subscribe')
        .and.returnValue(undefined);
      mockModalRef.dismissed.subscribe = jasmine
        .createSpy('subscribe')
        .and.callFake((cb: any) => cb());

      component['showConfirmation']('test.title', 'test.message').then(
        result => {
          expect(result).toBe(false);
          done();
        }
      );
    });
  });

  describe('Error Handling', () => {
    it('should handle task error with alert', () => {
      const error = { status: 400, message: 'Bad Request' };

      component['handleTaskError'](error, 'error.key', 'TestComponent');

      expect(alertService.error).toHaveBeenCalled();
    });

    it('should handle task error with keepAfterRouteChange flag', () => {
      const error = { status: 500, message: 'Internal Server Error' };

      component['handleTaskError'](error, 'error.key', 'TestComponent', true);

      expect(alertService.error).toHaveBeenCalled();
    });
  });

  describe('Lifecycle', () => {
    it('should clean up destroy subject on ngOnDestroy', () => {
      spyOn(component['destroy$'], 'next');
      spyOn(component['destroy$'], 'complete');

      component.ngOnDestroy();

      expect(component['destroy$'].next).toHaveBeenCalled();
      expect(component['destroy$'].complete).toHaveBeenCalled();
    });
  });

  describe('Certify Flow', () => {
    it('should open upgrade modal after successful certification and then navigate', done => {
      const confirmationRef = {
        componentInstance: {},
        closed: of(true),
        dismissed: EMPTY,
      } as any;

      modalService.open.and.returnValue(confirmationRef);
      tasksService.certifyResource.and.returnValue(
        of({
          uniqueId: 'task-123',
          name: 'Task Name (Certified)',
          version: '2.0',
        } as any)
      );
      spyOn(component as any, 'navigateToTaskList').and.callThrough();

      component['runCertifyFlow']({
        resourceId: 'task-123',
        auditMessage: 'Certified from test',
        successNotificationKey: 'success.key',
        errorNotificationKey: 'error.key',
        componentName: 'TestComponent',
      });

      setTimeout(() => {
        expect(tasksService.certifyResource).toHaveBeenCalledWith(
          'task-123',
          'Certified from test'
        );
        expect(modalService.open).toHaveBeenCalledTimes(1);
        expect(upgradeWorkflowsModalLauncher.open).toHaveBeenCalledWith({
          taskId: 'task-123',
          taskName: 'Task Name (Certified)',
          taskVersion: '2.0',
        });
        expect(modalService.open.calls.all()[0].args[0]).not.toBe(
          UpgradeWorkflowsModalComponent
        );
        expect(component['navigateToTaskList']).toHaveBeenCalled();
        expect(taskFlowSharedService.navigateToTaskList).toHaveBeenCalled();
        done();
      }, 0);
    });

    it('should navigate directly without upgrade modal for certified version 1.0', done => {
      const confirmationRef = {
        componentInstance: {},
        closed: of(true),
        dismissed: EMPTY,
      } as any;

      modalService.open.and.returnValue(confirmationRef);
      tasksService.certifyResource.and.returnValue(
        of({
          uniqueId: 'task-123',
          name: 'Task Name (Certified)',
          version: '1.0.0',
        } as any)
      );
      spyOn(component as any, 'navigateToTaskList').and.callThrough();

      component['runCertifyFlow']({
        resourceId: 'task-123',
        auditMessage: 'Certified from test',
        successNotificationKey: 'success.key',
        errorNotificationKey: 'error.key',
        componentName: 'TestComponent',
      });

      setTimeout(() => {
        expect(tasksService.certifyResource).toHaveBeenCalledWith(
          'task-123',
          'Certified from test'
        );
        expect(modalService.open).toHaveBeenCalledTimes(1);
        expect(upgradeWorkflowsModalLauncher.open).not.toHaveBeenCalled();
        expect(modalService.open.calls.all()[0].args[0]).not.toBe(
          UpgradeWorkflowsModalComponent
        );
        expect(component['navigateToTaskList']).toHaveBeenCalled();
        expect(taskFlowSharedService.navigateToTaskList).toHaveBeenCalled();
        done();
      }, 0);
    });

    it('should not open upgrade modal when certification is not confirmed', done => {
      const confirmationRef = {
        componentInstance: {},
        closed: of(false),
        dismissed: EMPTY,
      } as any;

      modalService.open.and.returnValue(confirmationRef);

      component['runCertifyFlow']({
        resourceId: 'task-123',
        auditMessage: 'Certified from test',
        successNotificationKey: 'success.key',
        errorNotificationKey: 'error.key',
        componentName: 'TestComponent',
      });

      setTimeout(() => {
        expect(tasksService.certifyResource).not.toHaveBeenCalled();
        expect(modalService.open).toHaveBeenCalledTimes(1);
        done();
      }, 0);
    });
  });
});
