/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Directive, OnDestroy, inject } from '@angular/core';
import { Subject } from 'rxjs';
import { switchMap, takeUntil } from 'rxjs/operators';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { PaneStateManagerService } from '../services/shared/pane-state-manager.service';
import { TaskFlowSharedService } from '../services/shared/task-flow-shared.service';
import { ConfirmationModalComponent } from 'src/app/components/shared/confirmation-modal/confirmation-modal.component';
import { TasksService } from '../services/task/tasks.service';
import { InputDefinition } from 'openapi/output/model/models';
import { UpgradeWorkflowsModalLauncherService } from '../services/shared/upgrade-workflows-modal-launcher.service';
import { isVersionGreaterThan } from '../task-version.util';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Directive()
export class TaskFlowOperationBaseComponent implements OnDestroy {
  protected readonly alertService = inject(TnapAlertService);
  protected readonly translateService = inject(TranslateService);
  protected readonly stateManager = inject(PaneStateManagerService);
  protected readonly taskFlowSharedService = inject(TaskFlowSharedService);
  protected readonly modalService = inject(NgbModal);
  protected readonly tasksService = inject(TasksService);
  protected readonly upgradeWorkflowsModalLauncher = inject(
    UpgradeWorkflowsModalLauncherService
  );

  isFormDirty = false;
  isSaving = false;
  isCertifying = false;
  protected isNavigatingOnSuccess = false;

  protected readonly destroy$ = new Subject<void>();

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  canDeactivate(): boolean {
    if (this.isNavigatingOnSuccess || !this.isFormDirty) {
      return true;
    }
    return false;
  }

  onFormDirtyChange(isDirty: boolean): void {
    this.isFormDirty = isDirty;
  }

  protected showConfirmation(
    titleKey: string,
    messageKey: string
  ): Promise<boolean> {
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });

    modalRef.componentInstance.title = this.translateService.instant(titleKey);
    modalRef.componentInstance.text = this.translateService.instant(messageKey);
    modalRef.componentInstance.okText =
      this.translateService.instant('common.buttons.ok');
    modalRef.componentInstance.cancelText = this.translateService.instant(
      'common.buttons.cancel'
    );

    return new Promise(resolve => {
      modalRef.closed.subscribe((confirmed: boolean) => resolve(!!confirmed));
      modalRef.dismissed.subscribe(() => resolve(false));
    });
  }

  protected handleTaskError(
    error: unknown,
    notificationKey: string,
    componentName: string,
    keepAfterRouteChange: boolean = false
  ): void {
    this.alertService.error(this.translateService.instant(notificationKey), {
      keepAfterRouteChange,
    });
  }

  protected showSuccessNotification(
    notificationKey: string,
    keepAfterRouteChange: boolean = false
  ): void {
    this.alertService.success(this.translateService.instant(notificationKey), {
      keepAfterRouteChange,
    });
  }

  protected mergeInputsByName(
    existingInputs: Array<InputDefinition>,
    updatedInputs: Array<InputDefinition>
  ): Array<InputDefinition> {
    const mergedByName = new Map<string, InputDefinition>();

    existingInputs.forEach(input => {
      const name = String(input?.['name'] ?? '').trim();
      if (name) {
        mergedByName.set(name, input);
      }
    });

    updatedInputs.forEach(input => {
      const name = String(input?.['name'] ?? '').trim();
      if (name) {
        mergedByName.set(name, input);
      }
    });

    return Array.from(mergedByName.values());
  }

  protected persistTaskInputs(
    resourceId: string,
    inputDefinitions: Array<InputDefinition>,
    options: {
      onSuccess: (updatedInputs: Array<InputDefinition>) => void;
      errorNotificationKey: string;
      componentName: string;
      keepErrorAfterRouteChange?: boolean;
    }
  ): void {
    this.isSaving = true;
    this.tasksService
      .saveInputs(resourceId, inputDefinitions)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: updatedInputs => {
          this.isSaving = false;
          if (updatedInputs !== null) {
            options.onSuccess(updatedInputs);
          }
        },
        error: error => {
          this.isSaving = false;
          this.handleTaskError(
            error,
            options.errorNotificationKey,
            options.componentName,
            options.keepErrorAfterRouteChange ?? false
          );
        },
      });
  }

  protected navigateToTaskList(): void {
    this.taskFlowSharedService.navigateToTaskList();
  }

  protected getPaneWidths(
    nextLeftPaneWidth: number,
    minPaneWidth: number,
    maxPaneWidth: number
  ): { leftPaneWidth: number; rightPaneWidth: number } {
    const leftPaneWidth = Math.max(
      minPaneWidth,
      Math.min(maxPaneWidth, nextLeftPaneWidth)
    );

    return {
      leftPaneWidth,
      rightPaneWidth: 100 - leftPaneWidth,
    };
  }

  protected resizeAndPersistPane(options: {
    nextLeftPaneWidth: number;
    minPaneWidth: number;
    maxPaneWidth: number;
    paneWidthStorageKey: string;
  }): { leftPaneWidth: number; rightPaneWidth: number } {
    const paneWidths = this.getPaneWidths(
      options.nextLeftPaneWidth,
      options.minPaneWidth,
      options.maxPaneWidth
    );

    this.stateManager.persistPaneWidth(
      options.paneWidthStorageKey,
      paneWidths.leftPaneWidth
    );

    return paneWidths;
  }

  protected runCertifyFlow(options: {
    resourceId: string;
    inputs?: InputDefinition[];
    auditMessage: string;
    successNotificationKey: string;
    errorNotificationKey: string;
    componentName: string;
  }): void {
    this.showCertifyConfirmation().then(confirmed => {
      if (!confirmed) {
        return;
      }

      this.isCertifying = true;
      const certify$ =
        this.isFormDirty &&
        Array.isArray(options.inputs) &&
        options.inputs.length > 0
          ? this.tasksService
              .saveInputs(options.resourceId, options.inputs)
              .pipe(
                switchMap(() =>
                  this.tasksService.certifyResource(
                    options.resourceId,
                    options.auditMessage
                  )
                )
              )
          : this.tasksService.certifyResource(
              options.resourceId,
              options.auditMessage
            );

      certify$.pipe(takeUntil(this.destroy$)).subscribe({
        next: response => {
          const certifiedTaskId = String(response?.uniqueId ?? '').trim();
          const certifiedTaskName = String(response?.name ?? '').trim();
          const certifiedTaskVersion = String(response?.version ?? '').trim();

          this.isCertifying = false;
          this.isFormDirty = false;
          this.isNavigatingOnSuccess = true;
          this.showSuccessNotification(options.successNotificationKey, true);

          if (isVersionGreaterThan(certifiedTaskVersion, '1.0.0')) {
            this.upgradeWorkflowsModalLauncher
              .open({
                taskId: certifiedTaskId,
                taskName: certifiedTaskName,
                taskVersion: certifiedTaskVersion,
              })
              .pipe(takeUntil(this.destroy$))
              .subscribe(() => this.navigateToTaskList());
            return;
          }

          this.navigateToTaskList();
        },
        error: error => {
          this.isCertifying = false;
          this.handleTaskError(
            error,
            options.errorNotificationKey,
            options.componentName,
            true
          );
        },
      });
    });
  }

  showCertifyConfirmation(): Promise<boolean> {
    const modalRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });

    modalRef.componentInstance.title = this.translateService.instant(
      'taskFlow.taskEdit.confirmations.certifyTask.title'
    );
    modalRef.componentInstance.text = this.translateService.instant(
      'taskFlow.taskEdit.confirmations.certifyTask.message'
    );
    modalRef.componentInstance.okText =
      this.translateService.instant('common.buttons.ok');
    modalRef.componentInstance.cancelText = this.translateService.instant(
      'common.buttons.cancel'
    );

    return new Promise(resolve => {
      modalRef.closed.subscribe((confirmed: boolean) => resolve(!!confirmed));
      modalRef.dismissed.subscribe(() => resolve(false));
    });
  }
}
