/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { of, Subject, throwError } from 'rxjs';
import { UpgradeWorkflowsModalComponent } from './upgrade-workflows-modal.component';
import { TaskFlowSharedService } from '../../../services/shared/task-flow-shared.service';
import { SdcComponentType } from 'openapi/output/model/sdcComponentType.model';
import { SdcLifecycleState } from 'openapi/output/model/sdcLifecycleState.model';
import { ComponentDependency } from 'openapi/output/model/componentDependency.model';
import { ComponentUpgradeRespone } from 'openapi/output/model/componentUpgradeRespone.model';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('UpgradeWorkflowsModalComponent', () => {
  let component: UpgradeWorkflowsModalComponent;
  let fixture: ComponentFixture<UpgradeWorkflowsModalComponent>;
  let activeModal: jasmine.SpyObj<NgbActiveModal>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let translateService: TranslateService;
  let taskFlowSharedService: jasmine.SpyObj<TaskFlowSharedService>;

  const mockDependencies: ComponentDependency[] = [
    {
      uniqueId: 'task-123',
      name: 'Task Self',
      version: '9.9.9',
      state: SdcLifecycleState.CERTIFIED,
      dependencies: [
        {
          uniqueId: 'workflow-self',
          name: 'Workflow Self',
          version: '1.0.0',
          state: SdcLifecycleState.CERTIFIED,
        },
      ],
    } as ComponentDependency,
    {
      uniqueId: 'task-1',
      name: 'Task A',
      version: '1.2.3',
      state: SdcLifecycleState.CERTIFIED,
      dependencies: [
        {
          uniqueId: 'workflow-1',
          name: 'Workflow One',
          version: '1.0.0',
          state: SdcLifecycleState.CERTIFIED,
        },
        {
          uniqueId: 'workflow-2',
          name: 'Workflow Two',
          version: '2.0.0',
          state: SdcLifecycleState.NOT_CERTIFIED_CHECKOUT,
        },
      ],
    } as ComponentDependency,
    {
      uniqueId: 'task-2',
      name: 'Task B',
      version: '2.0.0',
      state: SdcLifecycleState.CERTIFIED,
      dependencies: [],
    } as ComponentDependency,
    {
      uniqueId: 'task-draft',
      name: 'Task Draft',
      version: '1.0.0',
      state: SdcLifecycleState.NOT_CERTIFIED_CHECKIN,
      dependencies: [
        {
          uniqueId: 'workflow-draft',
          name: 'Workflow Draft',
          version: '1.0.0',
          state: SdcLifecycleState.CERTIFIED,
        },
      ],
    } as ComponentDependency,
  ];

  const initComponent = (taskId: string = 'task-123'): void => {
    fixture = TestBed.createComponent(UpgradeWorkflowsModalComponent);
    component = fixture.componentInstance;
    component.taskId = taskId;
    component.taskName = 'Task A';
    component.taskVersion = '1.2.3';
    fixture.detectChanges();
  };

  beforeEach(async () => {
    activeModal = jasmine.createSpyObj('NgbActiveModal', ['close', 'dismiss']);
    alertService = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
    ]);
    taskFlowSharedService = jasmine.createSpyObj('TaskFlowSharedService', [
      'getComponentDependencies',
      'upgradeDependentComponent',
    ]);
    taskFlowSharedService.getComponentDependencies.and.returnValue(
      of(mockDependencies)
    );
    taskFlowSharedService.upgradeDependentComponent.and.returnValue(
      of({} as any)
    );

    await TestBed.configureTestingModule({
      imports: [UpgradeWorkflowsModalComponent, TranslateModule.forRoot()],
      providers: [
        { provide: NgbActiveModal, useValue: activeModal },
        { provide: TnapAlertService, useValue: alertService },
        { provide: TaskFlowSharedService, useValue: taskFlowSharedService },
      ],
    }).compileComponents();

    translateService = TestBed.inject(TranslateService);
    spyOn(translateService, 'instant').and.callFake((key: string) => key);
  });

  it('loads dependencies for the selected task and builds task rows', () => {
    initComponent();

    expect(taskFlowSharedService.getComponentDependencies).toHaveBeenCalledWith(
      'task-123',
      SdcComponentType.RESOURCES
    );
    expect(component.certifiedTasks().length).toBe(3);
    expect(component.taskRows().length).toBe(1);
    expect(component.hasDependencies()).toBeTrue();
    expect(component.taskRows()[0].showTaskSelection).toBeFalse();
  });

  it('renders dependency rows and excludes non-eligible tasks', () => {
    initComponent();

    expect(fixture.nativeElement.querySelector('ngb-accordion')).toBeNull();
    expect(fixture.nativeElement.textContent).toContain('Task A v1.2.3');
    expect(fixture.nativeElement.textContent).toContain('Workflow One');
    expect(fixture.nativeElement.textContent).toContain('Workflow Two');
    expect(fixture.nativeElement.textContent).not.toContain('Task Self');
    expect(fixture.nativeElement.textContent).not.toContain('Task B v2.0.0');
    expect(fixture.nativeElement.textContent).not.toContain('Task Draft');
  });

  it('toggles a dependency selection and updates canUpgrade', () => {
    initComponent();

    expect(component.canUpgrade()).toBeFalse();

    component.toggleDependency('workflow-1');
    expect(component.selectedWorkflows().has('workflow-1')).toBeTrue();
    expect(component.canUpgrade()).toBeTrue();

    component.toggleDependency('workflow-1');
    expect(component.selectedWorkflows().has('workflow-1')).toBeFalse();
    expect(component.canUpgrade()).toBeFalse();
  });

  it('ignores empty dependency id when toggling a dependency', () => {
    initComponent();

    component.toggleDependency('');

    expect(component.selectedWorkflows().size).toBe(0);
  });

  it('toggles all dependency ids for a task selection', () => {
    initComponent();

    component.toggleTaskSelection(['workflow-1', 'workflow-3']);
    expect(component.selectedWorkflows().has('workflow-1')).toBeTrue();
    expect(component.selectedWorkflows().has('workflow-3')).toBeTrue();

    component.toggleTaskSelection(['workflow-1', 'workflow-3']);
    expect(component.selectedWorkflows().size).toBe(0);
  });

  it('ignores empty task selection list', () => {
    initComponent();

    component.toggleTaskSelection([]);

    expect(component.selectedWorkflows().size).toBe(0);
  });

  it('dismisses modal on cancel', () => {
    initComponent();

    component.cancel();

    expect(activeModal.dismiss).toHaveBeenCalled();
  });

  it('does not call upgrade service when no workflows are selected', () => {
    initComponent();

    component.upgrade();

    expect(
      taskFlowSharedService.upgradeDependentComponent
    ).not.toHaveBeenCalled();
  });

  it('upgrades selected workflows and closes modal on success', () => {
    const upgradeResponse$ = new Subject<ComponentUpgradeRespone>();
    taskFlowSharedService.upgradeDependentComponent.and.returnValue(
      upgradeResponse$.asObservable()
    );
    initComponent();
    component.toggleDependency('workflow-1');

    component.upgrade();

    expect(component.isUpgrading()).toBeTrue();
    expect(
      taskFlowSharedService.upgradeDependentComponent
    ).toHaveBeenCalledWith('task-123', SdcComponentType.RESOURCES, [
      { serviceId: 'workflow-1' },
    ]);

    upgradeResponse$.next({});
    upgradeResponse$.complete();

    expect(component.isUpgrading()).toBeFalse();
    expect(activeModal.close).toHaveBeenCalledWith([]);
    expect(alertService.success).toHaveBeenCalledWith(
      'taskFlow.tasks.upgradeWorkflows.successMessage'
    );
  });

  it('passes componentToUpgradeStatus ids as the close value', () => {
    const upgradeResponse$ = new Subject<ComponentUpgradeRespone>();
    taskFlowSharedService.upgradeDependentComponent.and.returnValue(
      upgradeResponse$.asObservable()
    );
    initComponent();
    component.toggleDependency('workflow-1');

    component.upgrade();

    upgradeResponse$.next({
      componentToUpgradeStatus: [{ uniqueId: 'wf-a' }, { uniqueId: 'wf-b' }],
    } as any);
    upgradeResponse$.complete();

    expect(activeModal.close).toHaveBeenCalledWith(['wf-a', 'wf-b']);
  });

  it('shows an error alert when upgrade fails', () => {
    taskFlowSharedService.upgradeDependentComponent.and.returnValue(
      throwError(() => new Error('upgrade failed'))
    );
    initComponent();
    component.toggleDependency('workflow-1');

    component.upgrade();

    expect(component.isUpgrading()).toBeFalse();
    expect(activeModal.close).not.toHaveBeenCalled();
    expect(alertService.error).toHaveBeenCalledWith(
      'taskFlow.tasks.upgradeWorkflows.errorMessage'
    );
  });

  it('sets loadError when dependency loading fails', () => {
    taskFlowSharedService.getComponentDependencies.and.returnValue(
      throwError(() => new Error('load failed'))
    );

    initComponent('task-xyz');

    expect(component.loadError()).toBeTrue();
    expect(component.isLoading()).toBeFalse();
    expect(component.hasDependencies()).toBeFalse();
  });

  it('clears selected workflows when reloading data for a new task id', () => {
    initComponent();
    component.toggleDependency('workflow-1');
    expect(component.canUpgrade()).toBeTrue();

    component.taskId = 'task-999';
    fixture.detectChanges();

    expect(taskFlowSharedService.getComponentDependencies).toHaveBeenCalledWith(
      'task-999',
      SdcComponentType.RESOURCES
    );
    expect(component.selectedWorkflows().size).toBe(0);
    expect(component.canUpgrade()).toBeFalse();
  });

  it('clears selected workflows when task id becomes empty', () => {
    initComponent();
    component.toggleDependency('workflow-1');
    expect(component.canUpgrade()).toBeTrue();

    component.taskId = '';
    fixture.detectChanges();

    expect(component.isLoading()).toBeFalse();
    expect(component.selectedWorkflows().size).toBe(0);
    expect(component.canUpgrade()).toBeFalse();
  });

  it('does not call upgrade service when task id is empty', () => {
    initComponent();
    component.taskId = '';
    fixture.detectChanges();
    component.toggleDependency('workflow-1');

    component.upgrade();

    expect(
      taskFlowSharedService.upgradeDependentComponent
    ).not.toHaveBeenCalled();
  });
});
