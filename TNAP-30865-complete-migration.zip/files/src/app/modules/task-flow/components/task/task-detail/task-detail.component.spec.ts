/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { NgbActiveOffcanvas } from '@ng-bootstrap/ng-bootstrap';
import { of, throwError } from 'rxjs';
import { TaskDetailComponent } from './task-detail.component';
import { TasksService } from '../../../services/task/tasks.service';
import { TaskItem } from '../../../models';
import { CommonModule } from '@angular/common';
import { TaskFormInputDefinitionService } from '../../../services/task/task-form-input-definition.service';
import { TasksTemplateService } from '../../../services/task/tasks-template.service';
import {
  SdcLifecycleState,
  SdcResourceType,
} from 'openapi/output/model/models';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('TaskDetailComponent', () => {
  let component: TaskDetailComponent;
  let fixture: ComponentFixture<TaskDetailComponent>;
  let tasksService: jasmine.SpyObj<TasksService>;
  let tasksTemplateService: jasmine.SpyObj<TasksTemplateService>;
  let inputDefinitionService: TaskFormInputDefinitionService;
  let offcanvas: jasmine.SpyObj<NgbActiveOffcanvas>;

  const mockTaskItem: TaskItem = {
    uniqueId: 'task-123',
    name: 'Test Task',
    description: 'Test Description',
    type: 'RanTask',
    vendorName: 'TestVendor',
    version: '1.0.0',
    status: 'ACTIVE',
  } as any;

  const mockResource = {
    uniqueId: 'task-123',
    uuid: 'uuid-123',
    name: 'Test Task',
    description: 'Test Description',
    vendorName: 'TestVendor',
    vendorRelease: '1.0.0',
    version: '1.0.0',
    lifecycleState: SdcLifecycleState.NOT_CERTIFIED_CHECKOUT,
    inputs: [],
    categories: [],
    model: 'TestModel',
    resourceType: SdcResourceType.CR,
    componentType: 'TestComponentType',
    derivedFromGenericType: 'GenericType',
    derivedFromGenericVersion: '1.0.0',
  };

  beforeEach(async () => {
    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);
    const tasksServiceSpy = jasmine.createSpyObj('TasksService', [
      'getResourceById',
    ]);
    const tasksTemplateServiceSpy = jasmine.createSpyObj(
      'TasksTemplateService',
      ['routeToEditTask']
    );
    const offcanvasSpy = jasmine.createSpyObj('NgbActiveOffcanvas', [
      'dismiss',
    ]);
    const alertServiceSpy = jasmine.createSpyObj('TnapAlertService', [
      'error',
      'success',
      'info',
      'warn',
    ]);
    await TestBed.configureTestingModule({
      declarations: [TaskDetailComponent],
      imports: [CommonModule, TranslateModule.forRoot()],
      providers: [
        { provide: Router, useValue: routerSpy },
        { provide: TasksService, useValue: tasksServiceSpy },
        TaskFormInputDefinitionService,
        { provide: NgbActiveOffcanvas, useValue: offcanvasSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
      ],
    })
      .overrideComponent(TaskDetailComponent, {
        set: {
          providers: [
            {
              provide: TasksTemplateService,
              useValue: tasksTemplateServiceSpy,
            },
          ],
        },
      })
      .compileComponents();

    tasksService = TestBed.inject(TasksService) as jasmine.SpyObj<TasksService>;
    tasksTemplateService = tasksTemplateServiceSpy;
    inputDefinitionService = TestBed.inject(TaskFormInputDefinitionService);
    offcanvas = TestBed.inject(
      NgbActiveOffcanvas
    ) as jasmine.SpyObj<NgbActiveOffcanvas>;

    tasksService.getResourceById.and.returnValue(of(mockResource));
    spyOn(inputDefinitionService, 'toDisplayLabel').and.returnValue(
      'Formatted Label'
    );

    fixture = TestBed.createComponent(TaskDetailComponent);
    component = fixture.componentInstance;
    component.task = mockTaskItem;
  });

  describe('Initialization', () => {
    it('should create component', () => {
      expect(component).toBeTruthy();
    });

    it('should initialize with default values', () => {
      expect(component.isExpanded()).toBe(false);
      expect(component.isLoadingDetails()).toBe(false);
      expect(component.detailLoadError()).toBe(false);
      expect(component.fullResource()).toBeNull();
    });
  });

  describe('Load Resource Details', () => {
    it('should load resource details on init', () => {
      fixture.detectChanges();

      expect(tasksService.getResourceById).toHaveBeenCalledWith(
        'task-123',
        true
      );
      expect(component.fullResource()).toEqual(mockResource);
      expect(component.isLoadingDetails()).toBe(false);
    });

    it('should set loading state during fetch', () => {
      tasksService.getResourceById.and.returnValue(of(mockResource));

      component.ngOnInit();

      expect(component.isLoadingDetails()).toBe(false);
    });

    it('should handle resource load error', () => {
      tasksService.getResourceById.and.returnValue(
        throwError(() => new Error('Load failed'))
      );

      fixture.detectChanges();

      expect(component.detailLoadError()).toBe(true);
      expect(component.fullResource()).toBeNull();
    });

    it('should clear loading state on error', () => {
      tasksService.getResourceById.and.returnValue(
        throwError(() => new Error('Load failed'))
      );

      component.ngOnInit();

      expect(component.isLoadingDetails()).toBe(false);
    });

    it('should skip loading properties when fetchProperties is false', () => {
      component.fetchProperties = false;

      fixture.detectChanges();

      expect(tasksService.getResourceById).not.toHaveBeenCalled();
      expect(component.isLoadingDetails()).toBe(false);
    });

    it('should hide edit action when fetchProperties is false', () => {
      component.fetchProperties = false;

      fixture.detectChanges();

      expect(fixture.nativeElement.querySelector('.qa_edit_button')).toBeNull();
    });
  });

  describe('Expand Toggle', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    it('should toggle expanded state', () => {
      expect(component.isExpanded()).toBe(false);

      component.toggleExpand();
      expect(component.isExpanded()).toBe(true);

      component.toggleExpand();
      expect(component.isExpanded()).toBe(false);
    });
  });

  describe('Edit Task', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    it('should dismiss offcanvas', () => {
      component.editTask();
      expect(offcanvas.dismiss).toHaveBeenCalled();
      expect(tasksTemplateService.routeToEditTask).toHaveBeenCalledWith(
        mockTaskItem
      );
    });
  });

  describe('Lifecycle', () => {
    it('should clean up on destroy', () => {
      spyOn(component['destroy$'], 'next');
      spyOn(component['destroy$'], 'complete');

      component.ngOnDestroy();

      expect(component['destroy$'].next).toHaveBeenCalled();
      expect(component['destroy$'].complete).toHaveBeenCalled();
    });
  });
});
