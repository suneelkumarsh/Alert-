/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, convertToParamMap, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { EMPTY, of, throwError } from 'rxjs';
import { TaskEditComponent } from './task-edit.component';
import { UpgradeWorkflowsModalLauncherService } from '../../../services/shared/upgrade-workflows-modal-launcher.service';
import { PaneStateManagerService } from '../../../services/shared/pane-state-manager.service';
import { TaskFlowSharedService } from '../../../services/shared/task-flow-shared.service';
import { TasksService } from '../../../services/task/tasks.service';
import {
  TaskType,
  TaskTypesService,
} from '../../../services/task/task-types.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('TaskEditComponent', () => {
  let component: TaskEditComponent;
  let fixture: ComponentFixture<TaskEditComponent>;
  let activatedRoute: ActivatedRoute;
  let tasksService: jasmine.SpyObj<TasksService>;
  let taskTypesService: jasmine.SpyObj<TaskTypesService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let translateService: jasmine.SpyObj<TranslateService>;
  let stateManager: jasmine.SpyObj<PaneStateManagerService>;
  let taskFlowSharedService: jasmine.SpyObj<TaskFlowSharedService>;
  let modalService: jasmine.SpyObj<NgbModal>;

  const mockTaskType: TaskType = {
    id: 'ran-task-id',
    name: 'RanTask',
    description: 'RAN Task',
    vendorName: 'TestVendor',
    version: '1.0.0',
    tasksDefinition: {
      generalProperties: {
        name: { label: 'Name', required: true },
      },
    },
  } as any;

  const mockResource = {
    uniqueId: 'task-123',
    name: 'Task Name',
    description: 'Task Description',
    vendorName: 'TestVendor',
    version: '1.0.0',
    lifecycleState: 'IN_WORK',
    categories: [{ subcategories: [{ name: 'RanTask' }] }],
  } as any;

  const setConfirmationResult = (confirmed: boolean): void => {
    modalService.open.and.returnValue({
      componentInstance: {},
      closed: of(confirmed),
      dismissed: EMPTY,
    } as any);
  };

  beforeEach(async () => {
    const activatedRouteStub: Partial<ActivatedRoute> = {
      paramMap: of(convertToParamMap({ id: 'task-123' })),
      snapshot: {
        paramMap: convertToParamMap({ id: 'task-123' }),
      } as any,
    };

    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);
    const tasksServiceSpy = jasmine.createSpyObj('TasksService', [
      'getResourceById',
      'saveInputs',
      'certifyResource',
      'checkoutTaskResource',
    ]);
    const taskTypesServiceSpy = jasmine.createSpyObj('TaskTypesService', [
      'loadAllTaskTypes',
      'findMatchingTaskType',
      'extractTaskTypeName',
      'resolveTaskTypeLabel',
    ]);
    const alertServiceSpy = jasmine.createSpyObj('TnapAlertService', [
      'error',
      'success',
    ]);
    const translateServiceSpy = jasmine.createSpyObj(
      'TranslateService',
      ['instant', 'get'],
      {
        onTranslationChange: of({}),
        onLangChange: of({}),
        onDefaultLangChange: of({}),
      }
    );
    const stateManagerSpy = jasmine.createSpyObj('PaneStateManagerService', [
      'getPersistedPaneWidth',
      'persistPaneWidth',
    ]);
    const taskFlowSharedServiceSpy = jasmine.createSpyObj(
      'TaskFlowSharedService',
      ['navigateToTaskEdit', 'navigateToTaskList']
    );
    const modalServiceSpy = jasmine.createSpyObj('NgbModal', ['open']);
    const upgradeModalLauncherSpy = jasmine.createSpyObj(
      'UpgradeWorkflowsModalLauncherService',
      ['open']
    );
    upgradeModalLauncherSpy.open.and.returnValue(of(void 0));

    await TestBed.configureTestingModule({
      declarations: [TaskEditComponent],
      imports: [ReactiveFormsModule, TranslateModule.forRoot()],
      providers: [
        { provide: ActivatedRoute, useValue: activatedRouteStub },
        { provide: Router, useValue: routerSpy },
        { provide: TasksService, useValue: tasksServiceSpy },
        { provide: TaskTypesService, useValue: taskTypesServiceSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
        { provide: PaneStateManagerService, useValue: stateManagerSpy },
        {
          provide: TaskFlowSharedService,
          useValue: taskFlowSharedServiceSpy,
        },
        { provide: NgbModal, useValue: modalServiceSpy },
        {
          provide: UpgradeWorkflowsModalLauncherService,
          useValue: upgradeModalLauncherSpy,
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    activatedRoute = TestBed.inject(ActivatedRoute);
    tasksService = TestBed.inject(TasksService) as jasmine.SpyObj<TasksService>;
    taskTypesService = TestBed.inject(
      TaskTypesService
    ) as jasmine.SpyObj<TaskTypesService>;
    alertService = TestBed.inject(
      TnapAlertService
    ) as jasmine.SpyObj<TnapAlertService>;
    translateService = TestBed.inject(
      TranslateService
    ) as jasmine.SpyObj<TranslateService>;
    stateManager = TestBed.inject(
      PaneStateManagerService
    ) as jasmine.SpyObj<PaneStateManagerService>;
    taskFlowSharedService = TestBed.inject(
      TaskFlowSharedService
    ) as jasmine.SpyObj<TaskFlowSharedService>;
    modalService = TestBed.inject(NgbModal) as jasmine.SpyObj<NgbModal>;

    translateService.instant.and.returnValue('Translated text');
    translateService.get.and.returnValue(of('Translated text'));
    stateManager.getPersistedPaneWidth.and.returnValue(30);
    tasksService.getResourceById.and.returnValue(of(mockResource));
    taskTypesService.loadAllTaskTypes.and.returnValue(of([mockTaskType]));
    taskTypesService.extractTaskTypeName.and.returnValue('RanTask');
    taskTypesService.resolveTaskTypeLabel.and.returnValue(
      'Huawei Configuration'
    );
    taskTypesService.findMatchingTaskType.and.returnValue(mockTaskType);
    setConfirmationResult(true);

    fixture = TestBed.createComponent(TaskEditComponent);
    component = fixture.componentInstance;
  });

  describe('Initialization', () => {
    it('should create component', () => {
      expect(component).toBeTruthy();
    });

    it('should initialize with default pane widths', () => {
      expect(component.leftPaneWidth).toBe(30);
      expect(component.rightPaneWidth).toBe(70);
    });

    it('should not render the available task types pane on edit screen', () => {
      fixture.detectChanges();

      expect(
        fixture.nativeElement.querySelector('app-task-type-selector')
      ).toBeNull();
      expect(fixture.nativeElement.querySelector('.left-pane')).toBeNull();
      expect(
        fixture.nativeElement.querySelector('.resizable-divider')
      ).toBeNull();
    });

    it('should load persisted pane width on init', () => {
      fixture.detectChanges();

      expect(stateManager.getPersistedPaneWidth).toHaveBeenCalledWith(
        'task-flow:task-edit:left-pane-width',
        20,
        70,
        30
      );
    });
  });

  describe('Checkout for edit', () => {
    it('should show checkout action in the header for certified tasks', () => {
      (component as any).viewModel = (() => ({
        resource: { ...mockResource, lifecycleState: 'CERTIFIED' },
      })) as any;

      expect(component.showCheckoutForEdit()).toBeTrue();
    });

    it('should hide checkout action in the header for non-certified tasks', () => {
      (component as any).viewModel = (() => ({
        resource: { ...mockResource, lifecycleState: 'NOT_CERTIFIED_CHECKOUT' },
      })) as any;

      expect(component.showCheckoutForEdit()).toBeFalse();
    });
  });

  describe('Load Task', () => {
    it('should navigate to tasks list when no ID provided', done => {
      (activatedRoute as any).paramMap = of(convertToParamMap({}));

      fixture.detectChanges();

      setTimeout(() => {
        expect(taskFlowSharedService.navigateToTaskList).toHaveBeenCalled();
        done();
      }, 0);
    });
  });

  describe('Save Workflow', () => {
    it('should save task inputs', done => {
      const inputs = [{ name: 'input-1' }] as any;
      tasksService.saveInputs.and.returnValue(of(inputs));

      fixture.detectChanges();
      component.onSave({ taskType: mockTaskType, formData: {}, inputs });

      setTimeout(() => {
        expect(tasksService.saveInputs).toHaveBeenCalledWith(
          'task-123',
          inputs
        );
        done();
      }, 0);
    });

    it('should show success notification after save', done => {
      tasksService.saveInputs.and.returnValue(of([{ name: 'input-1' }] as any));

      fixture.detectChanges();
      component.onSave({
        taskType: mockTaskType,
        formData: { description: 'updated' },
        inputs: [{ name: 'input-1' }] as any,
      });

      setTimeout(() => {
        expect(alertService.success).toHaveBeenCalled();
        done();
      }, 0);
    });

    it('should handle save error', done => {
      const error = { status: 500 };
      tasksService.saveInputs.and.returnValue(throwError(() => error));

      fixture.detectChanges();
      component.onSave({
        taskType: mockTaskType,
        formData: {},
        inputs: [{ name: 'input-1' }] as any,
      });

      setTimeout(() => {
        expect(alertService.error).toHaveBeenCalled();
        done();
      }, 0);
    });
  });

  describe('Checkout Workflow', () => {
    it('should proceed with checkout when confirmed', done => {
      setConfirmationResult(true);
      tasksService.checkoutTaskResource.and.returnValue(
        of({ uniqueId: 'new-1' })
      );

      fixture.detectChanges();
      component.onCheckout();

      setTimeout(() => {
        expect(tasksService.checkoutTaskResource).toHaveBeenCalledWith(
          'task-123',
          'Checked out from task-flow edit task'
        );
        expect(taskFlowSharedService.navigateToTaskEdit).toHaveBeenCalledWith(
          'new-1'
        );
        done();
      }, 0);
    });

    it('should cancel checkout when user declines confirmation', done => {
      setConfirmationResult(false);

      fixture.detectChanges();
      component.onCheckout();

      setTimeout(() => {
        expect(tasksService.checkoutTaskResource).not.toHaveBeenCalled();
        done();
      }, 0);
    });
  });

  describe('Certify Workflow', () => {
    it('should proceed with certification when confirmed', done => {
      setConfirmationResult(true);
      tasksService.certifyResource.and.returnValue(
        of({ certified: true } as any)
      );

      fixture.detectChanges();
      component.onCertify({ taskType: mockTaskType, formData: {}, inputs: [] });

      setTimeout(() => {
        expect(tasksService.certifyResource).toHaveBeenCalledWith(
          'task-123',
          'Certified from task-flow edit task'
        );
        expect(alertService.success).toHaveBeenCalled();
        expect(taskFlowSharedService.navigateToTaskList).toHaveBeenCalled();
        done();
      }, 0);
    });

    it('should save inputs before certify when form is dirty', done => {
      setConfirmationResult(true);
      component.isFormDirty = true;
      tasksService.saveInputs.and.returnValue(of([{ name: 'input-1' }] as any));
      tasksService.certifyResource.and.returnValue(
        of({ certified: true } as any)
      );

      fixture.detectChanges();
      component.onCertify({
        taskType: mockTaskType,
        formData: {},
        inputs: [{ name: 'input-1' }] as any,
      });

      setTimeout(() => {
        expect(tasksService.saveInputs).toHaveBeenCalledWith('task-123', [
          { name: 'input-1' },
        ] as any);
        expect(tasksService.certifyResource).toHaveBeenCalled();
        done();
      }, 0);
    });

    it('should cancel certification when user declines confirmation', done => {
      setConfirmationResult(false);

      fixture.detectChanges();
      component.onCertify({ taskType: mockTaskType, formData: {}, inputs: [] });

      setTimeout(() => {
        expect(tasksService.certifyResource).not.toHaveBeenCalled();
        done();
      }, 0);
    });
  });

  describe('Pane Resizing', () => {
    it('should update and persist pane width from resizer output', () => {
      fixture.detectChanges();

      component.onPaneResize(35);

      expect(component.leftPaneWidth).toBe(35);
      expect(component.rightPaneWidth).toBe(65);
      expect(stateManager.persistPaneWidth).toHaveBeenCalledWith(
        'task-flow:task-edit:left-pane-width',
        35
      );
    });

    it('should clamp pane width to configured bounds', () => {
      fixture.detectChanges();

      component.onPaneResize(10);
      expect(component.leftPaneWidth).toBe(20);

      component.onPaneResize(90);
      expect(component.leftPaneWidth).toBe(70);
    });
  });

  describe('PendingChangesGuard', () => {
    it('should allow deactivation when not dirty', () => {
      component.isFormDirty = false;
      expect(component.canDeactivate()).toBe(true);
    });

    it('should prevent deactivation when dirty and not navigating on success', () => {
      component.isFormDirty = true;
      component['isNavigatingOnSuccess'] = false;

      expect(component.canDeactivate()).toBe(false);
    });

    it('should allow deactivation when navigating on success', () => {
      component.isFormDirty = true;
      component['isNavigatingOnSuccess'] = true;

      expect(component.canDeactivate()).toBe(true);
    });
  });

  describe('Form Dirty State', () => {
    it('should update form dirty state', () => {
      fixture.detectChanges();

      component.onFormDirtyChange(true);
      expect(component.isFormDirty).toBe(true);

      component.onFormDirtyChange(false);
      expect(component.isFormDirty).toBe(false);
    });
  });

  describe('Cleanup', () => {
    it('should clean up on destroy', () => {
      spyOn(component['destroy$'], 'next');
      spyOn(component['destroy$'], 'complete');

      component.ngOnDestroy();

      expect(component['destroy$'].next).toHaveBeenCalled();
      expect(component['destroy$'].complete).toHaveBeenCalled();
    });
  });
});
