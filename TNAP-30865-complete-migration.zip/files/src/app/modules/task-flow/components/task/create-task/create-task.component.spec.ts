/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { of, throwError, Subject } from 'rxjs';
import { CreateTaskComponent } from './create-task.component';
import { TasksService } from '../../../services/task/tasks.service';
import { TaskType } from '../../../services/task/task-types.service';
import { TranslateService } from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import { PaneStateManagerService } from '../../../services/shared/pane-state-manager.service';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TaskFormInputDefinitionService } from '../../../services/task/task-form-input-definition.service';
import { UpgradeWorkflowsModalLauncherService } from '../../../services/shared/upgrade-workflows-modal-launcher.service';
import { TaskTypesService } from '../../../services/task/task-types.service';
import { TaskFlowSharedService } from '../../../services/shared/task-flow-shared.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('CreateTaskComponent', () => {
  let component: CreateTaskComponent;
  let fixture: ComponentFixture<CreateTaskComponent>;
  let tasksService: jasmine.SpyObj<TasksService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let translateService: jasmine.SpyObj<TranslateService>;
  let stateManager: jasmine.SpyObj<PaneStateManagerService>;
  let taskTypesService: jasmine.SpyObj<TaskTypesService>;
  let taskFlowSharedService: jasmine.SpyObj<TaskFlowSharedService>;

  const mockTaskType: TaskType = {
    id: 'configuration',
    name: 'Configuration',
    description: 'RAN Task',
    apiTypeSuffix: 'Configuration',
    schema: {
      type: 'object',
      properties: {},
    },
  } as any;

  beforeEach(async () => {
    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);
    const tasksServiceSpy = jasmine.createSpyObj('TasksService', [
      'createTask',
      'createTaskAndFetch',
      'saveInputs',
      'getInventoryFilterOptions',
      'getRanTemplateNameOptions',
      'clearInventoryFilterCache',
      'clearRanTemplateNameCache',
    ]);
    const alertServiceSpy = jasmine.createSpyObj('TnapAlertService', [
      'error',
      'success',
    ]);
    const translateServiceSpy = jasmine.createSpyObj(
      'TranslateService',
      ['instant', 'get'],
      {
        onTranslationChange: of({}),
        onLangChange: of({}),
        onDefaultLangChange: of({}),
      }
    );
    const stateManagerSpy = jasmine.createSpyObj('PaneStateManagerService', [
      'getPersistedPaneWidth',
      'persistPaneWidth',
    ]);
    const modalServiceSpy = jasmine.createSpyObj('NgbModal', ['open']);
    const formInputDefinitionServiceSpy = jasmine.createSpyObj(
      'TaskFormInputDefinitionService',
      ['getInputDefinitionsByResourceId']
    );
    const upgradeWorkflowsModalLauncherSpy = jasmine.createSpyObj(
      'UpgradeWorkflowsModalLauncherService',
      ['open']
    );
    const taskTypesServiceSpy = jasmine.createSpyObj('TaskTypesService', [
      'getApiTaskTypeName',
      'isSupportedCreateApiTaskTypeName',
      'resolveTaskTypeLabel',
    ]);
    const taskFlowSharedServiceSpy = jasmine.createSpyObj(
      'TaskFlowSharedService',
      ['navigateToTaskEdit', 'navigateToTaskList']
    );

    await TestBed.configureTestingModule({
      declarations: [CreateTaskComponent],
      imports: [ReactiveFormsModule, TranslateModule.forRoot()],
      providers: [
        { provide: Router, useValue: routerSpy },
        { provide: TasksService, useValue: tasksServiceSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
        { provide: PaneStateManagerService, useValue: stateManagerSpy },
        { provide: NgbModal, useValue: modalServiceSpy },
        {
          provide: TaskFormInputDefinitionService,
          useValue: formInputDefinitionServiceSpy,
        },
        {
          provide: UpgradeWorkflowsModalLauncherService,
          useValue: upgradeWorkflowsModalLauncherSpy,
        },
        { provide: TaskTypesService, useValue: taskTypesServiceSpy },
        {
          provide: TaskFlowSharedService,
          useValue: taskFlowSharedServiceSpy,
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    tasksService = TestBed.inject(TasksService) as jasmine.SpyObj<TasksService>;
    alertService = TestBed.inject(
      TnapAlertService
    ) as jasmine.SpyObj<TnapAlertService>;
    translateService = TestBed.inject(
      TranslateService
    ) as jasmine.SpyObj<TranslateService>;
    stateManager = TestBed.inject(
      PaneStateManagerService
    ) as jasmine.SpyObj<PaneStateManagerService>;
    taskTypesService = TestBed.inject(
      TaskTypesService
    ) as jasmine.SpyObj<TaskTypesService>;
    taskFlowSharedService = TestBed.inject(
      TaskFlowSharedService
    ) as jasmine.SpyObj<TaskFlowSharedService>;

    translateService.instant.and.returnValue('Translated text');
    translateService.get.and.returnValue(of('Translated text'));
    stateManager.getPersistedPaneWidth.and.returnValue(30);
    taskTypesService.getApiTaskTypeName.and.callFake(
      (_taskType, vendorName) => `${vendorName}Configuration`
    );
    taskTypesService.isSupportedCreateApiTaskTypeName.and.returnValue(true);
    taskTypesService.resolveTaskTypeLabel.and.callFake(
      (taskTypeName, vendorName) => `${vendorName} ${taskTypeName}`
    );

    fixture = TestBed.createComponent(CreateTaskComponent);
    component = fixture.componentInstance;
  });

  describe('Initialization', () => {
    it('should create component', () => {
      expect(component).toBeTruthy();
    });

    it('should initialize with default values', () => {
      expect(component.selectedTaskType).toBeNull();
      expect(component.isCreating).toBe(false);
    });

    it('should initialize with default pane widths', () => {
      expect(component.leftPaneWidth).toBe(30);
      expect(component.rightPaneWidth).toBe(70);
    });
  });

  describe('Create Task Workflow', () => {
    it('should create task with form data', done => {
      const formData = {
        name: 'New Task',
        description: 'Test Description',
        vendorName: 'TestVendor',
      };

      tasksService.createTask.and.returnValue(
        of({ uniqueId: 'new-task-123', ...formData })
      );

      fixture.detectChanges();

      component.onCreate({
        taskType: mockTaskType,
        formData,
        inputs: [],
      });

      setTimeout(() => {
        expect(tasksService.createTask).toHaveBeenCalledWith(
          'TestVendorConfiguration',
          formData
        );
        expect(taskFlowSharedService.navigateToTaskEdit).toHaveBeenCalledWith(
          'new-task-123',
          jasmine.objectContaining({
            state: jasmine.objectContaining({
              taskType: 'TestVendor TestVendorConfiguration',
            }),
          })
        );
        done();
      }, 100);
    });

    it('should not create unsupported api task types', () => {
      taskTypesService.getApiTaskTypeName.and.returnValue(
        'UnsupportedTaskType'
      );
      taskTypesService.isSupportedCreateApiTaskTypeName.and.returnValue(false);

      fixture.detectChanges();

      component.onCreate({
        taskType: mockTaskType,
        formData: {
          name: 'New Task',
          description: 'Test Description',
          vendorName: 'TestVendor',
        },
        inputs: [],
      });

      expect(tasksService.createTask).not.toHaveBeenCalled();
      expect(component.isCreating).toBeFalse();
    });

    it('should show success notification after create', done => {
      const formData = {
        name: 'New Task',
        description: 'Test',
        vendorName: 'Test',
      };
      tasksService.createTask.and.returnValue(
        of({ uniqueId: 'new-task-123', ...formData })
      );

      fixture.detectChanges();

      component.onCreate({
        taskType: mockTaskType,
        formData,
        inputs: [],
      });

      setTimeout(() => {
        expect(alertService.success).toHaveBeenCalled();
        done();
      }, 100);
    });

    it('should handle create error', done => {
      const error = { status: 400, message: 'Bad Request' };
      tasksService.createTask.and.returnValue(throwError(() => error));

      fixture.detectChanges();

      component.onCreate({
        taskType: mockTaskType,
        formData: { name: 'Test', description: 'Test', vendorName: 'Test' },
        inputs: [],
      });

      setTimeout(() => {
        expect(alertService.error).toHaveBeenCalled();
        done();
      }, 100);
    });

    it('should navigate away after successful create without switching local edit mode', done => {
      tasksService.createTask.and.returnValue(
        of({ uniqueId: 'new-task-123', name: 'Test' })
      );

      fixture.detectChanges();

      component.onCreate({
        taskType: mockTaskType,
        formData: { name: 'Test', description: 'Test', vendorName: 'Test' },
        inputs: [],
      });

      setTimeout(() => {
        expect((component as any).isNavigatingOnSuccess).toBeTrue();
        done();
      }, 100);
    });
  });

  describe('Pane Resizing', () => {
    it('should update and persist pane width from resizer output', () => {
      fixture.detectChanges();

      component.onPaneResize(35);

      expect(component.leftPaneWidth).toBe(35);
      expect(component.rightPaneWidth).toBe(65);
      expect(stateManager.persistPaneWidth).toHaveBeenCalledWith(
        'task-flow:create-task:left-pane-width',
        35
      );
    });

    it('should clamp pane width to configured bounds', () => {
      fixture.detectChanges();

      component.onPaneResize(10);
      expect(component.leftPaneWidth).toBe(20);

      component.onPaneResize(90);
      expect(component.leftPaneWidth).toBe(70);
    });
  });

  describe('Cancel Workflow', () => {
    it('should navigate back when cancel is called', () => {
      fixture.detectChanges();

      component.onCancel();

      expect(taskFlowSharedService.navigateToTaskList).toHaveBeenCalled();
    });

    it('should handle cancel when form is dirty', () => {
      component.isFormDirty = true;

      fixture.detectChanges();

      component.onCancel();

      expect(taskFlowSharedService.navigateToTaskList).toHaveBeenCalled();
    });

    it('should handle cancel when form is clean', () => {
      component.isFormDirty = false;

      fixture.detectChanges();

      component.onCancel();

      expect(taskFlowSharedService.navigateToTaskList).toHaveBeenCalled();
    });
  });

  describe('PendingChangesGuard', () => {
    it('should allow deactivation when not dirty', () => {
      component.isFormDirty = false;

      const result = component.canDeactivate();

      expect(result).toBe(true);
    });

    it('should prevent deactivation when dirty and not navigating on success', () => {
      component.isFormDirty = true;
      (component as any).isNavigatingOnSuccess = false;

      const result = component.canDeactivate();

      expect(result).toBeFalse();
    });

    it('should allow deactivation when dirty and navigating on success', () => {
      component.isFormDirty = true;
      (component as any).isNavigatingOnSuccess = true;

      const result = component.canDeactivate();

      expect(result).toBe(true);
    });
  });

  describe('Form Dirty State', () => {
    it('should update form dirty state', () => {
      fixture.detectChanges();

      component.onFormDirtyChange(true);
      expect(component.isFormDirty).toBe(true);

      component.onFormDirtyChange(false);
      expect(component.isFormDirty).toBe(false);
    });
  });

  describe('Cleanup', () => {
    it('should initialize with destroy$ observable', () => {
      expect((component as any).destroy$).toBeDefined();
    });

    it('should have destroy$ subject that can emit', done => {
      const destroySubject = (component as any).destroy$ as Subject<void>;
      let emissionCount = 0;

      destroySubject.subscribe(() => {
        emissionCount += 1;
      });

      destroySubject.next();
      expect(emissionCount).toBe(1);
      done();
    });
  });
});
