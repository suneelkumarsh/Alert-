/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, inject, Injector, OnInit, Signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute } from '@angular/router';
import { concat, EMPTY, forkJoin, merge, of, Subject } from 'rxjs';
import {
  tap,
  map,
  switchMap,
  catchError,
  takeUntil,
  shareReplay, // still used in taskTypes$
} from 'rxjs/operators';
import { EditViewModel, TaskActionPayload, TaskItem } from '../../../models';
import {
  TaskType,
  TaskTypesService,
} from '../../../services/task/task-types.service';
import { TaskFlowOperationBaseComponent } from '../../taskflow-operation-base.component';
import { ComponentCanDeactivate } from 'src/app/guards/pending-changes.guard';
import { InputDefinition, Resource, SdcLifecycleState } from 'openapi/output';
@Component({
  selector: 'app-task-edit',
  templateUrl: './task-edit.component.html',
  styleUrls: ['./task-edit.component.css'],
  standalone: false,
})
export class TaskEditComponent
  extends TaskFlowOperationBaseComponent
  implements OnInit, ComponentCanDeactivate
{
  private readonly route = inject(ActivatedRoute);
  private readonly taskTypesService = inject(TaskTypesService);
  private readonly injector = inject(Injector);

  viewModel!: Signal<EditViewModel | undefined>;
  formResetToken = 0;
  taskBreadcrumbName: string = '';

  selectedTaskType: TaskType | null = null;
  readonlyFields: string[] = ['name', 'description', 'vendor', 'vendorName'];
  private readonly vmUpdates$ = new Subject<EditViewModel>();
  private latestViewModel: EditViewModel | null = null;

  leftPaneWidth: number = 30;
  rightPaneWidth: number = 70;

  readonly minPaneWidth = 20;
  readonly maxPaneWidth = 70;
  private readonly paneWidthStorageKey = 'task-flow:task-edit:left-pane-width';

  private buildInitialValuesFromResource(
    resourceData: Resource
  ): Record<string, unknown> {
    const vendorValue = resourceData?.vendorName ?? resourceData?.['vendor'];
    const resourceRecord = resourceData as unknown as Record<string, unknown>;

    return {
      ...resourceRecord,
      name: resourceData?.name ?? resourceRecord['name'] ?? '',
      description:
        resourceData?.description ?? resourceRecord['description'] ?? '',
      vendor: vendorValue ?? '',
      vendorName: vendorValue ?? '',
      version: resourceData?.version ?? resourceRecord['version'] ?? '',
      lifecycleState: (resourceData?.lifecycleState as SdcLifecycleState) ?? '',
    };
  }

  private buildTaskItem(
    id: string,
    typeName: string,
    source: Partial<Resource> | Partial<TaskItem>
  ): TaskItem {
    const sourceRecord = source;

    return {
      uniqueId: id,
      name: sourceRecord?.name ?? '',
      description: sourceRecord?.description ?? '',
      type: typeName,
      vendorName: sourceRecord?.vendorName ?? '',
      version: sourceRecord?.version ?? '',
      lifecycleState: sourceRecord?.lifecycleState ?? '',
    } as TaskItem;
  }

  private buildEditViewModel(params: EditViewModel): EditViewModel {
    return {
      task: params.task,
      taskTypeId: params.taskTypeId,
      taskTypeName: params.taskTypeName,
      initialValues: params.initialValues,
      resource: params.resource,
      selectedTaskType: params.selectedTaskType,
    };
  }

  private buildSavedViewModel(
    formData: Record<string, unknown>,
    updatedInputs: Array<InputDefinition> | null
  ): EditViewModel | null {
    const currentVm = this.latestViewModel;
    if (!currentVm) {
      return null;
    }

    const previousInputs = Array.isArray(currentVm.resource?.['inputs'])
      ? (currentVm.resource?.['inputs'] as Array<InputDefinition>)
      : [];
    const nextInputs = Array.isArray(updatedInputs)
      ? this.mergeInputsByName(previousInputs, updatedInputs)
      : previousInputs;

    const nextResource = {
      ...currentVm.resource,
      ...formData,
      inputs: nextInputs,
    };

    return this.buildEditViewModel({
      task: this.buildTaskItem(
        currentVm.task.uniqueId,
        currentVm.taskTypeName,
        nextResource
      ),
      taskTypeId: currentVm.taskTypeId,
      taskTypeName: currentVm.taskTypeName,
      initialValues: {
        ...currentVm.initialValues,
        ...formData,
      },
      resource: nextResource,
      selectedTaskType: currentVm.selectedTaskType,
    });
  }

  ngOnInit(): void {
    this.leftPaneWidth = this.stateManager.getPersistedPaneWidth(
      this.paneWidthStorageKey,
      this.minPaneWidth,
      this.maxPaneWidth,
      this.leftPaneWidth
    );
    this.rightPaneWidth = 100 - this.leftPaneWidth;

    const routeVm$ = this.route.paramMap.pipe(
      map(params => params.get('id') ?? ''),
      switchMap(id => {
        if (!id) {
          this.navigateToTaskList();
          return of();
        }

        const stateSummary = (history.state?.taskSummary ??
          {}) as Partial<TaskItem>;
        const stateTaskType = String(
          history.state?.taskType ?? stateSummary?.type ?? ''
        ).trim();
        this.taskBreadcrumbName = String(stateSummary?.name ?? '').trim();

        const initialVm: EditViewModel = this.buildEditViewModel({
          task: this.buildTaskItem(id, stateTaskType, stateSummary),
          taskTypeId: '',
          taskTypeName: stateTaskType,
          initialValues: {
            ...stateSummary,
            vendorName: stateSummary?.vendorName ?? '',
            lifecycleState: stateSummary?.lifecycleState ?? '',
          },
          resource: null,
          selectedTaskType: null,
        });

        const hasStatePrefill =
          Object.keys(stateSummary).length > 0 || stateTaskType.length > 0;

        const taskTypes$ = this.taskTypesService
          .loadAllTaskTypes()
          .pipe(shareReplay({ refCount: true, bufferSize: 1 }));

        const prefillVm$ = hasStatePrefill
          ? taskTypes$.pipe(
              map(types => {
                const taskType = this.taskTypesService.findMatchingTaskType(
                  types,
                  {
                    resolvedName: stateTaskType,
                  }
                );

                return this.buildEditViewModel({
                  task: initialVm.task,
                  taskTypeId: taskType?.id ?? '',
                  taskTypeName: initialVm.taskTypeName,
                  initialValues: initialVm.initialValues,
                  resource: initialVm.resource,
                  selectedTaskType: taskType ?? null,
                });
              }),
              catchError(() => of(initialVm))
            )
          : EMPTY;

        const apiVm$ = forkJoin({
          resource: this.tasksService.getResourceById(id),
          types: taskTypes$,
        }).pipe(
          map(({ resource, types }) => {
            const resourceData = resource;
            const typeFromTable = stateTaskType;
            const rawTypeFromApi =
              this.taskTypesService.extractTaskTypeName(resourceData);
            const resolvedTaskTypeName =
              typeFromTable ||
              this.taskTypesService.resolveTaskTypeLabel(
                rawTypeFromApi,
                resourceData?.vendorName ?? resourceData?.['vendor'] ?? ''
              );

            const taskType = this.taskTypesService.findMatchingTaskType(types, {
              resolvedName: rawTypeFromApi || resolvedTaskTypeName,
            });

            this.selectedTaskType = taskType ?? null;

            const initialValues =
              this.buildInitialValuesFromResource(resourceData);

            return this.buildEditViewModel({
              task: this.buildTaskItem(id, resolvedTaskTypeName, resourceData),
              taskTypeId: taskType?.id ?? '',
              taskTypeName: resolvedTaskTypeName,
              initialValues,
              resource: resourceData,
              selectedTaskType: taskType ?? null,
            });
          }),
          catchError(() => {
            this.alertService.error(
              this.translateService.instant(
                'taskFlow.taskEdit.notifications.loadError'
              ),
              { keepAfterRouteChange: true }
            );
            return hasStatePrefill ? EMPTY : of(initialVm);
          })
        );

        return hasStatePrefill ? concat(prefillVm$, apiVm$) : apiVm$;
      })
    );

    this.viewModel = toSignal(
      merge(routeVm$, this.vmUpdates$).pipe(
        tap(vm => {
          this.latestViewModel = vm;
          this.selectedTaskType = vm.selectedTaskType;
          this.taskBreadcrumbName = String(
            vm.task?.name ?? vm.resource?.name ?? this.taskBreadcrumbName ?? ''
          ).trim();
        })
      ),
      { injector: this.injector }
    );
  }

  showCheckoutForEdit(): boolean {
    const lifecycleState =
      this.viewModel?.()?.resource?.lifecycleState ??
      this.viewModel?.()?.task?.lifecycleState ??
      '';

    return lifecycleState === 'CERTIFIED';
  }

  onCheckout(): void {
    const resourceId = this.route.snapshot.paramMap.get('id') ?? '';
    if (!resourceId || this.isSaving || this.isCertifying) {
      return;
    }

    this.showConfirmation(
      'taskFlow.taskEdit.confirmations.checkoutCertifiedTask.title',
      'taskFlow.taskEdit.confirmations.checkoutCertifiedTask.message'
    ).then(confirmed => {
      if (!confirmed) {
        return;
      }
      this.proceedWithCheckout(resourceId);
    });
  }

  private proceedWithCheckout(resourceId: string): void {
    this.isSaving = true;
    this.tasksService
      .checkoutTaskResource(resourceId, 'Checked out from task-flow edit task')
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: response => {
          this.isSaving = false;
          this.isFormDirty = false;
          this.alertService.success(
            this.translateService.instant(
              'taskFlow.taskEdit.notifications.checkoutSuccess'
            ),
            { keepAfterRouteChange: true }
          );
          const newId = response?.uniqueId ?? resourceId;
          this.taskFlowSharedService.navigateToTaskEdit(newId);
        },
        error: () => {
          this.isSaving = false;
          this.alertService.error(
            this.translateService.instant(
              'taskFlow.taskEdit.notifications.checkoutError'
            ),
            { keepAfterRouteChange: false }
          );
        },
      });
  }

  onSave(event: TaskActionPayload): void {
    if (!event?.taskType?.name) {
      return;
    }

    const inputDefinitions = Array.isArray(event?.inputs) ? event.inputs : [];
    if (inputDefinitions.length === 0) {
      return;
    }

    this.proceedWithSave(event.formData ?? {}, inputDefinitions);
  }

  private proceedWithSave(
    formData: Record<string, unknown>,
    inputDefinitions: Array<InputDefinition>
  ): void {
    const resourceId = this.route.snapshot.paramMap.get('id') ?? '';
    if (!resourceId) {
      return;
    }

    this.persistTaskInputs(resourceId, inputDefinitions, {
      onSuccess: updatedInputs => {
        const savedVm = this.buildSavedViewModel(formData, updatedInputs);

        this.isFormDirty = false;
        this.isNavigatingOnSuccess = false;
        this.formResetToken += 1;

        if (savedVm) {
          this.vmUpdates$.next(savedVm);
        }

        this.showSuccessNotification(
          'taskFlow.taskEdit.notifications.saveSuccess',
          false
        );
      },
      errorNotificationKey: 'taskFlow.taskEdit.notifications.saveError',
      componentName: 'TaskEditComponent Failed to update task inputs',
      keepErrorAfterRouteChange: false,
    });
  }

  onCertify(event: TaskActionPayload): void {
    const resourceId = this.route.snapshot.paramMap.get('id') ?? '';
    if (!resourceId || !event?.taskType?.name) {
      return;
    }

    this.runCertifyFlow({
      resourceId,
      inputs: event.inputs,
      auditMessage: 'Certified from task-flow edit task',
      successNotificationKey: 'taskFlow.taskEdit.notifications.certifySuccess',
      errorNotificationKey: 'taskFlow.taskEdit.notifications.certifyError',
      componentName: 'TaskEditComponent Failed to certify task',
    });
  }

  onDiscard(): void {
    this.navigateToTaskList();
  }

  onPaneResize(nextLeftPaneWidth: number): void {
    const paneWidths = this.resizeAndPersistPane({
      nextLeftPaneWidth,
      minPaneWidth: this.minPaneWidth,
      maxPaneWidth: this.maxPaneWidth,
      paneWidthStorageKey: this.paneWidthStorageKey,
    });

    this.leftPaneWidth = paneWidths.leftPaneWidth;
    this.rightPaneWidth = paneWidths.rightPaneWidth;
  }
}
