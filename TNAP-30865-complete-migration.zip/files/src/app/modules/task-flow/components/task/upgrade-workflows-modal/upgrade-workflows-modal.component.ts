/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  computed,
  Component,
  inject,
  Input,
  signal,
  ChangeDetectionStrategy,
  DestroyRef,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import { NgbActiveModal, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService, TranslateModule } from '@ngx-translate/core';
import { BadgeComponent } from '@portal-mfe/tnap-ui-kit/components/badge';
import { EMPTY } from 'rxjs';
import { catchError, finalize, switchMap } from 'rxjs/operators';
import { ComponentDependency } from 'openapi/output/model/componentDependency.model';
import { SdcComponentType } from 'openapi/output/model/sdcComponentType.model';
import { SdcLifecycleState } from 'openapi/output/model/sdcLifecycleState.model';
import { TaskFlowSharedService } from '../../../services/shared/task-flow-shared.service';
import { ComponentUpgradeRespone } from 'openapi/output/model/models';
import { SharedModule } from 'src/app/shared.module';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

type CertifiedTaskDependency = ComponentDependency & {
  dependencies: ComponentDependency[];
};

type DependencyRow = Omit<ComponentDependency, 'uniqueId'> & {
  uniqueId: string;
  selectable: boolean;
  selected: boolean;
};

type ComponentDependencyWithUniqueId = ComponentDependency & {
  uniqueId: string;
};

type TaskRow = {
  task: CertifiedTaskDependency;
  dependencies: DependencyRow[];
  selectableDependencyIds: string[];
  showTaskSelection: boolean;
  isFullySelected: boolean;
  isPartiallySelected: boolean;
};

@Component({
  selector: 'app-upgrade-workflows-modal',
  templateUrl: './upgrade-workflows-modal.component.html',
  styleUrls: ['./upgrade-workflows-modal.component.css'],
  standalone: true,
  imports: [
    CommonModule,
    TranslateModule,
    NgbTooltipModule,
    BadgeComponent,
    SharedModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UpgradeWorkflowsModalComponent {
  readonly taskNameValue = signal('');
  private readonly taskIdValue = signal('');
  readonly taskVersionValue = signal('');

  private readonly activeModal = inject(NgbActiveModal);
  private readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);
  private readonly taskFlowSharedService = inject(TaskFlowSharedService);
  private readonly destroyRef = inject(DestroyRef);

  readonly isLoading = signal(true);
  readonly isUpgrading = signal(false);
  readonly loadError = signal(false);
  readonly certifiedTasks = signal<CertifiedTaskDependency[]>([]);
  readonly selectedWorkflows = signal<Set<string>>(new Set());

  readonly taskRows = computed<TaskRow[]>(() => {
    const taskId = this.taskIdValue();
    const selected = this.selectedWorkflows();

    return this.certifiedTasks()
      .filter(task => task.uniqueId !== taskId && task.dependencies.length > 0)
      .map(task => {
        const dependencies = task.dependencies
          .filter(this.hasUniqueId)
          .map(dependency => ({
            ...dependency,
            uniqueId: dependency.uniqueId,
            selectable: dependency.state === SdcLifecycleState.CERTIFIED,
            selected: selected.has(dependency.uniqueId),
          }));
        const selectableDependencyIds = dependencies
          .filter(dependency => dependency.selectable)
          .map(dependency => dependency.uniqueId);

        return {
          task,
          dependencies,
          selectableDependencyIds,
          showTaskSelection: selectableDependencyIds.length > 1,
          isFullySelected:
            selectableDependencyIds.length > 0 &&
            selectableDependencyIds.every(id => selected.has(id)),
          isPartiallySelected:
            selectableDependencyIds.some(id => selected.has(id)) &&
            !(
              selectableDependencyIds.length > 0 &&
              selectableDependencyIds.every(id => selected.has(id))
            ),
        } satisfies TaskRow;
      });
  });

  readonly canUpgrade = computed(() => this.selectedWorkflows().size > 0);

  readonly hasDependencies = computed(() => this.taskRows().length > 0);

  private readonly hasUniqueId = (
    dependency: ComponentDependency
  ): dependency is ComponentDependencyWithUniqueId => !!dependency.uniqueId;

  constructor() {
    this.setupTaskDependenciesObservable();
  }

  private setupTaskDependenciesObservable(): void {
    toObservable(this.taskIdValue)
      .pipe(
        switchMap(taskId => {
          this.certifiedTasks.set([]);
          this.loadError.set(false);

          if (!taskId) {
            this.selectedWorkflows.set(new Set());
            this.isLoading.set(false);
            return EMPTY;
          }

          this.isLoading.set(true);
          return this.taskFlowSharedService
            .getComponentDependencies(taskId, SdcComponentType.RESOURCES)
            .pipe(
              catchError(() => {
                this.loadError.set(true);
                return EMPTY;
              }),
              finalize(() => this.isLoading.set(false))
            );
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe((response: ComponentDependency[]) => {
        const tasks = Array.isArray(response) ? response : [];
        const certifiedTasks = tasks
          .filter(
            task =>
              task.state === SdcLifecycleState.CERTIFIED && !!task.uniqueId
          )
          .map(task => ({
            ...task,
            dependencies: task.dependencies ?? [],
          }));
        this.certifiedTasks.set(certifiedTasks);
        this.selectedWorkflows.set(new Set());
      });
  }

  @Input()
  set taskId(value: string) {
    this.taskIdValue.set(value ?? '');
  }

  @Input()
  set taskName(value: string) {
    this.taskNameValue.set(value ?? '');
  }

  @Input()
  set taskVersion(value: string) {
    this.taskVersionValue.set(value ?? '');
  }

  toggleDependency(id: string): void {
    if (!id) {
      return;
    }

    const ids = new Set(this.selectedWorkflows());
    if (ids.has(id)) {
      ids.delete(id);
    } else {
      ids.add(id);
    }
    this.selectedWorkflows.set(ids);
  }

  toggleTaskSelection(depIds: string[]): void {
    if (depIds.length === 0) {
      return;
    }

    const selected = new Set(this.selectedWorkflows());
    const allSelected = depIds.every(id => selected.has(id));

    if (allSelected) {
      depIds.forEach(id => selected.delete(id));
    } else {
      depIds.forEach(id => selected.add(id));
    }
    this.selectedWorkflows.set(selected);
  }

  cancel(): void {
    this.activeModal.dismiss();
  }

  upgrade(): void {
    const taskId = this.taskIdValue();
    const workflows = Array.from(this.selectedWorkflows());

    if (!taskId || workflows.length === 0) {
      return;
    }

    this.isUpgrading.set(true);
    this.taskFlowSharedService
      .upgradeDependentComponent(
        taskId,
        SdcComponentType.RESOURCES,
        workflows.map(id => ({ serviceId: id }))
      )
      .pipe(
        finalize(() => this.isUpgrading.set(false)),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: (response: ComponentUpgradeRespone) => {
          this.alertService.success(
            this.translateService.instant(
              'taskFlow.tasks.upgradeWorkflows.successMessage'
            )
          );
          const workflowsToCertify =
            response.componentToUpgradeStatus?.map(w => w.uniqueId ?? '') ?? [];
          this.activeModal.close(workflowsToCertify);
        },
        error: () => {
          this.alertService.error(
            this.translateService.instant(
              'taskFlow.tasks.upgradeWorkflows.errorMessage'
            )
          );
        },
      });
  }
}
