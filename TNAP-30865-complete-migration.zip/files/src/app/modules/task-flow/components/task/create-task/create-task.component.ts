/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Component, inject, OnInit } from '@angular/core';
import {
  TaskType,
  TaskTypesService,
} from '../../../services/task/task-types.service';
import { takeUntil } from 'rxjs/operators';
import { TaskFlowOperationBaseComponent } from '../../taskflow-operation-base.component';
import { ComponentCanDeactivate } from 'src/app/guards/pending-changes.guard';
import { Resource } from 'openapi/output';
import { TaskActionPayload } from '../../../models';

@Component({
  selector: 'app-create-task',
  templateUrl: './create-task.component.html',
  styleUrls: ['./create-task.component.css'],
  standalone: false,
})
export class CreateTaskComponent
  extends TaskFlowOperationBaseComponent
  implements OnInit, ComponentCanDeactivate
{
  private readonly taskTypesService = inject(TaskTypesService);

  selectedTaskType: TaskType | null = null;
  isCreating = false;

  leftPaneWidth: number = 30;
  rightPaneWidth: number = 70;

  readonly minPaneWidth = 20;
  readonly maxPaneWidth = 70;
  private readonly paneWidthStorageKey =
    'task-flow:create-task:left-pane-width';

  ngOnInit(): void {
    this.leftPaneWidth = this.stateManager.getPersistedPaneWidth(
      this.paneWidthStorageKey,
      this.minPaneWidth,
      this.maxPaneWidth,
      this.leftPaneWidth
    );
    this.rightPaneWidth = 100 - this.leftPaneWidth;
  }

  onTaskTypeSelected(taskType: TaskType): void {
    this.selectedTaskType = taskType;
  }

  onCreate(event: TaskActionPayload): void {
    const vendorName = String(
      event.formData?.['vendorName'] ?? event.formData?.['vendor'] ?? ''
    ).trim();
    const taskTypeName = this.taskTypesService.getApiTaskTypeName(
      event?.taskType,
      vendorName
    );
    if (
      !taskTypeName ||
      !this.taskTypesService.isSupportedCreateApiTaskTypeName(taskTypeName)
    ) {
      return;
    }

    this.isCreating = true;
    this.tasksService
      .createTask(taskTypeName, event.formData)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: resource => {
          this.isCreating = false;
          const uniqueId = (resource as Resource)?.uniqueId;

          if (!uniqueId) {
            return;
          }

          this.isNavigatingOnSuccess = true;
          this.isFormDirty = false;

          const resolvedTaskTypeName =
            this.taskTypesService.resolveTaskTypeLabel(
              taskTypeName,
              vendorName
            );

          this.alertService.success(
            this.translateService.instant(
              'taskFlow.createTask.notifications.createSuccess'
            ),
            { keepAfterRouteChange: true }
          );

          this.taskFlowSharedService.navigateToTaskEdit(uniqueId, {
            state: {
              taskType: resolvedTaskTypeName,
              taskSummary: {
                uniqueId,
                name: String(event.formData?.['name'] ?? '').trim(),
                description: String(
                  event.formData?.['description'] ?? ''
                ).trim(),
                type: resolvedTaskTypeName,
                vendorName,
              },
            },
          });
        },
        error: () => {
          this.isCreating = false;
          this.alertService.error(
            this.translateService.instant(
              'taskFlow.createTask.notifications.createError'
            ),
            { keepAfterRouteChange: true }
          );
        },
      });
  }

  onCancel(): void {
    this.navigateToTaskList();
  }

  onPaneResize(nextLeftPaneWidth: number): void {
    const paneWidths = this.resizeAndPersistPane({
      nextLeftPaneWidth,
      minPaneWidth: this.minPaneWidth,
      maxPaneWidth: this.maxPaneWidth,
      paneWidthStorageKey: this.paneWidthStorageKey,
    });

    this.leftPaneWidth = paneWidths.leftPaneWidth;
    this.rightPaneWidth = paneWidths.rightPaneWidth;
  }
}
