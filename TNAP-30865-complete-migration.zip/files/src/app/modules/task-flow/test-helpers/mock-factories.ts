/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { of } from 'rxjs';
import { ServiceDesignAndCreationService } from 'openapi/output/api/api';
import { S3StorageService } from 'openapi/output/api/s3Storage.service';
import { TranslateService } from '@ngx-translate/core';
import { TaskFlowSharedService } from '../services/shared/task-flow-shared.service';
import { TaskTypesService } from '../services/task/task-types.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

/**
 * Factory functions for creating mocked services used in tests.
 * Centralizes mock creation to reduce duplication across spec files.
 */

export function createMockTaskFlowSharedService(): jasmine.SpyObj<TaskFlowSharedService> {
  return jasmine.createSpyObj('TaskFlowSharedService', [
    'loadTasks',
    'getResourceById',
    'getTaskTypes',
    'validateComponentName',
    'updateComponentInputs',
    'changeComponentState',
    'getComponentDependencies',
    'upgradeDependentComponent',
    'downloadWorkflowArtifact',
    'navigateToTaskEdit',
    'navigateToTaskList',
    'navigateToTaskCreate',
    'navigateToWorkflowEdit',
    'navigateToWorkflowList',
    'navigateToWorkflowCreate',
    'navigateToWorkflowInstances',
  ]);
}

export function createMockTaskTypesService(): jasmine.SpyObj<TaskTypesService> {
  return jasmine.createSpyObj('TaskTypesService', [
    'extractTaskTypeName',
    'resolveTaskTypeLabel',
    'resolveTaskType',
    'loadAllTaskTypes',
  ]);
}

export function createMockSdcService(): jasmine.SpyObj<ServiceDesignAndCreationService> {
  return jasmine.createSpyObj('ServiceDesignAndCreationService', [
    'getCatalogComponents',
    'createService',
    'getServiceById',
    'executeServiceWorkflow',
    'downloadServiceArtifact',
    'getResourceById',
    'validateResourceOrServiceName',
    'updateComponentInputs',
    'changeResourceState',
    'getComponentDependencies',
    'upgradeDependentTask',
    'addTaskComponentInstance',
    'deleteResourceInstance',
    'certifyDistribute',
    'listWorkflowRuns',
    'getWorkflowRunTasks',
  ]);
}

export function createMockS3StorageService(): jasmine.SpyObj<S3StorageService> {
  return jasmine.createSpyObj('S3StorageService', ['downloadS3Object']);
}

export function createMockAlertService(): jasmine.SpyObj<TnapAlertService> {
  return jasmine.createSpyObj('TnapAlertService', [
    'error',
    'success',
    'info',
    'warning',
  ]);
}

export function createMockTranslateService(): jasmine.SpyObj<TranslateService> {
  const spy = jasmine.createSpyObj('TranslateService', ['instant', 'get']);
  spy.instant.and.callFake((key: string) => key);
  spy.get.and.callFake((key: string) => of(key));
  return spy;
}
