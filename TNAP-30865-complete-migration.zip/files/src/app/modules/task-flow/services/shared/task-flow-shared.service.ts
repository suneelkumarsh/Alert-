/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Injectable, inject, OnDestroy } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import {
  catchError,
  EMPTY,
  map,
  Observable,
  of,
  shareReplay,
  Subject,
  takeUntil,
  throwError,
} from 'rxjs';
import {
  ComponentDependency,
  ComponentUpgradeRespone,
  InputDefinition,
  LifeCycleStateResponse,
  Resource,
  SdcComponentType,
  SdcIncludeType,
  SdcLifecycleOperation,
  ServiceDesignAndCreationService,
  UpgradeRequest,
} from 'openapi/output';
import { S3StorageService } from 'openapi/output/api/s3Storage.service';
import { TaskItem } from '../../models';
import { SKIP_GLOBAL_LOADING } from 'src/app/http-interceptors/loading-indicator.interceptor';
import { HttpContext } from '@angular/common/http';
import { TaskTypesService } from '../task/task-types.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';
import { TranslateService } from '@ngx-translate/core';

@Injectable({ providedIn: 'root' })
export class TaskFlowSharedService implements OnDestroy {
  private readonly sdcService = inject(ServiceDesignAndCreationService);
  private readonly s3StorageService = inject(S3StorageService);
  private readonly taskTypesService = inject(TaskTypesService);
  private readonly router = inject(Router);
  private readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);
  private readonly destroy$ = new Subject<void>();

  loadTasks(includedTypes?: Array<SdcIncludeType>): Observable<TaskItem[]> {
    return this.sdcService
      .getCatalogComponents(SdcComponentType.RESOURCES, includedTypes)
      .pipe(
        map((response: any) => {
          const resources = response?.resources || response?.body?.resources;
          if (!Array.isArray(resources)) {
            return [];
          }

          const sortedResources = [...resources].sort((a: any, b: any) => {
            const aLastUpdateDate = Number(a?.lastUpdateDate ?? 0);
            const bLastUpdateDate = Number(b?.lastUpdateDate ?? 0);
            return bLastUpdateDate - aLastUpdateDate;
          });

          return sortedResources
            .map((resource: any) => {
              const rawTaskType = this.taskTypesService.extractTaskTypeName(
                resource as Resource
              );
              const matchingTaskType =
                this.taskTypesService.resolveTaskType(rawTaskType);

              if (!matchingTaskType) {
                return null;
              }

              const taskType = this.taskTypesService.resolveTaskTypeLabel(
                rawTaskType,
                resource?.vendorName ?? resource?.vendor ?? ''
              );

              return {
                uniqueId: resource?.uniqueId ?? '',
                name: resource?.name ?? '',
                description: resource?.description ?? '',
                version: resource?.version ?? '',
                type: taskType,
                resourceType: String(resource?.resourceType ?? '').trim(),
                vendorName: resource?.vendorName ?? resource?.vendor ?? '',
                lifecycleState: resource?.lifecycleState ?? '',
              } as TaskItem;
            })
            .filter((task): task is TaskItem => task !== null);
        }),
        shareReplay({ refCount: true, bufferSize: 1 }),
        catchError(error => {
          return throwError(() => error);
        }),
        takeUntil(this.destroy$)
      );
  }

  getResourceById(
    resourceId: string,
    skipGlobalLoader = false
  ): Observable<Resource> {
    const normalizedResourceId = String(resourceId ?? '').trim();
    if (!normalizedResourceId) {
      throw new Error(
        '[TaskFlowSharedService] resourceId is required to load resource details.'
      );
    }

    return this.sdcService
      .getResourceById(normalizedResourceId, 'body', false, {
        context: new HttpContext().set(SKIP_GLOBAL_LOADING, skipGlobalLoader),
      })
      .pipe(
        takeUntil(this.destroy$),
        catchError(error => {
          return throwError(() => error);
        })
      );
  }

  getTaskTypes(tasks: TaskItem[]): string[] {
    return [...new Set(tasks.map(t => t.type).filter(Boolean))].sort((a, b) =>
      a.localeCompare(b, undefined, { sensitivity: 'base' })
    );
  }

  validateComponentName(
    componentType: SdcComponentType,
    name: string
  ): Observable<boolean> {
    return this.sdcService
      .validateResourceOrServiceName(componentType, name, 'body', false, {
        context: new HttpContext().set(SKIP_GLOBAL_LOADING, true),
      })
      .pipe(
        takeUntil(this.destroy$),
        catchError(() => {
          return of(false);
        })
      );
  }

  updateComponentInputs(
    componentType: SdcComponentType,
    id: string,
    inputs: Array<InputDefinition>
  ): Observable<Array<InputDefinition>> {
    return this.sdcService
      .updateComponentInputs(componentType, id, inputs as any[])
      .pipe(
        takeUntil(this.destroy$),
        catchError((error: any) => {
          return throwError(() => error);
        })
      );
  }

  changeComponentState(
    componentType: SdcComponentType,
    state: SdcLifecycleOperation,
    id: string,
    userRemarks: string = ''
  ): Observable<LifeCycleStateResponse> {
    return this.sdcService
      .changeResourceState(componentType, state, id, {
        userRemarks,
      })
      .pipe(
        takeUntil(this.destroy$),
        catchError((error: any) => {
          return throwError(() => error);
        })
      );
  }

  getComponentDependencies(
    id: string,
    componentType: SdcComponentType
  ): Observable<Array<ComponentDependency>> {
    return this.sdcService
      .getComponentDependencies(id, componentType, 'body', false, {
        context: new HttpContext().set(SKIP_GLOBAL_LOADING, true),
      })
      .pipe(takeUntil(this.destroy$));
  }

  upgradeDependentComponent(
    id: string,
    componentType: SdcComponentType,
    upgradeRequests: UpgradeRequest[]
  ): Observable<ComponentUpgradeRespone> {
    return this.sdcService
      .upgradeDependentTask(id, componentType, upgradeRequests, 'body', false, {
        context: new HttpContext().set(SKIP_GLOBAL_LOADING, true),
      })
      .pipe(takeUntil(this.destroy$));
  }

  downloadWorkflowArtifact(
    fileName: string,
    payload: 'payload' | 'day0'
  ): Observable<Blob> {
    const normalizedFileName = String(fileName ?? '').trim();
    if (!normalizedFileName) {
      this.alertService.error(
        this.translateService.instant(
          'taskFlow.workflow.error.artifactFileNameRequired'
        ),
        { keepAfterRouteChange: true }
      );
      return EMPTY;
    }

    return this.s3StorageService
      .downloadS3Object(payload, normalizedFileName)
      .pipe(
        takeUntil(this.destroy$),
        catchError(() => {
          this.alertService.error(
            this.translateService.instant(
              'taskFlow.workflow.error.artifactDownloadFailed',
              { fileName: normalizedFileName }
            ),
            { keepAfterRouteChange: true }
          );
          return EMPTY;
        })
      );
  }

  navigateToTaskEdit(taskId: string, extras?: NavigationExtras): void {
    this.router.navigate(['/task-flow/tasks', 'edit', taskId], extras);
  }

  navigateToTaskList(): void {
    this.router.navigate(['/task-flow/tasks']);
  }

  navigateToTaskCreate(): void {
    this.router.navigate(['/task-flow/tasks/create']);
  }

  navigateToWorkflowEdit(workflowId: string): void {
    this.router.navigate(['/task-flow/workflow', 'edit', workflowId]);
  }

  navigateToWorkflowList(): void {
    this.router.navigate(['/task-flow/workflow']);
  }

  navigateToWorkflowCreate(): void {
    this.router.navigate(['/task-flow/workflow/create']);
  }

  navigateToWorkflowInstances(workflowName: string): void {
    const normalizedWorkflowName = String(workflowName ?? '').trim();
    if (!normalizedWorkflowName) {
      return;
    }

    this.router.navigate([
      '/task-flow/workflow',
      normalizedWorkflowName,
      'instances',
    ]);
  }

  navigateToWorkflowInstanceDetails(
    workflowName: string,
    requestId: string,
    startTime?: string | null
  ): void {
    const normalizedWorkflowName = String(workflowName ?? '').trim();
    const normalizedRequestId = String(requestId ?? '').trim();
    if (!normalizedWorkflowName || !normalizedRequestId) {
      return;
    }

    this.router.navigate(
      [
        '/task-flow/workflow',
        normalizedWorkflowName,
        'instances',
        normalizedRequestId,
      ],
      startTime
        ? {
            state: {
              startTime,
            },
          }
        : undefined
    );
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
