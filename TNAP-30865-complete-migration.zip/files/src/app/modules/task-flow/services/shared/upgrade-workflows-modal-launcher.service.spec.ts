/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { TestBed } from '@angular/core/testing';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { of, Subject, throwError } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { UpgradeWorkflowsModalComponent } from '../../components/task/upgrade-workflows-modal/upgrade-workflows-modal.component';
import { UpgradeWorkflowsModalLauncherService } from './upgrade-workflows-modal-launcher.service';
import { WorkflowService } from '../workflow/workflow.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('UpgradeWorkflowsModalLauncherService', () => {
  let service: UpgradeWorkflowsModalLauncherService;
  let modalService: jasmine.SpyObj<NgbModal>;
  let workflowService: jasmine.SpyObj<WorkflowService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let translateService: jasmine.SpyObj<TranslateService>;
  let closed$: Subject<unknown>;
  let dismissed$: Subject<unknown>;
  let modalRef: any;

  beforeEach(() => {
    modalService = jasmine.createSpyObj('NgbModal', ['open']);
    workflowService = jasmine.createSpyObj('WorkflowService', [
      'certifyAndDistributeWorkflow',
    ]);
    alertService = jasmine.createSpyObj('TnapAlertService', ['error']);
    translateService = jasmine.createSpyObj('TranslateService', ['instant']);
    translateService.instant.and.callFake((key: string) => key);
    workflowService.certifyAndDistributeWorkflow.and.returnValue(of({} as any));
    closed$ = new Subject<unknown>();
    dismissed$ = new Subject<unknown>();
    modalRef = {
      componentInstance: {},
      closed: closed$.asObservable(),
      dismissed: dismissed$.asObservable(),
    };
    modalService.open.and.returnValue(modalRef);

    TestBed.configureTestingModule({
      providers: [
        UpgradeWorkflowsModalLauncherService,
        { provide: NgbModal, useValue: modalService },
        { provide: WorkflowService, useValue: workflowService },
        { provide: TnapAlertService, useValue: alertService },
        { provide: TranslateService, useValue: translateService },
      ],
    });

    service = TestBed.inject(UpgradeWorkflowsModalLauncherService);
  });

  it('should open modal with expected options and payload values', () => {
    let completed = false;

    service
      .open({
        taskId: 'task-123',
        taskName: 'Task Name',
        taskVersion: '2.0',
      })
      .subscribe({
        complete: () => {
          completed = true;
        },
      });

    expect(modalService.open).toHaveBeenCalledWith(
      UpgradeWorkflowsModalComponent,
      jasmine.objectContaining({
        ariaLabelledBy: 'upgrade-workflows-modal-title',
        size: 'lg',
        centered: true,
        backdrop: true,
        windowClass: 'upgrade-workflows-modal-window',
        backdropClass: 'upgrade-workflows-modal-backdrop',
        keyboard: true,
      })
    );
    expect(modalRef.componentInstance.taskId).toBe('task-123');
    expect(modalRef.componentInstance.taskName).toBe('Task Name');
    expect(modalRef.componentInstance.taskVersion).toBe('2.0');
    expect(completed).toBeFalse();
  });

  it('should complete when modal is closed', () => {
    let completed = false;

    service.open({ taskId: 'task-123' }).subscribe({
      complete: () => {
        completed = true;
      },
    });

    closed$.next(undefined);

    expect(completed).toBeTrue();
    expect(modalRef.componentInstance.taskName).toBe('');
    expect(modalRef.componentInstance.taskVersion).toBe('');
  });

  it('should complete when modal is dismissed', () => {
    let completed = false;

    service.open({ taskId: 'task-123' }).subscribe({
      complete: () => {
        completed = true;
      },
    });

    dismissed$.next(undefined);

    expect(completed).toBeTrue();
  });

  it('should trigger background certification with workflow IDs when modal closes', () => {
    service.open({ taskId: 'task-123' }).subscribe();

    closed$.next(['workflow-1', 'workflow-2']);

    expect(workflowService.certifyAndDistributeWorkflow).toHaveBeenCalledTimes(
      2
    );
    expect(workflowService.certifyAndDistributeWorkflow).toHaveBeenCalledWith(
      'workflow-1',
      'taskFlow.tasks.upgradeWorkflows.certificationComment',
      true
    );
    expect(workflowService.certifyAndDistributeWorkflow).toHaveBeenCalledWith(
      'workflow-2',
      'taskFlow.tasks.upgradeWorkflows.certificationComment',
      true
    );
  });

  it('should not trigger certification when modal closes with empty workflow IDs', () => {
    service.open({ taskId: 'task-123' }).subscribe();

    closed$.next([]);

    expect(workflowService.certifyAndDistributeWorkflow).not.toHaveBeenCalled();
  });

  it('should not trigger certification when modal is dismissed', () => {
    service.open({ taskId: 'task-123' }).subscribe();

    dismissed$.next(undefined);

    expect(workflowService.certifyAndDistributeWorkflow).not.toHaveBeenCalled();
  });

  it('should show an error alert when a certification fails', () => {
    workflowService.certifyAndDistributeWorkflow.and.returnValue(
      throwError(() => new Error('certify failed'))
    );
    service.open({ taskId: 'task-123' }).subscribe();

    closed$.next(['workflow-1']);

    expect(alertService.error).toHaveBeenCalledWith(
      'taskFlow.tasks.upgradeWorkflows.certificationErrorMessage'
    );
  });

  it('should not show an error alert when all certifications succeed', () => {
    workflowService.certifyAndDistributeWorkflow.and.returnValue(of({} as any));
    service.open({ taskId: 'task-123' }).subscribe();

    closed$.next(['workflow-1']);

    expect(alertService.error).not.toHaveBeenCalled();
  });
});
