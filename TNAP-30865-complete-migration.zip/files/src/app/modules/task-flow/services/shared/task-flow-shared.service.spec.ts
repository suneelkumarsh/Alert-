/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { S3StorageService } from 'openapi/output/api/s3Storage.service';
import { ServiceDesignAndCreationService } from 'openapi/output/api/serviceDesignAndCreation.service';
import { of, throwError } from 'rxjs';
import { HttpEvent } from '@angular/common/http';
import {
  InputDefinition,
  SdcComponentType,
  SdcIncludeType,
  SdcLifecycleOperation,
} from 'openapi/output/model/models';
import { ComponentDependency } from 'openapi/output/model/componentDependency.model';
import { ComponentUpgradeRespone } from 'openapi/output/model/componentUpgradeRespone.model';
import { UpgradeRequest } from 'openapi/output/model/upgradeRequest.model';
import { SKIP_GLOBAL_LOADING } from 'src/app/http-interceptors/loading-indicator.interceptor';
import { TaskTypesService } from '../task/task-types.service';
import { TaskItem } from '../../models';
import { TaskFlowSharedService } from './task-flow-shared.service';
import {
  createMockSdcService,
  createMockTaskTypesService,
  createMockS3StorageService,
} from '../../test-helpers/mock-factories';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';
import { TranslateService } from '@ngx-translate/core';

describe('TaskFlowSharedService', () => {
  let service: TaskFlowSharedService;
  let sdcService: jasmine.SpyObj<ServiceDesignAndCreationService>;
  let s3StorageService: jasmine.SpyObj<S3StorageService>;
  let taskTypesService: jasmine.SpyObj<TaskTypesService>;
  let router: jasmine.SpyObj<Router>;
  let alertService: jasmine.SpyObj<TnapAlertService>;

  beforeEach(() => {
    const sdcSpy = createMockSdcService();
    const s3Spy = createMockS3StorageService();
    const taskTypesSpy = createMockTaskTypesService();
    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);
    const alertSpy = jasmine.createSpyObj<TnapAlertService>(
      'TnapAlertService',
      ['error']
    );

    TestBed.configureTestingModule({
      providers: [
        TaskFlowSharedService,
        { provide: ServiceDesignAndCreationService, useValue: sdcSpy },
        { provide: S3StorageService, useValue: s3Spy },
        { provide: TaskTypesService, useValue: taskTypesSpy },
        { provide: Router, useValue: routerSpy },
        { provide: TnapAlertService, useValue: alertSpy },
        {
          provide: TranslateService,
          useValue: { instant: (key: string) => key },
        },
      ],
    });

    service = TestBed.inject(TaskFlowSharedService);
    sdcService = TestBed.inject(
      ServiceDesignAndCreationService
    ) as jasmine.SpyObj<ServiceDesignAndCreationService>;
    s3StorageService = TestBed.inject(
      S3StorageService
    ) as jasmine.SpyObj<S3StorageService>;
    taskTypesService = TestBed.inject(
      TaskTypesService
    ) as jasmine.SpyObj<TaskTypesService>;
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>;
    alertService = TestBed.inject(
      TnapAlertService
    ) as jasmine.SpyObj<TnapAlertService>;

    taskTypesService.extractTaskTypeName.and.callFake(
      (resource: Record<string, unknown>) =>
        String(resource['resolvedType'] ?? '')
    );
    taskTypesService.resolveTaskType.and.callFake((taskTypeName: string) => {
      if (taskTypeName === 'UnsupportedTaskType') {
        return undefined;
      }

      return { id: taskTypeName, name: taskTypeName } as any;
    });
    taskTypesService.resolveTaskTypeLabel.and.callFake(
      (taskTypeName: string, vendorName?: string) =>
        `${String(vendorName ?? '').trim()} ${taskTypeName}`.trim()
    );
  });

  it('should navigate to task edit route', () => {
    service.navigateToTaskEdit('task-1');

    expect(router.navigate).toHaveBeenCalledWith(
      ['/task-flow/tasks', 'edit', 'task-1'],
      undefined
    );
  });

  it('should navigate to task list route', () => {
    service.navigateToTaskList();

    expect(router.navigate).toHaveBeenCalledWith(['/task-flow/tasks']);
  });

  it('should navigate to task create route', () => {
    service.navigateToTaskCreate();

    expect(router.navigate).toHaveBeenCalledWith(['/task-flow/tasks/create']);
  });

  it('should navigate to workflow edit route', () => {
    service.navigateToWorkflowEdit('workflow-1');

    expect(router.navigate).toHaveBeenCalledWith([
      '/task-flow/workflow',
      'edit',
      'workflow-1',
    ]);
  });

  it('should navigate to workflow list route', () => {
    service.navigateToWorkflowList();

    expect(router.navigate).toHaveBeenCalledWith(['/task-flow/workflow']);
  });

  it('should navigate to workflow create route', () => {
    service.navigateToWorkflowCreate();

    expect(router.navigate).toHaveBeenCalledWith([
      '/task-flow/workflow/create',
    ]);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should map, sort and filter tasks in loadTasks', done => {
    sdcService.getCatalogComponents.and.returnValue(
      of({
        resources: [
          {
            uniqueId: '3',
            name: 'Ignored',
            description: 'd3',
            version: '1.0',
            vendorName: 'V3',
            lifecycleState: 'CERTIFIED',
            lastUpdateDate: 300,
            resolvedType: 'UnsupportedTaskType',
          },
          {
            uniqueId: '1',
            name: 'Older',
            description: 'd1',
            version: '1.0',
            vendorName: 'V1',
            lifecycleState: 'NOT_CERTIFIED_CHECKIN',
            lastUpdateDate: 100,
            resolvedType: 'DayZeroGenerationTask',
          },
          {
            uniqueId: '2',
            name: 'Newer',
            description: 'd2',
            version: '1.1',
            vendor: 'V2',
            lifecycleState: 'CERTIFIED',
            lastUpdateDate: 200,
            resolvedType: 'RANTemplateExecutionTask',
          },
        ],
      } as any)
    );

    service.loadTasks().subscribe(tasks => {
      expect(tasks.length).toBe(2);
      expect(tasks[0].uniqueId).toBe('2');
      expect(tasks[0].vendorName).toBe('V2');
      expect(tasks[0].type).toBe('V2 RANTemplateExecutionTask');
      expect(tasks[1].uniqueId).toBe('1');
      expect(tasks[1].type).toBe('V1 DayZeroGenerationTask');
      expect(sdcService.getCatalogComponents).toHaveBeenCalledWith(
        'resources',
        undefined
      );
      done();
    });
  });

  it('should return empty array when catalog response does not contain an array', done => {
    sdcService.getCatalogComponents.and.returnValue(of({ body: {} } as any));

    service.loadTasks().subscribe(tasks => {
      expect(tasks).toEqual([]);
      done();
    });
  });

  it('should rethrow loadTasks API errors', done => {
    spyOn(console, 'error');
    sdcService.getCatalogComponents.and.returnValue(
      throwError(() => new Error('catalog failure'))
    );

    service.loadTasks().subscribe({
      next: () => fail('Expected loadTasks to fail'),
      error: error => {
        expect(error).toBeTruthy();
        done();
      },
    });
  });

  it('should throw when resource id is empty', () => {
    expect(() => service.getResourceById('   ')).toThrowError(
      '[TaskFlowSharedService] resourceId is required to load resource details.'
    );
  });

  it('should request resource by id and set skip loader context', done => {
    sdcService.getResourceById.and.returnValue(
      of({ uniqueId: 'res-1' } as any)
    );

    service.getResourceById('  res-1  ', true).subscribe(resource => {
      expect(resource.uniqueId).toBe('res-1');
      const callArgs = sdcService.getResourceById.calls.mostRecent().args;
      expect(callArgs[0]).toBe('res-1');
      expect(callArgs[1] as string).toBe('body');
      expect(callArgs[2]).toBe(false);
      expect(callArgs[3]).toBeDefined();
      expect(callArgs[3]!.context!.get(SKIP_GLOBAL_LOADING)).toBeTrue();
      done();
    });
  });

  it('should return unique sorted task types', () => {
    const tasks: TaskItem[] = [
      { type: 'RANTemplateExecutionTask' } as TaskItem,
      { type: 'DayZeroGenerationTask' } as TaskItem,
      { type: 'RANTemplateExecutionTask' } as TaskItem,
    ];

    expect(service.getTaskTypes(tasks)).toEqual([
      'DayZeroGenerationTask',
      'RANTemplateExecutionTask',
    ]);
  });

  it('should validate component name using SDC service', done => {
    sdcService.validateResourceOrServiceName.and.returnValue(of(true) as any);

    service
      .validateComponentName('resources' as SdcComponentType, 'task-name')
      .subscribe(isValid => {
        expect(isValid).toBeTrue();
        done();
      });
  });

  it('should return false when validate component name fails', done => {
    spyOn(console, 'error');
    sdcService.validateResourceOrServiceName.and.returnValue(
      throwError(() => new Error('validation failed')) as any
    );

    service
      .validateComponentName('resources' as SdcComponentType, 'task-name')
      .subscribe(isValid => {
        expect(isValid).toBeFalse();
        done();
      });
  });

  it('should update component inputs', done => {
    const inputs = [{ name: 'field-1' }] as Array<InputDefinition>;
    sdcService.updateComponentInputs.and.returnValue(of(inputs) as any);

    service
      .updateComponentInputs('resources' as SdcComponentType, 'res-1', inputs)
      .subscribe(result => {
        expect(result).toEqual(inputs);
        done();
      });
  });

  it('should rethrow update component input errors', done => {
    spyOn(console, 'error');
    sdcService.updateComponentInputs.and.returnValue(
      throwError(() => new Error('update failed')) as any
    );

    service
      .updateComponentInputs('resources' as SdcComponentType, 'res-1', [])
      .subscribe({
        next: () => fail('Expected updateComponentInputs to fail'),
        error: () => {
          done();
        },
      });
  });

  it('should change component lifecycle state', done => {
    sdcService.changeResourceState.and.returnValue(
      of({ lifecycleState: 'CERTIFIED' } as any)
    );

    service
      .changeComponentState(
        'resources' as SdcComponentType,
        'certify' as SdcLifecycleOperation,
        'res-1',
        'remarks'
      )
      .subscribe(result => {
        expect(result.lifecycleState).toBe('CERTIFIED');
        expect(sdcService.changeResourceState).toHaveBeenCalledWith(
          'resources',
          'certify',
          'res-1',
          { userRemarks: 'remarks' }
        );
        done();
      });
  });

  it('should complete destroy subject on destroy', () => {
    spyOn((service as any).destroy$, 'next');
    spyOn((service as any).destroy$, 'complete');

    service.ngOnDestroy();

    expect((service as any).destroy$.next).toHaveBeenCalled();
    expect((service as any).destroy$.complete).toHaveBeenCalled();
  });

  it('should fetch component dependencies with skip loader context', done => {
    const mockDeps: ComponentDependency[] = [
      { uniqueId: 'dep-1' } as ComponentDependency,
    ];
    sdcService.getComponentDependencies.and.returnValue(of(mockDeps) as any);

    service
      .getComponentDependencies('res-1', SdcComponentType.RESOURCES)
      .subscribe(deps => {
        expect(deps).toEqual(mockDeps);
        const callArgs =
          sdcService.getComponentDependencies.calls.mostRecent().args;
        expect(callArgs[0]).toBe('res-1');
        expect(callArgs[1]).toBe(SdcComponentType.RESOURCES);
        expect(callArgs[4]!.context!.get(SKIP_GLOBAL_LOADING)).toBeTrue();
        done();
      });
  });

  it('should upgrade dependent component and return response', done => {
    const upgradeResponse: ComponentUpgradeRespone = {
      componentToUpgradeStatus: [{ uniqueId: 'wf-1' }],
    } as ComponentUpgradeRespone;
    const upgradeRequests: UpgradeRequest[] = [{ serviceId: 'wf-1' }];
    sdcService.upgradeDependentTask.and.returnValue(of(upgradeResponse) as any);

    service
      .upgradeDependentComponent(
        'res-1',
        SdcComponentType.RESOURCES,
        upgradeRequests
      )
      .subscribe(result => {
        expect(result).toEqual(upgradeResponse);
        const callArgs =
          sdcService.upgradeDependentTask.calls.mostRecent().args;
        expect(callArgs[0]).toBe('res-1');
        expect(callArgs[1]).toBe(SdcComponentType.RESOURCES);
        expect(callArgs[2]).toEqual(upgradeRequests);
        expect(callArgs[5]!.context!.get(SKIP_GLOBAL_LOADING)).toBeTrue();
        done();
      });
  });

  it('should handle error when fetching component dependencies', done => {
    sdcService.getComponentDependencies.and.returnValue(
      throwError(() => new Error('dependencies fetch failed')) as any
    );

    service
      .getComponentDependencies('res-1', SdcComponentType.RESOURCES)
      .subscribe({
        next: () => fail('Expected error'),
        error: () => {
          expect(sdcService.getComponentDependencies).toHaveBeenCalled();
          done();
        },
      });
  });

  it('should handle error when upgrading dependent component', done => {
    const upgradeRequests: UpgradeRequest[] = [{ serviceId: 'wf-1' }];
    sdcService.upgradeDependentTask.and.returnValue(
      throwError(() => new Error('upgrade failed')) as any
    );

    service
      .upgradeDependentComponent(
        'res-1',
        SdcComponentType.RESOURCES,
        upgradeRequests
      )
      .subscribe({
        next: () => fail('Expected error'),
        error: () => {
          expect(sdcService.upgradeDependentTask).toHaveBeenCalled();
          done();
        },
      });
  });

  it('should download workflow artifact from S3 with payload type', done => {
    const mockBlob = new Blob(['test'], { type: 'application/zip' });
    const mockHttpEvent = { body: mockBlob } as HttpEvent<Blob>;
    s3StorageService.downloadS3Object.and.returnValue(of(mockHttpEvent));

    service
      .downloadWorkflowArtifact('artifact.zip', 'payload')
      .subscribe(event => {
        expect(s3StorageService.downloadS3Object).toHaveBeenCalledWith(
          'payload',
          'artifact.zip'
        );
        expect(event as any).toBe(mockHttpEvent);
        done();
      });
  });

  it('should download workflow artifact from S3 with day0 type', done => {
    const mockBlob = new Blob(['test'], { type: 'application/zip' });
    const mockHttpEvent = { body: mockBlob } as HttpEvent<Blob>;
    s3StorageService.downloadS3Object.and.returnValue(of(mockHttpEvent));

    service
      .downloadWorkflowArtifact('artifact.zip', 'day0')
      .subscribe(event => {
        expect(s3StorageService.downloadS3Object).toHaveBeenCalledWith(
          'day0',
          'artifact.zip'
        );
        expect(event as any).toBe(mockHttpEvent);
        done();
      });
  });

  it('should show required-filename alert and complete without emitting when filename is blank', done => {
    service.downloadWorkflowArtifact('   ', 'payload').subscribe({
      next: () => fail('Expected no emission for blank filename'),
      error: () => fail('Expected clean completion, not an error'),
      complete: () => {
        expect(s3StorageService.downloadS3Object).not.toHaveBeenCalled();
        expect(alertService.error).toHaveBeenCalledWith(
          'taskFlow.workflow.error.artifactFileNameRequired',
          { keepAfterRouteChange: true }
        );
        done();
      },
    });
  });

  it('should show an error alert and complete without error when S3 download fails', done => {
    s3StorageService.downloadS3Object.and.returnValue(
      throwError(() => new Error('S3 download failed'))
    );

    service.downloadWorkflowArtifact('artifact.zip', 'payload').subscribe({
      next: () => fail('Expected no emission on S3 error'),
      error: () => fail('Expected observable to complete cleanly, not error'),
      complete: () => {
        expect(s3StorageService.downloadS3Object).toHaveBeenCalled();
        expect(alertService.error).toHaveBeenCalledWith(
          'taskFlow.workflow.error.artifactDownloadFailed',
          { keepAfterRouteChange: true }
        );
        done();
      },
    });
  });

  it('should navigate to workflow instances with the configured route path', () => {
    service.navigateToWorkflowInstances('workflow-1');

    expect(router.navigate).toHaveBeenCalledWith([
      '/task-flow/workflow',
      'workflow-1',
      'instances',
    ]);
  });

  it('should navigate to workflow instance details with the configured route path', () => {
    service.navigateToWorkflowInstanceDetails(
      'workflow-1',
      'request-1',
      '2024-01-01T00:00:00Z'
    );

    expect(router.navigate).toHaveBeenCalledWith(
      ['/task-flow/workflow', 'workflow-1', 'instances', 'request-1'],
      { state: { startTime: '2024-01-01T00:00:00Z' } }
    );
  });

  it('should load tasks with includedTypes parameter', done => {
    sdcService.getCatalogComponents.and.returnValue(
      of({
        resources: [
          {
            uniqueId: '1',
            name: 'Task One',
            description: 'd1',
            version: '1.0',
            vendorName: 'V1',
            lifecycleState: 'CERTIFIED',
            lastUpdateDate: 100,
            resolvedType: 'RANTemplateExecutionTask',
          },
        ],
      } as any)
    );

    const includedTypes: SdcIncludeType[] = [SdcIncludeType.CR];
    service.loadTasks(includedTypes).subscribe(tasks => {
      expect(sdcService.getCatalogComponents).toHaveBeenCalledWith(
        'resources',
        includedTypes
      );
      expect(tasks.length).toBe(1);
      done();
    });
  });

  it('should get resource by id without skipGlobalLoader', done => {
    sdcService.getResourceById.and.returnValue(
      of({ uniqueId: 'res-1' } as any)
    );

    service.getResourceById('res-1').subscribe(resource => {
      expect(resource.uniqueId).toBe('res-1');
      const callArgs = sdcService.getResourceById.calls.mostRecent().args;
      expect(callArgs[0]).toBe('res-1');
      expect(callArgs[3]!.context!.get(SKIP_GLOBAL_LOADING)).toBeFalse();
      done();
    });
  });

  it('should change component state with default empty remarks', done => {
    sdcService.changeResourceState.and.returnValue(
      of({ lifecycleState: 'CERTIFIED' } as any)
    );

    service
      .changeComponentState(
        'resources' as SdcComponentType,
        'certify' as SdcLifecycleOperation,
        'res-1'
      )
      .subscribe(result => {
        expect(result.lifecycleState).toBe('CERTIFIED');
        expect(sdcService.changeResourceState).toHaveBeenCalledWith(
          'resources',
          'certify',
          'res-1',
          { userRemarks: '' }
        );
        done();
      });
  });
});
