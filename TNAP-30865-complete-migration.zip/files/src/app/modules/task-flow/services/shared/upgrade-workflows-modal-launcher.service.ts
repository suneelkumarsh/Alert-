/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Injectable, inject } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { forkJoin, merge, Observable, of } from 'rxjs';
import { catchError, map, take } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { UpgradeWorkflowsModalComponent } from '../../components/task/upgrade-workflows-modal/upgrade-workflows-modal.component';
import { WorkflowService } from '../workflow/workflow.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

export type UpgradeWorkflowsModalPayload = {
  taskId: string;
  taskName?: string;
  taskVersion?: string;
};

@Injectable({ providedIn: 'root' })
export class UpgradeWorkflowsModalLauncherService {
  private readonly modalService = inject(NgbModal);
  private readonly workflowService = inject(WorkflowService);
  private readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);

  open(payload: UpgradeWorkflowsModalPayload): Observable<void> {
    const modalRef = this.modalService.open(UpgradeWorkflowsModalComponent, {
      ariaLabelledBy: 'upgrade-workflows-modal-title',
      size: 'lg',
      centered: true,
      backdrop: true,
      windowClass: 'upgrade-workflows-modal-window',
      backdropClass: 'upgrade-workflows-modal-backdrop',
      keyboard: true,
    });

    modalRef.componentInstance.taskId = payload.taskId;
    modalRef.componentInstance.taskName = payload.taskName ?? '';
    modalRef.componentInstance.taskVersion = payload.taskVersion ?? '';

    modalRef.closed.pipe(take(1)).subscribe((workflowIds: string[]) => {
      this.certifyUpgradedWorkflows(workflowIds ?? []);
    });

    return merge(modalRef.closed, modalRef.dismissed).pipe(
      take(1),
      map(() => void 0)
    );
  }

  private certifyUpgradedWorkflows(workflowIds: string[]): void {
    if (!Array.isArray(workflowIds) || workflowIds.length === 0) {
      return;
    }

    const certificationRequests = workflowIds.map(id =>
      this.workflowService
        .certifyAndDistributeWorkflow(
          id,
          this.translateService.instant(
            'taskFlow.tasks.upgradeWorkflows.certificationComment'
          ),
          true
        )
        .pipe(
          map(() => true as const),
          catchError(() => of(false as const))
        )
    );

    forkJoin(certificationRequests).subscribe(results => {
      if (results.some(success => !success)) {
        this.alertService.error(
          this.translateService.instant(
            'taskFlow.tasks.upgradeWorkflows.certificationErrorMessage'
          )
        );
      }
    });
  }
}
