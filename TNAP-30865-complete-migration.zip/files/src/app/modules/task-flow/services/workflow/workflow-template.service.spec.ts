/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { TranslateService } from '@ngx-translate/core';
import { of, throwError } from 'rxjs';
import { CatalogService } from 'openapi/output';
import { WorkflowService } from './workflow.service';
import { WorkflowTemplateService } from './workflow-template.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('WorkflowTemplateService', () => {
  let service: WorkflowTemplateService;
  let workflowService: jasmine.SpyObj<WorkflowService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let translateService: jasmine.SpyObj<TranslateService>;

  const createService = (): WorkflowTemplateService =>
    TestBed.runInInjectionContext(() => new WorkflowTemplateService());

  const mockWorkflows: CatalogService[] = [
    {
      uniqueId: 'w1',
      name: 'Workflow One',
      description: 'desc-1',
      lifecycleState: 'CERTIFIED',
      distributionStatus: 'DISTRIBUTED',
      tags: ['alpha'],
    } as CatalogService,
    {
      uniqueId: 'w2',
      name: 'Workflow Two',
      description: 'desc-2',
      lifecycleState: 'NOT_CERTIFIED_CHECKOUT',
      distributionStatus: 'NOT_DISTRIBUTED',
      tags: ['beta'],
    } as CatalogService,
  ];

  beforeEach(() => {
    const workflowServiceSpy = jasmine.createSpyObj('WorkflowService', [
      'loadWorkflows',
      'getCategories',
      'getSubCategories',
      'getLifecycleStates',
      'filterWorkflows',
      'executeWorkflowDirect',
      'executeWorkflowDistributed',
    ]);
    const alertServiceSpy = jasmine.createSpyObj('TnapAlertService', [
      'error',
      'success',
    ]);
    const translateServiceSpy = jasmine.createSpyObj('TranslateService', [
      'instant',
    ]);

    TestBed.configureTestingModule({
      providers: [
        WorkflowTemplateService,
        { provide: WorkflowService, useValue: workflowServiceSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
      ],
    });

    workflowService = TestBed.inject(
      WorkflowService
    ) as jasmine.SpyObj<WorkflowService>;
    alertService = TestBed.inject(
      TnapAlertService
    ) as jasmine.SpyObj<TnapAlertService>;
    translateService = TestBed.inject(
      TranslateService
    ) as jasmine.SpyObj<TranslateService>;

    translateService.instant.and.callFake((key: string) => key);
    workflowService.loadWorkflows.and.returnValue(of(mockWorkflows));
    workflowService.getCategories.and.returnValue(['TaskWorkflow']);
    workflowService.getSubCategories.and.returnValue(['SubA']);
    workflowService.getLifecycleStates.and.returnValue([
      'CERTIFIED' as any,
      'NOT_CERTIFIED_CHECKOUT' as any,
    ]);
    workflowService.filterWorkflows.and.callFake(
      (workflows, _status, _search, page, pageSize) => {
        const startIndex = (page - 1) * pageSize;
        return {
          items: workflows.slice(startIndex, startIndex + pageSize),
          totalCount: workflows.length,
        };
      }
    );
    workflowService.executeWorkflowDirect.and.returnValue(of({} as any));
    workflowService.executeWorkflowDistributed.and.returnValue(of({} as any));

    service = createService();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should emit statuses from workflow service', done => {
    service.statuses$.subscribe(statuses => {
      expect(statuses).toEqual(['CERTIFIED', 'NOT_CERTIFIED_CHECKOUT']);
      expect(workflowService.getLifecycleStates).toHaveBeenCalledWith(
        mockWorkflows
      );
      done();
    });
  });

  it('should set search/status filters and pagination state', () => {
    service.setSearchFilter('one');
    service.setStatusFilter('CERTIFIED');
    service.setPage(2);
    service.setPageSize(5);

    expect(service.stateService.filters.getCurrentSearch()).toBe('one');
    expect(service.stateService.pagination.getCurrentPage()).toBe(2);
    expect(service.stateService.pagination.getCurrentPageSize()).toBe(5);
  });

  it('should reset filters and pagination', done => {
    service.setSearchFilter('abc');
    service.setStatusFilter('CERTIFIED');
    service.setPage(4);

    service.resetFilters();

    expect(service.stateService.pagination.getCurrentPage()).toBe(1);
    service.stateService.filters.status.subscribe(status => {
      expect(status).toBe('');
      service.stateService.filters.search.subscribe(search => {
        expect(search).toBe('');
        done();
      });
    });
  });

  it('should emit filtered results and call filterWorkflows with state', fakeAsync(() => {
    let result: any;
    service.setStatusFilter('CERTIFIED');
    service.setSearchFilter('workflow');

    service.filteredResults$.subscribe(res => {
      result = res;
    });

    tick(400);

    expect(workflowService.filterWorkflows).toHaveBeenCalled();
    expect(result.totalCount).toBe(2);
    expect(result.items.length).toBe(2);
  }));

  it('should handle workflow load errors and return fallback values', done => {
    workflowService.loadWorkflows.and.returnValue(
      throwError(() => new Error('load failed'))
    );
    workflowService.getLifecycleStates.and.returnValue([]);
    service = createService();

    service.statuses$.subscribe(statuses => {
      expect(statuses).toEqual([]);
      expect(alertService.error).toHaveBeenCalled();
      done();
    });
  });

  it('should handle filter errors and return empty filtered result', fakeAsync(() => {
    workflowService.filterWorkflows.and.throwError('filter failed');
    service = createService();

    let result: any;
    service.filteredResults$.subscribe(res => {
      result = res;
    });

    tick(400);

    expect(alertService.error).toHaveBeenCalled();
    expect(result).toEqual({ items: [], totalCount: 0 });
  }));

  it('should emit reload trigger when reload is called', () => {
    spyOn(service['reload$'], 'next');

    service.reload();

    expect(service['reload$'].next).toHaveBeenCalled();
  });

  it('should open Temporal UI in a new tab', () => {
    const openSpy = spyOn(window, 'open');

    service.openTemporalUi('MyWorkflow');

    expect(openSpy).toHaveBeenCalled();
    const [url, target] = openSpy.calls.mostRecent().args;
    expect(String(url)).toContain('MyWorkflow');
    expect(target).toBe('_blank');
  });

  it('should execute direct workflow and show success notification', () => {
    service.handleWorkflowExecute('wf-1');

    expect(workflowService.executeWorkflowDirect).toHaveBeenCalledWith('wf-1');
    expect(alertService.success).toHaveBeenCalledWith(
      'taskFlow.workflow.success.executeWorkflow',
      { keepAfterRouteChange: true }
    );
  });

  it('should show direct workflow execution error notification', () => {
    workflowService.executeWorkflowDirect.and.returnValue(
      throwError(() => new Error('execute failed'))
    );

    service.handleWorkflowExecute('wf-1');

    expect(alertService.error).toHaveBeenCalledWith(
      'taskFlow.workflow.error.executeWorkflow',
      { keepAfterRouteChange: true }
    );
  });

  it('should execute distributed workflow and show success notification', () => {
    service.handleWorkflowDistributedExecute('wf-1');

    expect(workflowService.executeWorkflowDistributed).toHaveBeenCalledWith(
      'wf-1'
    );
    expect(alertService.success).toHaveBeenCalledWith(
      'taskFlow.workflow.success.distributedExecuteWorkflow',
      { keepAfterRouteChange: true }
    );
  });

  it('should show distributed workflow execution error notification', () => {
    workflowService.executeWorkflowDistributed.and.returnValue(
      throwError(() => new Error('distributed execute failed'))
    );

    service.handleWorkflowDistributedExecute('wf-1');

    expect(alertService.error).toHaveBeenCalledWith(
      'taskFlow.workflow.error.distributedExecuteWorkflow',
      { keepAfterRouteChange: true }
    );
  });

  it('should execute direct workflow first and show success notification', () => {
    service.handleWorkflowExecuteWithFallback('wf-1', 'uuid-1');

    expect(workflowService.executeWorkflowDirect).toHaveBeenCalledWith(
      'wf-1',
      true
    );
    expect(workflowService.executeWorkflowDistributed).not.toHaveBeenCalled();
    expect(alertService.success).toHaveBeenCalledWith(
      'taskFlow.workflow.success.executeWorkflow',
      { keepAfterRouteChange: true }
    );
  });

  it('should fall back to distributed execution when direct execution fails', () => {
    workflowService.executeWorkflowDirect.and.returnValue(
      throwError(() => new Error('execute failed'))
    );

    service.handleWorkflowExecuteWithFallback('wf-1', 'uuid-1');

    expect(workflowService.executeWorkflowDirect).toHaveBeenCalledWith(
      'wf-1',
      true
    );
    expect(workflowService.executeWorkflowDistributed).toHaveBeenCalledWith(
      'uuid-1'
    );
    expect(alertService.success).toHaveBeenCalledWith(
      'taskFlow.workflow.success.executeWorkflow',
      { keepAfterRouteChange: true }
    );
    expect(alertService.error).not.toHaveBeenCalled();
  });

  it('should show error when direct and distributed execution both fail', () => {
    workflowService.executeWorkflowDirect.and.returnValue(
      throwError(() => new Error('execute failed'))
    );
    workflowService.executeWorkflowDistributed.and.returnValue(
      throwError(() => new Error('distributed execute failed'))
    );

    service.handleWorkflowExecuteWithFallback('wf-1', 'uuid-1');

    expect(alertService.error).toHaveBeenCalledWith(
      'taskFlow.workflow.error.executeWorkflow',
      { keepAfterRouteChange: true }
    );
  });

  it('should not execute workflow when workflowId is undefined', () => {
    service.handleWorkflowExecute(undefined);
    service.handleWorkflowDistributedExecute(undefined);
    service.handleWorkflowExecuteWithFallback(undefined, 'uuid-1');
    service.handleWorkflowExecuteWithFallback('wf-1', undefined);

    expect(workflowService.executeWorkflowDirect).not.toHaveBeenCalled();
    expect(workflowService.executeWorkflowDistributed).not.toHaveBeenCalled();
  });
});
