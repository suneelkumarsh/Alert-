/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { inject, Injectable } from '@angular/core';
import { WorkflowService } from './workflow.service';
import { WorkflowStateService } from './workflow-state.service';
import { TranslateService } from '@ngx-translate/core';
import {
  catchError,
  combineLatest,
  debounceTime,
  distinctUntilChanged,
  defer,
  forkJoin,
  map,
  Observable,
  of,
  retry,
  shareReplay,
  startWith,
  Subject,
  switchMap,
} from 'rxjs';
import {
  WorkflowInstancesFilteredResult,
  WorkflowRunSummaryView,
} from '../../models';
import { WorkflowInstancesContextService } from './workflow-instances-context.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

export type FilteredResult = WorkflowInstancesFilteredResult;

@Injectable()
export class WorkflowInstancesTemplateService {
  private static readonly WORKFLOW_RUNS_PAGE_SIZE = 5000;

  private readonly workflowService = inject(WorkflowService);
  private readonly workflowInstancesContext = inject(
    WorkflowInstancesContextService
  );
  readonly stateService = new WorkflowStateService();
  private readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);

  private readonly reload$ = new Subject<void>();
  private readonly allWorkflowRunsCache = new Map<
    string,
    Observable<FilteredResult>
  >();

  private readonly pagedWorkflowRuns$: Observable<FilteredResult> =
    combineLatest([
      this.workflowInstancesContext.workflowName$,
      this.stateService.pagination.page,
      this.stateService.pagination.pageSize,
      this.reload$.pipe(startWith(void 0)),
    ]).pipe(
      switchMap(([workflowName, page, pageSize]) => {
        if (!workflowName) {
          return of({ items: [], totalCount: 0 } as FilteredResult);
        }

        return this.workflowService
          .getWorkflowInstancesList(workflowName, page, pageSize)
          .pipe(
            retry({ count: 2, delay: 0 }),
            map(response => {
              const items = (response.requests ??
                []) as WorkflowRunSummaryView[];

              return {
                items,
                totalCount: Number(response.totalCount ?? items.length),
              };
            }),
            catchError(() => this.handleLoadError())
          );
      }),
      shareReplay({ refCount: false, bufferSize: 1 })
    );

  readonly statuses$: Observable<string[]> = this.pagedWorkflowRuns$.pipe(
    map(({ items }) => {
      const statuses = new Set(
        items
          .map(item => String(item?.status ?? '').trim())
          .filter((status): status is string => Boolean(status))
      );

      return Array.from(statuses).sort((a, b) => a.localeCompare(b));
    }),
    shareReplay({ refCount: false, bufferSize: 1 })
  );

  readonly filteredResults$: Observable<FilteredResult> = combineLatest([
    this.workflowInstancesContext.workflowName$,
    this.stateService.filters.status,
    this.stateService.filters.search.pipe(
      debounceTime(300),
      distinctUntilChanged()
    ),
    this.stateService.pagination.page,
    this.stateService.pagination.pageSize,
    this.reload$.pipe(startWith(void 0)),
  ]).pipe(
    switchMap(([workflowName, status, search, page, pageSize]) => {
      if (!workflowName) {
        return of({ items: [], totalCount: 0 } as FilteredResult);
      }

      const normalizedSearch = String(search ?? '')
        .trim()
        .toLowerCase();
      const hasActiveFilters = Boolean(status) || Boolean(normalizedSearch);

      if (!hasActiveFilters) {
        return this.pagedWorkflowRuns$;
      }

      return this.getAllWorkflowRuns(workflowName).pipe(
        map(response => {
          const filteredItems = response.items.filter(item => {
            const matchesStatus = !status || item.status === status;
            const matchesSearch =
              !normalizedSearch ||
              String(item.requestId ?? '')
                .toLowerCase()
                .includes(normalizedSearch) ||
              String(item.workflowName ?? '')
                .toLowerCase()
                .includes(normalizedSearch) ||
              String(item.status ?? '')
                .toLowerCase()
                .includes(normalizedSearch);

            return matchesStatus && matchesSearch;
          });

          const totalCount = filteredItems.length;
          const startIndex = Math.max(0, (page - 1) * pageSize);
          const paginatedItems = filteredItems.slice(
            startIndex,
            startIndex + pageSize
          );

          return {
            items: paginatedItems,
            totalCount,
          };
        })
      );
    }),
    shareReplay({ refCount: false, bufferSize: 1 })
  );

  private getAllWorkflowRuns(workflowName: string): Observable<FilteredResult> {
    const cachedRequest = this.allWorkflowRunsCache.get(workflowName);
    if (cachedRequest) {
      return cachedRequest;
    }

    const request$ = defer(() => this.loadAllWorkflowRuns(workflowName)).pipe(
      retry({ count: 2, delay: 0 }),
      catchError(() => this.handleLoadError()),
      shareReplay({ refCount: false, bufferSize: 1 })
    );

    this.allWorkflowRunsCache.set(workflowName, request$);
    return request$;
  }

  private loadAllWorkflowRuns(
    workflowName: string
  ): Observable<FilteredResult> {
    return this.workflowService
      .getWorkflowInstancesList(
        workflowName,
        1,
        WorkflowInstancesTemplateService.WORKFLOW_RUNS_PAGE_SIZE
      )
      .pipe(
        switchMap(response => {
          const firstPageItems = (response.requests ??
            []) as WorkflowRunSummaryView[];
          const totalCount = Number(
            response.totalCount ?? firstPageItems.length
          );

          if (totalCount <= firstPageItems.length) {
            return of({
              items: firstPageItems,
              totalCount: firstPageItems.length,
            });
          }

          const totalPages = Math.ceil(
            totalCount /
              WorkflowInstancesTemplateService.WORKFLOW_RUNS_PAGE_SIZE
          );
          const remainingPageRequests = Array.from(
            { length: totalPages - 1 },
            (_value, index) =>
              this.workflowService.getWorkflowInstancesList(
                workflowName,
                index + 2,
                WorkflowInstancesTemplateService.WORKFLOW_RUNS_PAGE_SIZE
              )
          );

          return forkJoin(remainingPageRequests).pipe(
            map(pageResponses => {
              const remainingItems = pageResponses.flatMap(
                pageResponse =>
                  (pageResponse.requests ?? []) as WorkflowRunSummaryView[]
              );
              const items = [...firstPageItems, ...remainingItems];

              return {
                items,
                totalCount: items.length,
              };
            })
          );
        })
      );
  }

  setSearchFilter(value: string): void {
    this.stateService.filters.setSearch(value);
    this.stateService.pagination.resetPagination();
  }

  setStatusFilter(value: string): void {
    this.stateService.filters.setStatus(value);
    this.stateService.pagination.resetPagination();
  }

  resetFilters(): void {
    this.stateService.resetAll();
  }

  setPage(page: number): void {
    this.stateService.pagination.setPage(page);
  }

  setPageSize(pageSize: number): void {
    this.stateService.pagination.setPageSize(pageSize);
  }

  reload(): void {
    this.allWorkflowRunsCache.clear();
    this.reload$.next();
  }

  private handleLoadError(): Observable<FilteredResult> {
    this.alertService.error(
      this.translateService.instant('taskFlow.workflowInstances.loadingError'),
      { keepAfterRouteChange: true }
    );

    return of({ items: [], totalCount: 0 });
  }
}
