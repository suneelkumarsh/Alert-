/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { BehaviorSubject, of, throwError } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { WorkflowService } from './workflow.service';
import { WorkflowStateService } from './workflow-state.service';
import { WorkflowInstancesContextService } from './workflow-instances-context.service';
import {
  WorkflowInstanceDetailsTemplateService,
  WorkflowRunTasksFilteredResult,
} from './workflow-instance-details-template.service';
import { WorkflowTaskSummary } from 'openapi/output';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('WorkflowInstanceDetailsTemplateService', () => {
  let service: WorkflowInstanceDetailsTemplateService;
  let workflowService: jasmine.SpyObj<WorkflowService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let translateService: jasmine.SpyObj<TranslateService>;
  let requestIdSubject: BehaviorSubject<string>;

  const mockTasks: WorkflowTaskSummary[] = [
    {
      name: 'Task 1',
      type: 'RANTemplateExecutionTask',
      status: 'SUCCESS',
      artifactLink: undefined,
    },
    {
      name: 'Task 2',
      type: 'DayZeroGenerationTask',
      status: 'IN_PROGRESS',
      artifactLink: 'file1.zip',
    },
    {
      name: 'Task 3',
      type: 'RANTemplateExecutionTask',
      status: 'SUCCESS',
      artifactLink: undefined,
    },
    {
      name: 'Task 4',
      type: 'DayZeroGenerationTask',
      status: 'FAILED',
      artifactLink: 'artifact4.zip',
    },
  ];

  beforeEach(() => {
    requestIdSubject = new BehaviorSubject<string>('');

    const workflowServiceSpy = jasmine.createSpyObj('WorkflowService', [
      'getWorkflowRunTasks',
    ]);
    const alertServiceSpy = jasmine.createSpyObj('TnapAlertService', ['error']);
    const translateServiceSpy = jasmine.createSpyObj('TranslateService', [
      'instant',
    ]);
    const workflowInstancesContextSpy = jasmine.createSpyObj(
      'WorkflowInstancesContextService',
      [],
      {
        requestId$: requestIdSubject.asObservable(),
      }
    );

    TestBed.configureTestingModule({
      providers: [
        WorkflowInstanceDetailsTemplateService,
        WorkflowStateService,
        { provide: WorkflowService, useValue: workflowServiceSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
        {
          provide: WorkflowInstancesContextService,
          useValue: workflowInstancesContextSpy,
        },
      ],
    });

    service = TestBed.inject(WorkflowInstanceDetailsTemplateService);
    workflowService = TestBed.inject(
      WorkflowService
    ) as jasmine.SpyObj<WorkflowService>;
    alertService = TestBed.inject(
      TnapAlertService
    ) as jasmine.SpyObj<TnapAlertService>;
    translateService = TestBed.inject(
      TranslateService
    ) as jasmine.SpyObj<TranslateService>;

    translateService.instant.and.returnValue('Test Error');
    workflowService.getWorkflowRunTasks.and.returnValue(
      of({ tasks: mockTasks })
    );
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('allWorkflowRunTasks$', () => {
    it('should emit empty result when requestId is not available', done => {
      requestIdSubject.next('');

      service['allWorkflowRunTasks$'].subscribe(result => {
        expect(result.items.length).toBe(0);
        expect(result.totalCount).toBe(0);
        done();
      });
    });

    it('should fetch tasks from workflow service when requestId is available', done => {
      requestIdSubject.next('request-123');

      service['allWorkflowRunTasks$'].subscribe(result => {
        expect(workflowService.getWorkflowRunTasks).toHaveBeenCalledWith(
          'request-123'
        );
        expect(result.items.length).toBe(4);
        expect(result.totalCount).toBe(4);
        done();
      });
    });

    it('should handle error and emit empty result', done => {
      workflowService.getWorkflowRunTasks.and.returnValue(
        throwError(() => new Error('API Error'))
      );
      translateService.instant.and.returnValue('Error message');

      requestIdSubject.next('request-123');

      service['allWorkflowRunTasks$'].subscribe(result => {
        expect(alertService.error).toHaveBeenCalled();
        expect(result.items.length).toBe(0);
        expect(result.totalCount).toBe(0);
        done();
      });
    });

    it('should replay last value to new subscribers', done => {
      requestIdSubject.next('request-123');

      service['allWorkflowRunTasks$'].subscribe(() => {
        service['allWorkflowRunTasks$'].subscribe(result => {
          expect(result.items.length).toBe(4);
          done();
        });
      });
    });
  });

  describe('statuses$', () => {
    it('should extract unique statuses from tasks', done => {
      requestIdSubject.next('request-123');

      service.statuses$.subscribe(statuses => {
        expect(statuses.length).toBe(3);
        expect(statuses).toContain('SUCCESS');
        expect(statuses).toContain('IN_PROGRESS');
        expect(statuses).toContain('FAILED');
        done();
      });
    });

    it('should sort statuses alphabetically', done => {
      requestIdSubject.next('request-123');

      service.statuses$.subscribe(statuses => {
        expect(statuses).toEqual(['FAILED', 'IN_PROGRESS', 'SUCCESS']);
        done();
      });
    });

    it('should filter out null or empty statuses', done => {
      const tasksWithNullStatus: WorkflowTaskSummary[] = [
        {
          name: 'Task 1',
          type: 'RANTemplateExecutionTask',
          status: 'SUCCESS',
        } as any,
        { name: 'Task 2', type: 'DayZeroGenerationTask', status: null } as any,
        { name: 'Task 3', type: 'RANTemplateExecutionTask', status: '' } as any,
      ];

      workflowService.getWorkflowRunTasks.and.returnValue(
        of({ tasks: tasksWithNullStatus })
      );

      requestIdSubject.next('request-123');

      service.statuses$.subscribe(statuses => {
        expect(statuses.length).toBe(1);
        expect(statuses[0]).toBe('SUCCESS');
        done();
      });
    });
  });

  describe('filteredResults$', () => {
    beforeEach(() => {
      requestIdSubject.next('request-123');
    });

    it('should return all items when no filters applied', done => {
      service.filteredResults$.subscribe(result => {
        expect(result.items.length).toBe(4);
        expect(result.totalCount).toBe(4);
        done();
      });
    });

    it('should filter by status', fakeAsync(() => {
      let result: WorkflowRunTasksFilteredResult | undefined;

      service.filteredResults$.subscribe(r => {
        result = r;
      });

      tick(300);
      service.setStatusFilter('SUCCESS');
      tick(300);

      expect(result?.items.length).toBeGreaterThan(0);
      expect(result?.totalCount).toBeGreaterThan(0);
      expect(result?.items.every(item => item.status === 'SUCCESS')).toBe(true);
    }));

    it('should filter by search term in name', fakeAsync(() => {
      let result: WorkflowRunTasksFilteredResult | undefined;

      service.filteredResults$.subscribe(r => {
        result = r;
      });

      tick(300);
      service.setSearchFilter('Task 1');
      tick(300); // debounceTime

      expect(result?.items.length).toBe(1);
      expect(result?.items[0].name).toBe('Task 1');
    }));

    it('should filter by search term in type', fakeAsync(() => {
      let result: WorkflowRunTasksFilteredResult | undefined;

      service.filteredResults$.subscribe(r => {
        result = r;
      });

      tick(300);
      service.setSearchFilter('RAN');
      tick(300); // debounceTime

      expect(result?.items.length).toBeGreaterThan(0);
      expect(
        result?.items.some(item => item.type === 'RANTemplateExecutionTask')
      ).toBe(true);
    }));

    it('should filter by search term in status', fakeAsync(() => {
      let result: WorkflowRunTasksFilteredResult | undefined;

      service.filteredResults$.subscribe(r => {
        result = r;
      });

      tick(300);
      service.setSearchFilter('FAILED');
      tick(300); // debounceTime

      expect(result?.items.length).toBe(1);
      expect(result?.items[0].status).toBe('FAILED');
    }));

    it('should filter by search term in artifactLink', fakeAsync(() => {
      let result: WorkflowRunTasksFilteredResult | undefined;

      service.filteredResults$.subscribe(r => {
        result = r;
      });

      tick(300);
      service.setSearchFilter('file1');
      tick(300); // debounceTime

      expect(result?.items.length).toBe(1);
      expect(result?.items[0].artifactLink).toBe('file1.zip');
    }));

    it('should apply status and search filter together', fakeAsync(() => {
      let result: WorkflowRunTasksFilteredResult | undefined;

      service.filteredResults$.subscribe(r => {
        result = r;
      });

      tick(300);
      service.setStatusFilter('SUCCESS');
      service.setSearchFilter('Task 1');
      tick(300); // debounceTime

      expect(result?.items.length).toBe(1);
      expect(result?.items[0].name).toBe('Task 1');
      expect(result?.items[0].status).toBe('SUCCESS');
    }));

    it('should be case-insensitive for search', fakeAsync(() => {
      let result: WorkflowRunTasksFilteredResult | undefined;

      service.filteredResults$.subscribe(r => {
        result = r;
      });

      tick(300);
      service.setSearchFilter('task 2');
      tick(300); // debounceTime

      expect(result?.items.length).toBe(1);
      expect(result?.items[0].name).toBe('Task 2');
    }));
  });

  describe('pagination', () => {
    beforeEach(() => {
      requestIdSubject.next('request-123');
    });

    it('should apply pagination with default page size', fakeAsync(() => {
      let result: WorkflowRunTasksFilteredResult | undefined;

      service.filteredResults$.subscribe(r => {
        result = r;
      });

      tick(300);

      expect(result?.items.length).toBe(4);
    }));

    it('should paginate results based on page and pageSize', fakeAsync(() => {
      let result: WorkflowRunTasksFilteredResult | undefined;

      service.filteredResults$.subscribe(r => {
        result = r;
      });

      tick(300);
      service.setPageSize(2);
      service.setPage(1);
      tick(300);

      expect(result?.items.length).toBe(2);
      expect(result?.items[0].name).toBe('Task 1');
      expect(result?.items[1].name).toBe('Task 2');

      service.setPage(2);
      tick(300);

      expect(result?.items.length).toBe(2);
      expect(result?.items[0].name).toBe('Task 3');
      expect(result?.items[1].name).toBe('Task 4');
    }));

    it('should handle page out of bounds', fakeAsync(() => {
      let result: WorkflowRunTasksFilteredResult | undefined;

      service.filteredResults$.subscribe(r => {
        result = r;
      });

      tick(300);
      service.setPageSize(2);
      service.setPage(10);
      tick(300);

      expect(result?.items.length).toBe(0);
    }));

    it('should maintain totalCount for pagination', fakeAsync(() => {
      let result: WorkflowRunTasksFilteredResult | undefined;

      service.filteredResults$.subscribe(r => {
        result = r;
      });

      tick(300);
      service.setPageSize(2);
      tick(300);

      expect(result?.totalCount).toBe(4);
    }));
  });

  describe('filter methods', () => {
    beforeEach(() => {
      requestIdSubject.next('request-123');
    });

    it('should set search filter', fakeAsync(() => {
      let result: WorkflowRunTasksFilteredResult | undefined;

      service.filteredResults$.subscribe(r => {
        result = r;
      });

      tick(300);
      service.setSearchFilter('Task 1');
      tick(300);

      expect(result?.items.length).toBe(1);
    }));

    it('should set status filter', fakeAsync(() => {
      let result: WorkflowRunTasksFilteredResult | undefined;

      service.filteredResults$.subscribe(r => {
        result = r;
      });

      tick(300);
      service.setStatusFilter('SUCCESS');
      tick(300);

      expect(result?.items.length).toBe(2);
    }));

    it('should reset all filters', fakeAsync(() => {
      let result: WorkflowRunTasksFilteredResult | undefined;

      service.filteredResults$.subscribe(r => {
        result = r;
      });

      tick(300);
      service.setSearchFilter('Task 1');
      service.setStatusFilter('SUCCESS');
      tick(300);

      expect(result?.items.length).toBe(1);

      service.resetFilters();
      tick(300);

      expect(result?.items.length).toBe(4);
    }));
  });

  describe('pagination methods', () => {
    beforeEach(() => {
      requestIdSubject.next('request-123');
    });

    it('should set page', fakeAsync(() => {
      let result: WorkflowRunTasksFilteredResult | undefined;

      service.filteredResults$.subscribe(r => {
        result = r;
      });

      tick(300);
      service.setPageSize(2);
      service.setPage(2);
      tick(300);

      expect(result?.items[0].name).toBe('Task 3');
    }));

    it('should set page size', fakeAsync(() => {
      let result: WorkflowRunTasksFilteredResult | undefined;

      service.filteredResults$.subscribe(r => {
        result = r;
      });

      tick(300);
      service.setPageSize(3);
      tick(300);

      expect(result?.items.length).toBe(3);
    }));
  });

  describe('reload', () => {
    it('should reload tasks from workflow service', fakeAsync(() => {
      requestIdSubject.next('request-123');

      service['allWorkflowRunTasks$'].subscribe();
      tick(300);

      expect(workflowService.getWorkflowRunTasks).toHaveBeenCalledTimes(1);

      service.reload();
      tick(300);

      expect(workflowService.getWorkflowRunTasks).toHaveBeenCalledTimes(2);
    }));
  });

  describe('error handling', () => {
    it('should show alert on error', fakeAsync(() => {
      workflowService.getWorkflowRunTasks.and.returnValue(
        throwError(() => new Error('API Error'))
      );
      translateService.instant.and.returnValue('Failed to load tasks');

      requestIdSubject.next('request-123');

      let result: any;
      service['allWorkflowRunTasks$'].subscribe(r => (result = r));

      tick(10);

      expect(alertService.error).toHaveBeenCalledWith('Failed to load tasks', {
        keepAfterRouteChange: true,
      });
      // After error and retries exhausted, empty result is emitted
      expect(result).toEqual({ items: [], totalCount: 0 });
    }));

    it('should use correct translation key for error', fakeAsync(() => {
      workflowService.getWorkflowRunTasks.and.returnValue(
        throwError(() => new Error('API Error'))
      );

      requestIdSubject.next('request-123');

      service['allWorkflowRunTasks$'].subscribe();

      tick(10);

      expect(translateService.instant).toHaveBeenCalledWith(
        'taskFlow.workflowInstanceDetails.loadingError'
      );
    }));

    it('should keep stream active after error, allowing retries via reload', fakeAsync(() => {
      let callCount = 0;
      workflowService.getWorkflowRunTasks.and.callFake(() => {
        callCount++;
        if (callCount <= 3) {
          return throwError(() => new Error('API Error'));
        }
        return of({ tasks: mockTasks });
      });

      requestIdSubject.next('request-123');

      let emitCount = 0;
      let lastResult: any;
      service['allWorkflowRunTasks$'].subscribe(r => {
        emitCount++;
        lastResult = r;
      });

      tick(10);

      expect(alertService.error).toHaveBeenCalled();
      expect(emitCount).toBe(1);
      expect(lastResult.items).toEqual([]);

      service.reload();
      tick(10);

      expect(emitCount).toBe(2);
      expect(lastResult.items.length).toBe(4); // Real data
    }));

    it('should keep stream active after error, allowing retries via pagination change', fakeAsync(() => {
      let callCount = 0;
      workflowService.getWorkflowRunTasks.and.callFake(() => {
        callCount++;
        if (callCount <= 3) {
          return throwError(() => new Error('API Error'));
        }
        return of({ tasks: mockTasks });
      });

      requestIdSubject.next('request-123');

      let emitCount = 0;
      let lastResult: any;
      service['allWorkflowRunTasks$'].subscribe(r => {
        emitCount++;
        lastResult = r;
      });

      tick(10);

      expect(alertService.error).toHaveBeenCalled();
      expect(emitCount).toBe(1);
      expect(lastResult.items).toEqual([]);

      service.setPage(2);
      tick(10);

      expect(emitCount).toBe(2);
      expect(lastResult.items.length).toBe(4); // Real data on retry
    }));
  });

  describe('state service', () => {
    it('should have stateService instance', () => {
      expect(service.stateService).toBeDefined();
    });

    it('should have pagination state', () => {
      expect(service.stateService.pagination).toBeDefined();
    });

    it('should have filters state', () => {
      expect(service.stateService.filters).toBeDefined();
    });
  });
});
