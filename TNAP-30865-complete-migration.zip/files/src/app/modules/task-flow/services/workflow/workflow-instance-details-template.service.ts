/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { inject, Injectable, OnDestroy } from '@angular/core';
import { WorkflowService } from './workflow.service';
import { WorkflowStateService } from './workflow-state.service';
import { TranslateService } from '@ngx-translate/core';
import {
  catchError,
  combineLatest,
  debounceTime,
  defer,
  distinctUntilChanged,
  map,
  Observable,
  of,
  retry,
  shareReplay,
  startWith,
  Subject,
  switchMap,
  takeUntil,
} from 'rxjs';
import { WorkflowTaskSummary } from 'openapi/output';
import { WorkflowInstancesContextService } from './workflow-instances-context.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

export interface WorkflowRunTasksFilteredResult {
  items: WorkflowTaskSummary[];
  totalCount: number;
}

@Injectable()
export class WorkflowInstanceDetailsTemplateService implements OnDestroy {
  private readonly workflowService = inject(WorkflowService);
  private readonly workflowInstancesContext = inject(
    WorkflowInstancesContextService
  );
  readonly stateService = new WorkflowStateService();
  private readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);

  private readonly destroy$ = new Subject<void>();
  private readonly reload$ = new Subject<void>();

  private readonly allWorkflowRunTasks$: Observable<WorkflowRunTasksFilteredResult> =
    combineLatest([
      this.workflowInstancesContext.requestId$,
      this.stateService.pagination.page,
      this.stateService.pagination.pageSize,
      this.reload$.pipe(startWith(void 0)),
    ]).pipe(
      switchMap(([requestId]) => {
        if (!requestId) {
          return of({
            items: [],
            totalCount: 0,
          } as WorkflowRunTasksFilteredResult);
        }

        return defer(() =>
          this.workflowService.getWorkflowRunTasks(requestId)
        ).pipe(
          retry({ count: 2 }),
          map(response => {
            const tasks = (response.tasks ?? []) as WorkflowTaskSummary[];
            return {
              items: tasks,
              totalCount: tasks.length,
            };
          }),
          catchError(() => this.handleLoadError())
        );
      }),
      takeUntil(this.destroy$),
      shareReplay({ refCount: false, bufferSize: 1 })
    );

  readonly statuses$: Observable<string[]> = this.allWorkflowRunTasks$.pipe(
    map(({ items }) => {
      const statuses = new Set(
        items
          .map(item => String(item?.status ?? '').trim())
          .filter((status): status is string => Boolean(status))
      );

      return Array.from(statuses).sort((a, b) => a.localeCompare(b));
    }),
    shareReplay({ refCount: false, bufferSize: 1 })
  );

  readonly filteredResults$: Observable<WorkflowRunTasksFilteredResult> =
    combineLatest([
      this.allWorkflowRunTasks$,
      this.stateService.filters.status,
      this.stateService.filters.search.pipe(
        debounceTime(300),
        distinctUntilChanged()
      ),
      this.stateService.pagination.page,
      this.stateService.pagination.pageSize,
    ]).pipe(
      map(([response, status, search, page, pageSize]) => {
        const normalizedSearch = String(search ?? '')
          .trim()
          .toLowerCase();

        const filteredItems = response.items.filter(item => {
          const matchesStatus = !status || item.status === status;
          const matchesSearch =
            !normalizedSearch ||
            String(item.name ?? '')
              .toLowerCase()
              .includes(normalizedSearch) ||
            String(item.type ?? '')
              .toLowerCase()
              .includes(normalizedSearch) ||
            String(item.status ?? '')
              .toLowerCase()
              .includes(normalizedSearch) ||
            String(item.artifactLink ?? '')
              .toLowerCase()
              .includes(normalizedSearch);

          return matchesStatus && matchesSearch;
        });

        const totalCount = filteredItems.length;
        const startIndex = Math.max(0, (page - 1) * pageSize);
        const paginatedItems = filteredItems.slice(
          startIndex,
          startIndex + pageSize
        );

        return {
          items: paginatedItems,
          totalCount,
        };
      }),
      shareReplay({ refCount: false, bufferSize: 1 })
    );

  setSearchFilter(value: string): void {
    this.stateService.filters.setSearch(value);
    this.stateService.pagination.resetPagination();
  }

  setStatusFilter(value: string): void {
    this.stateService.filters.setStatus(value);
    this.stateService.pagination.resetPagination();
  }

  resetFilters(): void {
    this.stateService.resetAll();
  }

  setPage(page: number): void {
    this.stateService.pagination.setPage(page);
  }

  setPageSize(pageSize: number): void {
    this.stateService.pagination.setPageSize(pageSize);
  }

  reload(): void {
    this.reload$.next();
  }

  private handleLoadError(): Observable<WorkflowRunTasksFilteredResult> {
    this.alertService.error(
      this.translateService.instant(
        'taskFlow.workflowInstanceDetails.loadingError'
      ),
      { keepAfterRouteChange: true }
    );

    // Emit empty result to keep stream alive. Doesn't complete.
    // When user changes page/reload or source re-emits, switchMap will retry.
    return of({ items: [], totalCount: 0 });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
