/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Injectable, inject } from '@angular/core';
import { combineLatest, Observable, of, Subject } from 'rxjs';
import {
  catchError,
  debounceTime,
  distinctUntilChanged,
  map,
  repeat,
  take,
  shareReplay,
  switchMap,
} from 'rxjs/operators';
import { CatalogService } from 'openapi/output';
import { WorkflowService } from './workflow.service';
import { WorkflowStateService } from './workflow-state.service';
import { TranslateService } from '@ngx-translate/core';
import { WorkflowFilteredResult } from '../../models';
import { environment } from 'src/environments/environment';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

export type FilteredResult = WorkflowFilteredResult;

/**
 * Facade service that orchestrates data loading, filtering, and state management
 * Simplifies component by handling reactive logic
 */
@Injectable()
export class WorkflowTemplateService {
  private readonly workflowService = inject(WorkflowService);
  readonly stateService = new WorkflowStateService();
  private readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);

  private readonly workflowTemporalUrl = environment.workflowTemporalUrl;

  private readonly reload$ = new Subject<void>();

  private readonly allWorkflows$: Observable<CatalogService[]> =
    this.workflowService.loadWorkflows().pipe(
      catchError(() => this.handleLoadError()),
      shareReplay({ refCount: true, bufferSize: 1 })
    );

  readonly categories$: Observable<string[]> = this.allWorkflows$.pipe(
    map(workflows => this.workflowService.getCategories(workflows)),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  readonly subCategories$: Observable<string[]> = this.allWorkflows$.pipe(
    map(workflows => this.workflowService.getSubCategories(workflows)),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  readonly statuses$: Observable<string[]> = this.allWorkflows$.pipe(
    map(workflows => this.workflowService.getLifecycleStates(workflows)),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  readonly filteredResults$: Observable<FilteredResult> = combineLatest([
    this.stateService.pagination.page,
    this.stateService.pagination.pageSize,
    this.stateService.filters.status,

    this.stateService.filters.search.pipe(
      debounceTime(300),
      distinctUntilChanged()
    ),
  ]).pipe(
    distinctUntilChanged(),
    switchMap(([page, pageSize, status, search]) =>
      this.allWorkflows$.pipe(
        map(workflows =>
          this.workflowService.filterWorkflows(
            workflows,
            status,
            search,
            page,
            pageSize
          )
        ),
        repeat({ delay: () => this.reload$ })
      )
    ),
    catchError(() => this.handleFilterError()),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  setSearchFilter(value: string): void {
    this.stateService.filters.setSearch(value);
  }

  setStatusFilter(value: string): void {
    this.stateService.filters.setStatus(value);
  }

  resetFilters(): void {
    this.stateService.resetAll();
  }

  setPage(page: number): void {
    this.stateService.pagination.setPage(page);
  }

  setPageSize(pageSize: number): void {
    this.stateService.pagination.setPageSize(pageSize);
  }

  reload(): void {
    this.reload$.next();
  }

  handleWorkflowExecute(workflowId: string | undefined): void {
    this.executeWorkflow(
      workflowId,
      id => this.workflowService.executeWorkflowDirect(id),
      'taskFlow.workflow.success.executeWorkflow',
      'taskFlow.workflow.error.executeWorkflow'
    );
  }

  handleWorkflowDistributedExecute(workflowId: string | undefined): void {
    this.executeWorkflow(
      workflowId,
      id => this.workflowService.executeWorkflowDistributed(id),
      'taskFlow.workflow.success.distributedExecuteWorkflow',
      'taskFlow.workflow.error.distributedExecuteWorkflow'
    );
  }

  handleWorkflowExecuteWithFallback(
    directWorkflowId: string | undefined,
    distributedWorkflowId: string | undefined
  ): void {
    if (!directWorkflowId || !distributedWorkflowId) {
      return;
    }

    this.workflowService
      .executeWorkflowDirect(directWorkflowId, true)
      .pipe(
        take(1),
        catchError(() =>
          this.workflowService.executeWorkflowDistributed(distributedWorkflowId)
        )
      )
      .subscribe({
        next: () => {
          this.alertService.success(
            this.translateService.instant(
              'taskFlow.workflow.success.executeWorkflow'
            ),
            { keepAfterRouteChange: true }
          );
        },
        error: () => {
          this.alertService.error(
            this.translateService.instant(
              'taskFlow.workflow.error.executeWorkflow'
            ),
            { keepAfterRouteChange: true }
          );
        },
      });
  }

  private executeWorkflow(
    workflowId: string | undefined,
    executeAction: (id: string) => Observable<unknown>,
    successTranslationKey: string,
    errorTranslationKey: string
  ): void {
    if (!workflowId) {
      return;
    }

    executeAction(workflowId).subscribe({
      next: () => {
        this.alertService.success(
          this.translateService.instant(successTranslationKey),
          { keepAfterRouteChange: true }
        );
      },
      error: () => {
        this.alertService.error(
          this.translateService.instant(errorTranslationKey),
          { keepAfterRouteChange: true }
        );
      },
    });
  }

  private handleLoadError(): Observable<CatalogService[]> {
    this.alertService.error(
      this.translateService.instant('taskFlow.workflow.error.loadingWorkflows'),
      { keepAfterRouteChange: true }
    );
    return of([] as CatalogService[]);
  }

  private handleFilterError(): Observable<FilteredResult> {
    this.alertService.error(
      this.translateService.instant(
        'taskFlow.workflow.error.filteringWorkflows'
      ),
      { keepAfterRouteChange: true }
    );
    return of({ items: [], totalCount: 0 });
  }

  openTemporalUi(workflowName: string): void {
    const url = `${this.workflowTemporalUrl}/workflows?query=WorkflowId+STARTS_WITH+%22${workflowName}%22`;
    window.open(url, '_blank');
  }
}
