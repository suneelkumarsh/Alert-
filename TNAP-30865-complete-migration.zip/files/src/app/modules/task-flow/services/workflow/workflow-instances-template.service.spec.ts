/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { TranslateService } from '@ngx-translate/core';
import { BehaviorSubject, of, throwError } from 'rxjs';
import { WorkflowService } from './workflow.service';
import { WorkflowInstancesContextService } from './workflow-instances-context.service';
import { WorkflowInstancesTemplateService } from './workflow-instances-template.service';
import { WorkflowRunSummaryView } from '../../models';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('WorkflowInstancesTemplateService', () => {
  let service: WorkflowInstancesTemplateService;
  let workflowService: jasmine.SpyObj<WorkflowService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let workflowName$: BehaviorSubject<string>;

  const mockItems: WorkflowRunSummaryView[] = [
    {
      requestId: 'req-1',
      workflowName: 'WorkflowA',
      status: 'COMPLETE',
      startTime: '2026-01-01',
      endTime: '2026-01-02',
    },
    {
      requestId: 'req-2',
      workflowName: 'WorkflowB',
      status: 'IN_PROGRESS',
      startTime: '2026-01-03',
      endTime: '',
    },
    {
      requestId: 'req-3',
      workflowName: 'WorkflowA',
      status: 'FAILED',
      startTime: '2026-01-04',
      endTime: '2026-01-05',
    },
  ];

  const mockResponse = { requests: mockItems, totalCount: 3 };

  const createService = (): WorkflowInstancesTemplateService =>
    TestBed.runInInjectionContext(() => new WorkflowInstancesTemplateService());

  beforeEach(() => {
    workflowName$ = new BehaviorSubject('WorkflowA');

    const workflowServiceSpy = jasmine.createSpyObj('WorkflowService', [
      'getWorkflowInstancesList',
    ]);
    const contextServiceSpy = jasmine.createSpyObj(
      'WorkflowInstancesContextService',
      [],
      { workflowName$: workflowName$.asObservable() }
    );
    const alertServiceSpy = jasmine.createSpyObj('TnapAlertService', ['error']);
    const translateServiceSpy = jasmine.createSpyObj('TranslateService', [
      'instant',
    ]);
    translateServiceSpy.instant.and.callFake((key: string) => key);
    workflowServiceSpy.getWorkflowInstancesList.and.returnValue(
      of(mockResponse as any)
    );

    TestBed.configureTestingModule({
      providers: [
        WorkflowInstancesTemplateService,
        { provide: WorkflowService, useValue: workflowServiceSpy },
        {
          provide: WorkflowInstancesContextService,
          useValue: contextServiceSpy,
        },
        { provide: TnapAlertService, useValue: alertServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
      ],
    });

    workflowService = TestBed.inject(
      WorkflowService
    ) as jasmine.SpyObj<WorkflowService>;
    alertService = TestBed.inject(
      TnapAlertService
    ) as jasmine.SpyObj<TnapAlertService>;

    service = createService();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should emit all items when no filters are applied', done => {
    service.filteredResults$.subscribe(result => {
      expect(result.items.length).toBe(3);
      expect(result.totalCount).toBe(3);
      done();
    });
  });

  it('should load the full workflow-instance list for the active workflow', done => {
    service.filteredResults$.subscribe(() => {
      expect(workflowService.getWorkflowInstancesList).toHaveBeenCalledWith(
        'WorkflowA',
        1,
        20
      );
      done();
    });
  });

  it('should search across the full workflow list when the match is outside the current page', fakeAsync(() => {
    const firstPageItems: WorkflowRunSummaryView[] = Array.from(
      { length: 20 },
      (_, index) => ({
        requestId: `req-${index + 1}`,
        workflowName: 'WorkflowA',
        status: index % 2 === 0 ? 'COMPLETE' : 'IN_PROGRESS',
        startTime: '2026-01-01',
        endTime: '2026-01-02',
      })
    );
    const allItems: WorkflowRunSummaryView[] = [
      ...firstPageItems,
      {
        requestId: 'req-25',
        workflowName: 'WorkflowA',
        status: 'FAILED',
        startTime: '2026-02-01',
        endTime: '2026-02-02',
      },
    ];

    workflowService.getWorkflowInstancesList.and.callFake(
      (_workflowName: string, page: number, pageSize: number) => {
        if (page === 1 && pageSize >= 5000) {
          return of({ requests: allItems, totalCount: allItems.length } as any);
        }

        return of({
          requests: firstPageItems,
          totalCount: allItems.length,
        } as any);
      }
    );

    service = createService();
    service.setSearchFilter('req-25');

    let result: any;
    service.filteredResults$.subscribe(r => (result = r));

    tick(400);

    expect(workflowService.getWorkflowInstancesList).toHaveBeenCalledWith(
      'WorkflowA',
      1,
      5000
    );
    expect(result.items.length).toBe(1);
    expect(result.items[0].requestId).toBe('req-25');
    expect(result.totalCount).toBe(1);
  }));

  it('should search across all loaded workflow instances, not just the current page', fakeAsync(() => {
    const allItems: WorkflowRunSummaryView[] = [
      ...mockItems,
      {
        requestId: 'req-25',
        workflowName: 'WorkflowA',
        status: 'FAILED',
        startTime: '2026-02-01',
        endTime: '2026-02-02',
      },
    ];

    workflowService.getWorkflowInstancesList.and.returnValue(
      of({ requests: allItems, totalCount: allItems.length } as any)
    );

    service = createService();
    service.setPage(2);
    service.setPageSize(20);
    service.setSearchFilter('req-25');

    let result: any;
    service.filteredResults$.subscribe(r => (result = r));

    tick(400);

    expect(result.items.length).toBe(1);
    expect(result.items[0].requestId).toBe('req-25');
    expect(result.totalCount).toBe(1);
  }));

  it('should filter items by status', fakeAsync(() => {
    service.setStatusFilter('COMPLETE');

    let result: any;
    service.filteredResults$.subscribe(r => (result = r));

    tick(400);

    expect(
      result.items.every(
        (item: WorkflowRunSummaryView) => item.status === 'COMPLETE'
      )
    ).toBeTrue();
    expect(result.totalCount).toBe(1);
  }));

  it('should filter items by search matching requestId', fakeAsync(() => {
    service.setSearchFilter('req-2');

    let result: any;
    service.filteredResults$.subscribe(r => (result = r));

    tick(400);

    expect(result.items.length).toBe(1);
    expect(result.items[0].requestId).toBe('req-2');
  }));

  it('should filter items by search matching workflowName (case-insensitive)', fakeAsync(() => {
    service.setSearchFilter('workflowb');

    let result: any;
    service.filteredResults$.subscribe(r => (result = r));

    tick(400);

    expect(result.items.length).toBe(1);
    expect(result.items[0].workflowName).toBe('WorkflowB');
  }));

  it('should filter items by search matching status (case-insensitive)', fakeAsync(() => {
    service.setSearchFilter('in_progress');

    let result: any;
    service.filteredResults$.subscribe(r => (result = r));

    tick(400);

    expect(result.items.length).toBe(1);
    expect(result.items[0].status).toBe('IN_PROGRESS');
  }));

  it('should apply both status and search filters simultaneously', fakeAsync(() => {
    service.setStatusFilter('COMPLETE');
    service.setSearchFilter('req-1');

    let result: any;
    service.filteredResults$.subscribe(r => (result = r));

    tick(400);

    expect(result.items.length).toBe(1);
    expect(result.items[0].requestId).toBe('req-1');
  }));

  it('should return empty items when status filter matches nothing', fakeAsync(() => {
    service.setStatusFilter('UNKNOWN_STATUS');

    let result: any;
    service.filteredResults$.subscribe(r => (result = r));

    tick(400);

    expect(result.items.length).toBe(0);
    expect(result.totalCount).toBe(0);
  }));

  it('should emit distinct sorted statuses from loaded items', done => {
    service.statuses$.subscribe(statuses => {
      expect(statuses).toEqual(['COMPLETE', 'FAILED', 'IN_PROGRESS']);
      done();
    });
  });

  it('should exclude empty/null statuses from statuses$', done => {
    const itemsWithNullStatus: WorkflowRunSummaryView[] = [
      {
        requestId: 'r1',
        workflowName: 'wf',
        status: undefined,
      },
      {
        requestId: 'r2',
        workflowName: 'wf',
        status: null as unknown as WorkflowRunSummaryView['status'],
      },
    ];
    workflowService.getWorkflowInstancesList.and.returnValue(
      of({ requests: itemsWithNullStatus, totalCount: 2 } as any)
    );
    service = createService();

    service.statuses$.subscribe(statuses => {
      expect(statuses).toEqual([]);
      done();
    });
  });

  it('should emit empty result when workflowName is empty', done => {
    workflowName$.next('');
    service = createService();

    service.filteredResults$.subscribe(result => {
      expect(result.items).toEqual([]);
      expect(result.totalCount).toBe(0);
      expect(workflowService.getWorkflowInstancesList).not.toHaveBeenCalled();
      done();
    });
  });

  it('should update page via setPage', () => {
    service.setPage(3);

    expect(service.stateService.pagination.getCurrentPage()).toBe(3);
  });

  it('should update page size via setPageSize', () => {
    service.setPageSize(50);

    expect(service.stateService.pagination.getCurrentPageSize()).toBe(50);
  });

  it('should fetch the full workflow-instance dataset once and apply page slicing client-side', done => {
    service.setPage(2);
    service.setPageSize(5);

    service.filteredResults$.subscribe(() => {
      expect(workflowService.getWorkflowInstancesList).toHaveBeenCalledWith(
        'WorkflowA',
        2,
        5
      );
      done();
    });
  });

  it('should fetch subsequent API pages when totalCount exceeds first page size', done => {
    const firstPageItems: WorkflowRunSummaryView[] = Array.from(
      { length: 5000 },
      (_, index) => ({
        requestId: `req-${index + 1}`,
        workflowName: 'WorkflowA',
        status: 'COMPLETE',
      })
    );
    const secondPageItems: WorkflowRunSummaryView[] = [
      {
        requestId: 'req-5001',
        workflowName: 'WorkflowA',
        status: 'FAILED',
      },
    ];

    workflowService.getWorkflowInstancesList.and.callFake(
      (_workflowName: string, page: number, pageSize: number) => {
        if (page === 1 && pageSize === 5000) {
          return of({ requests: firstPageItems, totalCount: 5001 } as any);
        }

        if (page === 2 && pageSize === 5000) {
          return of({ requests: secondPageItems, totalCount: 5001 } as any);
        }

        return of({ requests: [], totalCount: 5001 } as any);
      }
    );

    service = createService();
    service.setSearchFilter('req-5001');

    service.filteredResults$.subscribe(result => {
      expect(workflowService.getWorkflowInstancesList).toHaveBeenCalledWith(
        'WorkflowA',
        2,
        5000
      );
      expect(result.totalCount).toBe(1);
      expect(result.items[0].requestId).toBe('req-5001');
      done();
    });
  });

  it('should set search filter via setSearchFilter', () => {
    service.setSearchFilter('test-search');

    expect(service.stateService.filters.getCurrentSearch()).toBe('test-search');
  });

  it('should set status filter via setStatusFilter', done => {
    service.setStatusFilter('FAILED');

    service.stateService.filters.status.subscribe(status => {
      expect(status).toBe('FAILED');
      done();
    });
  });

  it('should reset filters via resetFilters', done => {
    service.setSearchFilter('something');
    service.setStatusFilter('IN_PROGRESS');
    service.setPage(3);

    service.resetFilters();

    service.stateService.filters.status.subscribe(status => {
      expect(status).toBe('');
      service.stateService.filters.search.subscribe(search => {
        expect(search).toBe('');
        done();
      });
    });
  });

  it('should trigger reload when reload() is called', () => {
    spyOn(service['reload$'], 'next');

    service.reload();

    expect(service['reload$'].next).toHaveBeenCalled();
  });

  it('should re-fetch data after reload', fakeAsync(() => {
    let callCount = 0;

    service.filteredResults$.subscribe(() => {
      callCount++;
    });

    tick(300);

    service.reload();
    tick(300);

    expect(callCount).toBeGreaterThanOrEqual(2);
    expect(workflowService.getWorkflowInstancesList).toHaveBeenCalledTimes(2);
  }));

  it('should show alert on error from getWorkflowInstancesList', fakeAsync(() => {
    workflowService.getWorkflowInstancesList.and.returnValue(
      throwError(() => new Error('network error'))
    );
    service = createService();

    let result: any;
    service.filteredResults$.subscribe(r => (result = r));

    tick(400);

    expect(alertService.error).toHaveBeenCalledWith(
      'taskFlow.workflowInstances.loadingError',
      { keepAfterRouteChange: true }
    );
    // After error and retry exhaustion, empty result is emitted
    expect(result).toEqual({ items: [], totalCount: 0 });
  }));

  it('should keep stream active after error, allowing retries via reload', fakeAsync(() => {
    let callCount = 0;
    workflowService.getWorkflowInstancesList.and.callFake(() => {
      callCount++;
      if (callCount <= 3) {
        // First 3 calls fail (initial + 2 retries built-in = exhausted)
        return throwError(() => new Error('network error'));
      }
      // 4th call (via reload) succeeds
      return of(mockResponse as any);
    });

    service = createService();
    service.setSearchFilter('req');

    let emitCount = 0;
    let lastResult: any;
    service.filteredResults$.subscribe(r => {
      emitCount++;
      lastResult = r;
    });

    tick(400);

    // After retries exhausted, empty result is emitted
    expect(alertService.error).toHaveBeenCalled();
    expect(emitCount).toBe(1);
    expect(lastResult.items).toEqual([]);

    // Now manually retry via reload
    service.reload();
    tick(400);

    // Reload triggers retry and succeeds
    expect(emitCount).toBe(2);
    expect(workflowService.getWorkflowInstancesList).toHaveBeenCalledTimes(4);
    expect(lastResult.items.length).toBe(3); // Real data
  }));

  it('should fetch another server page when page changes without filters', fakeAsync(() => {
    service.filteredResults$.subscribe();
    tick(300);

    expect(workflowService.getWorkflowInstancesList).toHaveBeenCalledTimes(1);

    service.setPage(2);
    tick(300);

    expect(workflowService.getWorkflowInstancesList).toHaveBeenCalledTimes(2);
    expect(workflowService.getWorkflowInstancesList).toHaveBeenCalledWith(
      'WorkflowA',
      2,
      20
    );
  }));
});
