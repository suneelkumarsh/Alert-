/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { TestBed } from '@angular/core/testing';
import { HttpContext } from '@angular/common/http';
import { ComponentInstanceResponse, SdcComponentType } from 'openapi/output';
import { ServiceDesignAndCreationService } from 'openapi/output/api/serviceDesignAndCreation.service';
import { SUPPRESS_HTTP_ERROR_ALERT } from 'src/app/http-interceptors/http-error.interceptor';
import { TranslateService } from '@ngx-translate/core';
import { of, throwError } from 'rxjs';
import { TaskFlowSharedService } from '../shared/task-flow-shared.service';
import { WorkflowService } from './workflow.service';
import { TaskItem } from '../../models';
import {
  createMockSdcService,
  createMockTaskFlowSharedService,
  createMockAlertService,
  createMockTranslateService,
} from '../../test-helpers/mock-factories';
import { expectErrorWithoutSpyCall } from '../../test-helpers/error-assertion.helper';
import { TaskItemBuilder } from '../../test-helpers/test-data.builder';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('WorkflowService', () => {
  let service: WorkflowService;
  let sdcService: jasmine.SpyObj<ServiceDesignAndCreationService>;
  let taskFlowSharedService: jasmine.SpyObj<TaskFlowSharedService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let translateService: jasmine.SpyObj<TranslateService>;

  const mockWorkflows = [
    {
      uniqueId: 'w1',
      name: 'Workflow B',
      description: 'desc-b',
      lifecycleState: 'CERTIFIED',
      distributionStatus: 'DISTRIBUTED',
      tags: ['alpha'],
      lastUpdateDate: '100',
      categoryNormalizedName: 'taskworkflow',
      categories: [{ name: 'TaskWorkflow', subcategories: [{ name: 'SubA' }] }],
    },
    {
      uniqueId: 'w2',
      name: 'Workflow A',
      description: 'desc-a',
      lifecycleState: 'NOT_CERTIFIED_CHECKOUT',
      distributionStatus: 'NOT_DISTRIBUTED',
      tags: ['beta'],
      lastUpdateDate: '300',
      categoryNormalizedName: 'taskworkflow',
      categories: [{ name: 'TaskWorkflow', subcategories: [{ name: 'SubB' }] }],
    },
  ] as any[];

  beforeEach(() => {
    const sdcServiceSpy = createMockSdcService();
    const sharedSpy = createMockTaskFlowSharedService();
    const alertServiceSpy = createMockAlertService();
    const translateServiceSpy = createMockTranslateService();

    TestBed.configureTestingModule({
      providers: [
        WorkflowService,
        { provide: ServiceDesignAndCreationService, useValue: sdcServiceSpy },
        { provide: TaskFlowSharedService, useValue: sharedSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
      ],
    });

    service = TestBed.inject(WorkflowService);
    sdcService = TestBed.inject(
      ServiceDesignAndCreationService
    ) as jasmine.SpyObj<ServiceDesignAndCreationService>;
    taskFlowSharedService = TestBed.inject(
      TaskFlowSharedService
    ) as jasmine.SpyObj<TaskFlowSharedService>;
    alertService = TestBed.inject(
      TnapAlertService
    ) as jasmine.SpyObj<TnapAlertService>;
    translateService = TestBed.inject(
      TranslateService
    ) as jasmine.SpyObj<TranslateService>;
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should load and sort workflows by lastUpdateDate desc', done => {
    sdcService.getCatalogComponents.and.returnValue(
      of({ services: mockWorkflows } as any)
    );

    service.loadWorkflows().subscribe(workflows => {
      expect(sdcService.getCatalogComponents).toHaveBeenCalledWith(
        SdcComponentType.SERVICES
      );
      expect(workflows.length).toBe(2);
      expect(workflows[0].uniqueId).toBe('w2');
      expect(workflows[1].uniqueId).toBe('w1');
      done();
    });
  });

  it('should return empty workflows when API fails', done => {
    sdcService.getCatalogComponents.and.returnValue(
      throwError(() => new Error('api fail'))
    );

    service.loadWorkflows().subscribe(workflows => {
      expect(workflows).toEqual([]);
      done();
    });
  });

  it('should derive categories, subcategories and lifecycle states', () => {
    expect(service.getCategories(mockWorkflows as any)).toEqual([
      'TaskWorkflow',
    ]);
    expect(service.getSubCategories(mockWorkflows as any)).toEqual([
      'SubA',
      'SubB',
    ]);
    expect(service.getLifecycleStates(mockWorkflows as any)).toEqual([
      'CERTIFIED',
      'NOT_CERTIFIED_CHECKOUT',
    ] as any);
  });

  it('should validate workflow name via shared service', done => {
    taskFlowSharedService.validateComponentName.and.returnValue(of(true));

    service.validateTaskName('MyWorkflow').subscribe(isValid => {
      expect(isValid).toBeTrue();
      expect(taskFlowSharedService.validateComponentName).toHaveBeenCalledWith(
        SdcComponentType.SERVICES,
        'MyWorkflow'
      );
      done();
    });
  });

  it('should filter workflows by status/search and paginate', () => {
    const result = service.filterWorkflows(
      mockWorkflows as any,
      'CERTIFIED',
      'workflow b',
      1,
      10
    );

    expect(result.totalCount).toBe(1);
    expect(result.items.length).toBe(1);
    expect(result.items[0].uniqueId).toBe('w1');
  });

  it('should show translated error when workflowName is empty in createWorkflowAndFetch', done => {
    service.createWorkflowAndFetch({ workflowName: '  ' }).subscribe({
      next: () => fail('Expected error'),
      error: error => {
        expect(translateService.instant).toHaveBeenCalledWith(
          'taskFlow.workflow.error.workflowNameRequiredForCreation'
        );
        expect(alertService.error).toHaveBeenCalledWith(
          'taskFlow.workflow.error.workflowNameRequiredForCreation'
        );
        expect(String(error)).toContain(
          'taskFlow.workflow.error.workflowNameRequiredForCreation'
        );
        done();
      },
    });
  });

  it('should create workflow and map response', done => {
    sdcService.createService.and.returnValue(
      of({ serviceId: 'svc-1', lifeCycleState: 'CERTIFIED' } as any)
    );

    service
      .createWorkflowAndFetch({ workflowName: 'WF One', description: 'desc' })
      .subscribe(response => {
        expect(sdcService.createService).toHaveBeenCalled();
        expect(response).toEqual({
          serviceId: 'svc-1',
          lifeCycleState: 'CERTIFIED',
        });
        done();
      });
  });

  it('should throw when create response misses serviceId', done => {
    sdcService.createService.and.returnValue(of({} as any));

    service.createWorkflowAndFetch({ workflowName: 'WF One' }).subscribe({
      next: () => fail('Expected error'),
      error: error => {
        expect(alertService.error).toHaveBeenCalledWith(
          'taskFlow.workflow.error.createWorkflowMissingServiceId'
        );
        expect(String(error)).toContain(
          'taskFlow.workflow.error.createWorkflowMissingServiceId'
        );
        done();
      },
    });
  });

  it('should fetch workflow by id and return null on failure', done => {
    sdcService.getServiceById.and.returnValue(
      throwError(() => new Error('fail'))
    );

    service.getWorkflowById('wf-1').subscribe(result => {
      expect(result).toBeNull();
      done();
    });
  });

  it('should delegate distributed execution to executeServiceWorkflow', done => {
    sdcService.executeServiceWorkflow.and.returnValue(
      of({ requestId: 'r-1' } as any)
    );

    service.executeWorkflowDistributed('workflow-1').subscribe(response => {
      expect(sdcService.executeServiceWorkflow).toHaveBeenCalledWith(
        'workflow-1'
      );
      expect(response).toEqual({ requestId: 'r-1' } as any);
      done();
    });
  });

  it('should map workflow component instances to workflow tasks', () => {
    const workflow = {
      componentInstances: [
        {
          uniqueId: 'instance-1',
          componentUid: 'task-1',
          componentName: 'Task One',
          componentVersion: '1.0',
          originType: 'RanTemplateExecutionTask',
          name: 'Task One',
        },
      ],
      componentInstancesInputs: {
        'instance-1': [
          { name: 'region', value: 'EU' },
          { name: 'dryRun', defaultValue: 'true' },
        ],
      },
    } as any;

    expect(service.getWorkflowTaskInstances(workflow)).toEqual([
      {
        instanceId: 'instance-1',
        task: {
          uniqueId: 'task-1',
          name: 'Task One',
          description: '',
          version: '1.0',
          type: 'RanTemplateExecutionTask',
          resourceType: 'RanTemplateExecutionTask',
          vendorName: '',
          lifecycleState: '',
        },
        taskName: 'Task One',
        order: 1,
        properties: {
          region: 'EU',
          dryRun: 'true',
        },
      },
    ]);
  });

  it('should add task to workflow through addTaskComponentInstance', done => {
    const task = TaskItemBuilder.ranTemplateTask()
      .withUniqueId('task-1')
      .withName('Task One')
      .withVersion('1.0')
      .build();
    const response: ComponentInstanceResponse = {
      uniqueId: 'instance-1',
      name: 'Task One',
      inputs: [{ name: 'region', value: 'EU' } as any],
    };
    sdcService.addTaskComponentInstance.and.returnValue(of(response as any));

    service.addTaskToWorkflow('workflow-1', task).subscribe(result => {
      expect(sdcService.addTaskComponentInstance).toHaveBeenCalledWith(
        'workflow-1',
        SdcComponentType.SERVICES,
        {
          name: 'Task One',
          componentVersion: '1.0',
          originType: 'CR',
          componentUid: 'task-1',
        }
      );
      expect(result).toEqual({
        instanceId: 'instance-1',
        task,
        taskName: 'Task One',
        order: 0,
        properties: {
          region: 'EU',
        },
      });
      done();
    });
  });

  it('should show error and not call API when workflowId is missing in addTaskToWorkflow', done => {
    const task: TaskItem = {
      uniqueId: 'task-1',
      name: 'Task One',
      description: 'desc',
      version: '1.0',
      type: 'RanTemplateExecutionTask',
      resourceType: 'CR',
      vendorName: 'DT',
      lifecycleState: 'CERTIFIED',
    };

    service.addTaskToWorkflow('   ', task).subscribe({
      next: () => fail('Expected error when workflowId is missing'),
      error: () => {
        expect(alertService.error).toHaveBeenCalledWith(
          'taskFlow.workflow.error.workflowIdRequiredToAddTask'
        );
        expect(sdcService.addTaskComponentInstance).not.toHaveBeenCalled();
        done();
      },
    });
  });

  it('should certify and distribute workflow through certifyDistribute', done => {
    sdcService.certifyDistribute.and.returnValue(
      of({
        lifecycleState: 'CERTIFIED',
        distributionStatus: 'DISTRIBUTED',
      } as any)
    );

    service
      .certifyAndDistributeWorkflow('workflow-1', 'certified from test')
      .subscribe(result => {
        expect(sdcService.certifyDistribute).toHaveBeenCalledWith(
          'workflow-1',
          {
            userRemarks: 'certified from test',
          },
          jasmine.anything(),
          jasmine.anything(),
          jasmine.anything()
        );
        expect(result.lifecycleState).toBe('CERTIFIED');
        expect(result.distributionStatus).toBe('DISTRIBUTED');
        done();
      });
  });

  it('should cleanup destroy subject on destroy', () => {
    spyOn(service['destroy$'], 'next');
    spyOn(service['destroy$'], 'complete');

    service.ngOnDestroy();

    expect(service['destroy$'].next).toHaveBeenCalled();
    expect(service['destroy$'].complete).toHaveBeenCalled();
  });

  it('should execute workflow by id and return response', done => {
    sdcService.downloadServiceArtifact.and.returnValue(
      of({ payloadData: 'artifact-content' } as any)
    );

    service.executeWorkflowDirect('uuid-1').subscribe(result => {
      expect(sdcService.downloadServiceArtifact).toHaveBeenCalledWith(
        'uuid-1',
        'uuid-1.assettoscatemplate'
      );
      expect(result).toEqual({ payloadData: 'artifact-content' } as any);
      done();
    });
  });

  it('should suppress only the direct workflow execution http error alert', done => {
    sdcService.downloadServiceArtifact.and.returnValue(
      of({ payloadData: 'artifact-content' } as any)
    );
    sdcService.executeServiceWorkflow.and.returnValue(of({} as any));

    service.executeWorkflowDirect('uuid-1', true).subscribe(() => {
      const directOptions =
        sdcService.downloadServiceArtifact.calls.mostRecent().args[4] as
          | { context: HttpContext }
          | undefined;
      expect(directOptions).toEqual(
        jasmine.objectContaining({
          context: jasmine.any(HttpContext),
        })
      );
      expect(directOptions?.context.get(SUPPRESS_HTTP_ERROR_ALERT)).toBeTrue();

      service.executeWorkflowDistributed('workflow-1').subscribe(() => {
        const distributedOptions =
          sdcService.executeServiceWorkflow.calls.mostRecent().args[0];
        expect(distributedOptions).toBe('workflow-1');
        done();
      });
    });
  });

  it('should delete task from workflow through deleteResourceInstance', done => {
    sdcService.deleteResourceInstance.and.returnValue(
      of({ uniqueId: 'workflow-1' } as any)
    );

    service
      .deleteTaskFromWorkflow('workflow-1', 'instance-1')
      .subscribe(result => {
        expect(sdcService.deleteResourceInstance).toHaveBeenCalledWith(
          SdcComponentType.SERVICES,
          'workflow-1',
          'instance-1'
        );
        expect(result.uniqueId).toBe('workflow-1');
        done();
      });
  });

  it('should show error when workflowId is missing in deleteTaskFromWorkflow', done => {
    service.deleteTaskFromWorkflow('   ', 'instance-1').subscribe({
      next: () => fail('Expected error'),
      error: () => {
        expect(alertService.error).toHaveBeenCalledWith(
          'taskFlow.workflow.error.workflowIdRequiredToDeleteTask'
        );
        expect(sdcService.deleteResourceInstance).not.toHaveBeenCalled();
        done();
      },
    });
  });

  it('should show error when instanceId is missing in deleteTaskFromWorkflow', done => {
    service.deleteTaskFromWorkflow('workflow-1', '   ').subscribe({
      next: () => fail('Expected error'),
      error: () => {
        expect(alertService.error).toHaveBeenCalledWith(
          'taskFlow.workflow.error.instanceIdRequiredToDeleteTask'
        );
        expect(sdcService.deleteResourceInstance).not.toHaveBeenCalled();
        done();
      },
    });
  });

  it('should handle error when deleting task from workflow', done => {
    sdcService.deleteResourceInstance.and.returnValue(
      throwError(() => new Error('delete failed'))
    );

    service.deleteTaskFromWorkflow('workflow-1', 'instance-1').subscribe({
      next: () => fail('Expected error'),
      error: () => {
        expect(sdcService.deleteResourceInstance).toHaveBeenCalled();
        done();
      },
    });
  });

  it('should change workflow state to CHECKOUT', done => {
    taskFlowSharedService.changeComponentState.and.returnValue(
      of({ lifecycleState: 'NOT_CERTIFIED_CHECKOUT' } as any)
    );

    service
      .changeWorkflowState('workflow-1', 'CHECKOUT', 'test remarks')
      .subscribe(result => {
        expect(taskFlowSharedService.changeComponentState).toHaveBeenCalledWith(
          SdcComponentType.SERVICES,
          'checkout',
          'workflow-1',
          'test remarks'
        );
        expect(result.lifecycleState).toBe('NOT_CERTIFIED_CHECKOUT');
        done();
      });
  });

  it('should show error when workflowId is missing in changeWorkflowState', done => {
    service.changeWorkflowState('  ', 'CHECKOUT').subscribe({
      next: () => fail('Expected error'),
      error: () => {
        expect(alertService.error).toHaveBeenCalledWith(
          'taskFlow.workflow.error.workflowIdRequiredToChangeState'
        );
        expect(
          taskFlowSharedService.changeComponentState
        ).not.toHaveBeenCalled();
        done();
      },
    });
  });

  it('should show error and not call API when taskId is missing in addTaskToWorkflow', async () => {
    const task = TaskItemBuilder.aTask().withUniqueId('   ').build();

    await expectErrorWithoutSpyCall(
      service.addTaskToWorkflow('workflow-1', task),
      sdcService.addTaskComponentInstance
    );
    expect(alertService.error).toHaveBeenCalledWith(
      'taskFlow.workflow.error.taskIdRequiredToAddTask'
    );
  });

  it('should handle error when adding task to workflow', done => {
    const task: TaskItem = {
      uniqueId: 'task-1',
      name: 'Task One',
      description: 'desc',
      version: '1.0',
      type: 'RanTemplateExecutionTask',
      resourceType: 'CR',
      vendorName: 'DT',
      lifecycleState: 'CERTIFIED',
    };

    sdcService.addTaskComponentInstance.and.returnValue(
      throwError(() => new Error('add failed'))
    );

    service.addTaskToWorkflow('workflow-1', task).subscribe({
      next: () => fail('Expected error'),
      error: () => {
        expect(sdcService.addTaskComponentInstance).toHaveBeenCalled();
        done();
      },
    });
  });

  it('should certify and distribute workflow with skipGlobalLoading true', done => {
    sdcService.certifyDistribute.and.returnValue(
      of({
        lifecycleState: 'CERTIFIED',
        distributionStatus: 'DISTRIBUTED',
      } as any)
    );

    service
      .certifyAndDistributeWorkflow('workflow-1', 'remarks', true)
      .subscribe(result => {
        const callArgs = sdcService.certifyDistribute.calls.mostRecent().args;
        expect(callArgs[0]).toBe('workflow-1');
        expect(callArgs[1]).toEqual({ userRemarks: 'remarks' });
        expect(result.lifecycleState).toBe('CERTIFIED');
        done();
      });
  });

  it('should handle error in certifyAndDistributeWorkflow', done => {
    sdcService.certifyDistribute.and.returnValue(
      throwError(() => new Error('certify failed'))
    );

    service.certifyAndDistributeWorkflow('workflow-1').subscribe({
      next: () => fail('Expected error'),
      error: () => {
        expect(sdcService.certifyDistribute).toHaveBeenCalled();
        done();
      },
    });
  });

  it('should show error when workflowId is missing in certifyAndDistributeWorkflow', done => {
    service.certifyAndDistributeWorkflow('   ').subscribe({
      next: () => fail('Expected error'),
      error: () => {
        expect(alertService.error).toHaveBeenCalledWith(
          'taskFlow.workflow.error.workflowIdRequiredToCertifyAndDistribute'
        );
        expect(sdcService.certifyDistribute).not.toHaveBeenCalled();
        done();
      },
    });
  });

  it('should fetch workflow instances list with pagination', done => {
    const mockResponse = {
      requests: [
        { requestId: 'req-1', requestStatus: 'COMPLETED' },
        { requestId: 'req-2', requestStatus: 'PENDING' },
      ] as any[],
      totalCount: 2,
    };
    sdcService.listWorkflowRuns.and.returnValue(of(mockResponse as any));

    service.getWorkflowInstancesList('workflow-1', 1, 10).subscribe(result => {
      expect(sdcService.listWorkflowRuns).toHaveBeenCalledWith(
        'workflow-1',
        1,
        10
      );
      expect(result.requests?.length).toBe(2);
      expect((result.requests?.[0] as any).workflowName).toBe('workflow-1');
      done();
    });
  });

  it('should handle error when fetching workflow instances list', done => {
    sdcService.listWorkflowRuns.and.returnValue(
      throwError(() => new Error('list failed'))
    );

    service.getWorkflowInstancesList('workflow-1', 1, 10).subscribe({
      next: () => fail('Expected error'),
      error: () => {
        expect(sdcService.listWorkflowRuns).toHaveBeenCalled();
        done();
      },
    });
  });

  it('should fetch workflow run tasks', done => {
    const mockResponse = {
      tasks: [
        { name: 'Task 1', status: 'COMPLETED' },
        { name: 'Task 2', status: 'PENDING' },
      ] as any[],
    };
    sdcService.getWorkflowRunTasks.and.returnValue(of(mockResponse as any));

    service.getWorkflowRunTasks('request-1').subscribe(result => {
      expect(sdcService.getWorkflowRunTasks).toHaveBeenCalledWith('request-1');
      expect(result.tasks?.length).toBe(2);
      done();
    });
  });

  it('should handle missing tasks in workflow run response', done => {
    sdcService.getWorkflowRunTasks.and.returnValue(of({} as any));

    service.getWorkflowRunTasks('request-1').subscribe(result => {
      expect(result.tasks).toEqual([]);
      done();
    });
  });

  it('should handle error when fetching workflow run tasks', done => {
    sdcService.getWorkflowRunTasks.and.returnValue(
      throwError(() => new Error('tasks fetch failed'))
    );

    service.getWorkflowRunTasks('request-1').subscribe({
      next: () => fail('Expected error'),
      error: () => {
        expect(sdcService.getWorkflowRunTasks).toHaveBeenCalled();
        done();
      },
    });
  });
});
