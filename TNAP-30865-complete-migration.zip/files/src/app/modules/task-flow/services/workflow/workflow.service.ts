/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { inject, Injectable, OnDestroy } from '@angular/core';
import { Observable, of, Subject, throwError } from 'rxjs';
import {
  shareReplay,
  catchError,
  takeUntil,
  map,
  switchMap,
} from 'rxjs/operators';
import { HttpContext } from '@angular/common/http';
import { SUPPRESS_HTTP_ERROR_ALERT } from 'src/app/http-interceptors/http-error.interceptor';
import { SKIP_GLOBAL_LOADING } from 'src/app/http-interceptors/loading-indicator.interceptor';
import {
  CatalogComponent,
  CatalogService,
  CatalogServiceList,
  CertifyDistributeResponse,
  ComponentInstance,
  ComponentInstanceRequest,
  ComponentInstanceResponse,
  CreateServiceCategory,
  CreateServiceRequest,
  SdcLifecycleState,
  SdcLifecycleOperation,
  SdcComponentType,
  ServiceDesignAndCreationService,
  Service,
  ServiceResponse,
  ExecuteService,
  LifeCycleStateResponse,
  DownloadArtifact,
  WorkflowRunListResponse,
  WorkflowRunSummary,
  WorkflowRunTasksResponse,
} from 'openapi/output';
import {
  TaskItem,
  WorkflowTaskInstance,
  WorkflowRunSummaryView,
} from '../../models';
import { TaskFlowSharedService } from '../shared/task-flow-shared.service';
import { TranslateService } from '@ngx-translate/core';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

interface WorkflowComponentInstanceInput {
  name?: string;
  value?: string;
  defaultValue?: string;
}

interface WorkflowComponentInstancesInputsMap {
  [instanceId: string]: WorkflowComponentInstanceInput[];
}

interface WorkflowComponentInstancesView extends Service {
  componentInstancesInputs?: WorkflowComponentInstancesInputsMap;
}

@Injectable({ providedIn: 'root' })
export class WorkflowService implements OnDestroy {
  private readonly sdcService = inject(ServiceDesignAndCreationService);
  private readonly taskFlowSharedService = inject(TaskFlowSharedService);
  private readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);
  private readonly destroy$ = new Subject<void>();

  loadWorkflows(): Observable<CatalogService[]> {
    return this.sdcService.getCatalogComponents(SdcComponentType.SERVICES).pipe(
      map((response: CatalogComponent) => {
        const workflows: CatalogService[] = this.isCatalogServiceList(response)
          ? response.services
          : [];

        const sortedWorkflows = [...workflows].sort((a, b) => {
          const aLastUpdateDate = Number(a?.lastUpdateDate ?? 0);
          const bLastUpdateDate = Number(b?.lastUpdateDate ?? 0);
          return bLastUpdateDate - aLastUpdateDate;
        });

        return sortedWorkflows.filter(
          workflow => workflow.categoryNormalizedName === 'taskworkflow'
        );
      }),
      shareReplay({ refCount: true, bufferSize: 1 }),
      catchError(() => {
        return of([] as CatalogService[]);
      }),
      takeUntil(this.destroy$)
    );
  }

  private isCatalogServiceList(
    component: CatalogComponent
  ): component is CatalogServiceList {
    return 'services' in component;
  }

  getCategories(workflows: CatalogService[]): string[] {
    const categories = new Set(
      workflows
        .flatMap(w => w.categories ?? [])
        .map(category => category.name)
        .filter((category): category is string => Boolean(category))
    );

    return Array.from(categories).sort((a, b) => a.localeCompare(b));
  }

  getSubCategories(workflows: CatalogService[]): string[] {
    const subCategories = new Set(
      workflows
        .flatMap(w => w.categories ?? [])
        .flatMap(category => category.subcategories ?? [])
        .map(subcategory => subcategory.name)
        .filter((subcategory): subcategory is string => Boolean(subcategory))
    );

    return Array.from(subCategories).sort((a, b) => a.localeCompare(b));
  }

  getLifecycleStates(workflows: CatalogService[]): SdcLifecycleState[] {
    const statuses = new Set(
      workflows
        .map(workflow => workflow.lifecycleState)
        .filter((status): status is SdcLifecycleState => status !== undefined)
    );

    return Array.from(statuses).sort((a, b) => a.localeCompare(b));
  }

  validateTaskName(name: string): Observable<boolean> {
    return this.taskFlowSharedService.validateComponentName(
      SdcComponentType.SERVICES,
      name
    );
  }

  filterWorkflows(
    workflows: CatalogService[],
    status: string,
    search: string,
    page: number,
    pageSize: number
  ): { items: CatalogService[]; totalCount: number } {
    let filtered = workflows;

    if (status) {
      filtered = filtered.filter(
        workflow => workflow.lifecycleState === status
      );
    }

    if (search) {
      const searchLower = search.toLowerCase();
      filtered = filtered.filter(
        w =>
          (w.name ?? '').toLowerCase().includes(searchLower) ||
          (w.description ?? '').toLowerCase().includes(searchLower) ||
          (w.tags ?? []).some(tag => tag.toLowerCase().includes(searchLower))
      );
    }

    const totalCount = filtered.length;

    const startIndex = (page - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    const items = filtered.slice(startIndex, endIndex);

    return { items, totalCount };
  }

  createWorkflowAndFetch(formData: {
    workflowName?: string;
    description?: string;
  }): Observable<ServiceResponse> {
    const workflowName: string = String(formData?.workflowName ?? '').trim();
    if (!workflowName) {
      const message = this.translateService.instant(
        'taskFlow.workflow.error.workflowNameRequiredForCreation'
      );
      this.alertService.error(message);
      return throwError(() => new Error(message));
    }

    const categories: CreateServiceCategory[] = [
      {
        name: 'TaskWorkflow',
        normalizedName: 'taskworkflow',
        models: ['SDC AID'],
      },
    ];

    const request: CreateServiceRequest = {
      contactId: 'portal-ui',
      name: workflowName,
      description: formData?.description ?? '',
      tags: [workflowName],
      categories,
      componentType: CreateServiceRequest.ComponentTypeEnum.SERVICE,
      derivedFromGenericType: 'org.openecomp.resource.abstract.nodes.service',
      derivedFromGenericVersion: '1.0',
      ecompGeneratedNaming: true,
      environmentContext: 'General_Revenue-Bearing',
      icon: 'defaulticon',
      instantiationType: 'Macro',
    };

    return this.sdcService.createService(request).pipe(
      takeUntil(this.destroy$),
      switchMap(response => {
        const serviceId = response?.serviceId;
        if (!serviceId) {
          const message = this.translateService.instant(
            'taskFlow.workflow.error.createWorkflowMissingServiceId'
          );
          this.alertService.error(message);
          return throwError(() => new Error(message));
        }
        return of({ serviceId, lifeCycleState: response?.lifeCycleState });
      }),
      catchError(error => {
        return throwError(() => error);
      })
    );
  }

  getWorkflowById(workflowId: string): Observable<Service | null> {
    return this.sdcService.getServiceById(workflowId).pipe(
      catchError(() => {
        return of(null);
      })
    );
  }

  executeWorkflowDirect(
    componentId: string,
    suppressGlobalErrorAlert: boolean = false
  ): Observable<DownloadArtifact> {
    if (suppressGlobalErrorAlert) {
      return this.sdcService.downloadServiceArtifact(
        componentId,
        componentId + '.assettoscatemplate',
        undefined,
        false,
        {
          context: new HttpContext().set(SUPPRESS_HTTP_ERROR_ALERT, true),
        }
      );
    }

    return this.sdcService.downloadServiceArtifact(
      componentId,
      componentId + '.assettoscatemplate'
    );
  }

  executeWorkflowDistributed(
    workflowId: string,
    suppressGlobalErrorAlert: boolean = false
  ): Observable<ExecuteService | null> {
    if (suppressGlobalErrorAlert) {
      return this.sdcService.executeServiceWorkflow(workflowId, 'body', false, {
        context: new HttpContext().set(SUPPRESS_HTTP_ERROR_ALERT, true),
      });
    }

    return this.sdcService.executeServiceWorkflow(workflowId);
  }

  getWorkflowTaskInstances(
    workflow: Service | null | undefined
  ): WorkflowTaskInstance[] {
    const componentInstances = workflow?.componentInstances ?? [];

    return componentInstances.map((componentInstance, index) => {
      const instanceId = String(componentInstance?.uniqueId ?? '').trim();
      const fallbackInstanceId = String(
        componentInstance?.customizationUUID ?? ''
      ).trim();
      const resolvedInputs = this.resolveComponentInstanceInputs(
        workflow,
        componentInstance,
        instanceId || fallbackInstanceId
      );

      return {
        instanceId: instanceId || fallbackInstanceId,
        task: this.mapComponentInstanceToTaskItem(componentInstance),
        taskName:
          String(componentInstance?.name ?? '').trim() ||
          String(componentInstance?.componentName ?? '').trim(),
        order: index + 1,
        properties: this.mapInputsToProperties(resolvedInputs),
      };
    });
  }

  private resolveComponentInstanceInputs(
    workflow: Service | null | undefined,
    componentInstance: ComponentInstance,
    instanceId: string
  ): WorkflowComponentInstanceInput[] {
    if ((componentInstance?.inputs?.length ?? 0) > 0) {
      return componentInstance.inputs ?? [];
    }

    const inputsByInstance = (
      workflow as WorkflowComponentInstancesView | undefined
    )?.componentInstancesInputs;

    return inputsByInstance?.[instanceId] ?? [];
  }

  addTaskToWorkflow(
    workflowId: string,
    task: TaskItem
  ): Observable<WorkflowTaskInstance> {
    const normalizedWorkflowId = String(workflowId ?? '').trim();
    if (!normalizedWorkflowId) {
      const message = this.translateService.instant(
        'taskFlow.workflow.error.workflowIdRequiredToAddTask'
      );
      this.alertService.error(message);
      return throwError(() => new Error(message));
    }

    const normalizedTaskId = String(task?.uniqueId ?? '').trim();
    if (!normalizedTaskId) {
      const message = this.translateService.instant(
        'taskFlow.workflow.error.taskIdRequiredToAddTask'
      );
      this.alertService.error(message);
      return throwError(() => new Error(message));
    }

    const request: ComponentInstanceRequest = {
      name: String(task?.name ?? '').trim(),
      componentVersion: String(task?.version ?? '').trim() || undefined,
      originType: String(task?.resourceType ?? '').trim() || 'CR',
      componentUid: normalizedTaskId,
    };

    return this.sdcService
      .addTaskComponentInstance(
        normalizedWorkflowId,
        SdcComponentType.SERVICES,
        request
      )
      .pipe(
        takeUntil(this.destroy$),
        map(response => this.mapAddedTaskInstance(task, response)),
        catchError(error => {
          return throwError(() => error);
        })
      );
  }

  deleteTaskFromWorkflow(
    workflowId: string,
    instanceId: string
  ): Observable<Service> {
    const normalizedWorkflowId = String(workflowId ?? '').trim();
    if (!normalizedWorkflowId) {
      const message = this.translateService.instant(
        'taskFlow.workflow.error.workflowIdRequiredToDeleteTask'
      );
      this.alertService.error(message);
      return throwError(() => new Error(message));
    }

    const normalizedInstanceId = String(instanceId ?? '').trim();
    if (!normalizedInstanceId) {
      const message = this.translateService.instant(
        'taskFlow.workflow.error.instanceIdRequiredToDeleteTask'
      );
      this.alertService.error(message);
      return throwError(() => new Error(message));
    }

    return this.sdcService
      .deleteResourceInstance(
        SdcComponentType.SERVICES,
        normalizedWorkflowId,
        normalizedInstanceId
      )
      .pipe(
        takeUntil(this.destroy$),
        catchError(error => {
          return throwError(() => error);
        })
      );
  }

  certifyAndDistributeWorkflow(
    workflowId: string,
    userRemarks: string = '',
    skipGlobalLoading: boolean = false
  ): Observable<CertifyDistributeResponse> {
    const normalizedWorkflowId = String(workflowId ?? '').trim();
    if (!normalizedWorkflowId) {
      const message = this.translateService.instant(
        'taskFlow.workflow.error.workflowIdRequiredToCertifyAndDistribute'
      );
      this.alertService.error(message);
      return throwError(() => new Error(message));
    }

    return this.sdcService
      .certifyDistribute(normalizedWorkflowId, { userRemarks }, 'body', false, {
        context: new HttpContext().set(SKIP_GLOBAL_LOADING, skipGlobalLoading),
      })
      .pipe(
        takeUntil(this.destroy$),
        catchError(error => {
          return throwError(() => error);
        })
      );
  }

  changeWorkflowState(
    workflowId: string,
    state: 'CHECKOUT',
    userRemarks: string = ''
  ): Observable<LifeCycleStateResponse> {
    const normalizedWorkflowId = String(workflowId ?? '').trim();
    if (!normalizedWorkflowId) {
      const message = this.translateService.instant(
        'taskFlow.workflow.error.workflowIdRequiredToChangeState'
      );
      this.alertService.error(message);
      return throwError(() => new Error(message));
    }

    return this.taskFlowSharedService.changeComponentState(
      SdcComponentType.SERVICES,
      SdcLifecycleOperation.CHECKOUT,
      normalizedWorkflowId,
      userRemarks
    );
  }

  private mapAddedTaskInstance(
    task: TaskItem,
    response: ComponentInstanceResponse
  ): WorkflowTaskInstance {
    return {
      instanceId:
        String(response?.uniqueId ?? '').trim() ||
        String(response?.customizationUUID ?? '').trim() ||
        String(response?.componentUid ?? '').trim() ||
        task.uniqueId,
      task,
      taskName: String(response?.name ?? '').trim() || task.name,
      order: 0,
      properties: this.mapInputsToProperties(response?.inputs ?? []),
    };
  }

  private mapComponentInstanceToTaskItem(
    componentInstance: ComponentInstance
  ): TaskItem {
    return {
      uniqueId:
        String(componentInstance?.componentUid ?? '').trim() ||
        String(componentInstance?.uniqueId ?? '').trim(),
      name:
        String(componentInstance?.componentName ?? '').trim() ||
        String(componentInstance?.name ?? '').trim(),
      description: '',
      version: String(componentInstance?.componentVersion ?? '').trim(),
      type: String(componentInstance?.originType ?? '').trim(),
      resourceType: String(componentInstance?.originType ?? '').trim(),
      vendorName: '',
      lifecycleState: '',
    };
  }

  private mapInputsToProperties(
    inputs: WorkflowComponentInstanceInput[]
  ): Record<string, string> {
    return inputs.reduce<Record<string, string>>((properties, input) => {
      const name = String(input?.name ?? '').trim();
      if (!name) {
        return properties;
      }

      properties[name] = input?.value ?? input?.defaultValue ?? '';
      return properties;
    }, {});
  }

  getWorkflowInstancesList(
    workflowName: string,
    page: number,
    pageSize: number
  ): Observable<WorkflowRunListResponse> {
    return this.sdcService.listWorkflowRuns(workflowName, page, pageSize).pipe(
      takeUntil(this.destroy$),
      map((response: WorkflowRunListResponse) => {
        const mappedRequests: WorkflowRunSummaryView[] = (
          response.requests ?? []
        ).map((workflowRunSummary: WorkflowRunSummary) => ({
          ...workflowRunSummary,
          workflowName,
        }));

        return {
          ...response,
          requests: mappedRequests,
        };
      }),
      catchError(error => {
        return throwError(() => error);
      })
    );
  }

  getWorkflowRunTasks(requestId: string): Observable<WorkflowRunTasksResponse> {
    return this.sdcService.getWorkflowRunTasks(requestId).pipe(
      takeUntil(this.destroy$),
      map((response: WorkflowRunTasksResponse) => ({
        ...response,
        tasks: response.tasks ?? [],
      })),
      catchError(error => {
        return throwError(() => error);
      })
    );
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
