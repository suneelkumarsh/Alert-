/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { TaskItem } from '../../models';
import { TasksService } from './tasks.service';
import { TasksTemplateService } from './tasks-template.service';
import { TaskFlowSharedService } from '../shared/task-flow-shared.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('TasksTemplateService', () => {
  let service: TasksTemplateService;
  let tasksService: jasmine.SpyObj<TasksService>;
  let alertService: jasmine.SpyObj<TnapAlertService>;
  let translateService: jasmine.SpyObj<TranslateService>;
  let taskFlowSharedService: jasmine.SpyObj<TaskFlowSharedService>;

  const mockTasks: TaskItem[] = [
    {
      uniqueId: '1',
      name: 'Task One',
      type: 'RANTemplateExecutionTask',
      description: 'desc-1',
      version: '1.0',
      vendorName: 'Vendor',
      lifecycleState: 'NOT_CERTIFIED_CHECKIN',
    },
    {
      uniqueId: '2',
      name: 'Task Two',
      type: 'DayZeroGenerationTask',
      description: 'desc-2',
      version: '1.0',
      vendorName: 'Vendor',
      lifecycleState: 'CERTIFIED',
    },
  ];

  beforeEach(() => {
    const tasksServiceSpy = jasmine.createSpyObj('TasksService', [
      'loadTasks',
      'getTaskTypes',
      'getTaskStatuses',
      'filterTasks',
    ]);
    const alertServiceSpy = jasmine.createSpyObj('TnapAlertService', ['error']);
    const translateServiceSpy = jasmine.createSpyObj('TranslateService', [
      'instant',
    ]);
    const taskFlowSharedServiceSpy = jasmine.createSpyObj(
      'TaskFlowSharedService',
      ['navigateToTaskEdit']
    );

    TestBed.configureTestingModule({
      providers: [
        TasksTemplateService,
        { provide: TasksService, useValue: tasksServiceSpy },
        { provide: TnapAlertService, useValue: alertServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
        {
          provide: TaskFlowSharedService,
          useValue: taskFlowSharedServiceSpy,
        },
      ],
    });

    service = TestBed.inject(TasksTemplateService);
    tasksService = TestBed.inject(TasksService) as jasmine.SpyObj<TasksService>;
    alertService = TestBed.inject(
      TnapAlertService
    ) as jasmine.SpyObj<TnapAlertService>;
    translateService = TestBed.inject(
      TranslateService
    ) as jasmine.SpyObj<TranslateService>;
    taskFlowSharedService = TestBed.inject(
      TaskFlowSharedService
    ) as jasmine.SpyObj<TaskFlowSharedService>;

    translateService.instant.and.returnValue('load error');
    tasksService.loadTasks.and.returnValue(of(mockTasks));
    tasksService.getTaskTypes.and.returnValue([
      'RANTemplateExecutionTask',
      'DayZeroGenerationTask',
    ]);
    tasksService.getTaskStatuses.and.returnValue([
      'CERTIFIED',
      'NOT_CERTIFIED_CHECKIN',
    ]);
    tasksService.filterTasks.and.callFake(
      (tasks, _type, _status, _search, page, pageSize) => {
        const startIndex = (page - 1) * pageSize;
        return {
          items: tasks.slice(startIndex, startIndex + pageSize),
          totalCount: tasks.length,
        };
      }
    );
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should trigger reload subject when reload is called', () => {
    spyOn(service['reload$'], 'next');

    service.reload();

    expect(service['reload$'].next).toHaveBeenCalled();
  });

  it('should set type filter when setTypeFilter is called', () => {
    spyOn(service.stateService.filters, 'setType');

    service.setTypeFilter('DayZeroGenerationTask');

    expect(service.stateService.filters.setType).toHaveBeenCalledWith(
      'DayZeroGenerationTask'
    );
  });

  it('should set search filter when setSearchFilter is called', () => {
    spyOn(service.stateService.filters, 'setSearch');

    service.setSearchFilter('task-name');

    expect(service.stateService.filters.setSearch).toHaveBeenCalledWith(
      'task-name'
    );
  });

  it('should set status filter when setStatusFilter is called', () => {
    spyOn(service.stateService.filters, 'setStatus');

    service.setStatusFilter('CERTIFIED');

    expect(service.stateService.filters.setStatus).toHaveBeenCalledWith(
      'CERTIFIED'
    );
  });

  it('should reset filters and pagination when resetFilters is called', () => {
    spyOn(service.stateService.filters, 'resetFilters');
    spyOn(service.stateService.pagination, 'resetPagination');

    service.resetFilters();

    expect(service.stateService.filters.resetFilters).toHaveBeenCalled();
    expect(service.stateService.pagination.resetPagination).toHaveBeenCalled();
  });

  it('should set page and page size', () => {
    service.setPage(2);
    service.setPageSize(10);

    expect(service.stateService.pagination.getCurrentPage()).toBe(2);
    expect(service.stateService.pagination.getCurrentPageSize()).toBe(10);
  });

  it('should map taskTypes$ from loaded tasks', done => {
    service.taskTypes$.subscribe(taskTypes => {
      expect(taskTypes).toEqual([
        'RANTemplateExecutionTask',
        'DayZeroGenerationTask',
      ]);
      expect(tasksService.getTaskTypes).toHaveBeenCalledWith(mockTasks);
      done();
    });
  });

  it('should map statuses$ from loaded tasks', done => {
    service.statuses$.subscribe(statuses => {
      expect(statuses).toEqual(['CERTIFIED', 'NOT_CERTIFIED_CHECKIN']);
      expect(tasksService.getTaskStatuses).toHaveBeenCalledWith(mockTasks);
      done();
    });
  });

  it('should emit filtered results and call filterTasks with current state', fakeAsync(() => {
    let latestResult: any;
    service.filteredResults$.subscribe(result => {
      latestResult = result;
    });

    tick(400);

    expect(tasksService.filterTasks).toHaveBeenCalled();
    expect(latestResult.totalCount).toBe(2);
    expect(latestResult.items.length).toBe(2);
  }));

  it('should update filtered results when page changes', fakeAsync(() => {
    service.setPageSize(1);
    service.setPage(2);

    let latestResult: any;
    service.filteredResults$.subscribe(result => {
      latestResult = result;
    });

    tick(400);

    expect(latestResult.items.length).toBe(1);
    expect(latestResult.items[0].uniqueId).toBe('2');
  }));

  it('should handle load error and return empty tasks', done => {
    tasksService.loadTasks.and.returnValue(
      throwError(() => new Error('load failed'))
    );
    tasksService.getTaskTypes.and.returnValue([]);

    service.taskTypes$.subscribe(taskTypes => {
      expect(taskTypes).toEqual([]);
      expect(alertService.error).toHaveBeenCalled();
      done();
    });
  });

  it('should handle filter error and return empty filtered result', fakeAsync(() => {
    tasksService.filterTasks.and.throwError('filter failed');

    let latestResult: any;
    service.filteredResults$.subscribe(result => {
      latestResult = result;
    });

    tick(400);

    expect(alertService.error).toHaveBeenCalled();
    expect(latestResult).toEqual({ items: [], totalCount: 0 });
  }));

  it('should navigate to edit page with route state', () => {
    const task = mockTasks[0];

    service.routeToEditTask(task);

    expect(taskFlowSharedService.navigateToTaskEdit).toHaveBeenCalledWith(
      task.uniqueId,
      {
        state: {
          taskType: task.type,
          taskSummary: task,
        },
      }
    );
  });
});
