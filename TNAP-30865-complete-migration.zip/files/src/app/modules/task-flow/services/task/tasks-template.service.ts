/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Injectable, inject } from '@angular/core';
import { combineLatest, Observable, Subject, of } from 'rxjs';
import {
  catchError,
  debounceTime,
  distinctUntilChanged,
  map,
  shareReplay,
  startWith,
  switchMap,
} from 'rxjs/operators';
import { TasksService } from './tasks.service';
import { TaskItem, TasksFilteredResult } from '../../models';
import { TasksStateService } from './tasks-state.service';
import { TranslateService } from '@ngx-translate/core';
import { SdcIncludeType } from 'openapi/output';
import { TaskFlowSharedService } from '../shared/task-flow-shared.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

export type FilteredResult = TasksFilteredResult;

@Injectable()
export class TasksTemplateService {
  private readonly tasksService = inject(TasksService);
  private readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);
  private readonly taskFlowSharedService = inject(TaskFlowSharedService);
  readonly stateService = new TasksStateService();

  private readonly reload$ = new Subject<void>();

  private readonly allTasks$: Observable<TaskItem[]> = this.reload$.pipe(
    startWith(void 0),
    switchMap(() =>
      this.tasksService
        .loadTasks([SdcIncludeType.CR, SdcIncludeType.SERVICE])
        .pipe(catchError(() => this.handleLoadError()))
    ),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  readonly taskTypes$: Observable<string[]> = this.allTasks$.pipe(
    map(tasks => this.tasksService.getTaskTypes(tasks)),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  readonly statuses$: Observable<string[]> = this.allTasks$.pipe(
    map(tasks => this.tasksService.getTaskStatuses(tasks)),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  readonly filteredResults$: Observable<FilteredResult> = combineLatest([
    this.stateService.pagination.page,
    this.stateService.pagination.pageSize,
    this.stateService.filters.type.pipe(
      debounceTime(150),
      distinctUntilChanged()
    ),
    this.stateService.filters.status.pipe(
      debounceTime(150),
      distinctUntilChanged()
    ),
    this.stateService.filters.search.pipe(
      debounceTime(300),
      distinctUntilChanged()
    ),
  ]).pipe(
    distinctUntilChanged(),
    switchMap(([page, pageSize, type, status, search]) =>
      this.allTasks$.pipe(
        map(tasks =>
          this.tasksService.filterTasks(
            tasks,
            type,
            status,
            search,
            page,
            pageSize
          )
        )
      )
    ),
    catchError(() => this.handleFilterError()),
    shareReplay({ refCount: true, bufferSize: 1 })
  );

  setTypeFilter(value: string): void {
    this.stateService.filters.setType(value);
  }

  setSearchFilter(value: string): void {
    this.stateService.filters.setSearch(value);
  }

  setStatusFilter(value: string): void {
    this.stateService.filters.setStatus(value);
  }

  resetFilters(): void {
    this.stateService.filters.resetFilters();
    this.stateService.pagination.resetPagination();
  }

  setPage(page: number): void {
    this.stateService.pagination.setPage(page);
  }

  setPageSize(pageSize: number): void {
    this.stateService.pagination.setPageSize(pageSize);
  }

  reload(): void {
    this.reload$.next();
  }

  private handleLoadError(): Observable<TaskItem[]> {
    this.alertService.error(
      this.translateService.instant('taskFlow.tasks.error.loadingTasks'),
      { keepAfterRouteChange: true }
    );
    return of([]);
  }

  private handleFilterError(): Observable<FilteredResult> {
    this.alertService.error(
      this.translateService.instant('taskFlow.tasks.error.loadingTasks'),
      { keepAfterRouteChange: true }
    );
    return of({ items: [], totalCount: 0 });
  }

  routeToEditTask(task: TaskItem): void {
    this.taskFlowSharedService.navigateToTaskEdit(task.uniqueId, {
      state: {
        taskType: task.type,
        taskSummary: task,
      },
    });
  }
}
