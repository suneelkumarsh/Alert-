/*
 * Copyright (c) 2023. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { Injectable } from '@angular/core';
import {
  CellGroup,
  CellGroupListResponse,
  NetworkService,
  NetworkClustersService,
} from '../../../../../../openapi/output';
import { EMPTY, Observable, ReplaySubject, Subject } from 'rxjs';
import { map, repeatWhen, switchMap, take, tap } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { UserPermissionsService } from '../../../../services/user-permissions.service';
import { VIEW_NETWORK_CLUSTERS } from '../../../../permissions.config';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Injectable({
  providedIn: 'root',
})
export class CellSiteClustersService {
  private clusters$ = new ReplaySubject<CellGroupListResponse>(1);
  private refetch$ = new Subject<void>();

  constructor(
    private networkService: NetworkService,
    private alertService: TnapAlertService,
    private translateService: TranslateService,
    private networkClustersService: NetworkClustersService,
    private userPermissionsService: UserPermissionsService
  ) {
    this.userPermissionsService
      .checkUserPermissions(VIEW_NETWORK_CLUSTERS)
      .pipe(
        take(1),
        switchMap(() =>
          this.networkClustersService
            .listClusters()
            .pipe(repeatWhen(() => this.refetch$))
        )
      )
      .subscribe(clusters => this.clusters$.next(clusters));
  }

  public getClusters() {
    return this.clusters$.asObservable();
  }

  public createCluster(cluster: CellGroup) {
    return this.clusterExists(cluster.id).pipe(
      take(1),
      switchMap(exists => {
        if (exists) {
          this.alertService.error(
            this.translateService.instant(
              'cellCluster.messages.error.duplicateName',
              {
                name: cluster.id,
              }
            ),
            { keepAfterRouteChange: true }
          );
          return EMPTY;
        } else {
          return this.networkClustersService.createCluster(cluster);
        }
      }),
      tap(() => this.refetchClusters())
    );
  }

  public editCluster(cluster: CellGroup) {
    return this.networkClustersService
      .updateCluster(cluster.id, cluster)
      .pipe(tap(() => this.refetchClusters()));
  }

  public deleteCluster(cluster: CellGroup) {
    return this.networkClustersService
      .deleteCluster(cluster.id)
      .pipe(tap(() => this.refetchClusters()));
  }

  public refetchClusters() {
    this.refetch$.next();
  }

  public clusterExists(clusterName: string): Observable<boolean> {
    return this.networkClustersService
      .listClusters()
      .pipe(
        map(clusters =>
          clusters.items.some(cluster => cluster.id === clusterName)
        )
      );
  }
}
