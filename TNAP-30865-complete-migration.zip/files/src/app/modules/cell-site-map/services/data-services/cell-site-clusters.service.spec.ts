/*
 * Copyright (c) 2026. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { TestBed } from '@angular/core/testing';
import { EMPTY, of } from 'rxjs';
import {
  NetworkClustersService,
  NetworkService,
} from '../../../../../../openapi/output';
import { CellSiteClustersService } from './cell-site-clusters.service';
import { TranslateService } from '@ngx-translate/core';
import { UserPermissionsService } from '../../../../services/user-permissions.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('CellSiteClustersService – constructor permission guard', () => {
  let listClustersSpy: jasmine.Spy;
  let checkUserPermissionsSpy: jasmine.Spy;

  function setup(permissionObservable: any) {
    listClustersSpy = jasmine
      .createSpy('listClusters')
      .and.returnValue(of({ items: [] }));
    checkUserPermissionsSpy = jasmine
      .createSpy('checkUserPermissions')
      .and.returnValue(permissionObservable);

    TestBed.configureTestingModule({
      providers: [
        CellSiteClustersService,
        {
          provide: NetworkClustersService,
          useValue: { listClusters: listClustersSpy },
        },
        { provide: NetworkService, useValue: {} },
        { provide: TnapAlertService, useValue: { error: jasmine.createSpy() } },
        {
          provide: TranslateService,
          useValue: { instant: jasmine.createSpy().and.returnValue('') },
        },
        {
          provide: UserPermissionsService,
          useValue: { checkUserPermissions: checkUserPermissionsSpy },
        },
      ],
    });
  }

  afterEach(() => TestBed.resetTestingModule());

  it('loads clusters when VIEW_NETWORK_CLUSTERS is granted', () => {
    setup(of(null));

    TestBed.inject(CellSiteClustersService);

    expect(listClustersSpy).toHaveBeenCalled();
  });

  it('does not load clusters when VIEW_NETWORK_CLUSTERS is denied', () => {
    setup(EMPTY);

    TestBed.inject(CellSiteClustersService);

    expect(listClustersSpy).not.toHaveBeenCalled();
  });

  it('emits the cluster list to getClusters() when permission is granted', done => {
    setup(of(null));
    const mockCluster = { id: 'cluster-1' };
    listClustersSpy.and.returnValue(of({ items: [mockCluster] }));

    const service = TestBed.inject(CellSiteClustersService);

    service.getClusters().subscribe(result => {
      expect(result.items).toEqual([mockCluster] as any);
      done();
    });
  });
});
