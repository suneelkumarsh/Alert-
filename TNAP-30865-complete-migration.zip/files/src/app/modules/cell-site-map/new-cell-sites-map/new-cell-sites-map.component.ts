/*
 * Copyright (c) 2023. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */
import {
  AfterViewInit,
  afterNextRender,
  Component,
  computed,
  DestroyRef,
  ElementRef,
  HostListener,
  inject,
  Injector,
  isDevMode,
  signal,
  ViewChild,
  viewChild,
} from '@angular/core';
import { LeafletMapService } from '../services/leaflet-map.service';
import {
  CellSiteDataService,
  EnhancedAlarmAggregationServiceInstanceId,
} from '../services/data-services/cell-site-data.service';
import { UnsubscribeService } from '../../../services/unsubscribe/unsubscribe.service';
import {
  catchError,
  concatMap,
  debounceTime,
  delay,
  filter,
  map,
  share,
  shareReplay,
  switchMap,
  take,
  takeUntil,
  tap,
  withLatestFrom,
} from 'rxjs/operators';
import {
  CELL_SELECTED_STYLE,
  createAlarmMarker,
  createAlarmPulseMarker,
  createCellCoverage,
  createClusterMarker,
  createSiteMarker,
  getCellCoverageStyle,
  truncateString,
} from '../helpers';
import { CellEditPaneActions } from '../../../model/cell.model';
import { CellSiteMapDetailService } from '../services/cell-site-map-detail.service';
import {
  combineLatest,
  EMPTY,
  from,
  merge,
  Observable,
  of,
  OperatorFunction,
  Subject,
} from 'rxjs';
import {
  ActionsResponse,
  AddressSearchResult,
  AddressSuggestion,
  CellGroup,
  CellSiteResponse,
  CellSitesService,
  SliceDetailsResponse,
  SliceResponse,
} from '../../../../../openapi/output';
import { ActivatedRoute, Router } from '@angular/router';
import { CellSiteMapNeighborsService } from '../services/cell-site-map-neighbors.service';
import * as L from 'leaflet';
import { Circle, Polygon, Rectangle } from 'leaflet';
import 'leaflet-polylinedecorator';
import { CellSiteAlarmsService } from '../services/data-services/cell-site-alarms.service';
import { CellSiteClustersService } from '../services/data-services/cell-site-clusters.service';
import { CellSiteSlicesService } from '../services/data-services/cell-site-slices.service';
import {
  isNotNull,
  isNotUndefined,
  repeatLatestWhen,
} from '../../../helpers/helpers';
import { CellSiteClusterColorProviderService } from '../services/cell-site-cluster-color-provider.service';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { CellClusterModalComponent } from '../cell-cluster-modal/cell-cluster-modal.component';
import { ActionType, EntityType } from '../../../model/user-last-action.model';
import { HistoryService } from '../../../services/history.service';
import { TranslateService } from '@ngx-translate/core';
import { ConfirmationModalComponent } from '../../../components/shared/confirmation-modal/confirmation-modal.component';
import {
  CELL_GROUP_TYPE_SLICE,
  CELL_GROUP_SELECTED_COLOR,
  CELL_GROUP_SELECTED_STROKE_WEIGHT,
  CELL_ZOOM_HIGHTLIGHTED,
  CLUSTER_COLOR_OPTIONS,
  CITIES_ZOOM,
  LAYER_ATTRIBUTES,
  SITE_SELECTED_BORDER_COLOR,
  SITE_SELECTED_BORDER_WEIGHT,
  SITE_SELECTED_COLOR,
  SLICE_COLOR_OPTIONS,
  STREETS_ZOOM,
} from '../configuration';
import {
  CellSiteMapSearchResult,
  LayerConfiguration,
  LayerKey,
  LayerName,
  LayerSubType,
  LayerType,
  NeighbourDirection,
} from '../cell-site-map.model';
import { QueryParamService } from '../../../services/query-param.service';
import { SliceService } from '../../slice-management/shared/slice.service';
import { CellPolygon } from '../leaflet-extensions';
import {
  ALLOW_NETWORK_CLUSTERS_CREATE,
  VIEW_ALARMS_LIST,
  VIEW_CELL_NEIGHBORS,
  VIEW_NETWORK_CLUSTERS,
  VIEW_SLICE_LIST,
} from '../../../permissions.config';
import { BaseFilterService } from '../../../services/common-functionalities/base-filter.service';
import { AlarmPerceivedSeverity } from '../../../model/alarm.model';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { UserPermissionsService } from '../../../services/user-permissions.service';
import { LayoutService } from '../../../services/layout.service';
import { FullscreenService } from '../../../services/fullscreen.service';
import {
  MapSidePanelId,
  MapSidePanelService,
} from '../services/map-side-panel.service';
import { MapSidebarComponent } from '../map-sidebar/map-sidebar.component';
import { MapSiteListViewStateService } from '../services/map-site-list-view-state.service';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-new-cell-sites-map',
  templateUrl: './new-cell-sites-map.component.html',
  styleUrls: ['./new-cell-sites-map.component.css'],
  // MapSiteListViewStateService lives here, not in the site list component: a
  // detail pane replaces that component in the panel slot and would otherwise
  // reset its sort and page on every "back to list".
  providers: [
    UnsubscribeService,
    MapSidePanelService,
    MapSiteListViewStateService,
  ],
  standalone: false,
  host: {
    '[class.has-neighbour-relations]': 'hasNeighbourRelations()',
  },
})
export class NewCellSitesMapComponent implements AfterViewInit {
  readonly cellId$ = this.queryParamService.getValueOf('cellId');
  readonly latitude$ = this.queryParamService.getValueOf('latitude');
  readonly longitude$ = this.queryParamService.getValueOf('longitude');
  readonly siteName$ = this.queryParamService.getValueOf('siteName');
  readonly sliceId$ = this.queryParamService.getValueOf('sliceId');
  readonly searchTerm = signal('');
  readonly isMapFullscreen = signal(false);

  readonly canZoomIn = this.leafletMapService.canZoomIn;
  readonly canZoomOut = this.leafletMapService.canZoomOut;
  // At the zoom limit the button stays focusable and keeps its tooltip, so the
  // label explains why it no longer does anything.
  readonly zoomInLabel = computed(() =>
    this.canZoomIn()
      ? 'cellSiteMap.button.zoomIn'
      : 'cellSiteMap.button.zoomInLimitReached'
  );
  readonly zoomOutLabel = computed(() =>
    this.canZoomOut()
      ? 'cellSiteMap.button.zoomOut'
      : 'cellSiteMap.button.zoomOutLimitReached'
  );

  private readonly sidePanelService = inject(MapSidePanelService);
  readonly activePanel = this.sidePanelService.activePanel;
  private readonly sidebar = viewChild(MapSidebarComponent);

  /** Widens the side panel for the relations column of the cell table. */
  readonly hasNeighbourRelations = signal(false);

  private readonly layoutService = inject(LayoutService);
  private readonly fullscreenService = inject(FullscreenService);
  private readonly injector = inject(Injector);

  @ViewChild('fullscreenToggleBtn')
  private fullscreenToggleBtn?: ElementRef<HTMLButtonElement>;

  sliceProfiles: any | undefined;
  sliceProperties: SliceDetailsResponse | undefined;

  private selectedSiteMarkers: {
    marker: L.Path;
    original: L.PathOptions;
  }[] = [];

  /** Coverage markers per layer, kept so the cell highlight can be toggled
      without waiting for the next data reload. */
  private readonly cellCoverageMarkers = new Map<
    LayerKey,
    { markers: CellPolygon[]; defaultStyle: L.PathOptions }
  >();

  /** Signals that one cell layer finished (re)building its markers. All cell
      layers share a single debounced filtering pass — see ngAfterViewInit. */
  private readonly cellMarkersRebuilt$ = new Subject<void>();

  constructor(
    private readonly clusterColorsProvider: CellSiteClusterColorProviderService,
    private readonly leafletMapService: LeafletMapService,
    private readonly cellSiteData: CellSiteDataService,
    private readonly unsubscribeService: UnsubscribeService,
    private readonly router: Router,
    public detailService: CellSiteMapDetailService,
    public cellSiteAlarms: CellSiteAlarmsService,
    private readonly cellSiteClusterService: CellSiteClustersService,
    private readonly route: ActivatedRoute,
    private readonly cellSitesNeighbours: CellSiteMapNeighborsService,
    private readonly modalService: NgbModal,
    private readonly historyService: HistoryService,
    private readonly alertService: TnapAlertService,
    private readonly translateService: TranslateService,
    private readonly cellSitesService: CellSitesService,
    private readonly cellSiteSlices: CellSiteSlicesService,
    private readonly queryParamService: QueryParamService,
    private readonly sliceService: SliceService,
    private readonly filterService: BaseFilterService,
    private readonly userPermissionsService: UserPermissionsService,
    private readonly destroyRef$: DestroyRef
  ) {
    destroyRef$.onDestroy(() => {
      this.layoutService.resetMapFullscreen();
      if (document.fullscreenElement) {
        this.fullscreenService.leave();
      }
    });

    this.userPermissionsService
      .checkUserPermissions(VIEW_CELL_NEIGHBORS)
      .pipe(take(1), takeUntilDestroyed(destroyRef$))
      .subscribe(() => this.hasNeighbourRelations.set(true));
  }

  /** Closes the site pane and drops the query params that reopen it. */
  closeSiteDetail(): void {
    this.detailService.closeDetail();
    this.clearSiteMarkerSelection();
    this.clearDetailQueryParams({
      siteName: null,
      latitude: null,
      longitude: null,
      cellId: null,
    });
    this.restoreMapFocus();
  }

  /** The close action dismisses the whole slot, not just the detail pane. */
  closeSiteDetailAndPanel(): void {
    this.sidePanelService.close();
    this.closeSiteDetail();
  }

  /** Sidebar panels and detail panes share one slot, so opening one closes the other. */
  toggleSidebarPanel(panel: MapSidePanelId): void {
    // Toggle first: it drops any suspended panel, so closing the detail pane
    // below cannot restore the panel the user just asked to close.
    this.sidePanelService.toggle(panel);
    if (this.detailService.hasDetail) {
      this.closeSiteDetail();
    }
    if (this.detailService.hasCellGroupDetail) {
      this.closeCellGroupDetail();
    }
    this.leafletMapService.invalidateSize();
  }

  closeSidebarPanel(): void {
    const closedPanel = this.activePanel();
    this.sidePanelService.close();
    this.leafletMapService.invalidateSize();
    if (closedPanel) {
      this.sidebar()?.focusButton(closedPanel);
    }
  }

  /** Closes the cell group pane and drops the query param that reopens it. */
  closeCellGroupDetail(): void {
    this.detailService.closeCellGroupDetail();
    this.clearDetailQueryParams({ sliceId: null });
    this.restoreMapFocus();
  }

  // Removing the pane drops the focus to the body. Re-anchoring it on the map
  // only works after that removal was rendered, and only if nothing else (for
  // example a sidebar panel opening in the same slot) has claimed the focus.
  private restoreMapFocus(): void {
    afterNextRender(
      () => {
        if (
          !document.activeElement ||
          document.activeElement === document.body
        ) {
          this.leafletMapService.focusMap();
        }
      },
      { injector: this.injector }
    );
  }

  private clearDetailQueryParams(queryParams: Record<string, null>): void {
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams,
      queryParamsHandling: 'merge',
      replaceUrl: true,
    });
  }

  toggleFullscreen(): void {
    if (this.isMapFullscreen()) {
      this.fullscreenService.leave();
      this.layoutService.setMapFullscreen(false);
      this.isMapFullscreen.set(false);
    } else {
      this.fullscreenService.enter();
      this.layoutService.setMapFullscreen(true);
      this.isMapFullscreen.set(true);
    }
    // Restore focus after browser fullscreen transition — requestFullscreen() is
    // async and the browser may shift focus during the transition.
    setTimeout(() => this.fullscreenToggleBtn?.nativeElement?.focus());
  }

  zoomIn(): void {
    this.leafletMapService.zoomIn();
  }

  zoomOut(): void {
    this.leafletMapService.zoomOut();
  }

  @HostListener('document:fullscreenchange')
  protected onFullscreenChange(): void {
    if (!document.fullscreenElement) {
      this.layoutService.resetMapFullscreen();
      this.isMapFullscreen.set(false);
      // Restore focus when user exits fullscreen via ESC
      setTimeout(() => this.fullscreenToggleBtn?.nativeElement?.focus());
    }
  }

  //afterViewInit because map container div must already exist
  ngAfterViewInit() {
    // The layer groups below are new and empty on every visit, while the
    // root-scoped data service still remembers the viewport of the previous one.
    // Without this, re-entering the map skips its initial fetch as "already
    // covered" and renders no markers at all.
    this.cellSiteData.resetViewportCoverage();

    this.leafletMapService.onMoveEnd$
      .pipe(takeUntil(this.unsubscribeService.unsubscribe$))
      .subscribe(() => {
        const bounds = this.leafletMapService.getMapBounds();
        const zoom = this.leafletMapService.getMapZoom();
        if (!bounds || !zoom) {
          return;
        }
        this.cellSiteData.reFetchData({ bounds, zoom });
      });

    this.leafletMapService.onInit();

    this.userPermissionsService
      .checkUserPermissions(ALLOW_NETWORK_CLUSTERS_CREATE)
      .pipe(take(1), takeUntilDestroyed(this.destroyRef$))
      .subscribe(() => {
        this.leafletMapService.initPmControls();
      });

    this.cellSiteData.dataFetched$
      .pipe(takeUntil(this.unsubscribeService.unsubscribe$))
      .subscribe(() => {
        this.leafletMapService.emptyMap(
          this.leafletMapService.getLayerKeysOfType(LayerType.NEIGHBOURS)
        );
      });

    // Create Site layer
    Object.entries(LAYER_ATTRIBUTES)
      .filter(configuration => configuration[1].type === LayerType.SITE)
      .forEach(configuration =>
        this.createSiteLayer(
          this.cellSiteData,
          configuration[0] as LayerKey,
          configuration[1]
        )
      );

    // Create cell layer
    Object.entries(LAYER_ATTRIBUTES)
      .filter(configuration => configuration[1].type === LayerType.CELL)
      .sort((layerA, layerB) => layerA[1].order - layerB[1].order)
      .forEach(configuration =>
        this.createCellLayer(
          this.cellSiteData,
          configuration[0] as LayerKey,
          configuration[1]
        )
      );

    // The single place cell filtering happens, driven by both of its triggers:
    // a filter-control change, and any cell layer finishing its markers. Each
    // pass clears the visible group and re-adds every matching input layer, so
    // running it per cell layer multiplied that cost by the number of cell
    // layers on every data load.
    // debounceTime(0) defers execution to the next macrotask so Angular renders
    // the checkbox state change before the (potentially heavy) Leaflet filtering
    // runs. It also collapses the burst of per-layer signals — and rapid
    // successive filter changes — into a single filter pass.
    merge(
      this.leafletMapService.getTnapFilterControlList$(),
      this.cellMarkersRebuilt$
    )
      .pipe(debounceTime(0), takeUntil(this.unsubscribeService.unsubscribe$))
      .subscribe(() => {
        this.leafletMapService.doCellFiltering(
          this.leafletMapService.getTnapFilterControlListValue()
        );
      });

    // Single alarms source shared by both the alarm-marker and the pulse-marker
    // layers. getAlarmsForCellSites() fans out one service-instance lookup per
    // site (an N+1); previously two independent subscriptions ran that fan-out
    // twice per emission. share() multicasts one execution to both consumers.
    const alarms$ = this.userPermissionsService
      .checkUserPermissions(VIEW_ALARMS_LIST)
      .pipe(
        switchMap(() => this.cellSiteAlarms.getAlarmsForCellSites()),
        share()
      );

    alarms$
      .pipe(
        map(enhancedAlarms =>
          enhancedAlarms
            .filter(alarm => alarm !== undefined)
            .map(alarm => createAlarmMarker(alarm!, this.filterService))
        ),
        takeUntilDestroyed(this.destroyRef$)
      )
      .subscribe(alarmMarker => {
        alarmMarker.forEach(marker =>
          this.leafletMapService.addMarkerToLayer(marker, 'alarms')
        );
        this.leafletMapService.reorderLayers();
      });

    // get alarms for site
    // Both subscribers of the shared alarms$ source use takeUntilDestroyed so
    // they tear down together on component destroy (the pulse-marker layer
    // previously used takeUntil(unsubscribeService); that fires only on destroy
    // too, but matching the alarm-marker layer keeps the shared source's refCount
    // teardown consistent).
    alarms$
      .pipe(
        map(alarmAggregation =>
          this.createCriticalAlarmPulseMarkers(alarmAggregation)
        ),
        takeUntilDestroyed(this.destroyRef$)
      )
      .subscribe(alarmMarker => {
        // reorderLayers() hoisted out of the per-marker loop: it removes and
        // re-adds every layer group, so calling it once per marker is O(markers ×
        // layers) of Leaflet DOM churn.
        alarmMarker.forEach(marker =>
          this.leafletMapService.addMarkerToLayer(marker, 'alarms')
        );
        this.leafletMapService.reorderLayers();
      });

    //if we have a detail opened, and we redraw a map, we want to set style of marker which is opened to blue
    this.leafletMapService.onLayerAdd$
      .pipe(
        debounceTime(50),
        withLatestFrom(this.detailService.getDetail()),
        filter(([, cellSiteDetail]) => cellSiteDetail !== undefined),
        takeUntil(this.unsubscribeService.unsubscribe$)
      )
      .subscribe(([, cellSiteDetail]) => {
        this.leafletMapService
          .getAllSiteMarkers()
          .filter(
            marker =>
              marker.getTooltip()?.getContent() ===
              cellSiteDetail?.physicalLocationId
          )
          .forEach(marker =>
            marker?.setStyle({ color: 'blue', fillColor: 'blue' })
          );
      });

    //center on opened cell
    this.detailService
      .getDetail()
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        filter(cellSite => cellSite !== undefined) as OperatorFunction<
          CellSiteResponse | undefined,
          CellSiteResponse
        >
      )
      .subscribe(cellSite => {
        if (!cellSite) {
          return;
        }
        if (!cellSite.latitude) {
          return;
        }
        if (!cellSite.longitude) {
          return;
        }
        this.leafletMapService.focusOnDetail(
          cellSite.latitude,
          cellSite.longitude
        );
      });

    //center on opened slice or cluster
    this.detailService
      .getCellGroupDetail()
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        filter(group => group !== undefined)
      )
      .subscribe();

    //invalidate size when something happens with detail
    combineLatest([
      this.detailService.getDetail(),
      this.detailService.getCellGroupDetail(),
    ])
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        tap(([detail, cellGroupDetail]) => {
          // A detail pane takes over the side panel slot from the sidebar
          // panels; the panel comes back once the pane is closed.
          if (detail || cellGroupDetail) {
            this.sidePanelService.suspend();
          } else {
            this.sidePanelService.restore();
          }
          this.leafletMapService.invalidateSize();
        })
      )
      .subscribe();

    // get cell neighbours
    this.cellSitesNeighbours
      .getNeighbours()
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        repeatLatestWhen(this.cellSiteData.dataFetched$),
        delay(10),
        map(cellsNeighbours => {
          return Object.values(cellsNeighbours).flatMap(neighbourData => {
            const outgoingMarkers = this.cellSitesNeighbours.processNeighbours(
              neighbourData?.neighbours.outgoingNeighbours,
              NeighbourDirection.OUT,
              neighbourData?.cell
            );
            const incomingMarkers = this.cellSitesNeighbours.processNeighbours(
              neighbourData?.neighbours.incomingNeighbours,
              NeighbourDirection.IN,
              neighbourData?.cell
            );
            return [...outgoingMarkers, ...incomingMarkers];
          });
        })
      )
      .subscribe(markers => {
        this.leafletMapService.cleanLayers(
          this.leafletMapService.getLayerKeysOfType(LayerType.NEIGHBOURS)
        );
        markers?.forEach(marker => {
          this.leafletMapService.addMarkerToLayer(
            marker.polygon,
            marker.neighbourLayer
          );
        });
      });

    this.sliceId$
      .pipe(
        filter(isNotNull),
        switchMap(sliceId => this.cellSiteSlices.getSlice(sliceId)),
        takeUntil(this.unsubscribeService.unsubscribe$)
      )
      .subscribe((slice: SliceDetailsResponse) => {
        if (slice.cells && slice.cells.length >= 1) {
          const cellWithLatLong = slice.cells.find(
            cell => cell.latitude && cell.longitude
          );
          if (
            cellWithLatLong?.latitude !== undefined &&
            cellWithLatLong?.longitude !== undefined
          ) {
            this.leafletMapService.setMapCenter(
              cellWithLatLong.latitude,
              cellWithLatLong.longitude
            );
          }
          this.detailService.closeDetail();
          this.detailService.openCellGroupDetail(slice);
        }
      });

    //opening detail that's defined in url
    combineLatest([
      this.cellId$,
      this.latitude$,
      this.longitude$,
      this.siteName$,
    ])
      .pipe(
        // The four params emit one after another, so clearing them all would
        // briefly look like "cell still selected" and reopen the pane.
        debounceTime(0),
        filter(
          ([cellId, lat, long, site]) =>
            (lat !== null && long !== null && site !== null) || cellId !== null
        ),
        map(([cellId, lat, long, site]) => {
          const parsedLat =
            lat !== null && lat !== undefined
              ? Number.parseFloat(lat)
              : Number.NaN;
          const parsedLong =
            long !== null && long !== undefined
              ? Number.parseFloat(long)
              : Number.NaN;
          return [cellId, parsedLat, parsedLong, site] as [
            string,
            number,
            number,
            string,
          ];
        }),
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap(([cellId, lat, long, siteName]) => {
          return of([cellId, lat, long, siteName] as [
            string,
            number,
            number,
            string | undefined,
          ]);
        }),
        switchMap(([cellId, lat, long, siteName]) => {
          if (cellId) {
            return this.cellSitesService
              .getCellByCellId(cellId)
              .pipe(
                map(
                  cell =>
                    [
                      cell.latitude,
                      cell.longitude,
                      cell.sitePhysicalLocationId,
                    ] as [number, number, string | undefined]
                )
              );
          }
          return of([lat, long, siteName] as [
            number,
            number,
            string | undefined,
          ]);
        }),
        switchMap(([lat, long, siteName]) => {
          if (!siteName) {
            return EMPTY;
          }

          if (siteName) {
            this.leafletMapService.focusOnDetail(lat, long);
            return this.cellSiteData.getCellSite(siteName).pipe(
              take(1),
              map(site => {
                return { site };
              })
            );
          }
          return of({ site: null });
        })
      )
      .subscribe(({ site }) => {
        if (site) {
          this.detailService.closeCellGroupDetail();
          this.detailService.openDetail(site);
          this.ensureSiteInUrl(site);
        } else {
          return;
        }
      });

    this.cellId$
      .pipe(takeUntil(this.unsubscribeService.unsubscribe$))
      .subscribe(cellId => this.applyCellMarkerSelection(cellId));

    this.cellId$
      .pipe(
        filter(cellId => cellId !== null),
        takeUntil(this.unsubscribeService.unsubscribe$)
      )
      .subscribe(() =>
        this.leafletMapService.zoomInToAtLeast(CELL_ZOOM_HIGHTLIGHTED)
      );

    this.userPermissionsService
      .checkUserPermissions(VIEW_NETWORK_CLUSTERS)
      .pipe(
        switchMap(() =>
          this.cellSiteClusterService
            .getClusters()
            .pipe(repeatLatestWhen(this.cellSiteData.dataFetched$))
        ),
        takeUntil(this.unsubscribeService.unsubscribe$)
      )
      .subscribe(clusters => {
        this.leafletMapService.cleanLayers([LayerKey.CLUSTERS]);
        clusters.items.forEach(cluster => {
          if (!cluster.cells || cluster.cells.length === 0) {
            return;
          }
          const clusterCellsLocations = cluster.cells.map(cell => {
            if (cell.latitude !== undefined && cell.longitude !== undefined) {
              return { x: cell.latitude, y: cell.longitude };
            } else {
              // Optionally handle the case where latitude or longitude is undefined
              return { x: 0, y: 0 };
            }
          });
          const polygon = createClusterMarker(
            clusterCellsLocations,
            undefined,
            cluster.id,
            cluster.name,
            CLUSTER_COLOR_OPTIONS.at(-1)!,
            this.clusterColorsProvider.getNextColor(CLUSTER_COLOR_OPTIONS),
            false
          );
          if (!polygon) {
            return;
          }
          polygon.on('click', () => {
            this.openCellClusterModal(cluster);
          });
          this.leafletMapService.addMarkerToLayer(polygon, 'clusters');
          this.leafletMapService.reorderLayers();
        });
      });

    // Create slices

    this.userPermissionsService
      .checkUserPermissions(VIEW_SLICE_LIST)
      .pipe(
        switchMap(() =>
          this.sliceService.getSlicesForMap().pipe(
            repeatLatestWhen(this.cellSiteData.dataFetched$),
            takeUntil(this.unsubscribeService.unsubscribe$),
            withLatestFrom(this.sliceId$),
            switchMap(([slices, sliceId]) => {
              // Rebuilt on every map move (repeatLatestWhen). Clear first so
              // polygons are not duplicated on top of the previous pan's markers
              // (clusters already do this; slices previously did not).
              this.leafletMapService.cleanLayers([LayerKey.SLICES]);
              return from(slices.items ?? []).pipe(
                filter(slice => slice != undefined),
                concatMap(slice => {
                  if (!slice.cells || slice.cells.length === 0) {
                    return of(null);
                  }
                  const sliceCellsLocations = slice.cells.map(cell => {
                    if (
                      cell.latitude !== undefined &&
                      cell.longitude !== undefined
                    ) {
                      return { x: cell.latitude, y: cell.longitude };
                    } else {
                      // Optionally handle the case where latitude or longitude is undefined
                      return { x: 0, y: 0 };
                    }
                  });
                  const polygon = createClusterMarker(
                    sliceCellsLocations,
                    CELL_GROUP_TYPE_SLICE,
                    slice.id,
                    slice.name || '',
                    SLICE_COLOR_OPTIONS.at(-1)!,
                    this.clusterColorsProvider.getNextColor(
                      SLICE_COLOR_OPTIONS
                    ),
                    sliceId === slice.id
                  );
                  if (!polygon) {
                    return of(null);
                  }
                  return this.getSliceProperties(slice.id).pipe(
                    tap(sliceProperties => {
                      if (slice.id === sliceId) {
                        this.sliceProperties = sliceProperties;
                      }
                      if (sliceProperties) {
                        const serviceInstanceStr =
                          this.generateServiceInstanceStr(sliceProperties);
                        polygon.bindTooltip(serviceInstanceStr);
                      }
                    }),
                    catchError(error => {
                      console.error('Error occurred:', error);
                      return of(null);
                    }),
                    map(() => {
                      this.addClickHandler(polygon, undefined, slice);
                      this.leafletMapService.addMarkerToLayer(
                        polygon,
                        'slices'
                      );
                    })
                  );
                })
              );
            })
          )
        )
      )
      .subscribe(() => {
        this.leafletMapService.reorderLayers();
      });
  }

  // Build a pulse marker for every site that has at least one CRITICAL alarm.
  // Sites with no critical alarms must NOT get a pulse: `?.length !== 0` was
  // truthy when the filtered critical list was undefined, so those sites were
  // incorrectly pulsed red.
  private createCriticalAlarmPulseMarkers(
    alarmAggregation: Array<
      EnhancedAlarmAggregationServiceInstanceId | undefined
    >
  ) {
    return alarmAggregation
      .map(aggregation => {
        return {
          ...aggregation,
          alarmAggregation: aggregation?.alarmAggregation?.filter(
            severityItem =>
              severityItem.severity?.toLowerCase() ===
              AlarmPerceivedSeverity.CRITICAL.toLowerCase()
          ),
        };
      })
      .filter(
        alarmAggregation => (alarmAggregation.alarmAggregation?.length ?? 0) > 0
      )
      .map(filteredAlarmAggregation =>
        createAlarmPulseMarker(
          filteredAlarmAggregation.lat!,
          filteredAlarmAggregation.long!,
          this.leafletMapService.getMapZoom()
        )
      );
  }

  // Cache slice-detail lookups by slice id. The slice layer is rebuilt on every
  // map move (repeatLatestWhen), and each rebuild fetches a detail per slice — an
  // N+1 that previously re-fired for every slice on every pan. Slice details do
  // not change when the map moves, so replay the first response instead.
  //
  // Lifetime: this cache lives for the lifetime of the component instance. There
  // is no per-entry eviction beyond the empty-response case below, so if a slice
  // is changed server-side (e.g. deleted and re-created with the same id) while
  // the map is open, the cached shareReplay serves stale data. This is bounded to
  // a single visit — the component (and thus the cache) is destroyed on route
  // leave, so re-entering the map refetches. Acceptable for the current
  // navigation pattern; revisit if the map becomes long-lived / never re-created.
  private readonly slicePropertiesCache = new Map<
    string,
    Observable<SliceDetailsResponse | undefined>
  >();

  private getSliceProperties(
    sliceId: string
  ): Observable<SliceDetailsResponse | undefined> {
    let slice$ = this.slicePropertiesCache.get(sliceId);
    if (!slice$) {
      slice$ = this.sliceService.getSliceById(sliceId).pipe(
        // getSliceById swallows fetch errors to `undefined`. Don't let
        // shareReplay cache a transient failure permanently: evict the entry
        // when the response is empty so the next map move retries, while a
        // successful detail stays cached across pans (the N+1 fix).
        tap(slice => {
          if (!slice) {
            this.slicePropertiesCache.delete(sliceId);
          }
        }),
        shareReplay({ bufferSize: 1, refCount: false })
      );
      this.slicePropertiesCache.set(sliceId, slice$);
    }
    return slice$;
  }

  private generateServiceInstanceStr(
    sliceProperties: SliceDetailsResponse
  ): string {
    const sliceName = sliceProperties.sliceProfile?.profileId || '';
    const environmentContext = sliceProperties?.environmentContext;

    return `
  <div style="text-align: center; font-weight: bold;">${truncateString(
    sliceName,
    50
  )}</div>
  <table style="width: 100%;">
    ${
      environmentContext
        ? `<tr><td style="text-align: left;">${this.translateService.instant(
            'activeAvailableInventory.map.cellGroup.environmentContext'
          )}</td><td style="text-align: left;">${truncateString(
            environmentContext,
            50
          )}</td></tr>`
        : ''
    }
  </table>
`;
  }

  private openCellClusterModal(cluster: CellGroup): void {
    const networksCells = cluster.cells?.map(cell => ({
      ...cell,
      selected: true,
    }));
    if (networksCells?.length === 0) {
      return;
    }
    const modalRef = this.modalService.open(CellClusterModalComponent, {
      backdropClass: 'backdropClass',
    });
    modalRef.componentInstance.networkCells = networksCells;
    modalRef.componentInstance.clusterName = cluster.id;
    modalRef.componentInstance.clusterClass = cluster.name;
    modalRef.componentInstance.isEdit = true;
    modalRef.closed
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        switchMap((action: CellEditPaneActions) =>
          combineLatest([
            of(action),
            this.handleModalAction(action, modalRef, cluster.id, cluster),
          ])
        )
      )
      .subscribe(([action]) => {
        this.alertService.success(
          this.translateService.instant(
            'cellCluster.messages.success.' + action
          ),
          { keepAfterRouteChange: true }
        );
        this.cellSiteClusterService.refetchClusters();
      });
  }

  private handleModalAction(
    action: CellEditPaneActions,
    modalRef: NgbModalRef,
    clusterName: string,
    cluster: CellGroup
  ): Observable<ActionsResponse> {
    if (action === CellEditPaneActions.CANCEL) {
      return EMPTY;
    }
    if (action === CellEditPaneActions.DELETE) {
      return this.handleDeleteAction(clusterName, cluster);
    }
    if (action === CellEditPaneActions.EDIT) {
      return this.handleEditAction(modalRef, clusterName, cluster);
    }
    return EMPTY;
  }

  private handleDeleteAction(
    clusterName: string,
    cluster: CellGroup
  ): Observable<ActionsResponse> {
    const modalConfRef = this.modalService.open(ConfirmationModalComponent, {
      backdropClass: 'backdropClass',
      // ACCESSIBILITY FIX
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-desc',
    });
    modalConfRef.componentInstance.title = this.translateService.instant(
      'cellCluster.edit.deleteTitle'
    );
    modalConfRef.componentInstance.okText = this.translateService.instant(
      'common.buttons.delete'
    );
    modalConfRef.componentInstance.text = this.translateService.instant(
      'cellCluster.edit.deleteModal.text',
      {
        name: clusterName,
      }
    );
    modalConfRef.componentInstance.confirmButton =
      this.translateService.instant('common.buttons.delete');
    modalConfRef.componentInstance.cancelButton = this.translateService.instant(
      'common.buttons.cancel'
    );
    return modalConfRef.closed.pipe(
      take(1),
      filter((result: boolean) => result),
      switchMap(() =>
        this.cellSiteClusterService.deleteCluster(cluster).pipe(
          switchMap(() =>
            this.historyService.createClusterHistoryAction({
              type: ActionType.DELETE,
              entity: EntityType.CLUSTER,
              entityParams: { clusterName },
            })
          ),
          take(1)
        )
      )
    );
  }

  private handleEditAction(
    modalRef: NgbModalRef,
    clusterName: string,
    cluster: CellGroup
  ): Observable<ActionsResponse> {
    const editedCluster = this.leafletMapService.prepareClusterBody(
      modalRef.componentInstance.networkCells,
      modalRef.componentInstance.clusterName,
      modalRef.componentInstance.clusterClass,
      cluster.id,
      cluster.resourceVersion
    );
    return this.cellSiteClusterService.clusterExists(editedCluster.id).pipe(
      take(1),
      switchMap(exists => {
        if (exists && editedCluster.id !== clusterName) {
          this.alertService.error(
            this.translateService.instant(
              'cellCluster.messages.error.duplicateName',
              {
                name: editedCluster.id,
              }
            ),
            { keepAfterRouteChange: true }
          );
          return EMPTY;
        } else {
          return this.cellSiteClusterService.editCluster(editedCluster).pipe(
            switchMap(() =>
              this.historyService.createClusterHistoryAction({
                type: ActionType.EDIT,
                entity: EntityType.CLUSTER,
                entityParams: { clusterName },
              })
            ),
            take(1)
          );
        }
      })
    );
  }

  private generateMarkersFromCellSitesResponse(
    cellSites: CellSiteResponse[],
    configKey: LayerKey
  ) {
    const mapZoom = this.leafletMapService.getMapZoom();
    return cellSites.map(cellSite => {
      return this.createMarkers(cellSite, configKey, mapZoom);
    });
  }

  private createMarkers(
    cellSite: CellSiteResponse,
    configKey: LayerKey,
    mapZoom: number
  ) {
    const marker: (L.Circle | L.Polygon | L.Rectangle | undefined)[] = [];
    const layerConfig = LAYER_ATTRIBUTES[configKey];
    let cellOnlyPosition: { latitude: number; longitude: number }[] | undefined;
    const tooltipHint = this.hasNoCellsAtAll(cellSite)
      ? this.translateService.instant(
          'activeAvailableInventory.map.cellAttributes.emptyState.description'
        )
      : undefined;

    if (
      layerConfig.subType === LayerSubType.SITE_ONLY &&
      this.isSiteOnly(cellSite)
    ) {
      marker.push(
        createSiteMarker(
          cellSite,
          mapZoom,
          layerConfig,
          undefined,
          undefined,
          tooltipHint
        )
      );

      // create siteMarkers for all cells which have different coordinates
      cellOnlyPosition = this.getUniqueDifferentCoordinates(cellSite);
      cellOnlyPosition.forEach(cellPosition => {
        marker.push(
          createSiteMarker(
            cellSite,
            mapZoom,
            LAYER_ATTRIBUTES[
              configKey.replace(LayerSubType.SITE_ONLY, LayerSubType.CELLS_ONLY)
            ],
            cellPosition.longitude,
            cellPosition.latitude
          )
        );
      });
    } else if (
      layerConfig.subType === LayerSubType.SITE_CELLS &&
      this.isSiteCells(cellSite)
    ) {
      marker.push(
        createSiteMarker(
          cellSite,
          mapZoom,
          layerConfig,
          undefined,
          undefined,
          tooltipHint
        )
      );

      // create siteMarkers for all cells which have different coordinates
      cellOnlyPosition = this.getUniqueDifferentCoordinates(cellSite);
      cellOnlyPosition.forEach(cellPosition => {
        marker.push(
          createSiteMarker(
            cellSite,
            mapZoom,
            LAYER_ATTRIBUTES[
              configKey.replace(
                LayerSubType.SITE_CELLS,
                LayerSubType.CELLS_ONLY
              )
            ],
            cellPosition.longitude,
            cellPosition.latitude
          )
        );
      });
    } else {
      return undefined;
    }
    const siteMarkers = marker.filter(isNotUndefined);
    siteMarkers.forEach(siteMarker =>
      this.addClickHandler(siteMarker, cellSite, undefined, siteMarkers)
    );
    if (cellSite.physicalLocationId === this.detailService.selectedSiteId) {
      this.selectSiteMarkers(siteMarkers);
    }
    return marker;
  }

  /**
   * Highlights the markers of the currently selected site and remembers their
   * default style so the selection can be reverted when the detail pane closes.
   * The list is replaced on every call because only one site can be selected,
   * which also keeps the highlight alive when markers are rebuilt after a map move.
   */
  private selectSiteMarkers(markers: L.Path[]): void {
    this.selectedSiteMarkers = markers.map(marker => ({
      marker,
      original: {
        color: marker.options.color,
        fillColor: marker.options.fillColor,
        fillOpacity: marker.options.fillOpacity,
        opacity: marker.options.opacity,
        weight: marker.options.weight,
      },
    }));
    markers.forEach(marker =>
      marker.setStyle({
        color: SITE_SELECTED_BORDER_COLOR,
        fillColor: SITE_SELECTED_COLOR,
        fillOpacity: 1,
        opacity: 1,
        weight: SITE_SELECTED_BORDER_WEIGHT,
      })
    );
  }

  /** Restores the default style of the previously selected site markers. */
  private clearSiteMarkerSelection(): void {
    this.selectedSiteMarkers.forEach(({ marker, original }) =>
      marker.setStyle(original)
    );
    this.selectedSiteMarkers = [];
  }

  /** Highlights the coverage of the given cell and resets all others. */
  private applyCellMarkerSelection(cellId: string | null): void {
    this.cellCoverageMarkers.forEach(({ markers, defaultStyle }) =>
      markers.forEach(marker =>
        marker.setStyle(
          cellId !== null && marker.cellId === cellId
            ? CELL_SELECTED_STYLE
            : defaultStyle
        )
      )
    );
  }

  /** Adds the site reference to the URL so deselecting a cell keeps the pane open. */
  private ensureSiteInUrl(site: CellSiteResponse): void {
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: {
        siteName: site.physicalLocationId,
        latitude: site.latitude,
        longitude: site.longitude,
      },
      queryParamsHandling: 'merge',
      replaceUrl: true,
    });
  }

  private addClickHandler(
    marker: Polygon | Circle | Rectangle | undefined,
    cellSite: CellSiteResponse | undefined,
    slice: SliceResponse | undefined,
    siteMarkers?: L.Path[]
  ) {
    if (marker != undefined) {
      let queryParams = {};
      this.leafletMapService.addOnClickHandlerToMarker(
        marker,
        cellSite,
        slice,
        () => {
          if (cellSite) {
            this.clearSiteMarkerSelection();
            this.selectSiteMarkers(siteMarkers ?? [marker]);
            queryParams = {
              latitude: cellSite.latitude,
              longitude: cellSite.longitude,
              siteName: cellSite.physicalLocationId,
            };
          } else {
            marker.setStyle({
              color: CELL_GROUP_SELECTED_COLOR,
              fillColor: CELL_GROUP_SELECTED_COLOR,
              weight: CELL_GROUP_SELECTED_STROKE_WEIGHT,
            });
            queryParams = { sliceId: slice?.id };
          }
          this.router.navigate([], {
            relativeTo: this.route,
            queryParams,
          });
        }
      );
    }
  }

  // A site without cells in the payload cannot be classified by coordinates.
  // That covers both a sitesOnly=true response below the cell render zoom (cells
  // withheld, cellCount still accurate) and a site that genuinely has none —
  // both draw the ordinary site marker instead of the SITE_ONLY square.
  private hasNoComparableCells(cellSite: CellSiteResponse): boolean {
    return !cellSite.cells?.length;
  }

  // Only cellCount tells a genuinely empty site apart from one whose cells were
  // withheld below the cell render zoom.
  private hasNoCellsAtAll(cellSite: CellSiteResponse): boolean {
    return !cellSite.cells?.length && !cellSite.cellCount;
  }

  // Checks if any of the cells in a given `CellSiteResponse` share the same latitude or longitude as the site.
  // return `true` if any cell shares the same latitude or longitude as the site, or `false` if `cellSites.cells` is null or undefined.
  private isSiteCells(cellSites: CellSiteResponse): boolean {
    // Exactly one of isSiteCells/isSiteOnly must be true or createMarkers emits
    // nothing and the site disappears from the map.
    if (this.hasNoComparableCells(cellSites)) {
      return true;
    }
    return (
      cellSites.cells?.some(
        cell =>
          cell.latitude.toFixed(4) === cellSites.latitude.toFixed(4) ||
          cell.longitude.toFixed(4) === cellSites.longitude.toFixed(4)
      ) ?? false
    ); // false if cellSites.cells null or undefined
  }

  // Checks if all cells in a given `CellSiteResponse` have different latitude and longitude coordinates from the site.
  // return `true` if all cells have different latitude and longitude coordinates from the site, or `false` if `cellSites.cells` is null or undefined.
  private isSiteOnly(cellSites: CellSiteResponse): boolean {
    // Without this guard `[].every()` is vacuously true and every site without
    // cells in the payload would be reclassified into this layer, silently
    // swapping its shape and colour.
    if (this.hasNoComparableCells(cellSites)) {
      return false;
    }
    return (
      cellSites.cells?.every(
        cell =>
          cell.latitude.toFixed(4) !== cellSites.latitude.toFixed(4) &&
          cell.longitude.toFixed(4) !== cellSites.longitude.toFixed(4)
      ) ?? false
    ); // false if cellSites.cells null or undefined
  }

  private getUniqueDifferentCoordinates(
    cellSite: CellSiteResponse
  ): { latitude: number; longitude: number }[] {
    const uniqueCoordinates: Set<string> = new Set();

    const uniqueDifferentCoordinates: {
      latitude: number;
      longitude: number;
    }[] = [];

    if (cellSite.cells) {
      for (const cell of cellSite.cells) {
        const cellCoordinates = `${cell.latitude.toFixed(
          4
        )},${cell.longitude.toFixed(4)}`;
        const siteCoordinates = `${cellSite.latitude.toFixed(
          4
        )},${cellSite.longitude.toFixed(4)}`;

        if (
          cellCoordinates !== siteCoordinates &&
          !uniqueCoordinates.has(cellCoordinates)
        ) {
          uniqueDifferentCoordinates.push({
            latitude: cell.latitude,
            longitude: cell.longitude,
          });
          uniqueCoordinates.add(cellCoordinates);
        }
      }
    }
    return uniqueDifferentCoordinates;
  }

  private createCellLayer(
    data: CellSiteDataService,
    configKey: LayerKey,
    cellConfiguration: LayerConfiguration
  ) {
    data
      .getCellsFiltered(cellConfiguration)
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        withLatestFrom(this.cellId$),
        map(([cells, cellId]) => {
          const renderer = this.leafletMapService.getCellCoverageRenderer();
          // Wedges built before the map exists fall back to one SVG <path> each,
          // which renders correctly and so regresses only the load time this
          // renderer exists to fix — invisible without a warning. Reachable only
          // if the order in ngAfterViewInit (onInit before createCellLayer) or
          // the non-replaying cell source changes.
          if (!renderer && cells.length > 0 && isDevMode()) {
            console.warn(
              `Cell coverage for ${configKey} was built before the map existed; it falls back to SVG.`
            );
          }
          const markers = cells
            .filter(cell => cell !== undefined)
            .map(cell =>
              createCellCoverage(
                cell,
                cellId,
                configKey,
                this.leafletMapService.frequencyDistanceLists,
                renderer
              )
            );
          this.cellCoverageMarkers.set(configKey, {
            markers,
            defaultStyle: getCellCoverageStyle(configKey),
          });
          return markers;
        }),
        map((cellMarkers: CellPolygon[]) =>
          cellMarkers.map(marker =>
            marker.on('click', () =>
              this.router.navigate(['/cell-site-map'], {
                queryParams: { cellId: marker.cellId },
              })
            )
          )
        ),
        map(cellMarkers =>
          cellMarkers.forEach(marker =>
            this.leafletMapService.addMarkerToLayer(
              marker,
              LayerName.INPUT_CELLS
            )
          )
        )
      )
      .subscribe(() => {
        // Only announce that this layer's markers are ready. Filtering them into
        // the visible group is a full clearLayers() + re-addLayer() over *every*
        // input layer, so it must not run once per cell layer.
        this.cellMarkersRebuilt$.next();
      });
  }

  private createSiteLayer(
    data: CellSiteDataService,
    configKey: LayerKey,
    cellConfiguration: LayerConfiguration
  ) {
    data
      .getSitesFiltered(cellConfiguration)
      .pipe(
        takeUntil(this.unsubscribeService.unsubscribe$),
        delay(10),
        map(cellSites =>
          this.generateMarkersFromCellSitesResponse(cellSites, configKey)
        )
      )
      .subscribe(markers => {
        markers.forEach(markerArray => {
          markerArray?.forEach(marker => {
            if (marker != undefined) {
              this.leafletMapService.addMarkerToLayer(
                marker,
                cellConfiguration.layer
              );
            }
          });
        });
      });
  }

  onSearch(term: string | undefined): void {
    if (!term?.trim()) {
      return;
    }
    this.searchTerm.set(term ?? '');
    this.cellSiteData
      .search(term)
      .pipe(take(1))
      .subscribe(results => {
        if (!results.length) {
          return;
        }
        const first = results[0] as CellSiteMapSearchResult;
        if (first.type === 'cell-site') {
          this.detailService.openDetail(first.data as CellSiteResponse);
        } else if (first.type === 'place') {
          const place = first.data as AddressSuggestion;
          this.cellSiteData
            .selectPlace(place.id)
            .pipe(
              take(1),
              map(data => (data.results ? data.results[0] : undefined)),
              filter(isNotUndefined)
            )
            .subscribe((data: AddressSearchResult) => {
              const zoomLevel =
                place.locationType === 'Street' ? STREETS_ZOOM : CITIES_ZOOM;
              this.detailService.closeDetail();
              this.leafletMapService.setMapCenter(
                data.coordinate?.latitude ?? 0,
                data.coordinate?.longitude ?? 0,
                zoomLevel
              );
            });
        }
      });
  }

  onSearchReset(): void {
    this.searchTerm.set('');
  }
}
