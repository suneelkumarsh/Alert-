/*
 * Copyright (c) 2024. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CellSiteMapFilterComponent } from './cell-site-map-filter.component';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { OAuthModule } from 'angular-oauth2-oidc';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { LeafletMapService } from '../services/leaflet-map.service';
import { AuthService } from '@portal-mfe/auth';
import { ModalService } from '../../../components/modal/modal.service';
import { CellSiteClustersService } from '../services/data-services/cell-site-clusters.service';
import { HistoryService } from '../../../services/history.service';
import {
  provideHttpClient,
  withInterceptorsFromDi,
} from '@angular/common/http';
import { of } from 'rxjs';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

class MockCellSiteClustersService {
  getClusters = jasmine.createSpy().and.returnValue(of({ items: [] }));
  createCluster = jasmine.createSpy().and.returnValue(of({}));
  editCluster = jasmine.createSpy().and.returnValue(of({}));
  deleteCluster = jasmine.createSpy().and.returnValue(of({}));
  refetchClusters = jasmine.createSpy();
  clusterExists = jasmine.createSpy().and.returnValue(of(false));
}

describe('CellSiteMapFilterComponent', () => {
  let component: CellSiteMapFilterComponent;
  let fixture: ComponentFixture<CellSiteMapFilterComponent>;
  let authServiceMock: jasmine.SpyObj<AuthService>;

  beforeEach(async () => {
    authServiceMock = jasmine.createSpyObj('AuthService', [
      'getUserPermissions',
    ]);
    await TestBed.configureTestingModule({
      declarations: [CellSiteMapFilterComponent],
      imports: [TranslateModule.forRoot(), OAuthModule.forRoot()],
      providers: [
        LeafletMapService,
        TranslateService,
        { provide: AuthService, useValue: authServiceMock },
        ModalService,
        HistoryService,
        TnapAlertService,
        {
          provide: CellSiteClustersService,
          useValue: new MockCellSiteClustersService(),
        },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting(),
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(CellSiteMapFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should start with the RAT level expanded', () => {
    expect(component.topExpanded()).toBeTrue();
  });

  it('should toggle topExpanded on toggleTopLevel()', () => {
    component.toggleTopLevel();
    expect(component.topExpanded()).toBeFalse();
    component.toggleTopLevel();
    expect(component.topExpanded()).toBeTrue();
  });

  it('should return 0 for checkedRatCount when tnapFilterControl is undefined', () => {
    fixture.componentRef.setInput('tnapFilterControl', undefined);
    expect(component.checkedRatCount()).toBe(0);
  });

  it('should count only checked RATs in checkedRatCount', () => {
    fixture.componentRef.setInput('tnapFilterControl', [
      {
        id: 'nr',
        rat: 'NR',
        checked: true,
        color: '',
        icon: '',
        expanded: false,
        selectedAll: true,
        bands: [],
      },
      {
        id: 'lte',
        rat: 'LTE',
        checked: false,
        color: '',
        icon: '',
        expanded: false,
        selectedAll: false,
        bands: [],
      },
      {
        id: 'gsm',
        rat: 'GSM',
        checked: true,
        color: '',
        icon: '',
        expanded: false,
        selectedAll: true,
        bands: [],
      },
    ]);
    expect(component.checkedRatCount()).toBe(2);
  });

  describe('onRatChange', () => {
    it('should set rat.checked and propagate to bands/frequencies when not selectAll', () => {
      const rat = {
        id: 'nr',
        rat: 'NR',
        checked: true,
        color: '',
        icon: '',
        expanded: false,
        selectedAll: true,
        bands: [
          {
            id: 'b1',
            band: 'n78',
            checked: true,
            frequencies: [{ id: 'f1', frequency: '643666', checked: true }],
          },
        ],
      };
      fixture.componentRef.setInput('tnapFilterControl', [rat]);
      component.onRatChange(rat, false);
      expect(rat.checked).toBeFalse();
      expect(rat.selectedAll).toBeFalse();
      expect(rat.bands[0].checked).toBeFalse();
      expect(rat.bands[0].frequencies[0].checked).toBeFalse();
    });

    it('should NOT change rat.checked when selectAll=true', () => {
      const rat = {
        id: 'nr',
        rat: 'NR',
        checked: true,
        color: '',
        icon: '',
        expanded: false,
        selectedAll: false,
        bands: [
          {
            id: 'b1',
            band: 'n78',
            checked: false,
            frequencies: [{ id: 'f1', frequency: '643666', checked: false }],
          },
        ],
      };
      fixture.componentRef.setInput('tnapFilterControl', [rat]);
      component.onRatChange(rat, true, true);
      expect(rat.checked).toBeTrue(); // unchanged
      expect(rat.selectedAll).toBeTrue();
      expect(rat.bands[0].checked).toBeTrue();
    });
  });

  describe('onBandChange', () => {
    it('should set band.checked and propagate to frequencies', () => {
      const band = {
        id: 'b1',
        band: 'n78',
        checked: true,
        frequencies: [{ id: 'f1', frequency: '643666', checked: true }],
      };
      fixture.componentRef.setInput('tnapFilterControl', [
        {
          id: 'nr',
          rat: 'NR',
          checked: true,
          color: '',
          icon: '',
          expanded: false,
          selectedAll: true,
          bands: [band],
        },
      ]);
      component.onBandChange(band, false);
      expect(band.checked).toBeFalse();
      expect(band.frequencies[0].checked).toBeFalse();
    });
  });

  describe('onFrequencyChange', () => {
    it('should set frequency.checked', () => {
      const frequency = { id: 'f1', frequency: '643666', checked: false };
      fixture.componentRef.setInput('tnapFilterControl', [
        {
          id: 'nr',
          rat: 'NR',
          checked: true,
          color: '',
          icon: '',
          expanded: false,
          selectedAll: true,
          bands: [
            { id: 'b1', band: 'n78', checked: true, frequencies: [frequency] },
          ],
        },
      ]);
      component.onFrequencyChange(frequency, true);
      expect(frequency.checked).toBeTrue();
    });
  });
});
