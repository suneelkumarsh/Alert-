/*
 * Copyright (c) 2023. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CellSiteMapLayerComponent } from './cell-site-map-layer.component';
import { LeafletMapService } from '../services/leaflet-map.service';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AuthService, PermissionModel } from '@portal-mfe/auth';
import { ModalService } from '../../../components/modal/modal.service';
import { CellSiteClustersService } from '../services/data-services/cell-site-clusters.service';
import { HistoryService } from '../../../services/history.service';
import { OAuthModule } from 'angular-oauth2-oidc';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import {
  provideHttpClient,
  withInterceptorsFromDi,
} from '@angular/common/http';
import { of } from 'rxjs';
import {
  TnapLayerControl,
  TnapLayerControlItem,
  TnapLayerControlSubGroup,
} from '../cell-site-map.model';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

class MockCellSiteClustersService {
  getClusters = jasmine.createSpy().and.returnValue(of({ items: [] }));
  createCluster = jasmine.createSpy().and.returnValue(of({}));
  editCluster = jasmine.createSpy().and.returnValue(of({}));
  deleteCluster = jasmine.createSpy().and.returnValue(of({}));
  refetchClusters = jasmine.createSpy();
  clusterExists = jasmine.createSpy().and.returnValue(of(false));
}

function mockLayerGroup(layerCount = 0): any {
  return { getLayers: () => Array(layerCount).fill({}) };
}

function mockItem(
  partial: Partial<TnapLayerControlItem> = {}
): TnapLayerControlItem {
  return {
    key: 'item-1',
    label: 'Item 1',
    checked: false,
    color: '#000',
    icon: 'bi-circle',
    hidden: false,
    layerGroup: mockLayerGroup(0),
    weight: 1,
    ...partial,
  } as TnapLayerControlItem;
}

function mockGroup(partial: Partial<TnapLayerControl> = {}): TnapLayerControl {
  return {
    groupKey: 'TEST',
    groupName: 'Test',
    groupType: 'SIMPLE_LIST',
    expanded: false,
    selectAll: false,
    items: [],
    ...partial,
  };
}

describe('CellSiteMapLayerComponent', () => {
  let component: CellSiteMapLayerComponent;
  let fixture: ComponentFixture<CellSiteMapLayerComponent>;
  let authServiceMock: jasmine.SpyObj<AuthService>;

  beforeEach(async () => {
    authServiceMock = jasmine.createSpyObj('AuthService', [
      'getUserPermissions',
    ]);
    authServiceMock.getUserPermissions.and.returnValue(of([]));
    await TestBed.configureTestingModule({
      declarations: [CellSiteMapLayerComponent],
      imports: [TranslateModule.forRoot(), OAuthModule.forRoot()],
      providers: [
        LeafletMapService,
        TranslateService,
        { provide: AuthService, useValue: authServiceMock },
        ModalService,
        HistoryService,
        TnapAlertService,
        {
          provide: CellSiteClustersService,
          useValue: new MockCellSiteClustersService(),
        },
        provideHttpClient(withInterceptorsFromDi()),
        provideHttpClientTesting(),
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CellSiteMapLayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('groupCheckedCount', () => {
    it('should return 0 when no items are checked', () => {
      const group = mockGroup({ items: [mockItem(), mockItem()] });
      expect(component.groupCheckedCount(group)).toBe(0);
    });

    it('should count only checked visible items', () => {
      const group = mockGroup({
        items: [
          mockItem({ checked: true }),
          mockItem({ checked: true }),
          mockItem({ checked: false }),
        ],
      });
      expect(component.groupCheckedCount(group)).toBe(2);
    });

    it('should exclude hidden items from the count', () => {
      const group = mockGroup({
        items: [
          mockItem({ checked: true, hidden: true }),
          mockItem({ checked: true }),
        ],
      });
      expect(component.groupCheckedCount(group)).toBe(1);
    });

    it('should use items from subGroups when subGroups are present', () => {
      const group = mockGroup({
        subGroups: [
          {
            subGroupKey: 'A',
            subGroupName: 'A',
            expanded: true,
            items: [mockItem({ checked: true }), mockItem()],
          },
          {
            subGroupKey: 'B',
            subGroupName: 'B',
            expanded: true,
            items: [mockItem({ checked: true })],
          },
        ],
      });
      expect(component.groupCheckedCount(group)).toBe(2);
    });
  });

  describe('groupHasSomeChecked', () => {
    it('should return false when no items are checked', () => {
      const group = mockGroup({ items: [mockItem(), mockItem()] });
      expect(component.groupHasSomeChecked(group)).toBeFalse();
    });

    it('should return true when some but not all visible items are checked', () => {
      const group = mockGroup({
        items: [mockItem({ checked: true }), mockItem({ checked: false })],
      });
      expect(component.groupHasSomeChecked(group)).toBeTrue();
    });

    it('should return false when all visible items are checked', () => {
      const group = mockGroup({
        items: [mockItem({ checked: true }), mockItem({ checked: true })],
      });
      expect(component.groupHasSomeChecked(group)).toBeFalse();
    });

    it('should not count hidden items as visible', () => {
      // Only 1 visible item (the hidden one is excluded) and it is checked → all checked → false
      const group = mockGroup({
        items: [
          mockItem({ checked: true }),
          mockItem({ checked: false, hidden: true }),
        ],
      });
      expect(component.groupHasSomeChecked(group)).toBeFalse();
    });

    it('should return false for a group with no items (empty → nothing checked)', () => {
      expect(
        component.groupHasSomeChecked(mockGroup({ items: [] }))
      ).toBeFalse();
    });

    it('should return true for subGroup-based group when some items are checked', () => {
      // groupHasSomeChecked drives the indeterminate state of the select-all checkbox;
      // it must also work correctly for groups that use subGroups instead of flat items.
      const group = mockGroup({
        subGroups: [
          {
            subGroupKey: 'A',
            subGroupName: 'A',
            expanded: true,
            items: [mockItem({ checked: true }), mockItem({ checked: false })],
          },
        ],
      });
      expect(component.groupHasSomeChecked(group)).toBeTrue();
    });

    it('should return false for subGroup-based group when all items are checked', () => {
      const group = mockGroup({
        subGroups: [
          {
            subGroupKey: 'A',
            subGroupName: 'A',
            expanded: true,
            items: [mockItem({ checked: true }), mockItem({ checked: true })],
          },
        ],
      });
      expect(component.groupHasSomeChecked(group)).toBeFalse();
    });

    // Indeterminate state transition: after toggleAllCheckboxes(true) the select-all
    // checkbox must no longer be in indeterminate state (groupHasSomeChecked === false).
    it('should return false after toggleAllCheckboxes selects all items', () => {
      const svc = TestBed.inject(LeafletMapService);
      spyOn(svc, 'toggleControlLayer').and.stub();
      spyOn(svc, 'reorderLayers').and.stub();

      const items = [mockItem({ checked: true }), mockItem({ checked: false })];
      const group = mockGroup({ items });

      // Before: some checked → indeterminate
      expect(component.groupHasSomeChecked(group)).toBeTrue();

      component.toggleAllCheckboxes(group, true);

      // After: all checked → no longer indeterminate
      expect(component.groupHasSomeChecked(group)).toBeFalse();
    });

    // Indeterminate state transition: after toggleAllCheckboxes(false) the select-all
    // checkbox must no longer be indeterminate either (none checked).
    it('should return false after toggleAllCheckboxes deselects all items', () => {
      const svc = TestBed.inject(LeafletMapService);
      spyOn(svc, 'toggleControlLayer').and.stub();
      spyOn(svc, 'reorderLayers').and.stub();

      const items = [mockItem({ checked: true }), mockItem({ checked: false })];
      const group = mockGroup({ items });

      expect(component.groupHasSomeChecked(group)).toBeTrue();

      component.toggleAllCheckboxes(group, false);

      expect(component.groupHasSomeChecked(group)).toBeFalse();
    });
  });

  describe('subGroupCheckedCount', () => {
    it('should return the count of checked items in a subGroup', () => {
      const subGroup: TnapLayerControlSubGroup = {
        subGroupKey: 'SG',
        subGroupName: 'SG',
        expanded: true,
        items: [
          mockItem({ checked: true }),
          mockItem({ checked: false }),
          mockItem({ checked: true }),
        ],
      };
      expect(component.subGroupCheckedCount(subGroup)).toBe(2);
    });

    it('should return 0 for an empty subGroup', () => {
      const subGroup: TnapLayerControlSubGroup = {
        subGroupKey: 'SG',
        subGroupName: 'SG',
        expanded: true,
        items: [],
      };
      expect(component.subGroupCheckedCount(subGroup)).toBe(0);
    });
  });

  describe('toggleSubGroupAccordion', () => {
    it('should toggle subGroup.expanded from false to true', () => {
      const subGroup: TnapLayerControlSubGroup = {
        subGroupKey: 'SG',
        subGroupName: 'SG',
        expanded: false,
        items: [],
      };
      component.toggleSubGroupAccordion(subGroup);
      expect(subGroup.expanded).toBeTrue();
    });

    it('should toggle subGroup.expanded from true to false', () => {
      const subGroup: TnapLayerControlSubGroup = {
        subGroupKey: 'SG',
        subGroupName: 'SG',
        expanded: true,
        items: [],
      };
      component.toggleSubGroupAccordion(subGroup);
      expect(subGroup.expanded).toBeFalse();
    });
  });

  describe('toggleAllCheckboxes', () => {
    let leafletMapService: LeafletMapService;

    beforeEach(() => {
      leafletMapService = TestBed.inject(LeafletMapService);
      spyOn(leafletMapService, 'toggleControlLayer').and.stub();
      spyOn(leafletMapService, 'reorderLayers').and.stub();
    });

    it('should set all items to checked=true', () => {
      const items = [mockItem(), mockItem()];
      const group = mockGroup({ items });
      component.toggleAllCheckboxes(group, true);
      expect(items.every(i => i.checked)).toBeTrue();
    });

    it('should set all items to checked=false', () => {
      const items = [mockItem({ checked: true }), mockItem({ checked: true })];
      const group = mockGroup({ items });
      component.toggleAllCheckboxes(group, false);
      expect(items.every(i => i.checked)).toBeFalse();
    });

    it('should update group.selectAll', () => {
      const group = mockGroup({ items: [mockItem()] });
      component.toggleAllCheckboxes(group, true);
      expect(group.selectAll).toBeTrue();
    });

    // Empty groups must be toggled too: emptyMap() clears them on every viewport
    // refetch, so skipping them would strand the group off the map.
    it('should call toggleControlLayer for every item, including empty groups', () => {
      const itemWithLayer = mockItem({
        key: 'with-layer',
        layerGroup: mockLayerGroup(1),
      });
      const itemWithoutLayer = mockItem({
        key: 'no-layer',
        layerGroup: mockLayerGroup(0),
      });
      component.toggleAllCheckboxes(
        mockGroup({ items: [itemWithLayer, itemWithoutLayer] }),
        true
      );
      expect(leafletMapService.toggleControlLayer).toHaveBeenCalledTimes(2);
      expect(leafletMapService.toggleControlLayer).toHaveBeenCalledWith(
        'with-layer',
        true,
        false
      );
      expect(leafletMapService.toggleControlLayer).toHaveBeenCalledWith(
        'no-layer',
        true,
        false
      );
    });

    it('should call reorderLayers after updating items', () => {
      component.toggleAllCheckboxes(mockGroup(), true);
      expect(leafletMapService.reorderLayers).toHaveBeenCalledTimes(1);
    });

    // Delegating keeps the empty-filter message in sync with select all.
    it('should delegate the bulk change to the map service', () => {
      spyOn(leafletMapService, 'setLayerItemsChecked').and.callThrough();
      const items = [mockItem({ checked: true })];

      component.toggleAllCheckboxes(mockGroup({ items }), false);

      expect(leafletMapService.setLayerItemsChecked).toHaveBeenCalledOnceWith(
        items,
        false
      );
    });

    it('(Finding 3) calling with checked=true from indeterminate state selects all items', () => {
      // tnap-checkbox emits true when clicked from indeterminate state
      // (native browser behaviour: indeterminate → first click → checked=true).
      const items = [mockItem({ checked: true }), mockItem({ checked: false })];
      const group = mockGroup({ items, selectAll: false }); // some checked → indeterminate
      component.toggleAllCheckboxes(group, true); // simulates checkedChange emitting true
      expect(items.every(i => i.checked)).toBeTrue();
      expect(group.selectAll).toBeTrue();
    });
  });

  // ─── itemIsVisible – permission-gated visibility ───────────────────────────
  // itemIsVisible is private; we exercise it via the public groupCheckedCount()
  // and groupHasSomeChecked() methods so the tests remain black-box.
  describe('itemIsVisible – permission checks via hasUserPermissions', () => {
    const REQUIRED_PERMISSION = [
      { resources: [{ scopes: ['GET'], resource: 'test_resource' }] },
    ];
    const MATCHING_USER_PERMISSION: PermissionModel[] = [
      { rsid: '1', rsname: 'test_resource', scopes: ['GET'] },
    ];

    it('should count a permission-gated item when the user holds the required permission', () => {
      authServiceMock.getUserPermissions.and.returnValue(
        of(MATCHING_USER_PERMISSION)
      );
      // Re-create the component so the new permission emission is picked up.
      fixture = TestBed.createComponent(CellSiteMapLayerComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();

      const group = mockGroup({
        items: [mockItem({ checked: true, permission: REQUIRED_PERMISSION })],
      });
      expect(component.groupCheckedCount(group)).toBe(1);
    });

    it('should not count a permission-gated item when the user lacks the required permission', () => {
      authServiceMock.getUserPermissions.and.returnValue(of([]));
      fixture = TestBed.createComponent(CellSiteMapLayerComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();

      const group = mockGroup({
        items: [mockItem({ checked: true, permission: REQUIRED_PERMISSION })],
      });
      expect(component.groupCheckedCount(group)).toBe(0);
    });

    it('should count an item with no permission requirement regardless of user permissions', () => {
      authServiceMock.getUserPermissions.and.returnValue(of([]));
      fixture = TestBed.createComponent(CellSiteMapLayerComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();

      const group = mockGroup({
        items: [mockItem({ checked: true })], // no permission field
      });
      expect(component.groupCheckedCount(group)).toBe(1);
    });

    it('groupHasSomeChecked should exclude permission-gated items the user cannot see', () => {
      authServiceMock.getUserPermissions.and.returnValue(of([]));
      fixture = TestBed.createComponent(CellSiteMapLayerComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();

      // One visible item (checked) + one permission-gated item (checked but invisible)
      const group = mockGroup({
        items: [
          mockItem({ checked: true }),
          mockItem({ checked: true, permission: REQUIRED_PERMISSION }),
        ],
      });
      // Only 1 visible item, and it is checked → all visible checked → not "some"
      expect(component.groupHasSomeChecked(group)).toBeFalse();
    });
  });

  describe('onLayerChange', () => {
    let leafletMapService: LeafletMapService;

    beforeEach(() => {
      leafletMapService = TestBed.inject(LeafletMapService);
      spyOn(leafletMapService, 'toggleControlLayer').and.stub();
    });

    it('should update item.checked to the given value', () => {
      const item = mockItem({ checked: false });
      const group = mockGroup({ items: [item] });
      component.onLayerChange(item, group, true);
      expect(item.checked).toBeTrue();
    });

    it('should set group.selectAll=true when all items become checked', () => {
      const items = [mockItem({ checked: true }), mockItem({ checked: false })];
      const group = mockGroup({ items });
      component.onLayerChange(items[1], group, true);
      expect(group.selectAll).toBeTrue();
    });

    it('should set group.selectAll=false when not all items are checked', () => {
      const items = [mockItem({ checked: true }), mockItem({ checked: true })];
      const group = mockGroup({ items, selectAll: true });
      component.onLayerChange(items[0], group, false);
      expect(group.selectAll).toBeFalse();
    });

    it('should call toggleControlLayer with the item key and new checked state', () => {
      const item = mockItem({ key: 'my-layer' });
      const group = mockGroup({ items: [item] });
      component.onLayerChange(item, group, true);
      expect(leafletMapService.toggleControlLayer).toHaveBeenCalledOnceWith(
        'my-layer',
        true,
        false
      );
    });

    // Delegating keeps the empty-filter message in sync with single items.
    it('should delegate the single change to the map service', () => {
      spyOn(leafletMapService, 'setLayerItemChecked').and.callThrough();
      const item = mockItem({ key: 'my-layer' });
      const group = mockGroup({ items: [item] });

      component.onLayerChange(item, group, false);

      expect(leafletMapService.setLayerItemChecked).toHaveBeenCalledOnceWith(
        item,
        false
      );
    });
  });
});
