/*
 * Copyright (c) 2025. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

// Interface for OPA properties

import {
  Component,
  DestroyRef,
  EventEmitter,
  HostListener,
  inject,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import { PolicySet, PropertiesPolicy } from '../../../../../openapi/output';
import {
  CAPACITY_POLICY_FILE,
  capacityPolicyTemplate,
  RAN_TEMPLATE_POLICY_FILE,
  RanPolicyPageData,
  ranPolicyTemplate,
  SFC_POLICY_FILE,
  sfcPolicyTemplate,
  CAPACITY_OFFSET_POLICY_FILE,
  capacityOffsetPolicyTemplate,
} from '../../../model/ran-policy.model';
import { deepEqual } from '../../../helpers/helpers';
import { RanPolicyService } from '../../../services/ran-policyservice/ran-policy.service';
import { EMPTY, Observable } from 'rxjs';
import { ModalConfirmationService } from '../../../services/common-functionalities/modal-confirmation.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { switchMap } from 'rxjs/operators';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-policy-set-management',
  templateUrl: './policy-set-management.component.html',
  styleUrl: './policy-set-management.component.css',
  standalone: false,
})
export class PolicySetManagementComponent implements OnInit {
  @Input({ required: true }) styleHeight: string | undefined;
  @Output() editPolicyId = new EventEmitter<number>();

  private readonly ranPolicyService = inject(RanPolicyService);
  private readonly confirmationService = inject(ModalConfirmationService);
  private readonly destroyRef = inject(DestroyRef);
  readonly permissions = inject(PERMISSIONS_TOKEN);

  protected readonly alertService = inject(TnapAlertService);
  modifiedPolicySet!: PolicySet;
  draftPolicySet!: PolicySet;
  selectedRowIndex: number | null = null;
  changedRowIndex$: Observable<boolean[]> =
    this.ranPolicyService.getChangedRowIndex();
  ranPolicyPageData: RanPolicyPageData | undefined;
  policyName: Observable<string> = this.ranPolicyService.getPolicyName();

  status$ = this.ranPolicyService.getPolicyName().pipe(
    switchMap(policyName => {
      if (!policyName) return EMPTY;
      return this.ranPolicyService.getPoliciesStatus(policyName);
    })
  );

  moveUp(index: number) {
    if (
      this.modifiedPolicySet?.properties &&
      Array.isArray(this.modifiedPolicySet.properties.policies)
    ) {
      if (index > 0) {
        [
          this.modifiedPolicySet.properties.policies[index - 1],
          this.modifiedPolicySet.properties.policies[index],
        ] = [
          this.modifiedPolicySet.properties.policies[index],
          this.modifiedPolicySet.properties.policies[index - 1],
        ];
        this.selectedRowIndex = index - 1;
        this.refreshChangedRowIndex();
      }
    }
  }

  moveDown(index: number) {
    if (
      this.modifiedPolicySet?.properties &&
      Array.isArray(this.modifiedPolicySet.properties.policies)
    ) {
      if (index < this.modifiedPolicySet.properties.policies.length - 1) {
        [
          this.modifiedPolicySet.properties.policies[index + 1],
          this.modifiedPolicySet.properties.policies[index],
        ] = [
          this.modifiedPolicySet.properties.policies[index],
          this.modifiedPolicySet.properties.policies[index + 1],
        ];
        this.selectedRowIndex = index + 1;
        this.refreshChangedRowIndex();
      }
    }
  }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    if (this.selectedRowIndex !== null) {
      if (event.key === 'ArrowUp') {
        this.moveUp(this.selectedRowIndex);
      } else if (event.key === 'ArrowDown') {
        this.moveDown(this.selectedRowIndex);
      }
    }
  }

  addPolicy() {
    this.ranPolicyService
      .getPolicyName()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(policyName => {
        let policyTemplate: PropertiesPolicy | undefined;
        if (policyName === CAPACITY_POLICY_FILE) {
          policyTemplate = structuredClone(capacityPolicyTemplate);
        } else if (policyName === SFC_POLICY_FILE) {
          policyTemplate = structuredClone(sfcPolicyTemplate);
        } else if (policyName === CAPACITY_OFFSET_POLICY_FILE) {
          policyTemplate = structuredClone(capacityOffsetPolicyTemplate);
        } else if (policyName === RAN_TEMPLATE_POLICY_FILE) {
          policyTemplate = structuredClone(ranPolicyTemplate);
        } else {
          return;
        }
        if (policyTemplate) {
          let newId: number | undefined;
          if (
            this.modifiedPolicySet.properties &&
            Array.isArray(this.modifiedPolicySet.properties.policies)
          ) {
            newId =
              this.modifiedPolicySet.properties.policies.push(policyTemplate) -
              1;
            this.refreshChangedRowIndex();
            this.ranPolicyService.updateAddedPolicyId(newId);

            this.ranPolicyService.updateEditPolicyId(newId);
            this.ranPolicyService.updateEditPolicy(true);
          }
        }
      });
  }

  editPolicy(id: number) {
    this.ranPolicyService.updateEditPolicyId(id);
    this.ranPolicyService.updateEditPolicy(true);
  }

  deletePolicy(i: number) {
    this.openDeleteModal()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((confirm: boolean) => {
        if (confirm) {
          if (
            this.modifiedPolicySet.properties &&
            Array.isArray(this.modifiedPolicySet.properties.policies)
          ) {
            this.modifiedPolicySet.properties.policies.splice(i, 1);
            this.refreshChangedRowIndex();
            this.ranPolicyService.updateChangedRowIndex(i, true);
          }
        }
      });
  }

  public ngOnInit(): void {
    this.ranPolicyService
      .getRanPolicyPageData()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(resp => {
        if (resp?.ranPolicy) {
          this.modifiedPolicySet = this.ranPolicyService.getPolicySets(
            resp.ranPolicy,
            'modified'
          ) as PolicySet;
          this.draftPolicySet = this.ranPolicyService.getPolicySets(
            resp.ranPolicy,
            'draft'
          ) as PolicySet;
        }
      });
  }

  private isPolicyChanged(
    modifiedPropertiesPolicy: PropertiesPolicy | undefined,
    i: number
  ) {
    let draftPropertiesPolicy: PropertiesPolicy | undefined = undefined;
    if (
      this.draftPolicySet?.properties &&
      Array.isArray(this.draftPolicySet.properties.policies)
    ) {
      draftPropertiesPolicy = this.draftPolicySet.properties.policies[i];
    }
    return !deepEqual(modifiedPropertiesPolicy, draftPropertiesPolicy);
  }

  private refreshChangedRowIndex() {
    // Update changed row index to show which policy has changed
    if (
      this.modifiedPolicySet?.properties &&
      Array.isArray(this.modifiedPolicySet.properties.policies)
    ) {
      for (const [
        index,
        item,
      ] of this.modifiedPolicySet.properties.policies.entries()) {
        this.ranPolicyService.updateChangedRowIndex(
          index,
          this.isPolicyChanged(item, index)
        );
      }

      // Get latest RanPolicyPageData from Observable
      this.ranPolicyService
        .updatePolicyPageData(
          'policies',
          this.modifiedPolicySet.properties.policies
        )
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe();
    }
  }

  openDeleteModal() {
    return this.confirmationService.openConfirmationModal(
      'common.buttons.yes',
      'ranTemplate.policySetManagement.modal.delete.title',
      'ranTemplate.policySetManagement.modal.delete.text'
    );
  }

  drop(event: CdkDragDrop<PropertiesPolicy, any>) {
    if (this.modifiedPolicySet?.properties?.policies) {
      moveItemInArray(
        this.modifiedPolicySet.properties.policies,
        event.previousIndex,
        event.currentIndex
      );
      this.selectedRowIndex = event.currentIndex;
      this.refreshChangedRowIndex();
    }
  }

  selectRow(index: number): void {
    if (this.selectedRowIndex === index) {
      this.selectedRowIndex = null;
    } else {
      this.selectedRowIndex = index;
    }
  }

  onRowKeyDown(event: KeyboardEvent, index: number) {
    if (event.key === 'Enter' || event.key === ' ') {
      this.selectRow(index);
    }
  }

  protected readonly RAN_TEMPLATE_POLICY_FILE = RAN_TEMPLATE_POLICY_FILE;
}
