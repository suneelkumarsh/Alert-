/*
 * Copyright (c) 2024. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Component,
  DestroyRef,
  inject,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
} from '@angular/core';
import { RanTemplateService } from '../../../services/ran-templateservice/ran-template.service';
import { RanPolicyService } from '../../../services/ran-policyservice/ran-policy.service';
import { Draft } from '../../../../../openapi/output';
import {
  RanPolicyModel,
  RanPolicyValidationResponse,
  RanPolicyValidationSuccessResponse,
  RanPolicyValidationDetailsResponse,
} from '../../../model/ran-policy.model';
import { TranslateService } from '@ngx-translate/core';
import { ModalConfirmationService } from '../../../services/common-functionalities/modal-confirmation.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import {
  BranchTabDiffEditor,
  BranchTabDraftEditor,
  BranchTabMainEditor,
  BranchTabPolicyEditor,
  BranchTabsModel,
} from '../../../model/branch-tabs.model';
import { filter, map, switchMap, take } from 'rxjs/operators';
import { EMPTY, combineLatest } from 'rxjs';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-ran-policy',
  templateUrl: './ran-policy.component.html',
  styleUrl: './ran-policy.component.css',
  standalone: false,
})
export class RanPolicyComponent implements OnDestroy, OnChanges, OnInit {
  @Input({ required: true }) policyName!: string;

  private readonly ranTemplateService = inject(RanTemplateService);
  private readonly ranPolicyService = inject(RanPolicyService);
  readonly permissions = inject(PERMISSIONS_TOKEN);

  gitLabDraftUrl: string | undefined;
  gitLabMainUrl: string | undefined;

  title: string | undefined = undefined;
  isRanPolicyChanged = this.ranPolicyService.getChangedRowIndex().pipe(
    map(item => item.includes(true)),
    map(item => !item)
  );
  ranPolicySaved = false;

  data$ = this.ranPolicyService.getRanPolicyPageData();
  policyValidationResponse: RanPolicyValidationDetailsResponse | undefined;
  editPolicy$ = this.ranPolicyService.getEditPolicy();

  branchTabs: BranchTabsModel[] = [
    BranchTabPolicyEditor,
    BranchTabDraftEditor,
    BranchTabDiffEditor,
    BranchTabMainEditor,
  ];

  constructor(
    private readonly alertService: TnapAlertService,
    private readonly translateService: TranslateService,
    private readonly confirmationService: ModalConfirmationService,
    private readonly destroyRef: DestroyRef
  ) {
    this.initialLoadData();
  }

  hasDraftDelta(policyFile: RanPolicyModel) {
    return (
      this.ranTemplateService.normalizeContent(policyFile.mainContent) !==
      this.ranTemplateService.normalizeContent(policyFile.draftContent)
    );
  }

  public deploy(policyFile: RanPolicyModel, draftName: string | undefined) {
    this.ranPolicyService
      .deployPolicy(policyFile, draftName)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(response => {
        this.validateSaveResponse(response);

        if (
          this.isSuccessResponse(response) &&
          !this.ranPolicyService.policyIsValid(response)
        ) {
          this.alertService.error(
            this.translateService.instant('ranTemplate.message.error.deploy')
          );
        } else {
          this.alertService.success(
            this.translateService.instant('ranTemplate.message.success.deploy')
          );
        }
      });
  }

  public save(draftName: string | undefined) {
    this.ranPolicyService
      .getRanPolicyPageData()
      .pipe(
        take(1),
        switchMap(ranPolicyPageData => {
          if (ranPolicyPageData) {
            return this.ranPolicyService.savePolicy(
              ranPolicyPageData.ranPolicy,
              draftName
            );
          }
          return EMPTY;
        })
      )
      .subscribe(response => {
        this.validateSaveResponse(response);
      });
  }

  private validateSaveResponse(response: RanPolicyValidationResponse) {
    // First clear old validation messages
    this.policyValidationResponse = undefined;

    if (this.isSuccessResponse(response)) {
      // show success or save error
      if (response.draft?.name == '') {
        this.alertService.warn(
          this.translateService.instant(
            'ranTemplate.message.error.constrainViolation'
          )
        );
      } else {
        this.alertService.success(
          this.translateService.instant('ranTemplate.message.success.save')
        );
        // refresh data
        this.ranPolicyService.updateDraftBranches(response.draft);
      }

      // prepare validation message only if message is available. Test here simplifies the html template page
      if (
        response?.policyValidation.failureReason &&
        response.policyValidation.failureReason.length >= 1
      ) {
        this.policyValidationResponse = {
          status: response.policyValidation.status,
          reasons: this.getValidationResponseAsArray(
            response.policyValidation.failureReason
          ),
        };
      }

      // show alert if validation was failure
      if (!this.ranPolicyService.policyIsValid(response)) {
        this.alertService.error(
          this.translateService.instant(
            'ranTemplate.policies.message.error.validation'
          )
        );
      }
    }
  }

  public cancel() {
    this.openCancelModal()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((confirm: boolean) => {
        if (confirm) {
          this.initialLoadData();
          this.alertService.success(
            this.translateService.instant('ranTemplate.message.success.reset')
          );
        }
      });
  }

  public deleteBranch(draftName: string | undefined) {
    if (draftName) {
      this.openDeleteBranchModal()
        .pipe(
          filter(confirm => confirm),
          switchMap(() => this.ranPolicyService.deletePolicyBranch(draftName)),
          takeUntilDestroyed(this.destroyRef)
        )
        .subscribe(() => {
          // reset draft branch triggers reload data
          this.updateDraftBranch({ name: '', isDefault: false } as Draft);
          // last validation message
          this.policyValidationResponse = undefined;
          this.alertService.success(
            this.translateService.instant(
              'ranTemplate.message.success.deleteBranch'
            )
          );
        });
    }
  }

  openCancelModal() {
    return this.confirmationService.openConfirmationModal(
      'common.buttons.yes',
      'ranTemplate.modal.cancel.title',
      'ranTemplate.modal.cancel.text'
    );
  }

  openDeleteBranchModal() {
    return this.confirmationService.openConfirmationModal(
      'common.buttons.yes',
      'ranTemplate.modal.deleteBranch.title',
      'ranTemplate.modal.deleteBranch.text'
    );
  }

  private initialLoadData() {
    this.ranPolicyService.initialRanPolicyPageData$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(item => {
        this.gitLabDraftUrl = item.draft?.url;
      });
  }

  public updateDraftBranch(newDraft: Draft | undefined) {
    this.ranPolicyService.updateDraftBranches(newDraft);
  }

  private isSuccessResponse(
    response: RanPolicyValidationResponse | undefined
  ): response is RanPolicyValidationSuccessResponse {
    return (
      (response as RanPolicyValidationSuccessResponse).policyValidation !==
      undefined
    );
  }

  private getValidationResponseAsArray(response: string | undefined) {
    if (response) {
      if (response.startsWith('[') && response.endsWith(']')) {
        return response.substring(1, response.length - 1).split(',');
      }
      return [response];
    }
    return [];
  }

  public ngOnInit() {
    combineLatest([
      this.ranPolicyService.getPolicyDrafts$,
      this.ranPolicyService.getDefaultBranch$,
    ])
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(([draftList, defaultBranchName]) => {
        // Get branch URL's
        this.gitLabMainUrl = this.ranTemplateService.getBranchUrl(
          defaultBranchName,
          draftList.items
        );
        this.gitLabDraftUrl = this.ranTemplateService.getBranchUrl(
          this.policyName,
          draftList.items
        );

        // Get draft branch name for the specific file
        const draftBranch = this.ranTemplateService.getBranch(
          this.policyName,
          draftList.items
        );
        this.ranPolicyService.updateDraftBranches(draftBranch);
      });
  }

  public ngOnDestroy(): void {
    this.ranPolicyService.updateEditPolicy(false);
  }

  public ngOnChanges(changes: SimpleChanges): void {
    const changedValue: string = changes?.policyName.currentValue;
    this.title = changedValue.replace(/(-policy)?(-opa)?(\.yml)?$/gi, '');
    this.ranPolicyService.policyName$.next(changedValue);
  }
}
