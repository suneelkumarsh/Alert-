/*
 * Copyright (c) 2024. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RanPolicyComponent } from './ran-policy.component';
import { RanTemplateService } from '../../../services/ran-templateservice/ran-template.service';
import { RanPolicyService } from '../../../services/ran-policyservice/ran-policy.service';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { ModalConfirmationService } from '../../../services/common-functionalities/modal-confirmation.service';
import { of, BehaviorSubject } from 'rxjs';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {
  provideHttpClient,
  withInterceptorsFromDi,
} from '@angular/common/http';
import { NgbNavModule } from '@ng-bootstrap/ng-bootstrap';
import { Draft, DraftList } from '../../../../../openapi/output';
import { PERMISSIONS_TOKEN } from 'src/app/permissions.config';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

describe('RanPolicyComponent', () => {
  let component: RanPolicyComponent;
  let fixture: ComponentFixture<RanPolicyComponent>;
  let mockRanTemplateService: jasmine.SpyObj<RanTemplateService>;
  let mockRanPolicyService: jasmine.SpyObj<RanPolicyService>;
  let mockAlertService: jasmine.SpyObj<TnapAlertService>;
  let mockTranslateService: jasmine.SpyObj<TranslateService>;
  let mockConfirmationService: jasmine.SpyObj<ModalConfirmationService>;

  beforeEach(() => {
    mockRanTemplateService = jasmine.createSpyObj('RanTemplateService', [
      'getBranch',
      'normalizeContent',
      'getBranchUrl',
    ]);
    mockRanTemplateService.getBranchUrl.and.returnValue('http://test-url');
    mockRanPolicyService = jasmine.createSpyObj(
      'RanPolicyService',
      [
        'getEditPolicy',
        'getChangedRowIndex',
        'getRanPolicyPageData',
        'deployPolicy',
        'savePolicy',
        'updateDraftBranches',
        'policyIsValid',
        'updateEditPolicy',
      ],
      {
        initialRanPolicyPageData$: of({}),
        draftBranchName$: of([{ name: 'draftName', isDefault: false }]),
        getPolicyDrafts$: of({ items: [], totalCount: 0 } as DraftList),
        getDefaultBranch$: of('main'),
      }
    );

    mockRanPolicyService.getChangedRowIndex.and.returnValue(
      of([false, false, true])
    );
    mockRanPolicyService.getEditPolicy.and.returnValue(of(true));
    mockAlertService = jasmine.createSpyObj('TnapAlertService', [
      'success',
      'error',
    ]);
    mockTranslateService = jasmine.createSpyObj('TranslateService', [
      'instant',
    ]);
    mockConfirmationService = jasmine.createSpyObj('ModalConfirmationService', [
      'openConfirmationModal',
    ]);

    const mockActivatedRouteService = {
      queryParams: of({
        templateSet: 'Ericsson_2024_Q1',
        ref: 'f1de722d-9fad-46c0-8bc0-ab9a905ea053_Ericsson_2024_Q1',
        activeBranchTabIndex: 'draft',
      }),
    };

    TestBed.configureTestingModule({
      declarations: [RanPolicyComponent],
      schemas: [NO_ERRORS_SCHEMA],
      imports: [NgbNavModule, TranslateModule.forRoot()],
      providers: [
        { provide: RanTemplateService, useValue: mockRanTemplateService },
        { provide: RanPolicyService, useValue: mockRanPolicyService },
        { provide: TnapAlertService, useValue: mockAlertService },
        { provide: TranslateService, useValue: mockTranslateService },
        {
          provide: ModalConfirmationService,
          useValue: mockConfirmationService,
        },
        { provide: ActivatedRoute, useValue: mockActivatedRouteService },
        provideHttpClient(withInterceptorsFromDi()),
        { provide: PERMISSIONS_TOKEN, useValue: [] },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(RanPolicyComponent);
    component = fixture.componentInstance;

    mockRanPolicyService.getChangedRowIndex.and.returnValue(of([false]));
    mockRanPolicyService.getRanPolicyPageData.and.returnValue(
      of({
        ranPolicy: {
          name: 'capacity-check-policy.yml',
          nodePath: 'capacity-check-policy.yml',
          mainContent:
            'tosca_definitions_version: tosca_simple_yaml_1_1_0\ntopology_template:\n  inputs: {}\n  policies:\n  - tnap.policy.slice.capacity.check.set:\n      type: onap.policies.native.ToscaXacml\n      type_version: 1.0.0\n      properties:\n        policies:\n        - properties:\n            description: Test Uli 18 Policy which checks if the capacity threshold in a cell is crossed for slicing test\n            target:\n              anyOne:\n              - allOf:\n                - key: sliceData.sliceOrder.pLMNInfoList.sst\n                  value: 1\n                  operator: integer-equal\n            rules:\n            - description: Rule to check threshold of both upload and download capacity\n              condition:\n                apply:\n                  keys:\n                  - apply:\n                      operator: integer-greater-than\n                      keys:\n                      - sliceData.sliceOrder.cells.cellTotalResourceUsageUl\n                      compareWith:\n                        value: 30\n                  - apply:\n                      operator: integer-greater-than\n                      keys:\n                      - sliceData.sliceOrder.cells.cellTotalResourceUsageDl\n                      compareWith:\n                        value: 30\n                  operator: or\n              decision: Deny\n              advice:\n                value: "{\\"upload\\": 30, \\"download\\": 30}"\n            default: Permit\n          metadata:\n            policy-id: tnap.policy.slice.capacity.check.sst.1\n            policy-version: 2.0.0\n            description: "This policy checks if the slice threshold capacity of a cell is crossed, and if so denies the request"\n      name: tnap.policy.slice.capacity.check.set\n      version: 6.0.14\n      metadata:\n        action: capacity-check-policy\n        description: "This qpolicy checks if the slice threshold capacity of a cell is crossed, and if so denies the request"\n        policy-id: tnap.policy.slice.capacity.check.set\n        policy-version: 6.0.14\nname: ToscaServiceTemplateSimple\nversion: 1.0.0',
          mainJsonContent: {
            tosca_definitions_version: 'tosca_simple_yaml_1_1_0',
            topology_template: {
              inputs: {},
              policies: [
                {
                  'tnap.policy.slice.capacity.check.set': {
                    type: 'onap.policies.native.ToscaXacml',
                    type_version: '1.0.0',
                    properties: {
                      policies: [
                        {
                          properties: {
                            description:
                              'Test Uli 18 Policy which checks if the capacity threshold in a cell is crossed for slicing test',
                            target: {
                              anyOne: [
                                {
                                  allOf: [
                                    {
                                      key: 'sliceData.sliceOrder.pLMNInfoList.sst',
                                      value: 1,
                                      operator: 'integer-equal',
                                    },
                                  ],
                                },
                              ],
                            },
                            rules: [
                              {
                                description:
                                  'Rule to check threshold of both upload and download capacity',
                                condition: {
                                  apply: {
                                    keys: [
                                      {
                                        apply: {
                                          operator: 'integer-greater-than',
                                          keys: [
                                            'sliceData.sliceOrder.cells.cellTotalResourceUsageUl',
                                          ],
                                          compareWith: {
                                            value: 30,
                                          },
                                        },
                                      },
                                      {
                                        apply: {
                                          operator: 'integer-greater-than',
                                          keys: [
                                            'sliceData.sliceOrder.cells.cellTotalResourceUsageDl',
                                          ],
                                          compareWith: {
                                            value: 30,
                                          },
                                        },
                                      },
                                    ],
                                    operator: 'or',
                                  },
                                },
                                decision: 'Deny',
                                advice: {
                                  value: '{"upload": 30, "download": 30}',
                                },
                              },
                            ],
                            default: 'Permit',
                          },
                          metadata: {
                            'policy-id':
                              'tnap.policy.slice.capacity.check.sst.1',
                            'policy-version': '2.0.0',
                            description:
                              'This policy checks if the slice threshold capacity of a cell is crossed, and if so denies the request',
                          },
                        },
                      ],
                    },
                    name: 'tnap.policy.slice.capacity.check.set',
                    version: '6.0.14',
                    metadata: {
                      action: 'capacity-check-policy',
                      description:
                        'This qpolicy checks if the slice threshold capacity of a cell is crossed, and if so denies the request',
                      'policy-id': 'tnap.policy.slice.capacity.check.set',
                      'policy-version': '6.0.14',
                    },
                  },
                },
              ],
            },
            name: 'ToscaServiceTemplateSimple',
            version: '1.0.0',
          },
          draftContent:
            'tosca_definitions_version: tosca_simple_yaml_1_1_0\ntopology_template:\n  inputs: {}\n  policies:\n  - tnap.policy.slice.capacity.check.set:\n      type: onap.policies.native.ToscaXacml\n      type_version: 1.0.0\n      properties:\n        policies:\n        - properties:\n            description: Test Uli 18 Policy which checks if the capacity threshold in a cell is crossed for slicing test\n            target:\n              anyOne:\n              - allOf:\n                - key: sliceData.sliceOrder.pLMNInfoList.sst\n                  value: 1\n                  operator: integer-equal\n            rules:\n            - description: Rule to check threshold of both upload and download capacity\n              condition:\n                apply:\n                  keys:\n                  - apply:\n                      operator: integer-greater-than\n                      keys:\n                      - sliceData.sliceOrder.cells.cellTotalResourceUsageUl\n                      compareWith:\n                        value: 30\n                  - apply:\n                      operator: integer-greater-than\n                      keys:\n                      - sliceData.sliceOrder.cells.cellTotalResourceUsageDl\n                      compareWith:\n                        value: 30\n                  operator: or\n              decision: Deny\n              advice:\n                value: "{\\"upload\\": 30, \\"download\\": 30}"\n            default: Permit\n          metadata:\n            policy-id: tnap.policy.slice.capacity.check.sst.1\n            policy-version: 2.0.0\n            description: "This policy checks if the slice threshold capacity of a cell is crossed, and if so denies the request"\n        - properties:\n            description: test2 capacity policy\n            target:\n              anyOne:\n              - allOf: []\n            rules:\n            - description: ""\n              decision: Permit\n          metadata:\n            policy-id: test2\n            policy-version: 0.1.0\n      name: tnap.policy.slice.capacity.check.set\n      version: 6.0.14\n      metadata:\n        action: capacity-check-policy\n        description: "This qpolicy checks if the slice threshold capacity of a cell is crossed, and if so denies the request"\n        policy-id: tnap.policy.slice.capacity.check.set\n        policy-version: 6.0.14\nname: ToscaServiceTemplateSimple\nversion: 1.0.0',
          draftJsonContent: {
            tosca_definitions_version: 'tosca_simple_yaml_1_1_0',
            topology_template: {
              inputs: {},
              policies: [
                {
                  'tnap.policy.slice.capacity.check.set': {
                    type: 'onap.policies.native.ToscaXacml',
                    type_version: '1.0.0',
                    properties: {
                      policies: [
                        {
                          properties: {
                            description:
                              'Test Uli 18 Policy which checks if the capacity threshold in a cell is crossed for slicing test',
                            target: {
                              anyOne: [
                                {
                                  allOf: [
                                    {
                                      key: 'sliceData.sliceOrder.pLMNInfoList.sst',
                                      value: 1,
                                      operator: 'integer-equal',
                                    },
                                  ],
                                },
                              ],
                            },
                            rules: [
                              {
                                description:
                                  'Rule to check threshold of both upload and download capacity',
                                condition: {
                                  apply: {
                                    keys: [
                                      {
                                        apply: {
                                          operator: 'integer-greater-than',
                                          keys: [
                                            'sliceData.sliceOrder.cells.cellTotalResourceUsageUl',
                                          ],
                                          compareWith: {
                                            value: 30,
                                          },
                                        },
                                      },
                                      {
                                        apply: {
                                          operator: 'integer-greater-than',
                                          keys: [
                                            'sliceData.sliceOrder.cells.cellTotalResourceUsageDl',
                                          ],
                                          compareWith: {
                                            value: 30,
                                          },
                                        },
                                      },
                                    ],
                                    operator: 'or',
                                  },
                                },
                                decision: 'Deny',
                                advice: {
                                  value: '{"upload": 30, "download": 30}',
                                },
                              },
                            ],
                            default: 'Permit',
                          },
                          metadata: {
                            'policy-id':
                              'tnap.policy.slice.capacity.check.sst.1',
                            'policy-version': '2.0.0',
                            description:
                              'This policy checks if the slice threshold capacity of a cell is crossed, and if so denies the request',
                          },
                        },
                        {
                          properties: {
                            description: 'test2 capacity policy',
                            target: {
                              anyOne: [
                                {
                                  allOf: [],
                                },
                              ],
                            },
                            rules: [
                              {
                                description: '',
                                decision: 'Permit',
                              },
                            ],
                          },
                          metadata: {
                            'policy-id': 'test2',
                            'policy-version': '0.1.0',
                          },
                        },
                      ],
                    },
                    name: 'tnap.policy.slice.capacity.check.set',
                    version: '6.0.14',
                    metadata: {
                      action: 'capacity-check-policy',
                      description:
                        'This qpolicy checks if the slice threshold capacity of a cell is crossed, and if so denies the request',
                      'policy-id': 'tnap.policy.slice.capacity.check.set',
                      'policy-version': '6.0.14',
                    },
                  },
                },
              ],
            },
            name: 'ToscaServiceTemplateSimple',
            version: '1.0.0',
          },
          modifiedContent:
            'tosca_definitions_version: tosca_simple_yaml_1_1_0\ntopology_template:\n  inputs: {}\n  policies:\n  - tnap.policy.slice.capacity.check.set:\n      type: onap.policies.native.ToscaXacml\n      type_version: 1.0.0\n      properties:\n        policies:\n        - properties:\n            description: Test Uli 18 Policy which checks if the capacity threshold in a cell is crossed for slicing test\n            target:\n              anyOne:\n              - allOf:\n                - key: sliceData.sliceOrder.pLMNInfoList.sst\n                  value: 1\n                  operator: integer-equal\n            rules:\n            - description: Rule to check threshold of both upload and download capacity\n              condition:\n                apply:\n                  keys:\n                  - apply:\n                      operator: integer-greater-than\n                      keys:\n                      - sliceData.sliceOrder.cells.cellTotalResourceUsageUl\n                      compareWith:\n                        value: 30\n                  - apply:\n                      operator: integer-greater-than\n                      keys:\n                      - sliceData.sliceOrder.cells.cellTotalResourceUsageDl\n                      compareWith:\n                        value: 30\n                  operator: or\n              decision: Deny\n              advice:\n                value: "{\\"upload\\": 30, \\"download\\": 30}"\n            default: Permit\n          metadata:\n            policy-id: tnap.policy.slice.capacity.check.sst.1\n            policy-version: 2.0.0\n            description: "This policy checks if the slice threshold capacity of a cell is crossed, and if so denies the request"\n        - properties:\n            description: test2 capacity policy\n            target:\n              anyOne:\n              - allOf: []\n            rules:\n            - description: ""\n              decision: Permit\n          metadata:\n            policy-id: test2\n            policy-version: 0.1.0\n      name: tnap.policy.slice.capacity.check.set\n      version: 6.0.14\n      metadata:\n        action: capacity-check-policy\n        description: "This qpolicy checks if the slice threshold capacity of a cell is crossed, and if so denies the request"\n        policy-id: tnap.policy.slice.capacity.check.set\n        policy-version: 6.0.14\nname: ToscaServiceTemplateSimple\nversion: 1.0.0',
          modifiedJsonContent: {
            tosca_definitions_version: 'tosca_simple_yaml_1_1_0',
            topology_template: {
              inputs: {},
              policies: [
                {
                  'tnap.policy.slice.capacity.check.set': {
                    type: 'onap.policies.native.ToscaXacml',
                    type_version: '1.0.0',
                    properties: {
                      policies: [
                        {
                          properties: {
                            description:
                              'Test Uli 18 Policy which checks if the capacity threshold in a cell is crossed for slicing test',
                            target: {
                              anyOne: [
                                {
                                  allOf: [
                                    {
                                      key: 'sliceData.sliceOrder.pLMNInfoList.sst',
                                      value: 1,
                                      operator: 'integer-equal',
                                    },
                                  ],
                                },
                              ],
                            },
                            rules: [
                              {
                                description:
                                  'Rule to check threshold of both upload and download capacity',
                                condition: {
                                  apply: {
                                    keys: [
                                      {
                                        apply: {
                                          operator: 'integer-greater-than',
                                          keys: [
                                            'sliceData.sliceOrder.cells.cellTotalResourceUsageUl',
                                          ],
                                          compareWith: {
                                            value: 30,
                                          },
                                        },
                                      },
                                      {
                                        apply: {
                                          operator: 'integer-greater-than',
                                          keys: [
                                            'sliceData.sliceOrder.cells.cellTotalResourceUsageDl',
                                          ],
                                          compareWith: {
                                            value: 30,
                                          },
                                        },
                                      },
                                    ],
                                    operator: 'or',
                                  },
                                },
                                decision: 'Deny',
                                advice: {
                                  value: '{"upload": 30, "download": 30}',
                                },
                              },
                            ],
                            default: 'Permit',
                          },
                          metadata: {
                            'policy-id':
                              'tnap.policy.slice.capacity.check.sst.1',
                            'policy-version': '2.0.0',
                            description:
                              'This policy checks if the slice threshold capacity of a cell is crossed, and if so denies the request',
                          },
                        },
                        {
                          properties: {
                            description: 'test2 capacity policy',
                            target: {
                              anyOne: [
                                {
                                  allOf: [],
                                },
                              ],
                            },
                            rules: [
                              {
                                description: '',
                                decision: 'Permit',
                              },
                            ],
                          },
                          metadata: {
                            'policy-id': 'test2',
                            'policy-version': '0.1.0',
                          },
                        },
                      ],
                    },
                    name: 'tnap.policy.slice.capacity.check.set',
                    version: '6.0.14',
                    metadata: {
                      action: 'capacity-check-policy',
                      description:
                        'This qpolicy checks if the slice threshold capacity of a cell is crossed, and if so denies the request',
                      'policy-id': 'tnap.policy.slice.capacity.check.set',
                      'policy-version': '6.0.14',
                    },
                  },
                },
              ],
            },
            name: 'ToscaServiceTemplateSimple',
            version: '1.0.0',
          },
        },
        draft: {
          name: 'f1de722d-9fad-46c0-8bc0-ab9a905ea053_capacity-check-policy',
          url: 'http://localhost:8080',
          isDefault: false,
        } as Draft,
      })
    );
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should handle policy name changes', () => {
    const changes = { policyName: { currentValue: 'Test-Policy' } };

    const policyNameSubject = new BehaviorSubject<string>('');
    mockRanPolicyService.policyName$ = policyNameSubject;
    spyOn(policyNameSubject, 'next');

    component.ngOnChanges(changes as any);
    expect(component.title).toBe('Test');
    expect(mockRanPolicyService.policyName$.next).toHaveBeenCalledWith(
      'Test-Policy'
    );
  });

  it('should deploy a policy and show success', () => {
    const policyFile = { mainContent: '', draftContent: '' };
    mockRanPolicyService.deployPolicy.and.returnValue(
      of({
        policyValidation: { status: 'SUCCESS' },
        draft: {
          name: 'draftName',
          url: 'http://localhost:8080',
          isDefault: false,
        },
      })
    );

    component.deploy(policyFile as any, 'draftName');
    expect(mockAlertService.success).toHaveBeenCalled();
  });

  it('should save a policy', () => {
    mockRanPolicyService.savePolicy.and.returnValue(
      of({
        policyValidation: { status: 'SUCCESS' },
        draft: {
          name: 'draftName',
          url: 'http://localhost:8080',
          isDefault: false,
        },
      })
    );

    component.save('draftName');
    expect(mockAlertService.success).toHaveBeenCalled();
  });

  it('should reset and show success', () => {
    mockConfirmationService.openConfirmationModal.and.returnValue(of(true));

    component.cancel();
    expect(mockAlertService.success).toHaveBeenCalled();
  });

  it('should open reset modal', () => {
    component.openCancelModal();
    expect(mockConfirmationService.openConfirmationModal).toHaveBeenCalled();
  });
});
