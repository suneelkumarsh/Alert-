/*
 * Copyright (c) 2025. Deutsche Telekom AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Component,
  DestroyRef,
  inject,
  OnInit,
  input,
  viewChild,
  signal,
} from '@angular/core';
import {
  OpaPolicySet,
  OpaPolicySetProperties,
  PolicySet,
  PolicySetMetadata,
  PolicySetProperties,
  PropertiesPolicy,
} from '../../../../../openapi/output';
import {
  RAN_TEMPLATE_POLICY_FILE,
  RanPolicyPageData,
} from '../../../model/ran-policy.model';
import { RanPolicyService } from '../../../services/ran-policyservice/ran-policy.service';
import { CodeEditorService } from '../../../services/common-functionalities/code-editor.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { zip } from 'rxjs';
import { RanTemplateService } from '../../../services/ran-templateservice/ran-template.service';
import { RanTemplateFile } from '../../../model/ran-template.model';
import { isNotUndefined } from '../../../helpers/helpers';
import { filter, map } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { Extension } from '@codemirror/state';
import { NgModel } from '@angular/forms';
import { TnapAlertService } from '@portal-mfe/tnap-ui-kit/components/alert';

@Component({
  selector: 'app-policy-editor',
  templateUrl: './policy-editor.component.html',
  styleUrl: './policy-editor.component.css',
  standalone: false,
})
export class PolicyEditorComponent implements OnInit {
  styleHeight = input.required<string>();
  policyType = input<string>();
  language = 'json';
  private policyId: number | undefined;
  private originalPolicy: string | undefined;
  private originalName: string | undefined;
  private originalDescription: string | undefined;
  private originalTargetTemplate: string | undefined;
  protected modifiedPolicy: string | undefined;
  protected modifiedName: string | undefined;
  protected modifiedDescription: string | undefined;
  protected modifiedTargetTemplate: string | undefined;
  protected templateList: RanTemplateFile[] = [];
  protected policyJsonError: string[] = [];
  private propertiesPolicy: PropertiesPolicy | undefined;
  private propertiesPolicies: PropertiesPolicy[] | undefined;
  private ranPolicyPageData: RanPolicyPageData | undefined;
  protected policyFileName = '';
  protected readonly RAN_TEMPLATE_POLICY_FILE = RAN_TEMPLATE_POLICY_FILE;
  private readonly ranPolicyService = inject(RanPolicyService);
  private readonly ranTemplateService = inject(RanTemplateService);
  private readonly codeEditorService = inject(CodeEditorService);
  protected readonly alertService = inject(TnapAlertService);
  private readonly translateService = inject(TranslateService);
  editorTheme: Extension = this.codeEditorService.getEditorTheme();
  supportedLanguages = this.codeEditorService.getSupportedLanguages();
  private readonly destroyRef = inject(DestroyRef);
  protected extractedScriptFromYaml: string | undefined;
  protected policyTypeValue: string = '';
  protected handleMetaData!: PolicySetMetadata;
  protected modifiedPolicySet!: PolicySet;
  protected isEditMode = true;
  private readonly modifiedNameCtrl = viewChild<NgModel>('modifiedNameCtrl');
  protected readonly isNameInvalid = signal(false);
  /* Unified split-grid layout */
  leftPane = 75;
  unit: '%' | 'px' = '%';
  minWidth = 40;
  maxWidth = 85;
  step = 2;

  onDescriptionChange(description: string) {
    if (this.propertiesPolicy?.properties) {
      this.propertiesPolicy.properties.description = description;
      this.modifiedPolicy = this.getModifiedPolicyAsJson();
    }
  }

  onTemplateChange() {
    if (
      this.propertiesPolicy?.properties &&
      this.propertiesPolicy.properties.rules[0].advice
    ) {
      this.propertiesPolicy.properties.rules[0].advice.value = this
        .modifiedTargetTemplate as string;
      this.modifiedPolicy = this.getModifiedPolicyAsJson();
    }
  }

  onEditorChange(policyJson: string, props: OpaPolicySetProperties) {
    this.policyJsonError = [];
    const hasData = props.data && Object.keys(props.data).length > 0;
    const hasPolicy = props.policy && Object.keys(props.policy).length > 0;
    try {
      if (hasData || hasPolicy) {
        const policyObj = JSON.parse(policyJson);
        this.modifiedDescription = policyObj.description;
      }
    } catch (e) {
      if (e instanceof SyntaxError) {
        this.policyJsonError.push(e.message);
      }
    }
  }

  saveChanges() {
    if (!this.modifiedPolicy) return;
    this.savePolicyChanges();
  }

  private savePolicyChanges() {
    this.policyJsonError = [];

    try {
      const ranPolicy = this.ranPolicyPageData?.ranPolicy;
      if (!ranPolicy) return;

      const policySet = this.ranPolicyService.getPolicySets<
        PolicySet | OpaPolicySet
      >(ranPolicy, 'modified');

      if (!policySet?.properties) return;

      const isOpaPolicy = this.isOpaPolicySet(policySet.properties);
      if (isOpaPolicy) {
        this.saveOpaPolicy(policySet as OpaPolicySet);
      } else {
        this.saveStandardPolicy();
      }
    } catch (e) {
      if (e instanceof SyntaxError) {
        this.policyJsonError.push(e.message);
      }
    }
  }

  private saveOpaPolicy(policySet: OpaPolicySet) {
    const props = policySet.properties as OpaPolicySetProperties;

    if (this.policyId === 0 && props.data) {
      const dataKey = Object.keys(props.data)[0];
      props.data[dataKey] = this.modifiedPolicy!;
    } else if (props.policy) {
      const policyKey = Object.keys(props.policy)[0];
      props.policy[policyKey] = this.modifiedPolicy!;
    }

    if (policySet.metadata) {
      policySet.metadata['policy-id'] = this.modifiedName!;
    }
    policySet.name = this.modifiedName!;

    this.ranPolicyService
      .updatePolicyPageData('policy', [props])
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(success => this.handleSaveResponse(success));
  }

  private saveStandardPolicy() {
    const policy = this.propertiesPolicies?.[this.policyId!];
    if (!policy) return;

    policy.properties = JSON.parse(this.modifiedPolicy!);
    policy.metadata.policyId = this.modifiedName!;

    this.ranPolicyService
      .updatePolicyPageData('policies', this.propertiesPolicies!)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(success => this.handleSaveResponse(success));
  }

  private handleSaveResponse(success: boolean) {
    if (success) {
      this.ranPolicyService.updateEditPolicy(false);
      this.ranPolicyService.updateChangedRowIndex(this.policyId!, true);
      this.ranPolicyService.updateAddedPolicyId(undefined);
    } else {
      this.alertService.error(
        this.translateService.instant('ranTemplate.message.error.save'),
        { keepAfterRouteChange: true }
      );
    }
  }

  discardChanges() {
    zip(
      this.ranPolicyService.getAddedPolicyId().pipe(filter(isNotUndefined)),
      this.ranPolicyService.getEditPolicyId().pipe(filter(isNotUndefined))
    )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(([addedId, editId]) => {
        if (addedId == editId) {
          this.ranPolicyService.updateAddedPolicyId(undefined);
          this.propertiesPolicies?.splice(addedId, 1);
        }
      });

    this.ranPolicyService.updateEditPolicy(false);
  }

  resetChanges() {
    this.modifiedPolicy = this.originalPolicy;
    this.modifiedName = this.originalName!;
    this.modifiedDescription = this.originalDescription!;
    this.modifiedTargetTemplate = this.originalTargetTemplate;
    this.policyJsonError = [];
  }

  hasChanges(): boolean {
    if (this.policyJsonError.length >= 1) {
      return false;
    }
    return (
      this.modifiedPolicy !== this.originalPolicy ||
      this.modifiedName !== this.originalName ||
      this.modifiedDescription !== this.originalDescription
    );
  }

  ngOnInit(): void {
    this.modifiedNameCtrl()
      ?.control.valueChanges.pipe(
        map(() => this.modifiedNameCtrl()?.control.invalid)
      )
      .subscribe(invalid => {
        this.isNameInvalid.set(invalid ?? false);
      });

    zip(
      this.ranPolicyService.getRanPolicyPageData(),
      this.ranPolicyService.getEditPolicyId()
    )
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(([policyPageData, policyEditId]) => {
        this.policyId = policyEditId;
        this.ranPolicyPageData = policyPageData;

        const ranPolicy = policyPageData?.ranPolicy;
        const policyObj =
          ranPolicy?.mainJsonContent.topology_template.policies?.[
            this.policyId!
          ];
        if (policyObj) {
          const policyName = Object.keys(policyObj)[0];
          this.modifiedPolicySet = {
            ...policyObj[policyName],
            policyType: this.policyType(),
          } as PolicySet;
        }
        if (!ranPolicy) return;

        const policySet = this.ranPolicyService.getPolicySets<
          PolicySet | OpaPolicySet
        >(ranPolicy, 'modified');
        if (!policySet?.properties) return;

        this.modifiedName = policySet.name;
        this.modifiedNameCtrl()?.control.markAsDirty();
        this.modifiedNameCtrl()?.control.updateValueAndValidity();
        const isOpaPolicy = this.isOpaPolicySet(policySet.properties);

        if (isOpaPolicy) {
          if (typeof ranPolicy.modifiedContent === 'string') {
            const script = this.ranPolicyService.extractPolicyScript(
              ranPolicy.modifiedContent
            );
            if (script) {
              this.extractedScriptFromYaml = script;
            }
            const data = this.ranPolicyService.extractPolicyData(
              ranPolicy.modifiedContent
            );
            if (data && this.policyId === 0) {
              this.extractedScriptFromYaml = data;
            }
          }
          this.handleOpaPolicy(
            policySet.properties as OpaPolicySetProperties,
            policySet as OpaPolicySet
          );
        } else {
          this.handleStandardPolicy(
            policySet.properties as PolicySetProperties
          );
        }
      });
    this.ranPolicyService
      .getPolicyName()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(item => (this.policyFileName = item));
    this.ranTemplateService
      .getAllTemplates()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(items => (this.templateList = items));
  }

  private handleOpaPolicy(
    props: OpaPolicySetProperties,
    mData: OpaPolicySet
  ): void {
    // Metadata editability
    this.handleMetaData = mData.metadata as unknown as PolicySetMetadata;

    // Policy/data assignment
    const hasData = props.data && Object.keys(props.data).length > 0;
    const hasPolicy = props.policy && Object.keys(props.policy).length > 0;

    if (this.policyId === 0 && hasData) {
      const dataKey = Object.keys(props.data!)[0];
      const rawData = props.data![dataKey] ?? '{}';
      try {
        this.modifiedPolicy = JSON.stringify(JSON.parse(rawData), null, 2);
      } catch {
        this.modifiedPolicy = rawData;
      }
      this.modifiedDescription = this.translateService.instant(
        'ranTemplate.policySetManagement.list.fields.data'
      );
    } else if (hasPolicy) {
      const policyKey = Object.keys(props.policy!)[0];
      this.modifiedPolicy =
        this.extractedScriptFromYaml || props.policy![policyKey] || '';
      this.modifiedDescription = this.translateService.instant(
        'ranTemplate.policySetManagement.list.fields.script'
      );
    }
    this.originalPolicy = this.modifiedPolicy;
  }

  private handleStandardPolicy(props: PolicySetProperties): void {
    const policies = props.policies ?? [];
    if (this.policyId! < 0 || this.policyId! >= policies.length) return;

    this.propertiesPolicies = policies;
    this.propertiesPolicy = policies[this.policyId!];

    const { metadata, properties } = this.propertiesPolicy;
    if (!properties) return;

    const adviceValue = properties.rules?.[0]?.advice?.value ?? '';

    this.modifiedPolicy = this.getModifiedPolicyAsJson();
    this.originalPolicy = this.modifiedPolicy;

    this.originalName = metadata.policyId;
    this.originalDescription = properties.description;
    this.originalTargetTemplate = adviceValue;

    this.modifiedName = metadata.policyId;
    this.modifiedDescription = properties.description;
    this.modifiedTargetTemplate = adviceValue;
  }

  private isOpaPolicySet(props): boolean {
    return !!(props?.data || props?.policy);
  }

  private getModifiedPolicyAsJson() {
    if (this.propertiesPolicy?.properties) {
      return JSON.stringify(this.propertiesPolicy.properties, null, 2);
    }
    return '';
  }
}
